const authentication = require("../../middlewares/auth.js");

module.exports = app => {
    const auth = require("../../middlewares/auth");
    const users = require("../../controllers/automationControllers/users.controller.js");
  
    var router = require("express").Router();
  
    router.get("/get/:document", authentication, users.findAll);
  
    router.get("/edit/:document/:id", authentication, users.findOne);
  
    router.post("/register/:document", authentication, users.createUser);

    router.put("/update/:document/:id", authentication, users.updateUser);

    router.put("/delete/:document/:id", authentication, users.deleteUser);

    app.use('/users/',auth, router);
  };
  