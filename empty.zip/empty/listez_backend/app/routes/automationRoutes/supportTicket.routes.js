const authentication = require("../../middlewares/auth.js");

module.exports = app => {
    const auth = require("../../middlewares/auth");
    const support_ticket = require("../../controllers/automationControllers/supportTicket.controller.js");
  
    var router = require("express").Router();
  
    router.post("/save/:document", authentication, support_ticket.create);
  
    router.get("/get/:document", authentication, support_ticket.findAll);
  
    router.get("/edit/:document/:id", authentication, support_ticket.findOne);
  
    router.put("/update/:document/:id", authentication, support_ticket.update);
    
    router.put("/status_update/:document/:id", authentication, support_ticket.ticketStatusUpdate);
  
    router.put("/delete/:document/:id", authentication, support_ticket.delete);
  
    app.use('/support_ticket/',auth, router);
  };