const authentication = require("../../middlewares/auth.js");
const multer = require('multer')
const upload = multer({
  dest: 'uploads/',
  limits: {
    fileSize: 5242880
  },
  fileFilter(req, file, cb) {
    if (!file.originalname.match(/\.(jpg|jpeg|pdf|xlsx|png|ico)$/)) {
      return cb(new Error('Please upload a Image'))
    }
    cb(undefined, true)
  }
})

module.exports = app => {
    const auth = require("../../middlewares/auth");
    const business_settings = require("../../controllers/automationControllers/businessSettings.controller.js");
  
    var router = require("express").Router();
  
    router.post("/save/:document", authentication, business_settings.create);
  
    router.get("/get/:document", authentication, business_settings.findAll);
  
    router.get("/edit/:document/:id", authentication, business_settings.findOne);
  
    // router.put("/update/:document/:id", authentication, business_settings.update);
    router.put('/update/:document', authentication, upload.fields([
      { name: "site_favicon"},
      { name: "site_logo" },
    ]), function (req, res, next) {
      business_settings.update(req, res, next)
    });
  
    router.put("/delete/:document/:id", authentication, business_settings.delete);
  
    app.use(require('express').static('public'));
    app.use('/uploads', require('express').static('uploads'));
  
    app.use('/business_settings/',auth, router);
  };