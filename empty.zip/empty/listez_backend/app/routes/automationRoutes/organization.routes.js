const authentication = require("../../middlewares/auth.js");
const multer = require('multer')
const upload = multer({
  dest: 'uploads/',
  limits: {
    fileSize: 5242880
  },
  fileFilter(req, file, cb) {
    if (!file.originalname.match(/\.(jpg|jpeg|pdf|xlsx|png)$/)) {
      return cb(new Error('Please upload a Image'))
    }
    cb(undefined, true)
  }
})


module.exports = app => {
    const auth = require("../../middlewares/auth");
    const organization = require("../../controllers/automationControllers/organization.controller.js");
  
    var router = require("express").Router();
  
    // router.post("/save/:document", authentication, organization.create);
    router.post('/save/:document', authentication, upload.fields([
        { name: "logo", maxCount: 1 },
        { name: "water_mark", maxCount: 1 },
      ]), function (req, res, next) {
        organization.createOrg(req, res, next)
      });
    router.put('/update/:document/:id', authentication, upload.fields([
        { name: "logo", maxCount: 1 },
        { name: "water_mark", maxCount: 1 },
      ]), function (req, res, next) {
        organization.updateOrg(req, res, next)
      });
  
    router.get("/get/:document", authentication, organization.findAll);
  
    router.get("/edit/:document/:id", authentication, organization.findOne);
  
    // router.put("/update/:document/:id", authentication, organization.updateOrg);
  
    router.put("/delete/:document/:id", authentication, organization.delete);
    
    router.put("/approval_update/:document/:id", authentication, organization.updateApproval);

    router.get("/organization_dropdown/:document", authentication, organization.getOrgDropdown);

    router.put('/update_check/:document/:id', authentication, upload.fields([
      { name: "logo", maxCount: 1 },
      { name: "water_mark", maxCount: 1 },
    ]), function (req, res, next) {
      organization.updateOrgCheck(req, res, next)
    });
    
    app.use('/organization/',auth, router);
  };
  