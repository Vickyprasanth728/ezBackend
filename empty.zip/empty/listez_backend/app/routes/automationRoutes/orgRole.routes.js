module.exports = app => {
    const auth = require("../../middlewares/auth");
    const orgRoles = require("../../zOrganizationFile/orgController/orgRoles.controller.js");
  
    var router = require("express").Router();
  
    router.post("/save/:document", orgRoles.create);
  
    router.get("/get/:document", orgRoles.findAll);
  
    router.get("/edit/:document/:id", orgRoles.findOne);
  
    router.put("/update/:document/:id", orgRoles.update);
  
    router.put("/delete/:document/:id", orgRoles.delete);
  
    app.use('/orgRoles/',auth, router);
  };