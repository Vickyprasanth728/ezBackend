const authentication = require("../../middlewares/auth.js");

module.exports = app => {
    const auth = require("../../middlewares/auth");
    const settings = require("../../controllers/automationControllers/settings.controller.js");
  
    var router = require("express").Router();
  
    router.post("/save/:document", authentication, settings.create);
  
    router.get("/get/:document", authentication, settings.findAll);
  
    router.get("/edit/:document/:id", authentication, settings.findOne);
  
    router.put("/update/:document/:id", authentication, settings.update);
  
    router.put("/delete/:document/:id", authentication, settings.delete);
  
    app.use('/settings/',auth, router);
  };