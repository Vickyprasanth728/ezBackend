const db = require("../../models");
const Op = db.Sequelize.Op;

exports.create = async (req, res) => {
  try {
    const created_by = req.user.id
    console.log('created_by', created_by.id);

    const SubscriptionData = await db['subscription'].findOne({
      where: {status:1, subscription_name:`${req.body.subscription_name}`},
      attributes:['subscription_name']
    });
    const executives = SubscriptionData?.dataValues ? SubscriptionData?.dataValues.subscription_name : 0

    console.log("SubscriptionData", SubscriptionData);

    if (executives !== 0) {
      res.status(200).send({
        status:400,
        message: "Subscription Already Exists.",
      });
    } else {
    const data = await db['subscription'].create({
      subscription_name: req.body.subscription_name,
      amount: req.body.amount,
      no_of_days: req.body.no_of_days,
      status: req.body.status,
      created_by: created_by.id
    });
    var condition = {
      where:{
        status:1
      },
      order: [['id', 'DESC']], // ASC, DESC
      attributes:['id','subscription_name','amount','no_of_days','status']
    };
    const data1 = await db['subscription'].findAll(condition);

    res.status(200).send({
      status:200,
      message:'Success',
      output:data1
    });
  }} catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.findAll = async (req, res) => {
  try {
    var condition = {
      where:{
        status: {
          [Op.in]: [1,2]
        },
      },
      order: [['id', 'DESC']], // ASC, DESC
      attributes:['id','subscription_name','amount','no_of_days','status']
    };
    var offset = parseInt(req.query.offset);
    var limit = parseInt(req.query.limit);

    if (offset >= 0 && limit >= 0) {
      condition.offset = offset;
      condition.limit = limit;
    }

    const data = await db[req.params.document].findAll(condition);
    res.status(200).send({
      status:200,
      message:'Success',
      output:data
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.findOne = async (req, res) => {
  try {
    var condition = {
      where:{
        status:1
      },
      attributes:['id','subscription_name','amount','no_of_days','status']
    };
    const id = req.params.id;
    const data = await db[req.params.document].findByPk(id,condition);
    if (data) {
      res.status(200).send({
        status:200,
        message:'Success',
        output:data
        });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot find with id : ${id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.update = async (req, res) => {
  try {
    const id = req.params.id;
    const subscriptionID = await db['subscription'].findOne({
      where: {status:1, id: id},
    });
    const subscriptionData = subscriptionID?.dataValues ? subscriptionID?.dataValues.id : 0
    console.log("subscriptionData", subscriptionData);

    const subscriptionCheck = await db['subscription'].findOne({
      where: {
        id: {
          [Op.ne]: subscriptionData
        },
        status:1,
        subscription_name:`${req.body.subscription_name}`,
      },
      attributes:['subscription_name']
    });
    const checkData = subscriptionCheck?.dataValues ? subscriptionCheck?.dataValues.id : 0

    if (checkData !== 0) {
      res.status(200).send({
        status:400,
        message: "Subscription Already Exists.",
      });
    } else {
    const num = await db['subscription'].update(req.body, {
      where: { id: id },
    });
    var condition = {
      where:{
        status:1
      },
      order: [['id', 'DESC']], // ASC, DESC
      attributes:['id','subscription_name','amount','no_of_days','status']
    };
    const data1 = await db['subscription'].findAll(condition);

    if (num == 1) {
      res.status(200).send({
        status:200,
        message: "Updated successfully.",
        output:data1
      });
    } else {
      res.status(200).send({
        status:200,
        message: `Cannot update with id : ${id}.`
      });
    }
  }} catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.delete = async (req, res) => {
  const subscriptionData = {
    status: 0,
  }
  try {
    const id = req.params.id;
    const num = await db[req.params.document].update(subscriptionData,{
      where: { id: id },
    });

    var condition = {
      where:{
        status:1
      },
      order: [['id', 'DESC']], // ASC, DESC
      attributes:['id','subscription_name','amount','no_of_days','status']
    };
    var offset = parseInt(req.query.offset);
    var limit = parseInt(req.query.limit);

    if (offset >= 0 && limit >= 0) {
      condition.offset = offset;
      condition.limit = limit;
    }
    const data1 = await db['subscription'].findAll(condition);

    if (num == 1) {
      res.status(200).send({
        status:200,
        message: "Deleted successfully!",
        output:data1
      });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot delete with id : ${id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.updateSubscriptionStatus = async (req, res) => {
  try {
    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    const created_by = req.user.id
    console.log('created_by', created_by.id);

    const id = req.params.id;

    const data = {
      status: req.body.status,
    }

    const num = await db['subscription'].update(data, {
      where: { id: id },
    });
    if (num == 1) {
      
      res.status(200).send({
        status:200,
        message: "Updated successfully."
      });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot update with id : ${id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};

exports.getSubscriptionDropdown = async (req, res) => {
  try {
    const created_by = req.user.id
    console.log('created_by', created_by.id);
      let values = ['transaction_status']

      const dataFromSubscription = await db['subscription'].findAll({
        where :{status:1},
        attributes:['id','subscription_name','amount','no_of_days']
      });
      const dataFromOrganization = await db['organization'].findAll({
        where :{status:1},
        attributes:['id','organization_name']
      });
      // const dataFromTransaction = await Modelv1.getAllFromTransaction();
      // const dataFromPaymentGateway = await Modelv1.getAllFromPaymentGateway();

      const dataFromMasters = await  await db['masters'].findAll({values})
      let model4Datafetch = Object.values(JSON.parse(JSON.stringify(dataFromMasters)));
      const transaction_status = model4Datafetch.filter((obj) => obj.option_type == 'transaction_status');

      const combinedData = {
          subscription: dataFromSubscription,
          organization: dataFromOrganization,
          // transaction: [],
          // payment_gateway: [],
          // transaction_status: transaction_status,
      };
      res.status(200).send({
          message: "Subscription dropdown get data",
          status: 200,
          output: combinedData
      })

  }
  catch (error) {
      console.error(error);
      res.status(500).json({ message: 'Internal Server Error' });
  }
};