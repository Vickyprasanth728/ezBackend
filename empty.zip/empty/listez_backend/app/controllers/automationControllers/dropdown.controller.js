const db = require("../../models");
const Op = db.Sequelize.Op;

exports.getOrgDropdown = async (req, res) => {
    try {
      const created_by = req.user.id
      console.log('created_by', created_by.id);
        // let values = ['transaction_status']
  
        // const dataFromOrg = await Modelv1.getAllFromOrg();
        
        const dataFromCity = await  await db['city'].findAll({values})
        let model4Datafetch = Object.values(JSON.parse(JSON.stringify(dataFromMasters)));
        const transaction_status = model4Datafetch.filter((obj) => obj.option_type == 'transaction_status');
  
        const combinedData = {
            city: dataFromCity,
        };
        res.status(200).send({
            message: "Organization dropdown get data",
            status: 200,
            output: combinedData
        })
    }
    catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Internal Server Error' });
    }
};

exports.getSubscriptionDropdown = async (req, res) => {
    try {
      const created_by = req.user.id
      console.log('created_by', created_by.id);
        let values = ['transaction_status']
  
        const dataFromSubscription = await db['subscription'].findAll({
          where :{status:1},
          // attributes:['id','subscription_name','amount','no_of_days']
        });
        const dataFromOrganization = await db['organization'].findAll({
          where :{status:1},
          attributes:['id','organization_name']
        });
        // const dataFromTransaction = await Modelv1.getAllFromTransaction();
        // const dataFromPaymentGateway = await Modelv1.getAllFromPaymentGateway();
  
        const dataFromMasters = await  await db['masters'].findAll({values})
        let model4Datafetch = Object.values(JSON.parse(JSON.stringify(dataFromMasters)));
        const transaction_status = model4Datafetch.filter((obj) => obj.option_type == 'transaction_status');
  
        const combinedData = {
            subscription: dataFromSubscription,
            organization: dataFromOrganization,
            // transaction: [],
            // payment_gateway: [],
            // transaction_status: transaction_status,
        };
        res.status(200).send({
            message: "Subscription dropdown get data",
            status: 200,
            output: combinedData
        })
  
    }
    catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Internal Server Error' });
    }
};

// exports.getOrgDropdown = async (req, res) => {
//     try {
//       const created_by = req.user.id
//       console.log('created_by', created_by.id);
//         // let values = ['transaction_status']
  
//         // const dataFromOrg = await Modelv1.getAllFromOrg();
        
//         const dataFromCity = await  await db['city'].findAll({attributes:['id','country_id','state_id','name','status']});
//         const dataFromState = await  await db['state'].findAll({attributes:['id','country_id','name','status']});
//         const dataFromCountry = await  await db['state'].findAll({attributes:['id','name','status']});
//         const dataFromCurrency = await  await db['currency'].findAll({attributes:['id','name','symbol','status']});
//         // let model4Datafetch = Object.values(JSON.parse(JSON.stringify(dataFromMasters)));
//         // const transaction_status = model4Datafetch.filter((obj) => obj.option_type == 'transaction_status');
  
//         const combinedData = {
//             city: dataFromCity,
//             state: dataFromState,
//             country: dataFromCountry,
//             currency: dataFromCurrency,
//         };
//         res.status(200).send({
//             message: "Organization dropdown get data",
//             status: 200,
//             output: combinedData
//         })
  
//     }
//     catch (error) {
//         console.error(error);
//         res.status(500).json({ message: 'Internal Server Error' });
//     }
//   };