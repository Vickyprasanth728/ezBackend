const db = require("../../models");
const Op = db.Sequelize.Op;
const path = require("path");
const fs = require("fs");

exports.create = async (req, res) => {
  try {
    const created_by = req.user.id
    console.log('created_by', created_by.id);

    const data = await db[req.params.document].create({
      option_type: req.body.option_type,
      option_value: req.body.option_value,
      created_by: created_by.id
    });
    res.status(200).send({
      status:200,
      message:'Success',
      output:data
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.findAll = async (req, res) => {
  try {
 
    var condition = {
      where:{
        status:1
      },
      order: [['id', 'DESC']], // ASC, DESC
      attributes:['id','option_type','option_value']
    };
    var offset = parseInt(req.query.offset);
    var limit = parseInt(req.query.limit);

    if (offset >= 0 && limit >= 0) {
      condition.offset = offset;
      condition.limit = limit;
    }

    const data = await db[req.params.document].findAll(condition);
    const filters = req.query;
    const filteredUsers = data.filter(user => {
      let isValid = true;
      for (key in filters) {
        console.log(key, user[key], filters[key]);
        isValid = isValid && user[key] == filters[key];
      }
      return isValid;
    });

    const obj = data.reduce((acc, { option_type, option_value }) => {
      acc[option_type] = option_value;
      return acc;
      }, {});
  
    res.status(200).send({
      status:200,
      message:'Success',
      output:obj
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.findOne = async (req, res) => {
  try {
    // var condition = {
    //   where:{
    //     status:1
    //   },
    //   attributes:['id','option_type','option_value']
    // };

    const id = req.params.id;
    const data = await db[req.params.document].findByPk(id, {
      where: {
        [Op.and]: [
          { id: id },
          { status: 1 }
        ]
      },
      attributes:['id','option_type','option_value']
    }
      );
    if (data) {
      res.status(200).send({
        status:200,
        message:'Success',
        output:data
        });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot find with id : ${id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.update = async (req, res) => {
  try {
    // let { filename, mimetype, path: filePath } = req.file || {};
    // console.log('filenameeeeee',filename);
    // console.log("riuwrtg", mimetype);
    // console.log("rtyrytyrtyr", filePath);
    
    // const option_type = req.params.option_type;
    const option_type = req.body.option_type;
    const id = req.params.id;

    let option_value = "";
    if (req.files.option_value) {
      const extension = req.files.option_value[0]["mimetype"].split('/')[1]
      option_value = req.files.option_value[0]["filename"] + '.' + extension
    }
    var condition = {   
      option_type: req.body.option_type || null,
      option_value: option_value || req.body.option_value || null,
    }
    // const arr = Object.entries(condition);
    // // const arr = [req.body.option_type , req.body.option_value];
    // const hfiwyg = arr.map(element => {
    //   return element;
    // });
    // console.log('wwwwwwwwww',hfiwyg);
    // // const myArray = [[condition.option_type], [option_value]];
    // // const obj = req.body.reduce((acc, [option_type]) => (acc[option_type] = option_value, acc), {});

    // // console.log("obj : ", obj);
    // // console.log("myArray : ", myArray);
    // let jshhge = {};
    // hfiwyg.map((dfh, i) => {
    //   // { dfh[0]: dfh[1]}
    //   jshhge = {...jshhge, [dfh[0]] : dfh[1]}
    // })
    // console.log("wjehruwgrweg", jshhge)

    // for(let i=0; i< req.body.length)
    // req.body?.map(item => {})

    // let hwetfjegrre = req.files;
    
    // console.log("dfhskjdfgsd", hwetfjegrre);
    let herurug = req.files;

    for (const [key, value] of Object.entries(herurug)) {
      const extension = req.files[key][0]["mimetype"].split('/')[1];
      let lhrk = req.files[key][0]["filename"] + '.' + extension
      console.log("sfhur", value);

      const num = await db[req.params.document].update({ option_value : lhrk || null }, {
        where: { option_type: key || null},
      });

      const currentPath = path.join(process.cwd(), "uploads", req.files[key][0]["filename"]);
        const destinationPath = path.join(process.cwd(),"uploads/business_settings/option_value/" + key, lhrk);
        console.log("vvvvvvvv", destinationPath);

        const baseUrl = process.cwd()+'/uploads/business_settings/option_value/'+ key
        fs.mkdirSync(baseUrl, { recursive: true })
        fs.rename(currentPath, destinationPath, function (err) {
          if (err) {
            throw err
          } else {
            console.log("Successfully Uploaded !")
          }
        });
    }

    let gshgaj = req.body;
    for (const [key, value] of Object.entries(gshgaj)) {

      console.log("elhwiuerweur", `${key}: ${value}`);
      
      const num = await db[req.params.document].update({ option_value : value || null }, {
        where: { option_type: key || null},
      });
    }

    // const num = await db[req.params.document].update(condition, {
    //   where: { option_type: req.body.option_type},
    // });

    if (herurug) {

      let userId = req.params.id;

      if (req.files.option_value) {
        const currentPath = path.join(process.cwd(), "uploads", req.files.option_value[0]["filename"]);
        const destinationPath = path.join(process.cwd(), "uploads/setting" + `${req.body.option_type}`, option_value);

        const baseUrl = process.cwd() + '/uploads/settings' + `${req.body.option_type}`
        fs.mkdirSync(baseUrl, { recursive: true })
        fs.rename(currentPath, destinationPath, function (err) {
          if (err) {
            throw err
          } else {
            console.log("Successfully Uploaded !")
          }
        });
      }
      res.status(200).send({
        status:200,
        message: "Updated successfully.",
        // output:jshhge
      });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot update with id : ${req.body.option_type}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.delete = async (req, res) => {
  const MastersData = {
    status: 0,
  }
  try {
    const id = req.params.id;
    const num = await db[req.params.document].update(MastersData,{
      where: { id: id },
    });
    if (num == 1) {
      res.status(200).send({
        status:200,
        message: "Deleted successfully!"
      });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot delete with id : ${id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};


// exports.update = async (req, res) => {
//   try {

//     const option_type = req.params.option_type;
//     const id = req.params.id;

//     let option_value = "";
//     if (req.files.option_value) {
//       const extension = req.files.option_value[0]["mimetype"].split('/')[1]
//       option_value = req.files.option_value[0]["filename"] + '.' + extension
//     }
//     var condition = {   
//       option_type: req.body.option_type || null,
//       option_value: option_value || req.body.option_value || null,
//     }
//     const arr = Object.entries(condition);
//     // const arr = [req.body.option_type , req.body.option_value];
//     const hfiwyg = arr.map(element => {
//       return element;
//     });
//     console.log('wwwwwwwwww',hfiwyg);
//     // const myArray = [[condition.option_type], [option_value]];
//     // const obj = req.body.reduce((acc, [option_type]) => (acc[option_type] = option_value, acc), {});

//     // console.log("obj : ", obj);
//     // console.log("myArray : ", myArray);
//     let jshhge = {};

//     hfiwyg.map((dfh, i) => {
//       // { dfh[0]: dfh[1]}
//       jshhge = {...jshhge, [dfh[0]] : dfh[1]}
//     })
//     console.log("wjehruwgrweg", jshhge)

//     const num = await db[req.params.document].update(jshhge, {
//       where: { option_type: req.body.option_type},
//     });
//     if (num == 1) {

//       let userId = req.params.id;

//       if (req.files.option_value) {
//         const currentPath = path.join(process.cwd(), "uploads", req.files.option_value[0]["filename"]);
//         const destinationPath = path.join(process.cwd(), "uploads/business_settings/option_value/" + `${option_type}`, option_value);

//         const baseUrl = process.cwd() + '/uploads/business_settings/option_value/' + `${option_type}`
//         fs.mkdirSync(baseUrl, { recursive: true })
//         fs.rename(currentPath, destinationPath, function (err) {
//           if (err) {
//             throw err
//           } else {
//             console.log("Successfully Uploaded !")
//           }
//         });
//       }
//       res.status(200).send({
//         status:200,
//         message: "Updated successfully.",
//         output:jshhge
//       });
//     } else {
//       res.status(200).send({
//         status:404,
//         message: `Cannot update with id : ${req.body.option_type}.`
//       });
//     }
//   } catch (error) {
//     res.status(500).send({
//       message: error.message,
//     });
//   }
// };