module.exports = app => {
    const auth = require("../../zOrganizationFile/orgController/orgAuth.controller.js");
  
    var router = require("express").Router();
  
    router.post("/login_org_auth/:document", auth.loginOrgAuth);

    router.put("/change_org_password/:document", auth.changeOrgPassword);
  
    app.use("/auth", router);
  };