const authentication = require("../../middlewares/auth.js");

module.exports = app => {
    const auth = require("../../middlewares/auth");
    const orgNotes = require("../../zOrganizationFile/orgController/orgNotes.controller.js");
  
    var router = require("express").Router();
  
    router.post("/save/:document", authentication, orgNotes.saveNotes);
  
    router.get("/get/:document/:module_id/:module_name", authentication, orgNotes.getNotes);

    router.get("/get_lead_notes/:document/:module_id/:module_name", authentication, orgNotes.getLeadNotes);
  
    router.put("/update/:document/:id", authentication, orgNotes.updateNotes);
  
    router.put("/delete/:document/:id/:parent_id", authentication, orgNotes.deleteNotes);
  
    app.use('/orgNotes/',auth, router);
  };
  