const authentication = require("../../middlewares/auth.js");

module.exports = app => {
    const auth = require("../../middlewares/auth");
    const users = require("../../zOrganizationFile/orgController/orgUsers.controller.js");
  
    var router = require("express").Router();
  
    router.get("/get/:document", authentication, users.findAll);
  
    router.get("/org_edit/:document/:id", authentication, users.findOne);
  
    router.post("/org_register/:document", authentication, users.createUser);

    router.put("/org_update/:document/:id", authentication, users.updateUser);

    router.put("/org_delete/:document/:id", authentication, users.deleteUser);

    app.use('/OrgUsers/',auth, router);
  };
  