module.exports = app => {
    const auth = require("../../middlewares/auth");
    const templates = require("../../zOrganizationFile/orgController/orgTemplate.controller.js");
  
    var router = require("express").Router();
  
    router.post("/save/:document", templates.create);

    router.get("/get/:document", templates.findAll);
  
    router.get("/edit/:document/:id", templates.findOne);
  
    router.put("/update/:document/:id", templates.update);
  
    app.use('/orgTemplates/',auth, router);
  };