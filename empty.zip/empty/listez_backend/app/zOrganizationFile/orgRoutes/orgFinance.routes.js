const authentication = require("../../middlewares/auth.js");

module.exports = app => {
    const auth = require("../../middlewares/auth.js");
    const orgFinance = require("../orgController/orgFinance.controller.js");
  
    var router = require("express").Router();

    // Finance Fee Confirmation
    router.post("/save_fee_confirmation", authentication, orgFinance.saveFeeConfirmation);
    router.get("/get_fee_confirmation", authentication, orgFinance.getFeeConfirmation);
    router.get("/edit_fee_confirmation/:id", authentication, orgFinance.editFeeConfirmation);
    router.put("/update_fee_confirmation/:id", authentication, orgFinance.updateFeeConfirmation);
    router.put("/delete_fee_confirmation/:id", authentication, orgFinance.deleteFeeConfirmation);

    // Finance Pro Invoice
    router.post("/save_pro_invoice", authentication, orgFinance.saveProInvoice);
    router.get("/get_pro_invoice", authentication, orgFinance.getProInvoice);
    router.get("/edit_pro_invoice/:id", authentication, orgFinance.editProInvoice);
    router.put("/update_pro_invoice/:id", authentication, orgFinance.updateProInvoice);
    router.put("/delete_pro_invoice/:id", authentication, orgFinance.deleteProInvoice);

    // Finance Invoice
    router.post("/save_invoice", authentication, orgFinance.saveInvoice);
    router.get("/get_invoice", authentication, orgFinance.getInvoice);
    router.get("/edit_invoice/:id", authentication, orgFinance.editInvoice);
    router.put("/update_invoice/:id", authentication, orgFinance.updateInvoice);
    router.put("/delete_invoice/:id", authentication, orgFinance.deleteInvoice);

    // Finance Invoice Collection
    router.post("/save_invoice_collection", authentication, orgFinance.saveInvoiceCollection);
    router.get("/get_invoice_collection", authentication, orgFinance.getInvoiceCollection);
    router.get("/edit_invoice_collection/:id", authentication, orgFinance.editInvoiceCollection);
    router.put("/update_invoice_collection/:id", authentication, orgFinance.updateInvoiceCollection);
    router.put("/delete_invoice_collection/:id", authentication, orgFinance.deleteInvoiceCollection);
  
    // Finance Incentives
    router.post("/save/:document", authentication, orgFinance.saveIncentives);
    router.get("/get/:document", authentication, orgFinance.getIncentives);
    router.get("/edit/:document/:id", authentication, orgFinance.editIncentives);
    router.put("/update/:document/:id", authentication, orgFinance.updateIncentives);
    router.put("/delete/:document/:id", authentication, orgFinance.deleteIncentives);

    // Finance Cashbacks
    router.post("/save_cashback", authentication, orgFinance.saveCashback);
    router.get("/get_cashback", authentication, orgFinance.getCashback);
    router.get("/edit_cashback/:id", authentication, orgFinance.editCashback);
    router.put("/update_cashback/:id", authentication, orgFinance.updateCashback);
    router.put("/delete_cashback/:id", authentication, orgFinance.deleteCashback);
  
    app.use('/orgFinance/',auth, router);
  };