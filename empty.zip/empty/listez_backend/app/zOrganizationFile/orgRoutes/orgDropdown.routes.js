const authentication = require("../../middlewares/auth.js");

module.exports = app => {
    const auth = require("../../middlewares/auth");
    const dropdown = require("../../zOrganizationFile/orgController/orgDropdown.controller.js");
  
    var router = require("express").Router();
    // Lead Dropdown
    router.get("/lead_dropdown", authentication, dropdown.getLeadDropdown);
    // Property Dropdown
    router.get("/property_dropdown", authentication, dropdown.getPropertyDropdown);
    // Transaction Dropdown
    router.get("/transaction_dropdown", authentication, dropdown.getTransactionDropdown);
    // Task Dropdown
    router.get("/task_dropdown", authentication, dropdown.getTaskDropdown);
    // Team Dropdown
    router.get("/team_dropdown", authentication, dropdown.getTeamDropdown);
    // Contact Settings
    router.get("/contact_settings_dropdown", authentication, dropdown.getContactSettingsDropdown);
    // Finance Settings
    router.get("/finance_dropdown", authentication, dropdown.getFinanceDropdown);
  
    app.use('/orgDropdown/',auth, router);
  };
  