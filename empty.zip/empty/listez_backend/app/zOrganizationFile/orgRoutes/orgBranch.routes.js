const authentication = require("../../middlewares/auth.js");

module.exports = app => {
    const auth = require("../../middlewares/auth");
    const orgBranch = require("../../zOrganizationFile/orgController/orgBranch.controller.js");
  
    var router = require("express").Router();
  
    router.post("/save/:document", authentication, orgBranch.create);
  
    router.get("/get/:document", authentication, orgBranch.findAll);
  
    router.get("/edit/:document/:id", authentication, orgBranch.findOne);
  
    router.put("/update/:document/:id", authentication, orgBranch.update);
  
    router.put("/delete/:document/:id", authentication, orgBranch.delete);
  
    app.use('/orgBranch/',auth, router);
  };
  