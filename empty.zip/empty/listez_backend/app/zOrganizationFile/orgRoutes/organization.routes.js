const authentication = require("../../middlewares/auth.js");
const multer = require('multer')
const upload = multer({
  dest: 'uploads/',
  limits: {
    fileSize: 5242880
  },
  fileFilter(req, file, cb) {
    if (!file.originalname.match(/\.(jpg|jpeg|pdf|xlsx|png)$/)) {
      return cb(new Error('Please upload a Image'))
    }
    cb(undefined, true)
  }
})

module.exports = app => {
    const auth = require("../../middlewares/auth");
    const organization = require("../orgController/organization.controller.js");
    const dbSetup = require("../../zOrganizationFile/orgConfig/orgDb.config.js");
  
    var router = require("express").Router();
  
    router.put('/org_update/:document/:id', authentication, upload.fields([
        { name: "logo", maxCount: 1 },
        { name: "water_mark", maxCount: 1 },
      ]), function (req, res, next) {
        organization.updateOrg(req, res, next)
      });
    router.get("/org_edit/:document/:company_ref_id", authentication, organization.findOne);
    // router.get("/db_configuration", authentication, dbSetup.databaseAuth);
  
    app.use('/organization/',auth, router);
  };