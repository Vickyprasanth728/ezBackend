const authentication = require("../../middlewares/auth.js");

module.exports = app => {
    const auth = require("../../middlewares/auth");
    const orgRoles = require("../../zOrganizationFile/orgController/orgRoles.controller.js");
  
    var router = require("express").Router();
  
    // Roles
    router.post("/save/:document",authentication, orgRoles.create);
  
    router.get("/get/:document",authentication, orgRoles.findAll);
  
    router.get("/edit/:document/:id",authentication, orgRoles.findOne);
  
    router.put("/update/:document/:id",authentication, orgRoles.update);
  
    router.put("/delete/:document/:id",authentication, orgRoles.delete);

    // Role Permissions
    router.get("/get_role_permission_id/:document/:designation",authentication, orgRoles.getRoleByID);

    router.put("/update_role_permission/:document/:designation",authentication, orgRoles.updateRolePermission);
  
    app.use('/orgRoles/',auth, router);
  };
  