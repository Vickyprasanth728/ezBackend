const authentication = require("../../middlewares/auth.js");

module.exports = app => {
    const auth = require("../../middlewares/auth");
    const orgMasters = require("../../zOrganizationFile/orgController/orgMaster.controller.js");
  
    var router = require("express").Router();
  
    router.post("/save/:document", authentication, orgMasters.create);
  
    router.get("/get/:document", authentication, orgMasters.findAll);
  
    router.get("/edit/:document/:id", authentication, orgMasters.findOne);
  
    router.put("/update/:document/:option_type/:id", authentication, orgMasters.update);
  
    router.put("/delete/:document/:id", authentication, orgMasters.delete);
  
    app.use('/orgMasters/',auth, router);
  };
  