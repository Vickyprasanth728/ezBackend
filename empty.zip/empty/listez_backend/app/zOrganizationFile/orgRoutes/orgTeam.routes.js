const authentication = require("../../middlewares/auth.js");

module.exports = app => {
    const auth = require("../../middlewares/auth");
    const orgTeams = require("../../zOrganizationFile/orgController/orgTeams.controller.js");
  
    var router = require("express").Router();
  
    router.post("/save/:document", authentication, orgTeams.create);
  
    router.get("/get/:document", authentication, orgTeams.findAll);
    
    router.get("/get_team_list/:document", authentication, orgTeams.getTeamList);
  
    router.get("/edit/:document/:id", authentication, orgTeams.findOne);
  
    router.put("/update/:document/:option_type/:id", authentication, orgTeams.update);
  
    router.put("/delete/:document/:id", authentication, orgTeams.delete);
  
    app.use('/orgTeams/',auth, router);
  };
  