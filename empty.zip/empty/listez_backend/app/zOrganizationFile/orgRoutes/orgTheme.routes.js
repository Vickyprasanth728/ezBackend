const authentication = require("../../middlewares/auth.js");

module.exports = app => {
    const auth = require("../../middlewares/auth");
    const orgTheme = require("../../zOrganizationFile/orgController/orgTheme.controller.js");
  
    var router = require("express").Router();
  
    router.post("/save/:document",authentication, orgTheme.create);
  
    router.get("/get/:document",authentication, orgTheme.findAll);
  
    router.get("/edit/:document/:id",authentication, orgTheme.findOne);
  
    router.put("/update/:document/:id",authentication, orgTheme.update);
  
    router.put("/delete/:document/:id",authentication, orgTheme.delete);
  
    app.use('/orgTheme/',auth, router);
  };
  