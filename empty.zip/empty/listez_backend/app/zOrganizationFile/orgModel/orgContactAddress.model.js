module.exports = (sequelize, Sequelize) => {
    return sequelize.define("lz_contact_address", {
        contact_id: {
            type: Sequelize.INTEGER,
            allowNull: true,
            // validate: { isInt: true }
        },
        address_1: {
            type: Sequelize.TEXT,
            allowNull: true,
        },
        address_2: {
            type: Sequelize.TEXT,
            allowNull: true,
        },
        locality: {
            type: Sequelize.STRING,
            allowNull: true,
            // validate: { isInt: true || null}
        },
        country: {
            type: Sequelize.INTEGER,
            allowNull: true,
            // validate: { isInt: true || null}
        },
        city: {
            type: Sequelize.INTEGER,
            allowNull: true,
            // validate: { isInt: true || null}
        },
        state: {
            type: Sequelize.INTEGER,
            allowNull: true,
            // validate: { isInt: true || null}
        },
        zip_code: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        facebook: {
            type: Sequelize.TEXT,
            allowNull: true,
        },
        instagram: {
            type: Sequelize.TEXT,
            allowNull: true,
        },
        linkedin: {
            type: Sequelize.TEXT,
            allowNull: true,
        },
        twitter: {
            type: Sequelize.TEXT,
            allowNull: true,
        },
        createdAt: {
            type: 'TIMESTAMP',
            allowNull: true,
            defaultValue: sequelize.literal('CURRENT_TIMESTAMP'),
            field: 'created_at'
        },
        updatedAt: {
            type: 'TIMESTAMP',
            allowNull: true,
            defaultValue: sequelize.literal('CURRENT_TIMESTAMP'),
            field: 'updated_at'
        },
    }, {
        tableName: 'lz_contact_address'
    });
};