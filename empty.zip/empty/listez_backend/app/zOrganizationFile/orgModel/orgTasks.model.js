module.exports = (sequelize, Sequelize) => {
    return sequelize.define("lz_tasks", {
        org_id: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        task_type: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        priority: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        task_time: {
            type: Sequelize.DATE,
            allowNull: true,
        },
        finish_time: {
            type: Sequelize.DATE,
            allowNull: true,
        },
        project: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        contact: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        agenda: {
            type: Sequelize.TEXT,
            allowNull: true,
        },
        assign_to: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        reminder: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        task_status: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        created_by: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        status: {
            type: Sequelize.INTEGER,
            allowNull: true,
            defaultValue: 1,
        },
        createdAt: {
            type: 'TIMESTAMP',
            allowNull: true,
            defaultValue: sequelize.literal('CURRENT_TIMESTAMP'),
            field: 'created_at'
        },
        updatedAt: {
            type: 'TIMESTAMP',
            allowNull: true,
            defaultValue: sequelize.literal('CURRENT_TIMESTAMP'),
            field: 'updated_at'
        },
    }, {
        tableName: 'lz_tasks'
    });
};