module.exports = (sequelize, Sequelize) => {
    return sequelize.define("lz_finance_fee_confirmation", {
        transaction_id: {
            type: Sequelize.INTEGER(11),
            allowNull: true,
        },
        fee_confirmation_date: {
            type: Sequelize.DATEONLY,
            allowNull: true,
        },
        contact_name: {
            type: Sequelize.INTEGER(11),
            allowNull: true,
        },
        developer_name: {
            type: Sequelize.STRING(255),
            allowNull: true,
        },
        project_name: {
            type: Sequelize.INTEGER(11),
            allowNull: true,
        },
        brokerage_value: {
            type: Sequelize.DECIMAL(20,4),
            allowNull: true,
        },
        due_date: {
            type: Sequelize.DATEONLY,
            allowNull: true,
        },
        transaction_status: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        description: {
            type: Sequelize.TEXT,
            allowNull: true,
        },
        created_by: {
            type: Sequelize.INTEGER,
            allowNull: false,
        },
        status: {
            type: Sequelize.INTEGER,
            allowNull: true,
            defaultValue: 1,
        },
        createdAt: {
            type: 'TIMESTAMP',
            allowNull: true,
            defaultValue: sequelize.literal('CURRENT_TIMESTAMP'),
            field: 'created_at'
        },
        updatedAt: {
            type: 'TIMESTAMP',
            allowNull: true,
            defaultValue: sequelize.literal('CURRENT_TIMESTAMP'),
            field: 'updated_at'
        },
    }, {
        tableName: 'lz_finance_fee_confirmation'
    });
};