module.exports = (sequelize, Sequelize) => {
    return sequelize.define("lz_transaction_brokerage_details", {
      transaction_id: {
        type: Sequelize.INTEGER(20),
        allowNull: true,
      },
      s_gst_per: {
        type: Sequelize.INTEGER(20),
        allowNull: true,
      },
      c_gst_per: {
        type: Sequelize.INTEGER(20),
        allowNull: true,
      },
      i_gst_per: {
        type: Sequelize.INTEGER(20),
        allowNull: true,
      },
      gst_amount: {
        type: Sequelize.DECIMAL(20,4),
        allowNull: true,
      },
      gross_brokerage_value: {
        type: Sequelize.DECIMAL(20,4),
        allowNull: true,
      },
      tds_reducted_by_builder: {
        type: Sequelize.DECIMAL(20,4),
        allowNull: true,
      },
      tds_per: {
        type: Sequelize.DECIMAL(20,4),
        allowNull: true,
      },
      tds_amount: {
        type: Sequelize.DECIMAL(20,4),
        allowNull: true,
      },
      after_tds_brokerage: {
        type: Sequelize.DECIMAL(20,4),
        allowNull: true,
      },
      actual_receivable_amount: {
        type: Sequelize.DECIMAL(20,4),
        allowNull: true,
      },
      incentive_per: {
        type: Sequelize.INTEGER(20),
        allowNull: true,
      },
      incentive_without_tds: {
        type: Sequelize.DECIMAL(20,4),
        allowNull: true,
      },
      tds_per: {
        type: Sequelize.INTEGER(20),
        allowNull: true,
      },
      net_incentive_earned: {
        type: Sequelize.DECIMAL(20,4),
        allowNull: true,
      },
      invoice_status: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      createdAt: {
        type: 'TIMESTAMP',
        allowNull: true,
        defaultValue:sequelize.literal('CURRENT_TIMESTAMP'),
        field:'created_at'
      },
      updatedAt: {
        type: 'TIMESTAMP',
        allowNull: true,
        defaultValue:sequelize.literal('CURRENT_TIMESTAMP'),
        field:'updated_at'
      },
    },{
      tableName:'lz_transaction_brokerage_details'
    });
  };
  