module.exports = (sequelize, Sequelize) => {
    return sequelize.define("lz_user", {
      first_name: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      last_name: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      employee_id: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      org_id: {
        type: Sequelize.INTEGER,
        allowNull: true,
        // validate : {isInt: true}
      },
      designation: {
        type: Sequelize.INTEGER,
        allowNull: true,
        // validate : {isInt: true}
      },
      department: {
        type: Sequelize.INTEGER,
        allowNull: true,
        // validate : {isInt: true}
      },
      p_phone_number: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      email: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      o_phone_number: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      o_email: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      aadhar_number: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      pan_number: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      dob: {
        type: Sequelize.DATEONLY,
        allowNull: true,
        // validate: {isDate: true}
      },
      date_of_joining: {
        type: Sequelize.DATEONLY,
        allowNull: true,
        // validate: {isDate: true}
      },
      password: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      api_token: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      profile_image: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      team_leader: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      portfolio_head: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      language: {
        type: Sequelize.INTEGER,
        allowNull: true,
        // validate : {isInt: true}
      },
      created_by: {
        type: Sequelize.INTEGER,
        allowNull: true,
        validate : {isInt: true}
      },
      status: {
        type: Sequelize.INTEGER,
        allowNull: true,
        defaultValue:1,
        validate : {isInt: true}
      },
      createdAt: {
        type: 'TIMESTAMP',
        allowNull: true,
        defaultValue:sequelize.literal('CURRENT_TIMESTAMP'),
        field:'created_at'
      },
      updatedAt: {
        type: 'TIMESTAMP',
        allowNull: true,
        defaultValue:sequelize.literal('CURRENT_TIMESTAMP'),
        field:'updated_at'
      },
    },{
      tableName:'lz_user'
    });
};