module.exports = (sequelize, Sequelize) => {
    return sequelize.define("lz_finance_cashback", {
        transaction_id: {
            type: Sequelize.INTEGER(11),
            allowNull: true,
        },
        invoice_id: {
            type: Sequelize.INTEGER(11),
            allowNull: true,
        },
        client_name: {
            type: Sequelize.INTEGER(11),
            allowNull: true,
        },
        transaction_amount	: {
            type: Sequelize.DECIMAL(20,4),
            allowNull: true,
        },
        due_date: {
            type: Sequelize.DATEONLY,
            allowNull: true,
        },
        release_amount: {
            type: Sequelize.DECIMAL(20,4),
            allowNull: true,
        },
        release_mode: {
            type: Sequelize.INTEGER(11),
            allowNull: true,
        },
        description: {
            type: Sequelize.TEXT,
            allowNull: true,
        },
        created_by: {
            type: Sequelize.INTEGER,
            allowNull: false,
        },
        status: {
            type: Sequelize.INTEGER,
            allowNull: true,
            defaultValue: 1,
        },
        createdAt: {
            type: 'TIMESTAMP',
            allowNull: true,
            defaultValue: sequelize.literal('CURRENT_TIMESTAMP'),
            field: 'created_at'
        },
        updatedAt: {
            type: 'TIMESTAMP',
            allowNull: true,
            defaultValue: sequelize.literal('CURRENT_TIMESTAMP'),
            field: 'updated_at'
        },
    }, {
        tableName: 'lz_finance_cashback'
    });
};