module.exports = (sequelize, Sequelize) => {
    return sequelize.define("lz_contact_filter", {
        contact_type: {
            type: Sequelize.INTEGER,
            allowNull: true,
            // validate: { isInt: true }
        },
        contact_status: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        gender: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        contact_category: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        assign_to: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        source: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        property_id: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        locality: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        country: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        state: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        city: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        date_of_birth: {
            type: Sequelize.DATEONLY,
            allowNull: true,
        },
        nationality: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        contact_group: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        filter_name: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        created_date: {
            type: Sequelize.DATEONLY,
            allowNull: true,
        },
        created_end_date: {
            type: Sequelize.DATEONLY,
            allowNull: true,
        },
        updated_date: {
            type: Sequelize.DATEONLY,
            allowNull: true,
        },
        created_by: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        createdAt: {
            type: 'TIMESTAMP',
            allowNull: true,
            defaultValue: sequelize.literal('CURRENT_TIMESTAMP'),
            field: 'created_at'
        },
        updatedAt: {
            type: 'TIMESTAMP',
            allowNull: true,
            defaultValue: sequelize.literal('CURRENT_TIMESTAMP'),
            field: 'updated_at'
        },
    }, {
        tableName: 'lz_contact_filter'
    });
};