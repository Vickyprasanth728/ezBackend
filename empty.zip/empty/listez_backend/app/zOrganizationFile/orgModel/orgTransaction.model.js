module.exports = (sequelize, Sequelize) => {
    return sequelize.define("lz_transactions", {
      org_id: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      lead_id: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      booking_date: {
        type: Sequelize.DATEONLY,
        allowNull: true,
      },
      country: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      state: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      city: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      lead_source: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      team_leader: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      shared_with: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      closed_by: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      transaction_status: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      developer_name: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      project_name: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      client_name: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      contact_number: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      email_id: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      dob: {
        type: Sequelize.DATEONLY,
        allowNull: true,
      },
      anniversary_date: {
        type: Sequelize.DATEONLY,
        allowNull: true,
      },
      discount_amount: {
        type: Sequelize.DECIMAL(20,4),
        allowNull: true,
      },
      block_no: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      unit_no: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      floor_no: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      bhk_type: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      unit_size: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      plot_size: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      frc: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      plc: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      basic_price: {
        type: Sequelize.DECIMAL(20,4),
        allowNull: true,
      },
      car_parking_cost: {
        type: Sequelize.DECIMAL(20,4),
        allowNull: true,
      },
      pan: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      agreement_value: {
        type: Sequelize.DECIMAL(20,4),
        allowNull: true,
      },
      brokerage_percentage: {
        type: Sequelize.DECIMAL(20,4),
        allowNull: true,
      },
      brokerage_value: {
        type: Sequelize.DECIMAL(20,4),
        allowNull: true,
      },
      aop_percentage: {
        type: Sequelize.DECIMAL(20,4),
        allowNull: true,
      },
      discount_value: {
        type: Sequelize.DECIMAL(20,4),
        allowNull: true,
      },
      discount_paid_status: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      tds_value: {
        type: Sequelize.DECIMAL(20,4),
        allowNull: true,
      },
      revenue: {
        type: Sequelize.DECIMAL(20,4),
        allowNull: true,
      },
      created_by: {
        type: Sequelize.INTEGER,
        allowNull: true,
        validate : {isInt: true}
      },
      status: {
        type: Sequelize.INTEGER,
        allowNull: true,
        defaultValue:1,
        validate : {isInt: true}
      },
      createdAt: {
        type: 'TIMESTAMP',
        allowNull: true,
        defaultValue:sequelize.literal('CURRENT_TIMESTAMP'),
        field:'created_at'
      },
      updatedAt: {
        type: 'TIMESTAMP',
        allowNull: true,
        defaultValue:sequelize.literal('CURRENT_TIMESTAMP'),
        field:'updated_at'
      },
    },{
      tableName:'lz_transactions'
    });
  };
  