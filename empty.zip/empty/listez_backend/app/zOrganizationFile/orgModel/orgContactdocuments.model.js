module.exports = (sequelize, Sequelize) => {
    return sequelize.define("lz_contact_documents", {
        contact_id: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        file: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        fileoriginalname: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        person_id_documents: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        id_number: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        createdAt: {
            type: 'TIMESTAMP',
            allowNull: true,
            defaultValue: sequelize.literal('CURRENT_TIMESTAMP'),
            field: 'created_at'
        },
        updatedAt: {
            type: 'TIMESTAMP',
            allowNull: true,
            defaultValue: sequelize.literal('CURRENT_TIMESTAMP'),
            field: 'updated_at'
        },
    }, {
        tableName: 'lz_contact_documents'
    });
};