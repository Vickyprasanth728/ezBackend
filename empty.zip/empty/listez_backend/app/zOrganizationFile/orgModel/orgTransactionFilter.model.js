module.exports = (sequelize, Sequelize) => {
    return sequelize.define("lz_transaction_filter", {
        booking_from_date: {
            type: Sequelize.DATEONLY,
            allowNull: true,
        },
        booking_to_date: {
            type: Sequelize.DATEONLY,
            allowNull: true,
        },
        city: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        source: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        team_leader: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        shared_with: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        closed_by: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        developer_name: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        property_id: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        filter_name: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        bhk_type_min: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        bhk_type_max: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        agreement_value_min: {
            type: Sequelize.DECIMAL(20,4),
            allowNull: true,
        },
        agreement_value_max: {
            type: Sequelize.DECIMAL(20,4),
            allowNull: true,
        },
        brokerage_percentage_min: {
            type: Sequelize.DECIMAL(20,4),
            allowNull: true,
        },
        brokerage_percentage_max: {
            type: Sequelize.DECIMAL(20,4),
            allowNull: true,
        },
        brokerage_value_min: {
            type: Sequelize.DECIMAL(20,4),
            allowNull: true,
        },
        brokerage_value_max: {
            type: Sequelize.DECIMAL(20,4),
            allowNull: true,
        },
        discount_percentage_min: {
            type: Sequelize.DECIMAL(20,4),
            allowNull: true,
        },
        discount_percentage_max: {
            type: Sequelize.DECIMAL(20,4),
            allowNull: true,
        },
        discount_value_min: {
            type: Sequelize.DECIMAL(20,4),
            allowNull: true,
        },
        discount_value_max: {
            type: Sequelize.DECIMAL(20,4),
            allowNull: true,
        },
        revenue_min: {
            type: Sequelize.DECIMAL(20,4),
            allowNull: true,
        },
        revenue_max: {
            type: Sequelize.DECIMAL(20,4),
            allowNull: true,
        },
        transaction_status: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        created_by: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        createdAt: {
            type: 'TIMESTAMP',
            allowNull: true,
            defaultValue: sequelize.literal('CURRENT_TIMESTAMP'),
            field: 'created_at'
        },
        updatedAt: {
            type: 'TIMESTAMP',
            allowNull: true,
            defaultValue: sequelize.literal('CURRENT_TIMESTAMP'),
            field: 'updated_at'
        },
    }, {
        tableName: 'lz_transaction_filter'
    });
};