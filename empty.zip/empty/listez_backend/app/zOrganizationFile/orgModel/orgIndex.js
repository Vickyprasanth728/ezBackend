require('dotenv').config();
const dbConfig = require("../orgConfig/orgDb.config.js").databaseAuth();
const db = require("../../models")

const Sequelize = require("sequelize");
  const sequelize = new Sequelize(
    dbConfig.DB_DATABASE,
    dbConfig.DB_USER,
    dbConfig.DB_PASS, {
    host: dbConfig.DB_HOST,
    dialect: "mysql",
    operatorsAliases: 0,
  
    pool: {
      max: 5,
      min: 0,
      acquire: 30000,
      idle: 10000
    }
  },
  );
  
// const sequelize = new Sequelize(
//   dbConfig.databases["Database3"].DB_DATABASE3,
//   dbConfig.databases.Database1.DB_USER1,
//   dbConfig.databases.Database1.DB_PASS1, {
//   host: dbConfig.databases.Database1.DB_HOST1,
//   // host: dbConfig.DB_HOST,
//   dialect: dbConfig.databases.Database1.DB_DIALECT,
//   // dialect: "mysql",
//   operatorsAliases: 0,

//   pool: {
//     max: 5,
//     min: 0,
//     acquire: 30000,
//     idle: 10000
//   }
// });

const db2 = {};

db2.Sequelize = Sequelize;
db2.sequelize = sequelize;

// This model is required. Please don't delete.
// db2.tokens = require("./tokens.model.js")(sequelize, Sequelize);
// //---------
// db2.users = require("./users.model.js")(sequelize, Sequelize);
// db2.posts = require("./posts.model.js")(sequelize, Sequelize);
// db2.comments = require("./comments.model.js")(sequelize, Sequelize);

db2.roles = require("./orgRoles.model.js")(sequelize, Sequelize);
db2.rolePermissions = require("./orgRolePermissions.model.js")(sequelize, Sequelize);
db2.masters = require("./orgMaster.model.js")(sequelize, Sequelize);
db2.organization = require("./organization.model.js")(sequelize, Sequelize);
// db2.users = require("./orgUsers.model.js")(sequelize, Sequelize);
db2.theme = require("./OrgTheme.model.js")(sequelize, Sequelize);
db2.template = require("./orgTemplate.model.js")(sequelize, Sequelize);
db2.branch = require("./orgBranch.model.js")(sequelize, Sequelize);
db2.user = require("./orgUser.model.js")(sequelize, Sequelize);
db2.usersPersonal = require("./orgUsersPersonal.model.js")(sequelize, Sequelize);
db2.usersProfessional = require("./orgUsersProfessional.js")(sequelize, Sequelize);
db2.usersFinance = require("./orgUsersFinance.model.js")(sequelize, Sequelize);
db2.usersGoals = require("./orgUsersGoals.model.js")(sequelize, Sequelize);
db2.source = require("./orgSource.model.js")(sequelize, Sequelize);
db2.teams = require("./orgTeam.model.js")(sequelize, Sequelize);
db2.emailTemplate = require("./orgEmailTemplate.model.js")(sequelize, Sequelize);
db2.whatsAppTemplate = require("./orgWhatsAppTemplate.model.js")(sequelize, Sequelize);
// Contacts
db2.contacts = require("./orgContact.model.js")(sequelize, Sequelize);
db2.contactDetails = require("./orgContactDetails.model.js")(sequelize, Sequelize);
db2.contactAddress = require("./orgContactAddress.model.js")(sequelize, Sequelize);
db2.contactDocuments = require("./orgContactdocuments.model.js")(sequelize, Sequelize);
db2.contactFilter = require("./orgContactFilter.model.js")(sequelize, Sequelize);
db2.logs = require("./orgLogs.model.js")(sequelize, Sequelize);
// Leads
db2.leads = require("./orgLead.model.js")(sequelize, Sequelize);
db2.leadRequirement = require("./orgLeadsRequirement.model.js")(sequelize, Sequelize);
db2.leadFilter = require("./orgLeadFilter.model.js")(sequelize, Sequelize);
// property
db2.property = require("./orgProperty.model.js")(sequelize, Sequelize);
db2.propertyResidentials = require("./orgPropertyResidentials.js")(sequelize, Sequelize);
db2.propertyAddress = require("./orgPropertyAddress.model.js")(sequelize, Sequelize);
db2.propertyFilter = require("./orgPropertyFilter.js")(sequelize, Sequelize);
// Tasks
db2.tasks = require("./orgTasks.model.js")(sequelize, Sequelize);
db2.taskFilter = require("./orgTasksFilter.model.js")(sequelize, Sequelize);
// Transaction
db2.transaction = require("./orgTransaction.model.js")(sequelize, Sequelize);
db2.transactionBrokerageDetails = require("./orgTransactionBrokerageDetails.model.js")(sequelize, Sequelize);
db2.transactionInvoicingDetails = require("./orgTransactionInvoicingDetails.model.js")(sequelize, Sequelize);
// Transaction Filter
db2.transactionFilter = require("./orgTransactionFilter.model.js")(sequelize, Sequelize);
// Email Settings
db2.emailSettings = require("./emailSettings.model.js")(sequelize, Sequelize);


// Auto Assign To
db2.autoAssign = require("./orgAutoContactAssign.model.js")(sequelize, Sequelize);

// Notes
db2.notes = require("./orgNotes.model.js")(sequelize, Sequelize);
// Files
db2.files = require("./orgFileUploads.model.js")(sequelize, Sequelize);
// Finance
// Fee Confirmation
db2.financeFeeConfirmation = require("./orgFinanceFeeConfirmation.model.js")(sequelize, Sequelize);
// Pro InVoice
db2.financeProInvoice = require("./orgFinanceProInvoice.model.js")(sequelize, Sequelize);
// Pro InVoice
db2.financeInvoice = require("./orgFinanceInvoice.model.js")(sequelize, Sequelize);
// InVoice Collection
db2.financeCollection = require("./orgFinanceInvoiceCollection.model.js")(sequelize, Sequelize);
// Expenses
db2.expenses = require("./orgExpenses.model.js")(sequelize, Sequelize);
db2.expenseDetails = require("./orgExpensedetails.model.js")(sequelize, Sequelize);
// Incentives
db2.financeIncentives = require("./orgFinanceIncentives.model.js")(sequelize, Sequelize);
// Cashbacks
db2.financeCashback = require("./orgFinanceCashback.model.js")(sequelize, Sequelize);

// Email Trigger
db2.emailTrigger = require("./emailTrigger.model.js")(sequelize, Sequelize);

// BackUp
db2.backUp = require("./orgbackupRR.model.js")(sequelize, Sequelize);

//Settings
//Business Settings
db2.businessSettings = require("./orgBusinessSettings.model.js")(sequelize, Sequelize);
// Attendance
db2.attendance = require("./orgAttendance.model.js")(sequelize, Sequelize);

// Logout
db2.logoutTimeline = require("./orgUserTimline.model.js")(sequelize, Sequelize);
// Contact Settings
db2.contactSettings = require("./orgContactSettings.model.js")(sequelize, Sequelize);
db2.contactSettingMembers = require("./orgContactSettingsMembers.model.js")(sequelize, Sequelize);


db2.teams.belongsTo(db2.user,  {foreignKey: 'team_leader', as: 'team_leader_name'});
db2.teams.belongsTo(db2.user,  {foreignKey: 'executives', as: 'executives_name',});

db2.user.hasMany(db2.usersPersonal, {foreignKey: 'user_id'});
db2.user.hasMany(db2.usersProfessional, {foreignKey: 'user_id'});
db2.user.hasMany(db2.usersFinance, {foreignKey: 'user_id'});
db2.user.hasMany(db2.usersGoals, {foreignKey: 'user_id'});
// db2.usersPersonal.belongsTo(db2.user, {foreignKey: 'user_id'});
db2.logs.belongsTo(db2.user, {foreignKey: 'user_id', as:'user_name'});




// db2.contacts.hasMany(db2.contactDetails, {foreignKey: 'contact_id', as:'contact_details_name'});
// db2.contacts.hasMany(db2.contactAddress, {foreignKey: 'contact_id', as:'contact_address_name'});

// db2.contacts.belongsTo(db2.masters, {foreignKey: 'source', as:'source_name'});
// db2.contacts.belongsTo(db2.masters, {foreignKey: 'contact_group', as:'contact_group_name'});
// db2.contacts.belongsTo(db2.masters, {foreignKey: 'contact_type', as:'contact_type_name'});
// db2.contacts.belongsTo(db2.masters, {foreignKey: 'contact_category', as:'contact_category_name'});
// db2.contacts.belongsTo(db2.masters, {foreignKey: 'contact_status', as:'contact_status_name'});
// db2.contacts.belongsTo(db2.user, {foreignKey: 'assign_to', as:'assign_to_name'});
// db2.contacts.belongsTo(db2.user, {foreignKey: 'created_by', as:'created_by_name'});

// db2.contactFilter.belongsTo(db2.masters, {foreignKey: 'source', as:'source_name'});
// db2.contactFilter.belongsTo(db2.masters, {foreignKey: 'contact_group', as:'contact_group_name'});
// db2.contactFilter.belongsTo(db2.masters, {foreignKey: 'contact_type', as:'contact_type_name'});
// db2.contactFilter.belongsTo(db2.masters, {foreignKey: 'contact_status', as:'contact_status_name'});
// db2.contactFilter.belongsTo(db2.masters, {foreignKey: 'nationality', as:'nationality_name'});
// db2.contactFilter.belongsTo(db2.user, {foreignKey: 'assign_to', as:'assign_to_name'});
// db2.contactFilter.belongsTo(db2.user, {foreignKey: 'created_by', as:'created_by_name'});

// db2.leads.hasMany(db2.leadRequirement,{foreignKey: 'lead_id', as:'lead_requirement_name'});
// db2.leads.belongsTo(db2.contacts, {foreignKey: 'contact_id', as:'contact_name'});
// db2.leads.belongsTo(db2.masters, {foreignKey: 'looking_for', as:'looking_for_name'});
// db2.leads.belongsTo(db2.masters, {foreignKey: 'property_type', as:'property_type_name'});
// db2.leads.belongsTo(db2.masters, {foreignKey: 'lead_source', as:'lead_source_name'});
// db2.leads.belongsTo(db2.masters, {foreignKey: 'lead_group', as:'lead_group_name'});
// db2.leads.belongsTo(db2.masters, {foreignKey: 'segment', as:'segment_name'});
// db2.leads.belongsTo(db2.masters, {foreignKey: 'lead_priority', as:'lead_priority_name'});
// db2.leads.belongsTo(db2.masters, {foreignKey: 'lead_status', as:'lead_status_name'});
// db2.leads.belongsTo(db2.user, {foreignKey: 'sales_manager', as:'sales_manager_name'});
// db2.leadRequirement.belongsTo(db2.masters, {foreignKey: 'age_of_property', as:'age_of_property_name'});
// db2.leadRequirement.belongsTo(db2.masters, {foreignKey: 'vasthu_compliant', as:'vasthu_compliant_name'});
// db2.leadRequirement.belongsTo(db2.masters, {foreignKey: 'property_facing', as:'property_facing_name'});
// db2.leadRequirement.belongsTo(db2.masters, {foreignKey: 'amenities', as:'amenities_name'});
// db2.leadRequirement.belongsTo(db2.masters, {foreignKey: 'furnishing', as:'furnishing_name'});
// db2.leadRequirement.belongsTo(db2.masters, {foreignKey: 'requirement_location', as:'requirement_location_name'});
// db2.leadRequirement.belongsTo(db2.masters, {foreignKey: 'possession_status', as:'possession_status_name'});

// db2.leadFilter.belongsTo(db2.masters, {foreignKey: 'looking_for', as:'looking_for_name'});
// db2.leadFilter.belongsTo(db2.masters, {foreignKey: 'property_type', as:'property_type_name'});
// db2.leadFilter.belongsTo(db2.masters, {foreignKey: 'requirement_location', as:'requirement_location_name'});
// db2.leadFilter.belongsTo(db2.masters, {foreignKey: 'lead_source', as:'lead_source_name'});
// db2.leadFilter.belongsTo(db2.masters, {foreignKey: 'lead_group', as:'lead_group_name'});
// db2.leadFilter.belongsTo(db2.masters, {foreignKey: 'fee_oppurtunity', as:'fee_oppurtunity_name'});
// db2.leadFilter.belongsTo(db2.masters, {foreignKey: 'lead_status', as:'lead_status_name'});
// db2.leadFilter.belongsTo(db2.masters, {foreignKey: 'assign_to', as:'assign_to_name'});
// db2.leadFilter.belongsTo(db2.masters, {foreignKey: 'age_of_property', as:'age_of_property_name'});
// db2.leadFilter.belongsTo(db2.masters, {foreignKey: 'vasthu_compliant', as:'vasthu_compliant_name'});
// db2.leadFilter.belongsTo(db2.masters, {foreignKey: 'amenities', as:'amenities_name'});
// db2.leadFilter.belongsTo(db2.masters, {foreignKey: 'furnishing', as:'furnishing_name'});
// db2.leadFilter.belongsTo(db2.masters, {foreignKey: 'possession_status', as:'possession_status_name'});


/**
Create relationship
 - Posts have many comments
 - Comment have only one post
*/
// db.posts.hasMany(db.comments, { as: "comments" });
// db.comments.belongsTo(db.posts, {
//   foreignKey: "postId",
//   as: "posts",
// });
// ----------------------------


module.exports = db2;