module.exports = (sequelize, Sequelize) => {
    return sequelize.define("lz_transaction_invoicing_details", {
      transaction_id: {
        type: Sequelize.INTEGER(20),
        allowNull: true,
      },
      raised: {
        type: Sequelize.DECIMAL(20,4),
        allowNull: true,
      },
      pending: {
        type: Sequelize.DECIMAL(20,4),
        allowNull: true,
      },
      payment_status: {
        type: Sequelize.INTEGER(20),
        allowNull: true,
      },
      amount_received: {
        type: Sequelize.DECIMAL(20,4),
        allowNull: true,
      },
      receiving_date: {
        type: Sequelize.DATEONLY,
        allowNull: true,
      },
      pending_brokerage: {
        type: Sequelize.DECIMAL(20,4),
        allowNull: true,
      },
      s_gst_2: {
        type: Sequelize.INTEGER(20),
        allowNull: true,
      },
      c_gst_3: {
        type: Sequelize.INTEGER(20),
        allowNull: true,
      },
      i_gst_4: {
        type: Sequelize.INTEGER(20),
        allowNull: true,
      },
      gst_amount2: {
        type: Sequelize.DECIMAL(20,4),
        allowNull: true,
      },
      gross_brokerage_value2: {
        type: Sequelize.DECIMAL(20,4),
        allowNull: true,
      },
      tds_reducted_by_builder3: {
        type: Sequelize.DECIMAL(20,4),
        allowNull: true,
      },
      tds_amount2: {
        type: Sequelize.DECIMAL(20,4),
        allowNull: true,
      },
      after_tds_brokearge5: {
        type: Sequelize.DECIMAL(20,4),
        allowNull: true,
      },
      pending_receivable_amount: {
        type: Sequelize.DECIMAL(20,4),
        allowNull: true,
      },
      createdAt: {
        type: 'TIMESTAMP',
        allowNull: true,
        defaultValue:sequelize.literal('CURRENT_TIMESTAMP'),
        field:'created_at'
      },
      updatedAt: {
        type: 'TIMESTAMP',
        allowNull: true,
        defaultValue:sequelize.literal('CURRENT_TIMESTAMP'),
        field:'updated_at'
      },
    },{
      tableName:'lz_transaction_invoicing_details'
    });
  };
  