module.exports = (sequelize, Sequelize) => {
    return sequelize.define("lz_property_addresses", {
        property_id: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        name_of_building: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        door_number: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        address_line1: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        country: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        state: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        city: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        locality: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        pincode: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        latitude: {
            type: Sequelize.BIGINT,
            allowNull: true,
        },
        longitude: {
            type: Sequelize.BIGINT,
            allowNull: true,
        },
        module_number: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        createdAt: {
            type: 'TIMESTAMP',
            allowNull: true,
            defaultValue: sequelize.literal('CURRENT_TIMESTAMP'),
            field: 'created_at'
        },
        updatedAt: {
            type: 'TIMESTAMP',
            allowNull: true,
            defaultValue: sequelize.literal('CURRENT_TIMESTAMP'),
            field: 'updated_at'
        },
    }, {
        tableName: 'lz_property_addresses'
    });
};