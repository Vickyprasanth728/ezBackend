const orgDbConfig = require("../orgConfig/orgDb.config.js");
const db2 = require("../orgModel/orgIndex.js");
const Op = db2.Sequelize.Op;
var Sequelize = require('sequelize');
const { QueryTypes } = require('sequelize');

exports.create = async (req, res) => {
  try {
    const created_by = req.user.id
    console.log('created_by', created_by.id);

    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);
    
    const data = await db2['teams'].create({
      team_name: req.body.team_name,
      branch_id: req.body.branch_id,
      project_id: req.body.project_id,
      team_leader: req.body.team_leader,
      executives: req.body.executives,
      created_by: created_by.id
    });
    res.status(200).send({
      status:200,
      message:'Success',
      output:data
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.findAll = async (req, res) => {
    try {

    const users = await db2.sequelize.query("SELECT lz_teams.id, lz_teams.team_name, lz_teams.branch_id,lz_teams.project_id, lz_teams.team_leader, lz_teams.executives, lz_teams.status, CONCAT(' ', us1.first_name,' ', IFNULL(us1.last_name, ''),'-',us1.id) as team_leader_name, GROUP_CONCAT(distinct CONCAT(us.first_name,' ', IFNULL(us.last_name, ''),'-',us.id)) as executives_name FROM `lz_teams` LEFT JOIN lz_user as us on FIND_IN_SET(us.id,lz_teams.executives)>0 LEFT JOIN lz_user as us1 on (us1.id=lz_teams.team_leader) group by lz_teams.id");

      var condition = {
        where:{
          status:1, 
        },
        order: [['id', 'DESC']], // ASC, DESC
        attributes: {exclude :['createdAt','updatedAt']},
        // include: [
        //     {
        //       model: db2['user'],
        //       attributes: ['first_name'],
        //       where: {},
        //       as: 'team_leader_name',
        //       required: false,
        //     },
        //     {
        //       model: db2['user'],
        //       attributes: ['first_name'],
        //       where: Sequelize.where(Sequelize.fn('FIND_IN_SET','id', Sequelize.col('executives')), '>', 0),
        //       as: 'executives_name',
        //       required: false,
        //     }
        //   ]
      };
      var offset = parseInt(req.query.offset);
      var limit = parseInt(req.query.limit);
  
      if (offset >= 0 && limit >= 0) {
        condition.offset = offset;
        condition.limit = limit;
      }
  
      const data = await db2['teams'].findAll(condition);
      res.status(200).send({
        status:200,
        message:'Success',
        // output:data,
        data:users[0]
      });
    } catch (error) {
      res.status(500).send({
        message: error.message,
      });
    }
};
exports.findOne = async (req, res) => {
  try {
    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    const id = req.params.id;
    const data = await db2[req.params.document].findAll({
      where: {
          id: id, status:1
        },
      attributes: {exclude :['createdAt','updatedAt']}
    }
      );
    if (data) {
      res.status(200).send({
        status:200,
        message:'Success',
        output:data
        });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot find with id : ${id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.update = async (req, res) => {
  try {
    const id = req.params.id;
    const num = await db2[req.params.document].update(req.body, {
      where: { id: id },
    });
    if (num == 1) {
      res.status(200).send({
        status:200,
        message: "Updated successfully."
      });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot update with id : ${id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.delete = async (req, res) => {
  const RoleData = {
    status: 0,
  }
  try {
    const id = req.params.id;

    console.log("id111", id);
    const num = await db2[req.params.document].update(RoleData, {
      where: {
        id:id
    },
    });
    if (num == 1) {
      res.status(200).send({
        status:200,
        message: "Deleted successfully!"
      });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot delete with id : ${id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};

// Separate Team List ---->>> Designation Wise
exports.getTeamList = async (req, res) => {
  try {
    const created_id = req.user.id
    const created_by = created_id.id
    console.log('created_by', created_by);

    let thisQuery = ` SELECT us1.team_leader as team_leader_id, rol.role_name as role_name, us.designation as role_id, CONCAT(us.first_name,' ', IFNULL(us.last_name, '')) as team_leader_name, GROUP_CONCAT(distinct CONCAT(us1.id)) as user_id, GROUP_CONCAT( CONCAT(us1.first_name,' ',IFNULL(us1.last_name,''),'-',us1.id)) as user_name
    FROM lz_user as us
    LEFT JOIN lz_user as us1 on (us.id = us1.team_leader)
    LEFT JOIN lz_roles as rol on (rol.id = us.designation)
    where us.status = 1 and us1.id IS NOT NULL and us1.team_leader != 1 and us.designation IS NOT NULL and us.designation = 2
    group by us1.team_leader
    `

    let thisQuery2 = ` SELECT us2.portfolio_head as team_leader_id, rol.role_name as role_name, us.designation as role_id, CONCAT(us.first_name,' ', IFNULL(us.last_name, '')) as team_leader_name, GROUP_CONCAT(distinct CONCAT(us2.id)) as user_id, GROUP_CONCAT( CONCAT(us2.first_name,' ',IFNULL(us2.last_name,''),'-',us2.id)) as user_name
    FROM lz_user as us
    LEFT JOIN lz_user as us2 on (us.id = us2.portfolio_head)
    LEFT JOIN lz_roles as rol on (rol.id = us.designation)
    where us.status = 1 and us2.id IS NOT NULL and us2.portfolio_head != 1 and us.designation IS NOT NULL and us.designation = 3
    group by us2.portfolio_head
    `

    let thisQuery1 = `SELECT us.id as team_leader_id, rol.role_name as role_name, us.designation as role_id, CONCAT(us.first_name,' ', IFNULL(us.last_name, '')) as team_leader_name, GROUP_CONCAT(distinct CONCAT(user.id)) as user_id, GROUP_CONCAT( CONCAT(user.first_name,' ',IFNULL(user.last_name,''),'-',user.id)) as user_name 
    FROM lz_user as user 
    left join lz_user as us on (us.designation = 1) 
    LEFT JOIN lz_roles as rol on (rol.id = us.designation)
    where us.status = 1 and user.designation != 1 and user.status = 1 and us.designation IS NOT NULL and us.designation = 1
    group by us.id
    `

    const dataFromTeam = await db2.sequelize.query(thisQuery);
    const dataFromAdmin = await db2.sequelize.query(thisQuery1);
    const dataFromSubTl = await db2.sequelize.query(thisQuery2);

    res.status(200).send({
        message: "Team List",
        status: 200,
        // output: contactWithdata[0] ?? [],
        output: [...dataFromAdmin[0],...dataFromTeam[0],...dataFromSubTl[0]] ?? []
    })
  }
  catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};


// Team List
// exports.getTeamList = async (req, res) => {
//   try {
//     const created_by = req.user.id
//     console.log('created_by', created_by.id);

//       let thisQuery = ` SELECT us1.team_leader as team_leader_id, CONCAT(us.first_name) as team_leader_name, GROUP_CONCAT(distinct CONCAT(us1.id)) as user_id, GROUP_CONCAT( CONCAT(us1.first_name,' ',IFNULL(us.last_name,''),'-',us1.id)) as user_name
//       FROM lz_user as us
//       LEFT JOIN lz_user as us1 on (us.id = us1.team_leader)
//       where us.status = 1 and us1.id IS NOT NULL and us1.team_leader != 1
//       group by us1.team_leader
//       `

//       let thisQuery2 = ` SELECT us2.portfolio_head as team_leader_id, CONCAT(us.first_name) as team_leader_name, GROUP_CONCAT(distinct CONCAT(us2.id)) as user_id, GROUP_CONCAT( CONCAT(us2.first_name,' ',IFNULL(us2.last_name,''),'-',us2.id)) as user_name
//       FROM lz_user as us
//       LEFT JOIN lz_user as us2 on (us.id = us2.portfolio_head)
//       where us.status = 1 and us2.id IS NOT NULL
//       group by us2.portfolio_head
//       `

//       let thisQuery1 = `SELECT us.id as team_leader_id, CONCAT(us.first_name) as team_leader_name, GROUP_CONCAT(distinct CONCAT(user.id)) as user_id, GROUP_CONCAT( CONCAT(user.first_name,' ',IFNULL(user.last_name,''),'-',user.id)) as user_name 
//       FROM lz_user as user 
//       left join lz_user as us on (us.id = 1) 
//       where user.id != 1 and user.status = 1 `

//       const dataFromTeam = await db2.sequelize.query(thisQuery);
//       const dataFromAdmin = await db2.sequelize.query(thisQuery1);
//       const dataFromSubTl = await db2.sequelize.query(thisQuery2);

//       const aaa = dataFromTeam[0]
//       const bbb = dataFromAdmin[0][0]
//       const ccc = dataFromSubTl[0]

//       console.log("subTLLLLLLL", ccc);
//       let contactWithdata = [];
//       for(let i=0; aaa.length > i;i++) {

//       let dataPush = [bbb, ...aaa, ...ccc];
//       contactWithdata.push(dataPush);
//       }

//       res.status(200).send({
//           message: "Team List",
//           status: 200,
//           output: contactWithdata[0] ?? [],
//       })
//   }
//   catch (error) {
//       console.error(error);
//       res.status(500).json({ message: 'Internal Server Error' });
//   }
// };


// LIVE >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>.

// exports.getTeamList = async (req, res) => {
//   try {
//     const created_by = req.user.id
//     console.log('created_by', created_by.id);

//       let thisQuery = ` SELECT us1.team_leader as team_leader_id, us.designation as role_id, CONCAT(us.first_name) as team_leader_name, GROUP_CONCAT(distinct CONCAT(us1.id)) as user_id, GROUP_CONCAT( CONCAT(us1.first_name,' ',IFNULL(us1.last_name,''),'-',us1.id)) as user_name
//       FROM lz_user as us
//       LEFT JOIN lz_user as us1 on (us.id = us1.team_leader)
//       where us.status = 1 and us1.id IS NOT NULL and (us1.team_leader != 1 OR us1.team_leader = ${created_by} OR us1.portfolio_head =${created_by})
//       group by us1.team_leader
//       `

//       let thisQuery2 = ` SELECT us2.portfolio_head as team_leader_id, us.designation as role_id, CONCAT(us.first_name) as team_leader_name, GROUP_CONCAT(distinct CONCAT(us2.id)) as user_id, GROUP_CONCAT( CONCAT(us2.first_name,' ',IFNULL(us2.last_name,''),'-',us2.id)) as user_name
//       FROM lz_user as us
//       LEFT JOIN lz_user as us2 on (us.id = us2.portfolio_head)
//       where us.status = 1 and us2.id IS NOT NULL and (us2.portfolio_head != 1 OR us2.portfolio_head = ${created_by} OR us1.team_leader = ${created_by} )
//       group by us2.portfolio_head
//       `

//       let thisQuery1 = `SELECT us.id as team_leader_id, us.designation as role_id, CONCAT(us.first_name) as team_leader_name, GROUP_CONCAT(distinct CONCAT(user.id)) as user_id, GROUP_CONCAT( CONCAT(user.first_name,' ',IFNULL(user.last_name,''),'-',user.id)) as user_name 
//       FROM lz_user as user 
//       left join lz_user as us on (us.designation = 1) 
//       where user.designation != 1 and user.status = 1 
//       group by us.id
//       `

//       // let thisQuery1 = `SELECT us.id as id, us.designation as designation 
//       // FROM lz_user as us 
//       // group by us.id
//       // `

//       const dataFromTeam = await db2.sequelize.query(thisQuery);
//       const dataFromAdmin = await db2.sequelize.query(thisQuery1);
//       const dataFromSubTl = await db2.sequelize.query(thisQuery2);

//       const aaa = dataFromTeam[0]
//       const bbb = dataFromAdmin[0]
//       const ccc = dataFromSubTl[0]

//       let contactWithdata = [];
//       for(let i=0; aaa.length > i;i++) {

//       let dataPush = [...bbb, ...aaa, ...ccc];
//       contactWithdata.push(dataPush);
//       }

//       res.status(200).send({
//           message: "Team List",
//           status: 200,
//           output: contactWithdata[0] ?? [],
//       })
//   }
//   catch (error) {
//       console.error(error);
//       res.status(500).json({ message: 'Internal Server Error' });
//   }
// };
