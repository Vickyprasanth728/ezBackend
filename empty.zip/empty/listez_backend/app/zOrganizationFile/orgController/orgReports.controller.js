const db2 = require("../orgModel/orgIndex.js");
const db = require("../../models");
const Op = db2.Sequelize.Op;
const Moment = require('moment')
const dbConfig = require("../../config/db.config.js");
const modulesModel = require("../../models/modules.model.js");
const DbName = dbConfig.DB_DATABASE

const datebetween = async (queryString) => {
  let dateBetween;

  if (queryString.filter_by == '' || queryString.filter_by == undefined ) {
    dateBetween = ` `
  }
  if (queryString.filter_by == 1) {
    dateBetween = ` and (DATE(c.created_at) = DATE(NOW())) `
  }
  else if (queryString.filter_by == 2) {
    dateBetween = ` and (DATE(c.created_at) = DATE(NOW())-1) `
  }
  else if (queryString.filter_by == 3) {
    dateBetween = ` and (c.created_at >= curdate() - INTERVAL DAYOFWEEK(curdate())+6 DAY AND c.created_at <= curdate() - INTERVAL DAYOFWEEK(curdate())-1 DAY)  `
  }
  else if (queryString.filter_by == 4) {
    dateBetween = ` and (c.created_at >= last_day(curdate() - interval 2 month) + interval 1 day AND c.created_at <= last_day(curdate() - interval 1 month)) `
  }
  else if (queryString.filter_by == 5) {
    dateBetween = ` and (c.created_at >= last_day(curdate() - interval 1 month) + interval 1 day AND c.created_at <= last_day(curdate() - interval 0 month)) `
  }
  else if (queryString.filter_by == 6) {
    dateBetween = ` and (c.created_at >= last_day(curdate() - interval 2 year) + interval 1 day AND c.created_at <= last_day(curdate() - interval 0 year)) `
  }
  else if (queryString.filter_by == 7) {
    dateBetween = ` and (DATE(c.created_at) >= '${queryString.start_date}' AND DATE(c.created_at) <= '${queryString.end_date}') `
  }
  return dateBetween;
}
exports.getLeadsReports = async (req, res) => {
  try {
    const created_id = req.user.id
    const created_by = created_id.id
    console.log('created_by', created_by);

    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    const role = req.user.id
    const role_id = role.designation
    console.log('role_id', role_id);

    const userID = req.params.created_by;
    const teamID = req.params.team_leader;

    const queryString = req.query;

    const timeLimit = req.params.id;

    let thisQuery123 = ` select designation from lz_user where id = ${userID} `
    const adminData = await db2.sequelize.query(thisQuery123);

    const findAdmin = adminData[0][0]?.designation
    console.log('adminData', findAdmin);

    let thisQuery1 = ` `

    if (teamID == 0) {
      if (timeLimit == 1) {
        thisQuery1 += ` SELECT c.* FROM lz_leads as c 
          where c.status= 1 and (DATE(c.created_at) = DATE(NOW())) 
          ${findAdmin == 1 ? `` : ` and FIND_IN_SET(${userID},c.assign_to)>0 `} 
          `
      }
      if (timeLimit == 2) {
        thisQuery1 += ` SELECT c.* FROM lz_leads as c  
          where c.status= 1 and (DATE(c.created_at) = DATE_SUB(CURDATE(), INTERVAL 1 DAY)) 
          ${findAdmin == 1 ? `` : ` and FIND_IN_SET(${userID},c.assign_to)>0 `} 
          `
      }
      if (timeLimit == 3) {
        thisQuery1 += ` SELECT c.*, DAYNAME(c.created_at) as dayname, DATE_FORMAT(c.created_at,'%Y-%m') as date FROM lz_leads as c 
          where c.status= 1 and (c.created_at >= curdate() - INTERVAL DAYOFWEEK(curdate())+6 DAY AND c.created_at < curdate() - INTERVAL DAYOFWEEK(curdate())-1 DAY) 
          ${findAdmin == 1 ? `` : ` and FIND_IN_SET(${userID},c.assign_to)>0 `} 
          GROUP BY DAYNAME(c.created_at) `
      }
      if (timeLimit == 4) {
        thisQuery1 += ` SELECT c.*, DATE_FORMAT(c.created_at,'%Y-%m-%d') as date, MONTHNAME(c.created_at) as month FROM lz_leads as c 
          where c.status= 1 and (c.created_at >= last_day(curdate() - interval 2 month) + interval 1 day AND c.created_at < last_day(curdate() - interval 1 month)) 
          ${findAdmin == 1 ? `` : ` and FIND_IN_SET(${userID},c.assign_to)>0 `} 
          GROUP BY DATE(c.created_at) `
      }
      if (timeLimit == 5) {
        thisQuery1 += ` SELECT c.*, DATE_FORMAT(c.created_at,'%Y-%m-%d') as date, MONTHNAME(c.created_at) as month FROM lz_leads as c 
          where c.status= 1 and (c.created_at >= last_day(curdate() - interval 1 month) + interval 1 day AND c.created_at < last_day(curdate() - interval 0 month)) 
          ${findAdmin == 1 ? `` : ` and FIND_IN_SET(${userID},c.assign_to)>0 `} 
          GROUP BY DATE(c.created_at) `
      }
      if (timeLimit == 6) {
        thisQuery1 += ` SELECT c.*, DATE_FORMAT(c.created_at,'%Y-%m') as date, MONTHNAME(c.created_at) as month FROM lz_leads as c 
          where c.status= 1 and (c.created_at >= last_day(curdate() - interval 2 year) + interval 1 day AND c.created_at < last_day(curdate() - interval 0 year)) 
          ${findAdmin == 1 ? `` : ` and FIND_IN_SET(${userID},c.assign_to)>0 `} 
          GROUP BY MONTH(c.created_at) `
      }
      if (timeLimit == 7) {
        thisQuery1 += ` SELECT c.*, DATE_FORMAT(c.created_at,'%Y-%m-%d') as date FROM lz_leads as c 
          where c.status= 1 and (date(c.created_at) >= '${queryString.start_date}' AND date(c.created_at) <= '${queryString.end_date}') 
          ${findAdmin == 1 ? `` : ` and FIND_IN_SET(${userID},c.assign_to)>0 `} 
          GROUP BY DATE(c.created_at) `
      }
    }
    else if (userID == 0) {
      // Today
      if (timeLimit == 1) {
        thisQuery1 += ` SELECT c.* FROM lz_leads as c 
          LEFT JOIN lz_user as us on (us.id = c.created_by)
          LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
          where c.status= 1 and (DATE(c.created_at) = DATE(NOW())) 
          and FIND_IN_SET(${userID},c.assign_to)>0 OR us.team_leader = ${teamID} OR c.created_by = ${teamID} `
      }
      // Yesterday
      if (timeLimit == 2) {
        thisQuery1 += ` SELECT c.* FROM lz_leads as c 
          LEFT JOIN lz_user as us on (us.id = c.created_by)
          LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
          where c.status= 1 and (DATE(c.created_at) = DATE_SUB(CURDATE(), INTERVAL 1 DAY)) 
          and FIND_IN_SET(${userID},c.assign_to)>0 OR us.team_leader = ${teamID} OR c.created_by = ${teamID} 
          `
      }
      // Last Week
      if (timeLimit == 3) {
        thisQuery1 += ` SELECT  c.*, DAYNAME(c.created_at) as dayname, DATE_FORMAT(c.created_at,'%Y-%m') as date FROM lz_leads as c 
          LEFT JOIN lz_user as us on (us.id = c.created_by)
          LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
          where c.status= 1 and (c.created_at >= curdate() - INTERVAL DAYOFWEEK(curdate())+6 DAY AND c.created_at < curdate() - INTERVAL DAYOFWEEK(curdate())-1 DAY) 
          and FIND_IN_SET(${userID},c.assign_to)>0 OR us.team_leader = ${teamID} OR c.created_by = ${teamID} 
          GROUP BY DAYNAME(c.created_at) `
      }
      // Last Month
      if (timeLimit == 4) {
        thisQuery1 += ` SELECT  c.*, DATE_FORMAT(c.created_at,'%Y-%m-%d') as date, MONTHNAME(c.created_at) as month FROM lz_leads as c 
          LEFT JOIN lz_user as us on (us.id = c.created_by)
          LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
          where c.status= 1 and (c.created_at >= last_day(curdate() - interval 2 month) + interval 1 day AND c.created_at < last_day(curdate() - interval 1 month)) 
          and FIND_IN_SET(${userID},c.assign_to)>0 OR us.team_leader = ${teamID} OR c.created_by = ${teamID}
          GROUP BY DATE(c.created_at) `
      }
      // This Month
      if (timeLimit == 5) {
        thisQuery1 += ` SELECT  c.*, DATE_FORMAT(c.created_at,'%Y-%m-%d') as date, MONTHNAME(c.created_at) as month FROM lz_leads as c 
          LEFT JOIN lz_user as us on (us.id = c.created_by)
          LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
          where c.status= 1 and (c.created_at >= last_day(curdate() - interval 1 month) + interval 1 day AND c.created_at < last_day(curdate() - interval 0 month)) 
          and FIND_IN_SET(${userID},c.assign_to)>0 OR us.team_leader = ${teamID} OR c.created_by = ${teamID}
          GROUP BY DATE(c.created_at) `
      }
      // This Year
      if (timeLimit == 6) {
        thisQuery1 += ` SELECT  c.*, DATE_FORMAT(c.created_at,'%Y-%m') as date, MONTHNAME(c.created_at) as month FROM lz_leads as c 
          LEFT JOIN lz_user as us on (us.id = c.created_by)
          LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
          where c.status= 1 and (c.created_at >= last_day(curdate() - interval 2 year) + interval 1 day AND c.created_at < last_day(curdate() - interval 0 year))
          and FIND_IN_SET(${userID},c.assign_to)>0 OR us.team_leader = ${teamID} OR c.created_by = ${teamID}
          GROUP BY MONTH(c.created_at)
          `
      }

      if (timeLimit == 7) {
        thisQuery1 += ` SELECT  c.*, DATE_FORMAT(c.created_at,'%Y-%m-%d') as date FROM lz_leads as c 
          LEFT JOIN lz_user as us on (us.id = c.created_by)
          LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
          where c.status= 1 and (date(c.created_at) >= '${queryString.start_date}' AND date(c.created_at) <= '${queryString.end_date}') 
          and FIND_IN_SET(${userID},c.assign_to)>0 OR us.team_leader = ${teamID} OR c.created_by = ${teamID}
          GROUP BY DATE(c.created_at) `
      }
    }

    const data = await db2.sequelize.query(thisQuery1);
    console.log("data", thisQuery1);

    const count_filter = (data[0])

    res.status(200).send({
      status: 200,
      message: 'Success',
      count: count_filter.length,
      output: data[0]
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
// Leads
exports.getLeadsReportMasters = async (req, res) => {
  try {
    const module = req.params.moduleId;
    const masterId = req.params.option_type;

    const created_id = req.user.id
    const created_by = created_id.id
    console.log('created_by', created_by);

    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    const role = req.user.id
    const role_id = role.designation
    console.log('role_id', role_id);

    const userID = req.params.created_by;
    const teamID = req.params.team_leader;

    const queryString = req.query;

    let querydatebetween = await datebetween(queryString).then(dateBetween => {
      return dateBetween;
    });
    const timeLimit = req.params.id;

    let thisQuery123 = ` select designation from lz_user where id = ${userID} `
    const adminData = await db2.sequelize.query(thisQuery123);

    let thisQuery1234 = ` select designation from lz_user where id = ${teamID} `
    const adminTeamData = await db2.sequelize.query(thisQuery1234);

    const findAdmin = adminData[0][0]?.designation
    console.log('adminData', findAdmin);

    const findTeamAdmin = adminTeamData[0][0]?.designation
    console.log('findTeamAdmin', findTeamAdmin);

    let thisQuery1 = ` `

    // Lead Masters
    if(module == 1) {
      if (teamID == 0) {
          thisQuery1 += ` SELECT c.*, ls.option_value as lead_source_name, lg.option_value as lead_group_name, pt.option_value as property_type_name, lss.option_value as lead_status_name, lfr.option_value as looking_for_name, con.company_name as builder_name, pa.name_of_building as property_name, ca.locality as locality, lr.country as country, lr.state as state, cou.name as country_name, st.name as state_name, ci.name as city_name, CONCAT(lr.budget_min,'-', IFNULL(lr.budget_max, '')) as budget, ttt.option_value as task_ype_name, CONCAT(con.first_name,' ', IFNULL(con.last_name, '')) as contact_name, con.mobile as mobile, con.email as email, CONCAT(lr.no_of_bedrooms_min,'-', IFNULL(lr.no_of_bedrooms_max, '')) as bedroom_name, CONCAT(lr.built_up_area_min,'-', IFNULL(lr.built_up_area_max, '')) as builtup_area,
          GROUP_CONCAT(distinct CONCAT(pss.option_value),'-',pss.id) as possession_status_name, pri.option_value as priority_name, DATE_FORMAT(c.created_at,'%Y-%m-%d') as created_at, GROUP_CONCAT(distinct CONCAT(us5.first_name,' ', IFNULL(us5.last_name, ''))) as assign_to_name,
          (SELECT reply FROM lz_notes where module_name = 2 and module_id = c.id order by id desc limit 1 ) as last_note,
          (SELECT co.id FROM lz_contacts as co where co.contact_status = 7 and co.id = c.contact_id and co.status = 1) as re_assign
          FROM lz_leads as c
          LEFT JOIN lz_lead_requirements as lr on (c.id = lr.lead_id)
          LEFT JOIN lz_contacts as con on (con.id = c.contact_id)
          LEFT JOIN lz_contact_address as ca on (con.id = ca.contact_id)
          LEFT JOIN lz_properties as p on (c.property_id = p.id)
          LEFT JOIN lz_property_addresses as pa on (c.id = pa.property_id)
          LEFT JOIN lz_tasks as ta on (ta.contact = con.id)
          LEFT JOIN lz_masters as lfr on (c.looking_for = lfr.id)
          LEFT JOIN lz_masters as ls on (c.lead_source = ls.id)
          LEFT JOIN lz_masters as lg on (c.lead_group = lg.id)
          LEFT JOIN lz_masters as pt on (c.property_type = pt.id)
          LEFT JOIN lz_masters as lss on (c.lead_status = lss.id)
          LEFT JOIN lz_masters as ttt on (ta.task_type = ttt.id)
          LEFT JOIN lz_masters as pri on (c.lead_priority = pri.id)
          LEFT JOIN lz_masters as pss on FIND_IN_SET(lr.possession_status,pss.id)>0
          LEFT JOIN ${DbName}.lz_country as cou on (cou.id = lr.country)
          LEFT JOIN ${DbName}.lz_state as st on (st.id = lr.state)
          LEFT JOIN ${DbName}.lz_city as ci on (ci.id = lr.city)
          LEFT JOIN lz_user as us on (us.id = c.created_by)
          LEFT JOIN lz_user as us5 on FIND_IN_SET(us5.id,c.assign_to) > 0 
          LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
          where c.status = 1 ${querydatebetween} and (FIND_IN_SET(${userID},c.assign_to)>0 or c.created_by = ${userID})
          `
      }
    else if (userID == 0) {

      thisQuery1 += ` SELECT c.*, ls.option_value as lead_source_name, lg.option_value as lead_group_name, pt.option_value as property_type_name, lss.option_value as lead_status_name, lfr.option_value as looking_for_name, con.company_name as builder_name, pa.name_of_building as property_name, ca.locality as locality, lr.country as country, lr.state as state, cou.name as country_name, st.name as state_name, ci.name as city_name, CONCAT(lr.budget_min,'-', IFNULL(lr.budget_max, '')) as budget, ttt.option_value as task_ype_name, CONCAT(con.first_name,' ', IFNULL(con.last_name, '')) as contact_name, con.mobile as mobile, con.email as email, CONCAT(lr.no_of_bedrooms_min,'-', IFNULL(lr.no_of_bedrooms_max, '')) as bedroom_name, CONCAT(lr.built_up_area_min,'-', IFNULL(lr.built_up_area_max, '')) as builtup_area,
      GROUP_CONCAT(distinct CONCAT(pss.option_value),'-',pss.id) as possession_status_name, pri.option_value as priority_name, DATE_FORMAT(c.created_at,'%Y-%m-%d') as created_at, GROUP_CONCAT(distinct CONCAT(us5.first_name,' ', IFNULL(us5.last_name, ''))) as assign_to_name,
      (SELECT reply FROM lz_notes where module_name = 2 and module_id = c.id order by id desc limit 1 ) as last_note,
      (SELECT co.id FROM lz_contacts as co where co.contact_status = 7 and co.id = c.contact_id and co.status = 1) as re_assign
      FROM lz_leads as c
      LEFT JOIN lz_lead_requirements as lr on (c.id = lr.lead_id)
      LEFT JOIN lz_contacts as con on (con.id = c.contact_id)
      LEFT JOIN lz_contact_address as ca on (con.id = ca.contact_id)
      LEFT JOIN lz_properties as p on (c.property_id = p.id)
      LEFT JOIN lz_property_addresses as pa on (c.id = pa.property_id)
      LEFT JOIN lz_tasks as ta on (ta.contact = con.id)
      LEFT JOIN lz_masters as lfr on (c.looking_for = lfr.id)
      LEFT JOIN lz_masters as ls on (c.lead_source = ls.id)
      LEFT JOIN lz_masters as lg on (c.lead_group = lg.id)
      LEFT JOIN lz_masters as pt on (c.property_type = pt.id)
      LEFT JOIN lz_masters as lss on (c.lead_status = lss.id)
      LEFT JOIN lz_masters as ttt on (ta.task_type = ttt.id)
      LEFT JOIN lz_masters as pri on (c.lead_priority = pri.id)
      LEFT JOIN lz_masters as pss on FIND_IN_SET(lr.possession_status,pss.id)>0
      LEFT JOIN ${DbName}.lz_country as cou on (cou.id = lr.country)
      LEFT JOIN ${DbName}.lz_state as st on (st.id = lr.state)
      LEFT JOIN ${DbName}.lz_city as ci on (ci.id = lr.city)
      LEFT JOIN lz_user as us on (us.id = c.created_by)
      LEFT JOIN lz_user as us5 on FIND_IN_SET(us5.id,c.assign_to) > 0 
      LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
      where c.status = 1 ${querydatebetween}
      ${findTeamAdmin == 1 ? `` : 
      findTeamAdmin == 2 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or us.team_leader = ${teamID} or us.portfolio_head = ${teamID} or c.created_by = ${userID}) ` : 
      findTeamAdmin == 3 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or us.portfolio_head = ${teamID} or c.created_by = ${userID}) ` : 
      findTeamAdmin == 4 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or c.created_by = ${userID}) ` : ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or c.created_by = ${userID}) ` 
      }
      `
    }
    }
    // Lead Tasks
    if (module == 2) {
      if (teamID == 0) {
        thisQuery1 += ` SELECT t.*, tt.option_value as task_type_name
          FROM lz_tasks as t
          LEFT JOIN lz_leads as l on (t.id = l.contact_id)
          LEFT JOIN lz_contacts as c on (c.id = l.contact_id)
          LEFT JOIN lz_masters as tt on (tt.id = t.task_type)
          where c.status = 1 ${querydatebetween} and (FIND_IN_SET(${userID},c.assign_to)>0 or c.created_by = ${userID}) `
      }
      else if (userID == 0) {
        thisQuery1 += ` SELECT t.*, tt.option_value as task_type_name
          FROM lz_tasks as t
          LEFT JOIN lz_leads as l on (t.id = l.contact_id)
          LEFT JOIN lz_contacts as c on (c.id = l.contact_id)
          LEFT JOIN lz_masters as tt on (tt.id = t.task_type)
          LEFT JOIN lz_user as us on (us.id = c.assign_to)
          LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
          LEFT JOIN lz_user as us2 on (us2.id = us.portfolio_head)
          where c.status = 1 ${querydatebetween} 
          ${findTeamAdmin == 1 ? `` : 
          findTeamAdmin == 2 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or us.team_leader = ${teamID} or us.portfolio_head = ${teamID} or c.created_by = ${userID}) ` : 
          findTeamAdmin == 3 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or us.portfolio_head = ${teamID} or c.created_by = ${userID}) ` : 
          findTeamAdmin == 4 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or c.created_by = ${userID}) ` : ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or c.created_by = ${userID}) ` 
          }
          `
      }
    }
    // Lead CityWise
    if (module == 3) {
      if (teamID == 0) {
        thisQuery1 += ` SELECT c.*, lr2.city as city, ci.name as city_name
          FROM lz_leads as c
          LEFT JOIN lz_lead_requirements as lr2 on (c.id = lr2.lead_id)
          LEFT JOIN ${DbName}.lz_city as ci on (ci.id = lr2.city)
          where c.status = 1 ${querydatebetween} and (FIND_IN_SET(${userID},c.assign_to)>0 or c.created_by = ${userID}) `
      }
      else if (userID == 0) {
        thisQuery1 += ` SELECT c.*, lr2.city as city, ci.name as city_name
          FROM lz_leads as c
          LEFT JOIN lz_lead_requirements as lr2 on (c.id = lr2.lead_id)
          LEFT JOIN ${DbName}.lz_city as ci on (ci.id = lr2.city)
          LEFT JOIN lz_user as us on (us.id = c.assign_to)
          LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
          LEFT JOIN lz_user as us2 on (us2.id = us.portfolio_head)
          where c.status = 1 ${querydatebetween} 
          ${findTeamAdmin == 1 ? `` : 
          findTeamAdmin == 2 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or us.team_leader = ${teamID} or us.portfolio_head = ${teamID} or c.created_by = ${userID}) ` : 
          findTeamAdmin == 3 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or us.portfolio_head = ${teamID} or c.created_by = ${userID}) ` : 
          findTeamAdmin == 4 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or c.created_by = ${userID}) ` : ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or c.created_by = ${userID}) ` 
          }
          `
      }
    }
    // Lead Re-Assign
    if (module == 4) {
      if (teamID == 0) {
        thisQuery1 += ` SELECT c.*, re_ass.option_value as re_assign_name
          FROM lz_leads as c
          LEFT JOIN lz_contacts as con on (con.id = c.contact_id)
          LEFT JOIN lz_masters as re_ass on (re_ass.id = con.contact_status)
          where c.status = 1 ${querydatebetween} and FIND_IN_SET(${userID},c.assign_to)>0 or c.created_by = ${userID} `
      }
      else if (userID == 0) {
        thisQuery1 += ` SELECT c.*, re_ass.option_value as re_assign_name
          FROM lz_leads as c
          LEFT JOIN lz_contacts as con on (con.id = c.contact_id)
          LEFT JOIN lz_masters as re_ass on (re_ass.id = con.contact_status)
          LEFT JOIN lz_user as us on (us.id = c.assign_to)
          LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
          LEFT JOIN lz_user as us2 on (us2.id = us.portfolio_head)
          where c.status = 1 ${querydatebetween} 
          ${findTeamAdmin == 1 ? `` : 
          findTeamAdmin == 2 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or us.team_leader = ${teamID} or us.portfolio_head = ${teamID} or c.created_by = ${teamID}) ` : 
          findTeamAdmin == 3 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or us.portfolio_head = ${teamID} or c.created_by = ${teamID}) ` : 
          findTeamAdmin == 4 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or c.created_by = ${teamID}) ` : ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or c.created_by = ${teamID}) ` 
          } `
      }
    }
    // Lead Lost
    if (module == 5) {
      if (teamID == 0) {
        thisQuery1 += ` SELECT c.*, ll.option_value as lost_lead_name
          FROM lz_leads as c
          LEFT JOIN lz_masters as ll on (ll.id = c.lead_status)
          where c.status = 1 and c.lead_status = 60 ${querydatebetween} and (FIND_IN_SET(${userID},c.assign_to)>0 or c.created_by = ${userID}) `
      }
      else if (userID == 0) {
        thisQuery1 += ` SELECT c.*, ll.option_value as lost_lead_name
          FROM lz_leads as c
          LEFT JOIN lz_masters as ll on (ll.id = c.lead_status)
          LEFT JOIN lz_user as us on (us.id = c.assign_to)
          LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
          LEFT JOIN lz_user as us2 on (us2.id = us.portfolio_head)
          where c.status = 1 and c.lead_status = 60 ${querydatebetween} 
          ${findTeamAdmin == 1 ? `` : 
          findTeamAdmin == 2 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or us.team_leader = ${teamID} or us.portfolio_head = ${teamID} or c.created_by = ${teamID}) ` : 
          findTeamAdmin == 3 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or us.portfolio_head = ${teamID} or c.created_by = ${teamID}) ` : 
          findTeamAdmin == 4 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or c.created_by = ${teamID}) ` : ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or c.created_by = ${teamID}) ` 
          } `
      }
    }
    // Property List
    if(module == 6) {
      if (teamID == 0) {
          thisQuery1 += ` SELECT c.*, ls.option_value as lead_source_name, lg.option_value as lead_group_name, pt.option_value as property_type_name, lss.option_value as lead_status_name, lfr.option_value as looking_for_name, con.company_name as builder_name, pa.name_of_building as property_name, ca.locality as locality, lr.country as country, lr.state as state, cou.name as country_name, st.name as state_name, ci.name as city_name, CONCAT(lr.budget_min,'-', IFNULL(lr.budget_max, '')) as budget, ttt.option_value as task_ype_name, CONCAT(con.first_name,' ', IFNULL(con.last_name, '')) as contact_name, con.mobile as mobile, con.email as email, CONCAT(lr.no_of_bedrooms_min,'-', IFNULL(lr.no_of_bedrooms_max, '')) as bedroom_name, CONCAT(lr.built_up_area_min,'-', IFNULL(lr.built_up_area_max, '')) as builtup_area,
          GROUP_CONCAT(distinct CONCAT(pss.option_value),'-',pss.id) as possession_status_name, pri.option_value as priority_name, DATE_FORMAT(c.created_at,'%Y-%m-%d') as created_at, GROUP_CONCAT(distinct CONCAT(us5.first_name,' ', IFNULL(us5.last_name, ''))) as assign_to_name,
          (SELECT reply FROM lz_notes where module_name = 2 and module_id = c.id order by id desc limit 1 ) as last_note,
          (SELECT co.id FROM lz_contacts as co where co.contact_status = 7 and co.id = c.contact_id and co.status = 1) as re_assign
          FROM lz_leads as c
          LEFT JOIN lz_lead_requirements as lr on (c.id = lr.lead_id)
          LEFT JOIN lz_contacts as con on (con.id = c.contact_id)
          LEFT JOIN lz_contact_address as ca on (con.id = ca.contact_id)
          LEFT JOIN lz_properties as p on (c.property_id = p.id)
          LEFT JOIN lz_property_addresses as pa on (p.id = pa.property_id)
          LEFT JOIN lz_tasks as ta on (ta.contact = con.id)
          LEFT JOIN lz_masters as lfr on (c.looking_for = lfr.id)
          LEFT JOIN lz_masters as ls on (c.lead_source = ls.id)
          LEFT JOIN lz_masters as lg on (c.lead_group = lg.id)
          LEFT JOIN lz_masters as pt on (c.property_type = pt.id)
          LEFT JOIN lz_masters as lss on (c.lead_status = lss.id)
          LEFT JOIN lz_masters as ttt on (ta.task_type = ttt.id)
          LEFT JOIN lz_masters as pri on (c.lead_priority = pri.id)
          LEFT JOIN lz_masters as pss on FIND_IN_SET(lr.possession_status,pss.id)>0
          LEFT JOIN ${DbName}.lz_country as cou on (cou.id = lr.country)
          LEFT JOIN ${DbName}.lz_state as st on (st.id = lr.state)
          LEFT JOIN ${DbName}.lz_city as ci on (ci.id = lr.city)
          LEFT JOIN lz_user as us on (us.id = c.created_by)
          LEFT JOIN lz_user as us5 on FIND_IN_SET(us5.id,c.assign_to) > 0 
          LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
          where c.status = 1 and pa.name_of_building IS NOT NULL ${querydatebetween} and (FIND_IN_SET(${userID},c.assign_to)>0 or c.created_by = ${userID})
          `
      }
    else if (userID == 0) {

      thisQuery1 += ` SELECT c.*, ls.option_value as lead_source_name, lg.option_value as lead_group_name, pt.option_value as property_type_name, lss.option_value as lead_status_name, lfr.option_value as looking_for_name, con.company_name as builder_name, pa.name_of_building as property_name, ca.locality as locality, lr.country as country, lr.state as state, cou.name as country_name, st.name as state_name, ci.name as city_name, CONCAT(lr.budget_min,'-', IFNULL(lr.budget_max, '')) as budget, ttt.option_value as task_ype_name, CONCAT(con.first_name,' ', IFNULL(con.last_name, '')) as contact_name, con.mobile as mobile, con.email as email, CONCAT(lr.no_of_bedrooms_min,'-', IFNULL(lr.no_of_bedrooms_max, '')) as bedroom_name, CONCAT(lr.built_up_area_min,'-', IFNULL(lr.built_up_area_max, '')) as builtup_area,
      GROUP_CONCAT(distinct CONCAT(pss.option_value),'-',pss.id) as possession_status_name, pri.option_value as priority_name, DATE_FORMAT(c.created_at,'%Y-%m-%d') as created_at, GROUP_CONCAT(distinct CONCAT(us5.first_name,' ', IFNULL(us5.last_name, ''))) as assign_to_name,
      (SELECT reply FROM lz_notes where module_name = 2 and module_id = c.id order by id desc limit 1 ) as last_note,
      (SELECT co.id FROM lz_contacts as co where co.contact_status = 7 and co.id = c.contact_id and co.status = 1) as re_assign
      FROM lz_leads as c
      LEFT JOIN lz_lead_requirements as lr on (c.id = lr.lead_id)
      LEFT JOIN lz_contacts as con on (con.id = c.contact_id)
      LEFT JOIN lz_contact_address as ca on (con.id = ca.contact_id)
      LEFT JOIN lz_properties as p on (c.property_id = p.id)
      LEFT JOIN lz_property_addresses as pa on (p.id = pa.property_id)
      LEFT JOIN lz_tasks as ta on (ta.contact = con.id)
      LEFT JOIN lz_masters as lfr on (c.looking_for = lfr.id)
      LEFT JOIN lz_masters as ls on (c.lead_source = ls.id)
      LEFT JOIN lz_masters as lg on (c.lead_group = lg.id)
      LEFT JOIN lz_masters as pt on (c.property_type = pt.id)
      LEFT JOIN lz_masters as lss on (c.lead_status = lss.id)
      LEFT JOIN lz_masters as ttt on (ta.task_type = ttt.id)
      LEFT JOIN lz_masters as pri on (c.lead_priority = pri.id)
      LEFT JOIN lz_masters as pss on FIND_IN_SET(lr.possession_status,pss.id)>0
      LEFT JOIN ${DbName}.lz_country as cou on (cou.id = lr.country)
      LEFT JOIN ${DbName}.lz_state as st on (st.id = lr.state)
      LEFT JOIN ${DbName}.lz_city as ci on (ci.id = lr.city)
      LEFT JOIN lz_user as us on (us.id = c.created_by)
      LEFT JOIN lz_user as us5 on FIND_IN_SET(us5.id,c.assign_to) > 0 
      LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
      where c.status = 1 ${querydatebetween}
      ${findTeamAdmin == 1 ? `` : 
      findTeamAdmin == 2 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or us.team_leader = ${teamID} or us.portfolio_head = ${teamID} or c.created_by = ${userID}) ` : 
      findTeamAdmin == 3 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or us.portfolio_head = ${teamID} or c.created_by = ${userID}) ` : 
      findTeamAdmin == 4 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or c.created_by = ${userID}) ` : ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or c.created_by = ${userID}) ` 
      }
      `
    }
    }

    const filters = req.query;
    // for (key in filters) {
    if (filters.source) {
      thisQuery1 += " and ls.option_value = " + `'${filters.source}'`
    }
    if (filters.looking_for) {
      thisQuery1 += " and lfr.option_value = " + `'${filters.looking_for}'`
    }
    if (filters.lead_group) {
      thisQuery1 += " and lg.option_value = " + `'${filters.lead_group}'`
    }
    if (filters.property_type) {
      thisQuery1 += " and pt.option_value = " + `'${filters.property_type}'`
    }
    if (filters.lead_status) {
      thisQuery1 += " and lss.option_value = " + `'${filters.lead_status}'`
    }
    if (filters.lost_lead) {
      thisQuery1 += " and ll.option_value = " + `'${filters.lost_lead}'`
    }
    if (filters.builder_name) {
      thisQuery1 += " and con.company_name = " + `'${filters.builder_name}'`
    }
    if (filters.re_assign) {
      thisQuery1 += " and con.option_value = " + `'${filters.re_assign}'`
    }
    if (filters.task_type) {
      thisQuery1 += " and tt.option_value = " + `'${filters.task_type}'`
    }
    if (filters.project_name) {
      thisQuery1 += " and pa.name_of_building = " + `'${filters.project_name}'`
    }
    if (filters.locality) {
      thisQuery1 += " and lr.locality = " + `'${filters.locality}'`
    }
    if (filters.country) {
      thisQuery1 += " and cou.name = " + `'${filters.country}'`
    }
    if (filters.state) {
      thisQuery1 += " and st.name = " + `'${filters.state}'`
    }
    if (filters.city) {
      thisQuery1 += " and ci.name = " + `'${filters.city}'`
    }
    if (filters.budget_min && filters.budget_max) {
      thisQuery1 += ` and budget_min and budget_max BETWEEN '${filters.budget_min}' and '${filters.budget_max}' ` 
      // WHERE CategoryID and SupplierID BETWEEN 3 AND 10;
    }

    if(module == 1) {
      thisQuery1 += ` group by c.id `
    }
    if(module == 6) {
      thisQuery1 += ` group by c.id `
    }

    const data = await db2.sequelize.query(thisQuery1);
    console.log("data", thisQuery1);

    res.status(200).send({
      status: 200,
      message: 'Success',
      count: data[0].length,
      output: data[0]
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
// Property
exports.getPropertyReportMasters = async (req, res) => {
  try {
    const module = req.params.moduleId;
    const masterId = req.params.option_type;

    const created_id = req.user.id
    const created_by = created_id.id
    console.log('created_by', created_by);

    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    const role = req.user.id
    const role_id = role.designation
    console.log('role_id', role_id);

    const userID = req.params.created_by;
    const teamID = req.params.team_leader;

    const queryString = req.query;

    let querydatebetween = await datebetween(queryString).then(dateBetween => {
      return dateBetween;
    });
    const timeLimit = req.params.id;

    let thisQuery123 = ` select designation from lz_user where id = ${userID} `
    const adminData = await db2.sequelize.query(thisQuery123);

    let thisQuery1234 = ` select designation from lz_user where id = ${teamID} `
    const adminTeamData = await db2.sequelize.query(thisQuery1234);

    const findAdmin = adminData[0][0]?.designation
    console.log('adminData', findAdmin);

    const findTeamAdmin = adminTeamData[0][0]?.designation
    console.log('findTeamAdmin', findTeamAdmin);

    let thisQuery1 = ` `
    // Project Masters
    if (module == 1) {
      if (teamID == 0) {
        thisQuery1 += ` SELECT con.*, CONCAT(user.first_name,' ', IFNULL(user.last_name, '')) as user_name, ps.option_value as property_status_name, pss.option_value as property_source_name, se.option_value as segment_name, pt.option_value as property_type_name, con.company_name as builder_name, pa.name_of_building as property_name,  CONCAT(con.first_name,' ', IFNULL(con.last_name, '')) as contact_name, GROUP_CONCAT(distinct CONCAT(us2.first_name,' ', IFNULL(us2.last_name, ''))) as assign_to_name, pr.project_unit_type as project_unit_type, pa.locality as locality, pa.country as country, pa.state as state, pa.city as city, cou.name as country_name, st.name as state_name, ci.name as city_name, DATE_FORMAT(c.created_at,'%Y-%m-%d') as created_at
        FROM lz_properties as c
        LEFT JOIN lz_contacts as con on (con.property_id = c.id)
        LEFT JOIN lz_property_addresses as pa on (c.id = pa.property_id)
        LEFT JOIN lz_property_residentials as pr on (pr.property_id = c.id)
        LEFT JOIN lz_masters as pss on (con.source = pss.id)
        LEFT JOIN lz_masters as ps on (con.contact_status = ps.id)
        LEFT JOIN lz_masters as se on (c.segment = se.id)
        LEFT JOIN lz_masters as pt on (c.property_type = pt.id)
        LEFT JOIN lz_user as us2 on FIND_IN_SET(us2.id,c.assign_to) > 0 
        LEFT JOIN lz_user as us on (us.id = c.created_by)
        LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
        LEFT JOIN lz_user as user on (user.id = ${userID})
        LEFT JOIN ${DbName}.lz_country as cou on (cou.id = pa.country)
        LEFT JOIN ${DbName}.lz_state as st on (st.id = pa.state)
        LEFT JOIN ${DbName}.lz_city as ci on (ci.id = pa.city)
        where con.status = 1 ${querydatebetween} and (con.property_id = ${userID}) `
      }
      else if (userID == 0) {
        thisQuery1 += ` SELECT c.*, CONCAT(user.first_name,' ', IFNULL(user.last_name, '')) as user_name, ps.option_value as property_status_name, pss.option_value as property_source_name, se.option_value as segment_name, pt.option_value as property_type_name, con.company_name as builder_name, pa.name_of_building as property_name,  CONCAT(con.first_name,' ', IFNULL(con.last_name, '')) as contact_name, GROUP_CONCAT(distinct CONCAT(us.first_name,' ', IFNULL(us.last_name, ''))) as assign_to_name, pr.project_unit_type as project_unit_type,  pa.locality as locality, pa.country as country, pa.state as state, pa.city as city, cou.name as country_name, st.name as state_name, ci.name as city_name, DATE_FORMAT(c.created_at,'%Y-%m-%d') as created_at
        FROM lz_properties as c
        LEFT JOIN lz_contacts as con on (con.id = c.contact_id)
        LEFT JOIN lz_property_addresses as pa on (c.id = pa.property_id)
        LEFT JOIN lz_property_residentials as pr on (pr.property_id = c.id)
        LEFT JOIN lz_masters as pss on (con.source = pss.id)
        LEFT JOIN lz_masters as ps on (con.contact_status = ps.id)
        LEFT JOIN lz_masters as se on (c.segment = se.id)
        LEFT JOIN lz_masters as pt on (c.property_type = pt.id)
        LEFT JOIN lz_user as us on FIND_IN_SET(us.id,c.assign_to) > 0
        LEFT JOIN lz_user as user on (user.id = ${teamID})
        LEFT JOIN ${DbName}.lz_country as cou on (cou.id = pa.country)
        LEFT JOIN ${DbName}.lz_state as st on (st.id = pa.state)
        LEFT JOIN ${DbName}.lz_city as ci on (ci.id = pa.city)
        where c.status = 1 ${querydatebetween}
        ${findTeamAdmin == 1 ? `` : 
        findTeamAdmin == 2 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or us.team_leader = ${teamID} or us.portfolio_head = ${teamID} or c.created_by = ${teamID}) ` : 
        findTeamAdmin == 3 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or us.portfolio_head = ${teamID} or c.created_by = ${teamID}) ` : 
        findTeamAdmin == 4 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or c.created_by = ${teamID}) ` : ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or c.created_by = ${teamID}) ` } `
      }
    }
    // Project Wise
    if (module == 2) {
      if (teamID == 0) {
        thisQuery1 += ` SELECT con.*, CONCAT(user.first_name,' ', IFNULL(user.last_name, '')) as user_name, ps.option_value as property_status_name, pa.name_of_building as property_name,pa.city as city, ci.name as city_name, CONCAT(con.first_name,' ', IFNULL(con.last_name, '')) as contact_name, pt.option_value as property_type_name, se.option_value as segment_name, GROUP_CONCAT(distinct CONCAT(us3.first_name,' ', IFNULL(us3.last_name, ''))) as assign_to_name
          FROM lz_contacts as con
          LEFT JOIN lz_properties as c on (con.property_id = c.id)
          LEFT JOIN lz_masters as pt on (pt.id = c.property_type)
          LEFT JOIN lz_masters as se on (se.id = c.segment)
          LEFT JOIN lz_masters as pss on (con.source = pss.id)
          LEFT JOIN lz_masters as ps on (con.contact_status = ps.id)
          LEFT JOIN lz_property_addresses as pa on (c.id = pa.property_id)
          LEFT JOIN lz_leads as lr2 on (c.id = lr2.property_id)
          LEFT JOIN lz_user as us3 on FIND_IN_SET(us3.id,c.assign_to) > 0
          LEFT JOIN lz_user as user on (user.id = ${userID})
          LEFT JOIN ${DbName}.lz_city as ci on (ci.id = pa.city)
          where con.status = 1 ${querydatebetween} and (con.property_id = ${userID}) `
      }
      else if (userID == 0) {
        thisQuery1 += ` SELECT c.*, CONCAT(user.first_name,' ', IFNULL(user.last_name, '')) as user_name, ps.option_value as property_status_name, pa.name_of_building as property_name,pa.city as city, ci.name as city_name, CONCAT(con.first_name,' ', IFNULL(con.last_name, '')) as contact_name, pt.option_value as property_type_name, se.option_value as segment_name, GROUP_CONCAT(distinct CONCAT(us3.first_name,' ', IFNULL(us3.last_name, ''))) as assign_to_name
          FROM lz_properties as c
          LEFT JOIN lz_contacts as con on (con.id = c.contact_id)
          LEFT JOIN lz_masters as pt on (pt.id = c.property_type)
          LEFT JOIN lz_masters as se on (se.id = c.segment)
          LEFT JOIN lz_masters as ps on (c.property_status = ps.id)
          LEFT JOIN lz_property_addresses as pa on (c.id = pa.property_id)
          LEFT JOIN lz_leads as lr2 on (c.id = lr2.property_id)
          LEFT JOIN lz_user as us3 on FIND_IN_SET(us3.id,c.assign_to) > 0
          LEFT JOIN lz_user as user on (user.id = ${teamID})
          LEFT JOIN ${DbName}.lz_city as ci on (ci.id = pa.city)
          LEFT JOIN lz_user as us on (us.id = c.assign_to)
          LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
          LEFT JOIN lz_user as us2 on (us2.id = us.portfolio_head)
          where c.status = 1 ${querydatebetween} 
          ${findTeamAdmin == 1 ? `` :
            findTeamAdmin == 2 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or us.team_leader = ${teamID} or us.portfolio_head = ${teamID} or c.created_by = ${teamID}) ` :
              findTeamAdmin == 3 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or us.portfolio_head = ${teamID} or c.created_by = ${teamID} ) ` :
                findTeamAdmin == 4 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or c.created_by = ${teamID} ) ` : ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or c.created_by = ${teamID} ) `
          } `
      }
    }
    // Project CityWise
    if (module == 3) {
      if (teamID == 0) {
        thisQuery1 += ` SELECT con.*, CONCAT(user.first_name,' ', IFNULL(user.last_name, '')) as user_name, pa.name_of_building as property_name, pa.city as city, ci.name as      city_name,
          CONCAT(con.first_name,' ', IFNULL(con.last_name, '')) as contact_name, pt.option_value as property_type_name, se.option_value as segment_name, GROUP_CONCAT(distinct CONCAT(us3.first_name,' ', IFNULL(us3.last_name, ''))) as assign_to_name
          FROM lz_contacts as con
          LEFT JOIN lz_properties as c on (con.property_id = c.id)
          LEFT JOIN lz_masters as pt on (pt.id = c.property_type)
          LEFT JOIN lz_masters as se on (se.id = c.segment)
          LEFT JOIN lz_masters as pss on (con.source = pss.id)
          LEFT JOIN lz_masters as ps on (con.contact_status = ps.id)
          LEFT JOIN lz_property_addresses as pa on (c.id = pa.property_id)
          LEFT JOIN lz_leads as lr2 on (c.id = lr2.property_id)
          LEFT JOIN lz_user as us3 on FIND_IN_SET(us3.id,c.assign_to) > 0
          LEFT JOIN lz_user as user on (user.id = ${userID})
          LEFT JOIN ${DbName}.lz_city as ci on (ci.id = pa.city)
          where con.status = 1 ${querydatebetween} and (con.property_id = ${userID}) `
      }
      else if (userID == 0) {
        thisQuery1 += ` SELECT c.*, CONCAT(user.first_name,' ', IFNULL(user.last_name, '')) as user_name, pa.name_of_building as property_name, pa.city as city, ci.name as      city_name,
          CONCAT(con.first_name,' ', IFNULL(con.last_name, '')) as contact_name, pt.option_value as property_type_name, se.option_value as segment_name, GROUP_CONCAT(distinct CONCAT(us3.first_name,' ', IFNULL(us3.last_name, ''))) as assign_to_name
          FROM lz_properties as c
          LEFT JOIN lz_contacts as con on (con.id = c.contact_id)
          LEFT JOIN lz_masters as pt on (pt.id = c.property_type)
          LEFT JOIN lz_masters as se on (se.id = c.segment)
          LEFT JOIN lz_property_addresses as pa on (c.id = pa.property_id)
          LEFT JOIN lz_leads as lr2 on (c.id = lr2.property_id)
          LEFT JOIN lz_user as us3 on FIND_IN_SET(us3.id,c.assign_to) > 0
          LEFT JOIN lz_user as user on (user.id = ${teamID})
          LEFT JOIN ${DbName}.lz_city as ci on (ci.id = pa.city)
          LEFT JOIN lz_user as us on (us.id = c.assign_to)
          LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
          LEFT JOIN lz_user as us2 on (us2.id = us.portfolio_head)
          where c.status = 1 ${querydatebetween} 
          ${findTeamAdmin == 1 ? `` : 
          findTeamAdmin == 2 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or us.team_leader = ${teamID} or us.portfolio_head = ${teamID} or c.created_by = ${teamID}) ` : 
          findTeamAdmin == 3 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or us.portfolio_head = ${teamID} or c.created_by = ${teamID}) ` : 
          findTeamAdmin == 4 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or c.created_by = ${teamID}) ` : ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or c.created_by = ${teamID}) ` 
          } `
      }
    }
    // Configuration Report
    if (module == 5) {
      if (teamID == 0) {
        thisQuery1 += ` SELECT con.*, REPLACE(JSON_EXTRACT(pr.project_unit_type,'$[0].unit_type'), '\"', '') AS unit_type, CONCAT(user.first_name,' ', IFNULL(user.last_name, '')) as user_name, pa.name_of_building as property_name, pa.city as city, ci.name as      city_name,
          CONCAT(con.first_name,' ', IFNULL(con.last_name, '')) as contact_name, pt.option_value as property_type_name, se.option_value as segment_name, GROUP_CONCAT(distinct CONCAT(us3.first_name,' ', IFNULL(us3.last_name, ''))) as assign_to_name
          FROM lz_contacts as con
          LEFT JOIN lz_properties as c on (con.property_id = c.id)
          LEFT JOIN lz_masters as pt on (pt.id = c.property_type)
          LEFT JOIN lz_masters as se on (se.id = c.segment)
          LEFT JOIN lz_masters as pss on (con.source = pss.id)
          LEFT JOIN lz_masters as ps on (con.contact_status = ps.id)
          LEFT JOIN lz_property_addresses as pa on (c.id = pa.property_id)
          LEFT JOIN lz_property_residentials as pr on (c.id = pr.property_id)
          LEFT JOIN lz_leads as lr2 on (c.id = lr2.property_id)
          LEFT JOIN lz_user as us3 on FIND_IN_SET(us3.id,c.assign_to) > 0
          LEFT JOIN lz_user as user on (user.id = ${userID})
          LEFT JOIN ${DbName}.lz_city as ci on (ci.id = pa.city)
          where con.status = 1 ${querydatebetween} and (con.property_id = ${userID}) `
      }
      else if (userID == 0) {
        thisQuery1 += ` SELECT c.*, REPLACE(JSON_EXTRACT(pr.project_unit_type,'$[0].unit_type'), '\"', '') AS unit_type, CONCAT(user.first_name,' ', IFNULL(user.last_name, '')) as user_name, pa.name_of_building as property_name, pa.city as city, ci.name as      city_name,
          CONCAT(con.first_name,' ', IFNULL(con.last_name, '')) as contact_name, pt.option_value as property_type_name, se.option_value as segment_name, GROUP_CONCAT(distinct CONCAT(us3.first_name,' ', IFNULL(us3.last_name, ''))) as assign_to_name
          FROM lz_properties as c
          LEFT JOIN lz_contacts as con on (con.id = c.contact_id)
          LEFT JOIN lz_masters as pt on (pt.id = c.property_type)
          LEFT JOIN lz_masters as se on (se.id = c.segment)
          LEFT JOIN lz_property_addresses as pa on (c.id = pa.property_id)
          LEFT JOIN lz_property_residentials as pr on (c.id = pr.property_id)
          LEFT JOIN lz_leads as lr2 on (c.id = lr2.property_id)
          LEFT JOIN lz_user as us3 on FIND_IN_SET(us3.id,c.assign_to) > 0
          LEFT JOIN lz_user as user on (user.id = ${teamID})
          LEFT JOIN ${DbName}.lz_city as ci on (ci.id = pa.city)
          LEFT JOIN lz_user as us on (us.id = c.assign_to)
          LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
          LEFT JOIN lz_user as us2 on (us2.id = us.portfolio_head)
          where c.status = 1 ${querydatebetween} 
          ${findTeamAdmin == 1 ? `` : 
          findTeamAdmin == 2 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or us.team_leader = ${teamID} or us.portfolio_head = ${teamID} or c.created_by = ${teamID}) ` : 
          findTeamAdmin == 3 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or us.portfolio_head = ${teamID} or c.created_by = ${teamID}) ` : 
          findTeamAdmin == 4 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or c.created_by = ${teamID}) ` : ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or c.created_by = ${teamID}) ` 
          } `
      }
    }
    const filters = req.query;
    // for (key in filters) {
    // Project Masters M1
    if (filters.property_status) {
      thisQuery1 += " and ps.option_value = " + `'${filters.property_status}'`
    }
    if (filters.source) {
      thisQuery1 += " and pss.option_value = " + `'${filters.source}'`
    }
    // M1
    if (filters.segment) {
      thisQuery1 += " and se.option_value = " + `'${filters.segment}'`
    }
    // M1
    if (filters.property_type) {
      thisQuery1 += " and pt.option_value = " + `'${filters.property_type}'`
    }
    // M1
    if (filters.builder_name) {
      thisQuery1 += " and con.company_name = " + `'${filters.builder_name}'`
    }
    // Project-Wise M2
    if (filters.project_name) {
      thisQuery1 += " and pa.name_of_building = " + `'${filters.project_name}'`
    }
    if (filters.locality) {
      thisQuery1 += " and pa.locality = " + `'${filters.locality}'`
    }
    if (filters.country) {
      thisQuery1 += " and cou.name = " + `'${filters.country}'`
    }
    if (filters.state) {
      thisQuery1 += " and st.name = " + `'${filters.state}'`
    }
    if (filters.city) {
      thisQuery1 += " and ci.name = " + `'${filters.city}'`
    }

    if(module != 2 ) {
      thisQuery1 += ` group by con.id `
    }

    if(module == 2) {
      thisQuery1 += ` group by lr2.id `
    }

    const data = await db2.sequelize.query(thisQuery1);
    console.log("data", thisQuery1);

    res.status(200).send({
      status: 200,
      message: 'Success',
      count: data[0].length,
      output: data[0]
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
// Task
exports.getTaskReportMasters = async (req, res) => {
  try {
    const module = req.params.moduleId;
    console.log("module", module);
    const masterId = req.params.option_type

    const created_id = req.user.id
    const created_by = created_id.id
    console.log('created_by', created_by);

    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    const role = req.user.id
    const role_id = role.designation
    console.log('role_id', role_id);

    const userID = req.params.created_by;
    const teamID = req.params.team_leader;

    const queryString = req.query;

    let querydatebetween = await datebetween(queryString).then(dateBetween => {
      return dateBetween;
    });
    const timeLimit = req.params.id;

    let thisQuery123 = ` select designation from lz_user where id = ${userID} `
    const adminData = await db2.sequelize.query(thisQuery123);

    let thisQuery1234 = ` select designation from lz_user where id = ${teamID} `
    const adminTeamData = await db2.sequelize.query(thisQuery1234);

    const findAdmin = adminData[0][0]?.designation
    console.log('adminData', findAdmin);

    const findTeamAdmin = adminTeamData[0][0]?.designation
    console.log('findTeamAdmin', findTeamAdmin);

    let thisQuery1 = ` `
    // Task Type & status
    if(module == 1) {
      if (teamID == 0) {
        thisQuery1 += ` SELECT c.*, CONCAT(user.first_name,' ', IFNULL(user.last_name, '')) as user_name, ts.option_value as task_status_name, tt.option_value as task_type_name,
        CONCAT(con.first_name,' ', IFNULL(con.last_name, '')) as contact_name, con.email as email, con.mobile as mobile, pa.name_of_building as property_name, GROUP_CONCAT(distinct CONCAT(us2.first_name,' ', IFNULL(us2.last_name, ''))) as assign_to_name, pri.option_value as priority_name, ca.locality as locality, ca.country as country, ca.state as state, ca.city as city, cou.name as country_name, st.name as state_name, ci.name as city_name 
        FROM lz_tasks as c
        LEFT JOIN lz_contacts as con on (con.id = c.contact)
        LEFT JOIN lz_contact_address as ca on (ca.contact_id = con.id)
        LEFT JOIN lz_masters as ts on (c.task_status = ts.id)
        LEFT JOIN lz_masters as tt on (c.task_type = tt.id)
        LEFT JOIN lz_masters as pri on (c.priority = pri.id)
        LEFT JOIN lz_properties as pro on (pro.id = c.project)
        LEFT JOIN lz_property_addresses as pa on (pro.id = pa.property_id)
        LEFT JOIN lz_user as us on (us.id = c.created_by)
        LEFT JOIN ${DbName}.lz_country as cou on (cou.id = ca.country)
        LEFT JOIN ${DbName}.lz_state as st on (st.id = ca.state)
        LEFT JOIN ${DbName}.lz_city as ci on (ci.id = ca.city)
        LEFT JOIN lz_user as user on (user.id = ${userID})
        LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
        LEFT JOIN lz_user as us2 on FIND_IN_SET(us2.id,c.assign_to) > 0 
        where c.status = 1 ${querydatebetween} and (FIND_IN_SET(${userID},c.assign_to)>0 or c.created_by = ${userID}) `
      }
      else if (userID == 0) {
        thisQuery1 += ` SELECT c.*, CONCAT(user.first_name,' ', IFNULL(user.last_name, '')) as user_name, ts.option_value as task_status_name, tt.option_value as task_type_name,
        CONCAT(con.first_name,' ', IFNULL(con.last_name, '')) as contact_name, con.email as email, con.mobile as mobile, pa.name_of_building as property_name, GROUP_CONCAT(distinct CONCAT(us2.first_name,' ', IFNULL(us2.last_name, ''))) as assign_to_name, pri.option_value as priority_name, ca.locality as locality, ca.country as country, ca.state as state, ca.city as city, cou.name as country_name, st.name as state_name, ci.name as city_name 
        FROM lz_tasks as c
        LEFT JOIN lz_contacts as con on (con.id = c.contact)
        LEFT JOIN lz_contact_address as ca on (ca.contact_id = con.id)
        LEFT JOIN lz_masters as ts on (c.task_status = ts.id)
        LEFT JOIN lz_masters as tt on (c.task_type = tt.id)
        LEFT JOIN lz_masters as pri on (c.priority = pri.id)
        LEFT JOIN lz_properties as pro on (pro.id = c.project)
        LEFT JOIN lz_property_addresses as pa on (pro.id = pa.property_id)
        LEFT JOIN lz_user as us on (us.id = c.created_by)
        LEFT JOIN ${DbName}.lz_country as cou on (cou.id = ca.country)
        LEFT JOIN ${DbName}.lz_state as st on (st.id = ca.state)
        LEFT JOIN ${DbName}.lz_city as ci on (ci.id = ca.city)
        LEFT JOIN lz_user as user on (user.id = ${teamID})
        LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
        LEFT JOIN lz_user as us2 on FIND_IN_SET(us2.id,c.assign_to) > 0 
        where c.status = 1 ${querydatebetween} 
        ${findTeamAdmin == 1 ? `` :
            findTeamAdmin == 2 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or us.team_leader = ${teamID} or us.portfolio_head = ${teamID} or c.created_by = ${teamID}) ` :
              findTeamAdmin == 3 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or us.portfolio_head = ${teamID} or c.created_by = ${teamID}) ` :
                findTeamAdmin == 4 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or c.created_by = ${teamID}) ` : ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or c.created_by = ${teamID})  `} `
      }
    }
    // Task Reports Summary
    if (module == 2) {
      if (teamID == 0) {
        thisQuery1 += ` SELECT CONCAT(user.first_name,' ', IFNULL(user.last_name, '')) as user_name,
        COUNT(case when c.task_type ='152' then 1 end) as site_visit_count,
        COUNT(case when c.task_type ='151' then 1 end) as meeting_count,
        COUNT(case when c.task_type ='150' then 1 end) as follow_up_count
        FROM lz_tasks as c
        LEFT JOIN lz_user as user on (user.id = ${userID})
        where c.status = 1 and user.id IS NOT NULL ${querydatebetween} and (c.created_by = ${userID}) `
      }
    else if (userID == 0) {
        thisQuery1 += ` SELECT CONCAT(user.first_name,' ', IFNULL(user.last_name, '')) as team_leader_name, CONCAT(us.first_name,' ', IFNULL(us.last_name, '')) as user_name,
        COUNT(case when task_type ='152' then 1 end) as site_visit_count,
        COUNT(case when task_type ='151' then 1 end) as meeting_count,
        COUNT(case when task_type ='150' then 1 end) as follow_up_count
        FROM lz_tasks as c
        LEFT JOIN lz_user as user on (user.id = ${teamID})
        LEFT JOIN lz_user as us on (us.id = c.created_by)
        LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
        LEFT JOIN lz_user as us2 on (us2.id = us.portfolio_head)
        where c.status = 1 and us.id IS NOT NULL ${querydatebetween} ${findTeamAdmin == 1 ? ` group by us.id ` : `and us.team_leader = ${teamID} or us.portfolio_head = ${teamID} or us.id = ${teamID} group by us.id `} `
    }
    }

    const filters = req.query;
    // for (key in filters) {
    if (filters.task_status) {
      thisQuery1 += " and ts.option_value = " + `'${filters.task_status}'`
    }
    if (filters.task_type) {
      thisQuery1 += " and tt.option_value = " + `'${filters.task_type}'`
    }
    if (filters.priority) {
      thisQuery1 += " and pri.option_value = " + `'${filters.priority}'`
    }
    if (filters.project) {
      thisQuery1 += " and pa.name_of_building = " + `'${filters.project}'`
    }
    if (filters.locality) {
      thisQuery1 += " and ca.locality = " + `'${filters.locality}'`
    }
    if (filters.country) {
      thisQuery1 += " and cou.name = " + `'${filters.country}'`
    }
    if (filters.state) {
      thisQuery1 += " and st.name = " + `'${filters.state}'`
    }
    if (filters.city) {
      thisQuery1 += " and ci.name = " + `'${filters.city}'`
    }

    // thisQuery1 += ` group by c.id `

    if(module != 2) {
      thisQuery1 +=  thisQuery1 += `group by c.id order by c.id desc `
    }

    const data = await db2.sequelize.query(thisQuery1);
    console.log("data", thisQuery1);

    res.status(200).send({
      status: 200,
      message: 'Success',
      count: data[0].length,
      output: data[0]
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
// Transaction
exports.getTransactionReportMasters = async (req, res) => {
  try {
    const module = req.params.moduleId;
    const masterId = req.params.option_type

    const created_id = req.user.id
    const created_by = created_id.id
    console.log('created_by', created_by);

    const organ_id = req.user.id;
    const org_id = organ_id.org_id;
    console.log('organ_id', org_id);

    const role = req.user.id;
    const role_id = role.designation;
    console.log('role_id', role_id);

    const userID = req.params.created_by;
    const teamID = req.params.team_leader;

    const queryString = req.query;

    let querydatebetween = await datebetween(queryString).then(dateBetween => {
      return dateBetween;
    });
    const timeLimit = req.params.id;

    let thisQuery123 = ` select designation from lz_user where id = ${userID} `
    const adminData = await db2.sequelize.query(thisQuery123);

    let thisQuery1234 = ` select designation from lz_user where id = ${teamID} `
    const adminTeamData = await db2.sequelize.query(thisQuery1234);

    const findAdmin = adminData[0][0]?.designation
    console.log('adminData', findAdmin);

    const findTeamAdmin = adminTeamData[0][0]?.designation
    console.log('findTeamAdmin', findTeamAdmin);

    let thisQuery1 = ` `
    // Masters
    if(module == 1) {
      if (teamID == 0) {
        thisQuery1 += ` SELECT c.*, CONCAT(user.first_name,' ', IFNULL(user.last_name, '')) as user_name, ls.option_value as source, CONCAT(con.first_name,' ', IFNULL(con.last_name, '')) as contact_name, con.email as email, con.developer_name as developer_name, con.mobile as mobile, GROUP_CONCAT(distinct CONCAT(us5.first_name,' ', IFNULL(us5.last_name, ''))) as team_leader_name, GROUP_CONCAT(distinct CONCAT(us6.first_name,' ', IFNULL(us6.last_name, ''))) as shared_with_name, GROUP_CONCAT(distinct CONCAT(us7.first_name,' ', IFNULL(us7.last_name, ''))) as closed_by_name, pa.name_of_building as property_name, CONCAT(user.first_name,' ', IFNULL(user.last_name, '')) as created_by_name, pt.option_value as property_type_name, ps.option_value as property_status_name, ca.locality as locality, c.country as country, c.state as state, c.city as city, cou.name as country_name, st.name as state_name, ci.name as city_name
          FROM lz_transactions as c
          LEFT JOIN lz_contacts as con on (c.client_name = con.id)
          LEFT JOIN lz_contact_address as ca on (ca.contact_id = con.id)
          LEFT JOIN lz_leads as lee on (c.lead_id = lee.id)
          LEFT JOIN lz_properties as p on (p.id = c.project_name)
          LEFT JOIN lz_property_addresses as pa on (pa.property_id = p.id)
          LEFT JOIN lz_masters as ls on (c.lead_source = ls.id)
          LEFT JOIN lz_masters as pt on (lee.property_type = ls.id)
          LEFT JOIN lz_masters as ps on (c.project_name = ps.id)
          LEFT JOIN ${DbName}.lz_country as cou on (cou.id = c.country)
          LEFT JOIN ${DbName}.lz_state as st on (st.id = c.state)
          LEFT JOIN ${DbName}.lz_city as ci on (ci.id = c.city)
          LEFT JOIN lz_user as us on (us.id = c.created_by)
          LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
          LEFT JOIN lz_user as us5 on FIND_IN_SET(us5.id,c.team_leader) > 0 
          LEFT JOIN lz_user as us6 on FIND_IN_SET(us6.id,c.shared_with) > 0 
          LEFT JOIN lz_user as us7 on FIND_IN_SET(us7.id,c.closed_by) > 0 
          LEFT JOIN lz_user as user on (user.id = ${userID})
          where c.status = 1 ${querydatebetween} and (FIND_IN_SET(${userID},lee.assign_to)>0 or c.created_by = ${userID})
          `
      }
      else if (userID == 0) {
  
        thisQuery1 += ` SELECT c.*, CONCAT(user.first_name,' ', IFNULL(user.last_name, '')) as user_name, ls.option_value as source, CONCAT(con.first_name,' ', IFNULL(con.last_name, '')) as contact_name, con.email as email, con.developer_name as developer_name, con.mobile as mobile, GROUP_CONCAT(distinct CONCAT(us5.first_name,' ', IFNULL(us5.last_name, ''))) as team_leader_name, GROUP_CONCAT(distinct CONCAT(us6.first_name,' ', IFNULL(us6.last_name, ''))) as shared_with_name, GROUP_CONCAT(distinct CONCAT(us7.first_name,' ', IFNULL(us7.last_name, ''))) as closed_by_name, pa.name_of_building as property_name, CONCAT(user.first_name,' ', IFNULL(user.last_name, '')) as created_by_name, pt.option_value as property_type_name, ps.option_value as property_status_name, ca.locality as locality, c.country as country, c.state as state, c.city as city, cou.name as country_name, st.name as state_name, ci.name as city_name
          FROM lz_transactions as c
          LEFT JOIN lz_contacts as con on (c.client_name = con.id)
          LEFT JOIN lz_contact_address as ca on (ca.contact_id = con.id)
          LEFT JOIN lz_leads as lee on (c.lead_id = lee.id)
          LEFT JOIN lz_properties as p on (p.id = c.project_name)
          LEFT JOIN lz_property_addresses as pa on (pa.property_id = p.id)
          LEFT JOIN lz_masters as ls on (c.lead_source = ls.id)
          LEFT JOIN lz_masters as pt on (p.property_type = pt.id)
          LEFT JOIN lz_masters as ps on (c.project_name = ps.id)
          LEFT JOIN ${DbName}.lz_country as cou on (cou.id = c.country)
          LEFT JOIN ${DbName}.lz_state as st on (st.id = c.state)
          LEFT JOIN ${DbName}.lz_city as ci on (ci.id = c.city)
          LEFT JOIN lz_user as us on (us.id = c.created_by)
          LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
          LEFT JOIN lz_user as us5 on FIND_IN_SET(us5.id,c.team_leader) > 0 
          LEFT JOIN lz_user as us6 on FIND_IN_SET(us6.id,c.shared_with) > 0 
          LEFT JOIN lz_user as us7 on FIND_IN_SET(us7.id,c.closed_by) > 0 
          LEFT JOIN lz_user as user on (user.id = ${teamID})
          where c.status = 1 ${querydatebetween}
          ${findTeamAdmin == 1 ? `` : 
          findTeamAdmin == 2 ? ` and (FIND_IN_SET(${teamID},lee.assign_to)>0 or us.team_leader = ${teamID} or us.portfolio_head = ${teamID} or c.created_by = ${userID}) ` : 
          findTeamAdmin == 3 ? ` and (FIND_IN_SET(${teamID},lee.assign_to)>0 or us.portfolio_head = ${teamID} or c.created_by = ${userID}) ` : 
          findTeamAdmin == 4 ? ` and (FIND_IN_SET(${teamID},lee.assign_to)>0 or c.created_by = ${userID}) ` : ` and (FIND_IN_SET(${teamID},lee.assign_to)>0 or c.created_by = ${userID}) ` 
          }
          ` 
      }
    }
    // Project Wise
    if(module == 2) {
      if (teamID == 0) {
        thisQuery1 += ` SELECT c.*, CONCAT(user.first_name,' ', IFNULL(user.last_name, '')) as user_name, ls.option_value as source, CONCAT(con.first_name,' ', IFNULL(con.last_name, '')) as contact_name, con.email as email, con.mobile as mobile, GROUP_CONCAT(distinct CONCAT(us5.first_name,' ', IFNULL(us5.last_name, ''))) as team_leader_name, GROUP_CONCAT(distinct CONCAT(us6.first_name,' ', IFNULL(us6.last_name, ''))) as shared_with_name, GROUP_CONCAT(distinct CONCAT(us7.first_name,' ', IFNULL(us7.last_name, ''))) as closed_by_name, pa.name_of_building as property_name, CONCAT(user.first_name,' ', IFNULL(user.last_name, '')) as created_by_name, pt.option_value as property_type_name, ps.option_value as property_status_name, ca.locality as locality, c.country as country, c.state as state, c.city as city, cou.name as country_name, st.name as state_name, ci.name as city_name
          FROM lz_transactions as c

          LEFT JOIN lz_contacts as con on (c.client_name = con.id)
          LEFT JOIN lz_contact_address as ca on (ca.contact_id = con.id)
          LEFT JOIN lz_leads as lee on (c.lead_id = lee.id)
          LEFT JOIN lz_properties as p on (c.project_name = p.id)
          LEFT JOIN lz_property_addresses as pa on (pa.property_id = p.id)
          LEFT JOIN lz_masters as ls on (c.lead_source = ls.id)
          LEFT JOIN lz_masters as pt on (lee.property_type = ls.id)
          LEFT JOIN lz_masters as ps on (c.project_name = ps.id)
          LEFT JOIN ${DbName}.lz_country as cou on (cou.id = c.country)
          LEFT JOIN ${DbName}.lz_state as st on (st.id = c.state)
          LEFT JOIN ${DbName}.lz_city as ci on (ci.id = c.city)
          LEFT JOIN lz_user as us on (us.id = c.created_by)
          LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
          LEFT JOIN lz_user as user on (user.id = ${userID})
          LEFT JOIN lz_user as us5 on FIND_IN_SET(us5.id,c.team_leader) > 0 
          LEFT JOIN lz_user as us6 on FIND_IN_SET(us6.id,c.shared_with) > 0 
          LEFT JOIN lz_user as us7 on FIND_IN_SET(us7.id,c.closed_by) > 0 
          where c.status = 1 ${querydatebetween} and (FIND_IN_SET(${userID},lee.assign_to)>0 or c.created_by = ${userID}) `
      }
      else if (userID == 0) {
        thisQuery1 += ` SELECT c.*, CONCAT(user.first_name,' ', IFNULL(user.last_name, '')) as user_name, ls.option_value as source, CONCAT(con.first_name,' ', IFNULL(con.last_name, '')) as contact_name, con.email as email, con.mobile as mobile, GROUP_CONCAT(distinct CONCAT(us5.first_name,' ', IFNULL(us5.last_name, ''))) as team_leader_name, GROUP_CONCAT(distinct CONCAT(us6.first_name,' ', IFNULL(us6.last_name, ''))) as shared_with_name, GROUP_CONCAT(distinct CONCAT(us7.first_name,' ', IFNULL(us7.last_name, ''),'-',us7.id)) as closed_by_name, pa.name_of_building as property_name, CONCAT(user.first_name,' ', IFNULL(user.last_name, '')) as created_by_name, pt.option_value as property_type_name, ps.option_value as property_status_name, ca.locality as locality, c.country as country, c.state as state, c.city as city, cou.name as country_name, st.name as state_name, ci.name as city_name
          FROM lz_transactions as c

          LEFT JOIN lz_contacts as con on (c.client_name = con.id)
          LEFT JOIN lz_contact_address as ca on (ca.contact_id = con.id)
          LEFT JOIN lz_leads as lee on (c.lead_id = lee.id)
          LEFT JOIN lz_properties as p on (c.project_name = p.id)
          LEFT JOIN lz_property_addresses as pa on (pa.property_id = p.id)
          LEFT JOIN lz_masters as ls on (c.lead_source = ls.id)
          LEFT JOIN lz_masters as pt on (lee.property_type = ls.id)
          LEFT JOIN lz_masters as ps on (c.project_name = ps.id)
          LEFT JOIN ${DbName}.lz_country as cou on (cou.id = c.country)
          LEFT JOIN ${DbName}.lz_state as st on (st.id = c.state)
          LEFT JOIN ${DbName}.lz_city as ci on (ci.id = c.city)
          LEFT JOIN lz_user as us on (us.id = c.created_by)
          LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
          LEFT JOIN lz_user as user on (user.id = ${teamID})
          LEFT JOIN lz_user as us5 on FIND_IN_SET(us5.id,c.team_leader) > 0 
          LEFT JOIN lz_user as us6 on FIND_IN_SET(us6.id,c.shared_with) > 0 
          LEFT JOIN lz_user as us7 on FIND_IN_SET(us7.id,c.closed_by) > 0 
          where c.status = 1 ${querydatebetween}
          ${findTeamAdmin == 1 ? `` : 
          findTeamAdmin == 2 ? ` and (FIND_IN_SET(${teamID},lee.assign_to)>0 or us.team_leader = ${teamID} or us.portfolio_head = ${teamID} or c.created_by = ${userID}) ` : 
          findTeamAdmin == 3 ? ` and (FIND_IN_SET(${teamID},lee.assign_to)>0 or us.portfolio_head = ${teamID} or c.created_by = ${userID}) ` : 
          findTeamAdmin == 4 ? ` and (FIND_IN_SET(${teamID},lee.assign_to)>0 or c.created_by = ${userID}) ` : ` and (FIND_IN_SET(${teamID},lee.assign_to)>0 or c.created_by = ${userID}) ` 
          } `
      }
    }
    // Transaction CityWise
    if(module == 3) {
      if (teamID == 0) {
        thisQuery1 += ` SELECT c.*, CONCAT(user.first_name,' ', IFNULL(user.last_name, '')) as user_name, ls.option_value as source, CONCAT(con.first_name,' ', IFNULL(con.last_name, '')) as contact_name, con.email as email, con.mobile as mobile, GROUP_CONCAT(distinct CONCAT(us5.first_name,' ', IFNULL(us5.last_name, ''))) as team_leader_name, GROUP_CONCAT(distinct CONCAT(us6.first_name,' ', IFNULL(us6.last_name, ''))) as shared_with_name, GROUP_CONCAT(distinct CONCAT(us7.first_name,' ', IFNULL(us7.last_name, ''))) as closed_by_name, ca.locality as city_name, pa.name_of_building as property_name, CONCAT(user.first_name,' ', IFNULL(user.last_name, '')) as created_by_name, ci.name as city_name
          FROM lz_transactions as c
          LEFT JOIN lz_contacts as con on (c.client_name = con.id)
          LEFT JOIN lz_contact_address as ca on (ca.contact_id = con.id)
          LEFT JOIN lz_properties as p on (c.project_name = p.id)
          LEFT JOIN lz_property_addresses as pa on (pa.property_id = p.id)
          LEFT JOIN lz_leads as lee on (c.lead_id = lee.id)
          LEFT JOIN lz_leads as le on (c.lead_id = le.id)
          LEFT JOIN lz_lead_requirements as lr on (lr.lead_id = le.id)
          LEFT JOIN ${DbName}.lz_city as ci on (ci.id = c.city)
          LEFT JOIN lz_user as us on (us.id = c.created_by)
          LEFT JOIN lz_masters as ls on (c.lead_source = ls.id)
          LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
          LEFT JOIN lz_user as user on (user.id = ${userID})
          LEFT JOIN lz_user as us5 on FIND_IN_SET(us5.id,c.team_leader) > 0 
          LEFT JOIN lz_user as us6 on FIND_IN_SET(us6.id,c.shared_with) > 0 
          LEFT JOIN lz_user as us7 on FIND_IN_SET(us7.id,c.closed_by) > 0 
          where c.status = 1 ${querydatebetween} and (FIND_IN_SET(${userID},lee.assign_to)>0 or c.created_by = ${userID})
          `
      }
      else if (userID == 0) {
        thisQuery1 += ` SELECT c.*, CONCAT(user.first_name,' ', IFNULL(user.last_name, '')) as user_name, ls.option_value as source, CONCAT(con.first_name,' ', IFNULL(con.last_name, '')) as contact_name, con.email as email, con.mobile as mobile, GROUP_CONCAT(distinct CONCAT(us5.first_name,' ', IFNULL(us5.last_name, ''))) as team_leader_name, GROUP_CONCAT(distinct CONCAT(us6.first_name,' ', IFNULL(us6.last_name, ''))) as shared_with_name, GROUP_CONCAT(distinct CONCAT(us7.first_name,' ', IFNULL(us7.last_name, ''))) as closed_by_name, ca.locality as city_name, pa.name_of_building as property_name, CONCAT(user.first_name,' ', IFNULL(user.last_name, '')) as created_by_name, ci.name as city_name
          FROM lz_transactions as c
          LEFT JOIN lz_contacts as con on (c.client_name = con.id)
          LEFT JOIN lz_contact_address as ca on (ca.contact_id = con.id)
          LEFT JOIN lz_properties as p on (c.project_name = p.id)
          LEFT JOIN lz_property_addresses as pa on (pa.property_id = p.id)
          LEFT JOIN lz_leads as lee on (c.lead_id = lee.id)
          LEFT JOIN lz_leads as le on (c.lead_id = le.id)
          LEFT JOIN lz_lead_requirements as lr on (lr.lead_id = le.id)
          LEFT JOIN ${DbName}.lz_city as ci on (ci.id = c.city)
          LEFT JOIN lz_user as us on (us.id = c.created_by)
          LEFT JOIN lz_masters as ls on (c.lead_source = ls.id)
          LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
          LEFT JOIN lz_user as user on (user.id = ${teamID})
          LEFT JOIN lz_user as us5 on FIND_IN_SET(us5.id,c.team_leader) > 0 
          LEFT JOIN lz_user as us6 on FIND_IN_SET(us6.id,c.shared_with) > 0 
          LEFT JOIN lz_user as us7 on FIND_IN_SET(us7.id,c.closed_by) > 0 
          where c.status = 1 ${querydatebetween}
          ${findTeamAdmin == 1 ? `` : 
          findTeamAdmin == 2 ? ` and (FIND_IN_SET(${teamID},lee.assign_to)>0 or us.team_leader = ${teamID} or us.portfolio_head = ${teamID} or c.created_by = ${userID}) ` : 
          findTeamAdmin == 3 ? ` and (FIND_IN_SET(${teamID},lee.assign_to)>0 or us.portfolio_head = ${teamID} or c.created_by = ${userID}) ` : 
          findTeamAdmin == 4 ? ` and (FIND_IN_SET(${teamID},lee.assign_to)>0 or c.created_by = ${userID}) ` : ` and (FIND_IN_SET(${teamID},lee.assign_to)>0 or c.created_by = ${userID}) ` 
          } `
      }
    }

    const filters = req.query;
    // for (key in filters) {
    // M1
    if (filters.transaction_source) {
      thisQuery1 += " and ls.option_value = " + `'${filters.transaction_source}'`
    }
    if (filters.property_type) {
      thisQuery1 += " and pt.option_value = " + `'${filters.property_type}'`
    }
    if (filters.property_status) {
      thisQuery1 += " and ps.option_value = " + `'${filters.property_status}'`
    }
    if (filters.locality) {
      thisQuery1 += " and ca.locality = " + `'${filters.locality}'`
    }
    if (filters.state) {
      thisQuery1 += " and st.name = " + `'${filters.state}'`
    }
    if (filters.project_name) {
      thisQuery1 += " and pa.name_of_building = " + `'${filters.project_name}'`
    }
    if (filters.city) {
      thisQuery1 += " and ci.name = " + `'${filters.city}'`
    }

      thisQuery1 += ` group by c.id `

    const data = await db2.sequelize.query(thisQuery1);
    console.log("data", thisQuery1);

    res.status(200).send({
      status: 200,
      message: 'Success',
      count: data[0].length,
      output: data[0]
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
// Finance
exports.getFinanceReportMasters = async (req, res) => {
  try {
    const module = req.params.moduleId;
    const masterId = req.params.option_type;

    const created_id = req.user.id
    const created_by = created_id.id
    console.log('created_by', created_by);

    const organ_id = req.user.id;
    const org_id = organ_id.org_id;
    console.log('organ_id', org_id);

    const role = req.user.id;
    const role_id = role.designation;
    console.log('role_id', role_id);

    const userID = req.params.created_by;
    const teamID = req.params.team_leader;

    const queryString = req.query;

    let querydatebetween = await datebetween(queryString).then(dateBetween => {
      return dateBetween;
    });
    const timeLimit = req.params.id;

    let thisQuery123 = ` select designation from lz_user where id = ${userID} `
    const adminData = await db2.sequelize.query(thisQuery123);

    let thisQuery1234 = ` select designation from lz_user where id = ${teamID} `
    const adminTeamData = await db2.sequelize.query(thisQuery1234);

    const findAdmin = adminData[0][0]?.designation
    console.log('adminData', findAdmin);

    const findTeamAdmin = adminTeamData[0][0]?.designation
    console.log('findTeamAdmin', findTeamAdmin);

    let thisQuery1 = ` `
    // Finance
    if(module == 1) {
      if (teamID == 0) {
        thisQuery1 += ` SELECT c.*, DATE_FORMAT(c.created_at,'%Y-%m-%d') as created_date, et.option_value as expense_name, CONCAT(us.first_name,' ', IFNULL(us.last_name, '')) as created_by_name
          FROM lz_finance_invoice as c
          LEFT JOIN lz_masters as et on (et.id = c.expense_id)
          LEFT JOIN lz_user as us on (us.id = c.created_by)
          LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
          where c.status = 1 ${querydatebetween} and (c.created_by = ${userID}) `
      }
      else if (userID == 0) {
          thisQuery1 += ` SELECT c.*, DATE_FORMAT(c.created_at,'%Y-%m-%d') as created_date, et.option_value as expense_name, CONCAT(us.first_name,' ', IFNULL(us.last_name, '')) as created_by_name
          FROM lz_finance_invoice as c
          LEFT JOIN lz_masters as et on (et.id = c.expense_id)
          LEFT JOIN lz_user as us on (us.id = c.created_by)
          LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
          where c.status = 1 ${querydatebetween}
          ${findTeamAdmin == 1 ? `` : 
          findTeamAdmin == 2 ? ` and (us.team_leader = ${teamID} or us.portfolio_head = ${teamID} or c.created_by = ${teamID}) ` : 
          findTeamAdmin == 3 ? ` and (us.portfolio_head = ${teamID} or c.created_by = ${teamID}) ` : 
          findTeamAdmin == 4 ? ` and (c.created_by = ${teamID}) ` : ` and (c.created_by = ${teamID}) ` 
          } `
      }
    }
    // Finance Reports Summary
    if (module == 2) {
      if (teamID == 0) {
        thisQuery1 += ` SELECT CONCAT(user.first_name,' ', IFNULL(user.last_name, '')) as user_name,
        (SELECT COUNT(lz_transactions.id) FROM lz_transactions LEFT JOIN lz_leads as lee on (lee.id = lz_transactions.lead_id) where lz_transactions.status = 1 ${querydatebetween} and (FIND_IN_SET(${userID},lee.assign_to)>0)) as no_of_transactions,
        (SELECT SUM(lz_transactions.revenue) FROM lz_transactions LEFT JOIN lz_leads as lee on (lee.id = lz_transactions.lead_id) where lz_transactions.status = 1 ${querydatebetween} and (FIND_IN_SET(${userID},lee.assign_to)>0)) as revenue_earned,
        (SELECT SUM(lz_transactions.discount_value) FROM lz_transactions LEFT JOIN lz_leads as lee on (lee.id = lz_transactions.lead_id) where lz_transactions.status = 1 ${querydatebetween} and (FIND_IN_SET(${userID},lee.assign_to)>0)) as discount_offered,
        (SELECT SUM(ed.total_value) FROM lz_expenses as exp LEFT JOIN lz_expense_details as ed on (ed.expense_id = exp.id) where exp.status = 1 ${querydatebetween}) as total_expense
        FROM lz_transactions as c
        LEFT JOIN lz_user as user on (user.id = ${userID})
        LEFT JOIN lz_leads as le on (le.id = c.lead_id)
        where c.status = 1 ${querydatebetween} and (FIND_IN_SET(${userID},le.assign_to)>0) limit 1 `
      }
      else if (userID == 0) {
        thisQuery1 += ` SELECT CONCAT(user.first_name,' ', IFNULL(user.last_name, '')) as team_leader_name, CONCAT(us.first_name,' ', IFNULL(us.last_name, '')) as user_name,
        (SELECT COUNT(lz_transactions.id) FROM lz_transactions LEFT JOIN lz_leads as lee on (lee.id = lz_transactions.lead_id) where lz_transactions.status = 1 ${querydatebetween}   
          ${findTeamAdmin == 1 ? `` : 
          findTeamAdmin == 2 ? ` and (FIND_IN_SET(${teamID},lee.assign_to)>0 or us.team_leader = ${teamID} or us.portfolio_head = ${teamID}) ` : 
          findTeamAdmin == 3 ? ` and (FIND_IN_SET(${teamID},lee.assign_to)>0 or us.portfolio_head = ${teamID}) ` : 
          findTeamAdmin == 4 ? ` and (FIND_IN_SET(${teamID},lee.assign_to)>0) ` : ` and (FIND_IN_SET(${teamID},lee.assign_to)>0) ` 
          }
        ) as no_of_transactions,
        (SELECT SUM(lz_transactions.revenue) FROM lz_transactions LEFT JOIN lz_leads as lee on (lee.id = lz_transactions.lead_id) where lz_transactions.status = 1 ${querydatebetween} 
          ${findTeamAdmin == 1 ? `` : 
          findTeamAdmin == 2 ? ` and (FIND_IN_SET(${teamID},lee.assign_to)>0 or us.team_leader = ${teamID} or us.portfolio_head = ${teamID}) ` : 
          findTeamAdmin == 3 ? ` and (FIND_IN_SET(${teamID},lee.assign_to)>0 or us.portfolio_head = ${teamID}) ` : 
          findTeamAdmin == 4 ? ` and (FIND_IN_SET(${teamID},lee.assign_to)>0) ` : ` and (FIND_IN_SET(${teamID},lee.assign_to)>0) ` 
          }
        ) as revenue_earned,
        (SELECT SUM(lz_transactions.discount_value) FROM lz_transactions LEFT JOIN lz_leads as lee on (lee.id = lz_transactions.lead_id) where lz_transactions.status = 1 ${querydatebetween} 
          ${findTeamAdmin == 1 ? `` : 
          findTeamAdmin == 2 ? ` and (FIND_IN_SET(${teamID},lee.assign_to)>0 or us.team_leader = ${teamID} or us.portfolio_head = ${teamID}) ` : 
          findTeamAdmin == 3 ? ` and (FIND_IN_SET(${teamID},lee.assign_to)>0 or us.portfolio_head = ${teamID}) ` : 
          findTeamAdmin == 4 ? ` and (FIND_IN_SET(${teamID},lee.assign_to)>0) ` : ` and (FIND_IN_SET(${teamID},lee.assign_to)>0) ` 
          }
        ) as discount_offered,
        (SELECT SUM(ed.total_value) 
        FROM lz_transactions as tra 
        LEFT JOIN lz_expenses as exp on (exp.transaction_id = tra.id)
        LEFT JOIN lz_expense_details as ed on (ed.expense_id = exp.id)
        LEFT JOIN lz_leads as le on (le.id = tra.lead_id)
        where exp.status = 1 ${querydatebetween} 
          ${findTeamAdmin == 1 ? `` : 
          findTeamAdmin == 2 ? ` and (FIND_IN_SET(${teamID},le.assign_to)>0 or us.team_leader = ${teamID} or us.portfolio_head = ${teamID}) ` : 
          findTeamAdmin == 3 ? ` and (FIND_IN_SET(${teamID},le.assign_to)>0 or us.portfolio_head = ${teamID}) ` : 
          findTeamAdmin == 4 ? ` and (FIND_IN_SET(${teamID},le.assign_to)>0) ` : ` and (FIND_IN_SET(${teamID},le.assign_to)>0) ` 
          }
        ) as total_expense
        FROM lz_transactions as c
        LEFT JOIN lz_user as user on (user.id = ${teamID})
        LEFT JOIN lz_leads as lea on (lea.id = c.lead_id)
        LEFT JOIN lz_user as us on FIND_IN_SET(us.id,lea.assign_to)>0
        LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
        LEFT JOIN lz_user as us2 on (us2.id = us.portfolio_head)
        where c.status = 1 ${querydatebetween} ${findTeamAdmin == 1 ? ` group by us.id ` : `and us.team_leader = ${teamID} or us.portfolio_head = ${teamID} or us.id = ${teamID} group by us.id `} `
      }
    }

    const filters = req.query;

    if (filters.expenses_type) {
      thisQuery1 += " and et.option_value = " + `'${filters.expenses_type}'`
    }
    if (filters.created_by) {
      thisQuery1 += " and CONCAT(us.first_name,' ', IFNULL(us.last_name, '')) = " + `'${filters.created_by}'`
    }

    if(module != 2) {
      thisQuery1 += `group by c.id order by c.id desc `
    }

    const data = await db2.sequelize.query(thisQuery1);
    console.log("data", thisQuery1);

    res.status(200).send({
      status: 200,
      message: 'Success',
      count: data[0].length,
      output: data[0]
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
// HR
exports.getHRReportMasters = async (req, res) => {
  try {
    const module = req.params.moduleId;
    const masterId = req.params.option_type;
    console.log("moduleeeee", module);

    const created_id = req.user.id
    const created_by = created_id.id
    console.log('created_by', created_by);

    const organ_id = req.user.id;
    const org_id = organ_id.org_id;
    console.log('organ_id', org_id);

    const role = req.user.id;
    const role_id = role.designation;
    console.log('role_id', role_id);

    const userID = req.params.created_by;
    const teamID = req.params.team_leader;

    const queryString = req.query;

    let querydatebetween = await datebetween(queryString).then(dateBetween => {
      return dateBetween;
    });
    const timeLimit = req.params.id;

    let thisQuery123 = ` select designation from lz_user where id = ${userID} `
    const adminData = await db2.sequelize.query(thisQuery123);

    let thisQuery1234 = ` select designation from lz_user where id = ${teamID} `
    const adminTeamData = await db2.sequelize.query(thisQuery1234);

    const findAdmin = adminData[0][0]?.designation
    console.log('adminData', findAdmin);

    const findTeamAdmin = adminTeamData[0][0]?.designation
    console.log('findTeamAdmin', findTeamAdmin);

    let thisQuery1 = ``
    // Attendance Status
    if(module == 1) {
      if (teamID == 0) {
        thisQuery1 += ` SELECT c.*, CONCAT(us.first_name,' ', IFNULL(us.last_name, '')) as user_name, lt.option_value as leave_type_name, atts.option_value as attendance_status_name, upd.gender as gender, gen.option_value as gender_name, uf.branch_name as branch_name
          FROM lz_attendance as c
          LEFT JOIN lz_masters as lt on (lt.id = c.leave_type)
          LEFT JOIN lz_masters as atts on (atts.id = c.attendance_status)
          LEFT JOIN lz_user as us on (us.id = c.user_id)
          LEFT JOIN lz_users_personal_details as upd on (upd.user_id = us.id)
          LEFT JOIN lz_users_finance as uf on (uf.user_id = us.id)
          LEFT JOIN lz_masters as gen on (gen.id = upd.gender)
          LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
          where c.status = 1 ${querydatebetween} and (c.user_id = ${userID}) `
      }
      else if (userID == 0) {
          thisQuery1 += `SELECT c.*, CONCAT(us.first_name,' ', IFNULL(us.last_name, '')) as user_name, lt.option_value as leave_type_name, atts.option_value as attendance_status_name, upd.gender as gender, gen.option_value as gender_name, uf.branch_name as branch_name
          FROM lz_attendance as c
          LEFT JOIN lz_masters as lt on (lt.id = c.leave_type)
          LEFT JOIN lz_masters as atts on (atts.id = c.attendance_status)
          LEFT JOIN lz_user as us on (us.id = c.user_id)
          LEFT JOIN lz_users_personal_details as upd on (upd.user_id = us.id)
          LEFT JOIN lz_users_finance as uf on (uf.user_id = us.id)
          LEFT JOIN lz_masters as gen on (gen.id = upd.gender)
          LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
          where c.status = 1 ${querydatebetween}
          ${findTeamAdmin == 1 ? `` : 
          findTeamAdmin == 2 ? ` and (us.team_leader = ${teamID} or us.portfolio_head = ${teamID} or c.user_id = ${teamID}) ` : 
          findTeamAdmin == 3 ? ` and (us.portfolio_head = ${teamID} or c.user_id = ${teamID}) ` : 
          findTeamAdmin == 4 ? ` and (c.user_id = ${teamID}) ` : ` and (c.user_id = ${teamID}) ` 
          } `
      }
    }
    // Leave Type
    if(module == 2) {
      if (teamID == 0) {
        thisQuery1 += ` SELECT c.*, CONCAT(us.first_name,' ', IFNULL(us.last_name, '')) as user_name, lt.option_value as leave_type_name, atts.option_value as attendance_status_name, upd.gender as gender, gen.option_value as gender_name
          FROM lz_attendance as c
          LEFT JOIN lz_masters as lt on (lt.id = c.leave_type)
          LEFT JOIN lz_masters as atts on (atts.id = c.attendance_status)
          LEFT JOIN lz_user as us on (us.id = c.user_id)
          LEFT JOIN lz_users_personal_details as upd on (upd.user_id = us.id)
          LEFT JOIN lz_masters as gen on (gen.id = upd.gender)
          LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
          where c.status = 1 ${querydatebetween} and atts.option_value = 'Absent' and (c.user_id = ${userID}) `
      }
      else if (userID == 0) {
          thisQuery1 += ` SELECT c.*, CONCAT(us.first_name,' ', IFNULL(us.last_name, '')) as user_name, lt.option_value as leave_type_name, atts.option_value as attendance_status_name, upd.gender as gender, gen.option_value as gender_name
          FROM lz_attendance as c
          LEFT JOIN lz_masters as lt on (lt.id = c.leave_type)
          LEFT JOIN lz_masters as atts on (atts.id = c.attendance_status)
          LEFT JOIN lz_user as us on (us.id = c.user_id)
          LEFT JOIN lz_users_personal_details as upd on (upd.user_id = us.id)
          LEFT JOIN lz_masters as gen on (gen.id = upd.gender)
          LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
          where c.status = 1 ${querydatebetween} and atts.option_value = 'Absent'
          ${findTeamAdmin == 1 ? `` : 
          findTeamAdmin == 2 ? ` and (us.team_leader = ${teamID} or us.portfolio_head = ${teamID} or c.user_id = ${teamID}) ` : 
          findTeamAdmin == 3 ? ` and (us.portfolio_head = ${teamID} or c.user_id = ${teamID}) ` : 
          findTeamAdmin == 4 ? ` and (c.user_id = ${teamID}) ` : ` and (c.user_id = ${teamID}) ` 
          } `
      }
    }
    // Attendance Summary
    if (module == 3) {
      if (teamID == 0) {
        thisQuery1 += ` SELECT CONCAT(user.first_name,' ', IFNULL(user.last_name, '')) as user_name,
        COUNT(case when c.attendance_status ='160' then 1 end) as absent_count,
        COUNT(case when c.attendance_status ='159' then 1 end) as present_count,
        COUNT(case when c.attendance_status ='161' then 1 end) as half_count
        FROM lz_attendance as c
        LEFT JOIN lz_user as user on (user.id = ${userID})
        where c.status = 1 ${querydatebetween} and (user_id = ${userID}) `
      }
    else if (userID == 0) {
        thisQuery1 += ` SELECT CONCAT(user.first_name,' ', IFNULL(user.last_name, '')) as team_leader_name, CONCAT(us.first_name,' ', IFNULL(us.last_name, '')) as user_name,
        COUNT(case when attendance_status ='160' then 1 end) as absent_count,
        COUNT(case when attendance_status ='159' then 1 end) as present_count ,
        COUNT(case when attendance_status ='161' then 1 end) as half_count
        FROM lz_attendance as c
        LEFT JOIN lz_user as user on (user.id = ${teamID})
        LEFT JOIN lz_user as us on (us.id = c.user_id)
        LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
        LEFT JOIN lz_user as us2 on (us2.id = us.portfolio_head)
        where c.status = 1 and us.id IS NOT NULL ${querydatebetween} ${findTeamAdmin == 1 ? ` group by us.id ` : `and us.team_leader = ${teamID} or us.portfolio_head = ${teamID} or us.id = ${teamID} group by us.id `}`
    }
    }
    // Gender, Branches & age
    if(module == 4) {
    if (teamID == 0) {
      thisQuery1 += ` SELECT c.*, CONCAT(us.first_name,' ', IFNULL(us.last_name, '')) as user_name, lt.option_value as leave_type_name, atts.option_value as attendance_status_name, upd.gender as gender, gen.option_value as gender_name, uf.branch_name as branch_name,
      IF(REPLACE(DATE_FORMAT(FROM_DAYS(DATEDIFF(NOW(), us.dob)), '%Y'), '00', '') = null , 0 , REPLACE(DATE_FORMAT(FROM_DAYS(DATEDIFF(NOW(), us.dob)), '%Y'), '00', '')) as dob
        FROM lz_attendance as c
        LEFT JOIN lz_masters as lt on (lt.id = c.leave_type)
        LEFT JOIN lz_masters as atts on (atts.id = c.attendance_status)
        LEFT JOIN lz_user as us on (us.id = c.user_id)
        LEFT JOIN lz_users_personal_details as upd on (upd.user_id = us.id)
        LEFT JOIN lz_users_finance as uf on (uf.user_id = us.id)
        LEFT JOIN lz_masters as gen on (gen.id = upd.gender)
        LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
        where c.status = 1 ${querydatebetween} and (c.user_id = ${userID}) `
    }
    else if (userID == 0) {
        thisQuery1 += `SELECT c.*, CONCAT(us.first_name,' ', IFNULL(us.last_name, '')) as user_name, lt.option_value as leave_type_name, atts.option_value as attendance_status_name, upd.gender as gender, gen.option_value as gender_name, uf.branch_name as branch_name,
        IF(REPLACE(DATE_FORMAT(FROM_DAYS(DATEDIFF(NOW(), us.dob)), '%Y'), '00', '') = null , 0 , REPLACE(DATE_FORMAT(FROM_DAYS(DATEDIFF(NOW(), us.dob)), '%Y'), '00', '')) as dob
        FROM lz_attendance as c
        LEFT JOIN lz_masters as lt on (lt.id = c.leave_type)
        LEFT JOIN lz_masters as atts on (atts.id = c.attendance_status)
        LEFT JOIN lz_user as us on (us.id = c.user_id)
        LEFT JOIN lz_users_personal_details as upd on (upd.user_id = us.id)
        LEFT JOIN lz_users_finance as uf on (uf.user_id = us.id)
        LEFT JOIN lz_masters as gen on (gen.id = upd.gender)
        LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
        where c.status = 1 ${querydatebetween}
        ${findTeamAdmin == 1 ? `` : 
        findTeamAdmin == 2 ? ` and (us.team_leader = ${teamID} or us.portfolio_head = ${teamID} or c.user_id = ${teamID}) ` : 
        findTeamAdmin == 3 ? ` and (us.portfolio_head = ${teamID} or c.user_id = ${teamID}) ` : 
        findTeamAdmin == 4 ? ` and (c.user_id = ${teamID}) ` : ` and (c.user_id = ${teamID}) ` 
        } `
    }
    }
    const filters = req.query;
    // for (key in filters) {
    if (filters.leave_type) {
      thisQuery1 += " and lt.option_value = " + `'${filters.leave_type}' `
    }
    if (filters.attendance_status) {
      thisQuery1 += " and atts.option_value = " + `'${filters.attendance_status}' `
    }
    if (filters.gender) {
      thisQuery1 += " and gen.option_value = " + `'${filters.gender}' `
    }
    if (filters.branch_name) {
      thisQuery1 += " and uf.branch_name = " + `'${filters.branch_name}' `
    }
    if (filters.dob) {
      thisQuery1 += " and IF(REPLACE(DATE_FORMAT(FROM_DAYS(DATEDIFF(NOW(), us.dob)), '%Y'), '00', '') = null , 0 , REPLACE(DATE_FORMAT(FROM_DAYS(DATEDIFF(NOW(), us.dob)), '%Y'), '00', '')) = " + `'${filters.dob}'`
    }

    if(module != 3) {
      thisQuery1 += `group by c.id order by c.id desc `
    }
    // thisQuery1 += ` group by c.id order by c.id desc `


    if(module == 3) {
      thisQuery1 += ``
    }

    const data = await db2.sequelize.query(thisQuery1);

    let thisQuery2 = ` `
    if(teamID == 0) {
      thisQuery2 += ` SELECT c.*, lt.option_value as leave_type_name, atts.option_value as attendance_status_name,
      count(case when c.attendance_status ='160' then 1 end) as absent_count, 
      count(case when c.attendance_status ='159' then 1 end) as present_count,
      count(case when c.attendance_status ='161' then 1 end) as halfday_count,
      count(case when c.leave_type ='180' then 1 end) as sick_leave_count,
      count(case when c.leave_type ='181' then 1 end) as casual_leave_count,
      count(case when c.leave_type ='182' then 1 end) as lop_count,
      count(case when c.leave_type ='161' then 1 end) as paid_leave_count
      FROM lz_attendance as c
      LEFT JOIN lz_masters as lt on (lt.id = c.leave_type)
      LEFT JOIN lz_masters as atts on (atts.id = c.attendance_status)
      LEFT JOIN lz_user as us on (us.id = c.user_id)
      LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
      where c.status = 1 and (c.user_id = ${userID}) `
    }
    else if(userID == 0) {
      thisQuery2 += ` SELECT c.*, lt.option_value as leave_type_name, atts.option_value as attendance_status_name,
      count(case when c.attendance_status ='160' then 1 end) as absent_count, 
      count(case when c.attendance_status ='159' then 1 end) as present_count,
      count(case when c.attendance_status ='161' then 1 end) as halfday_count,
      count(case when c.leave_type ='180' then 1 end) as sick_leave_count,
      count(case when c.leave_type ='181' then 1 end) as casual_leave_count,
      count(case when c.leave_type ='182' then 1 end) as lop_count,
      count(case when c.leave_type ='161' then 1 end) as paid_leave_count
      FROM lz_attendance as c
      LEFT JOIN lz_masters as lt on (lt.id = c.leave_type)
      LEFT JOIN lz_masters as atts on (atts.id = c.attendance_status)
      LEFT JOIN lz_user as us on (us.id = c.user_id)
      LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
      where c.status = 1 
      ${findTeamAdmin == 1 ? `` : 
      findTeamAdmin == 2 ? ` and (us.team_leader = ${teamID} or us.portfolio_head = ${teamID} or c.user_id = ${teamID}) ` : 
      findTeamAdmin == 3 ? ` and (us.portfolio_head = ${teamID} or c.user_id = ${teamID}) ` : 
      findTeamAdmin == 4 ? ` and (c.user_id = ${teamID}) ` : ` and (c.user_id = ${teamID}) ` 
      } `
    }
    const data2 = await db2.sequelize.query(thisQuery2);

    console.log("data", thisQuery1);

    res.status(200).send({
      status: 200,
      message: 'Success',
      // present_count:data2[0][0].present_count ?? [],
      // absent_count:data2[0][0].absent_count ?? [],
      // halfday_count:data2[0][0].halfday_count ?? [],
      // sick_leave_count:data2[0][0].sick_leave_count ?? [],
      // casual_leave_count:data2[0][0].casual_leave_count ?? [],
      // lop_count:data2[0][0].lop_count ?? [],
      // paid_leave_count:data2[0][0].paid_leave_count ?? [],
      count: data[0].length,
      output: data[0]
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
// Contacts
exports.getContactsReportMasters = async (req, res) => {
  try {
    const module = req.params.moduleId;
    const masterId = req.params.option_type;

    const created_id = req.user.id
    const created_by = created_id.id
    console.log('created_by', created_by);

    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    const role = req.user.id
    const role_id = role.designation
    console.log('role_id', role_id);

    const userID = req.params.created_by;
    const teamID = req.params.team_leader;

    const queryString = req.query;

    let querydatebetween = await datebetween(queryString).then(dateBetween => {
      return dateBetween;
    });
    const timeLimit = req.params.id;

    let thisQuery123 = ` select designation from lz_user where id = ${userID} `
    const adminData = await db2.sequelize.query(thisQuery123);

    let thisQuery1234 = ` select designation from lz_user where id = ${teamID} `
    const adminTeamData = await db2.sequelize.query(thisQuery1234);

    const findAdmin = adminData[0][0]?.designation
    console.log('adminData', findAdmin);

    const findTeamAdmin = adminTeamData[0][0]?.designation
    console.log('findTeamAdmin', findTeamAdmin);

    let thisQuery1 = ` `
    // Contact Masters
    if (module == 1) {
      if (teamID == 0) {
        thisQuery1 += ` SELECT c.*, cs.option_value as contact_status_name, CONCAT(c.first_name,' ', IFNULL(c.last_name, '')) as contact_name, DATE_FORMAT(c.created_at,'%Y-%m-%d') as created_at, pas.name_of_building as property_name, cso.option_value as source_name, ct.option_value as contact_type_name, cg.option_value as contact_group_name, gen.option_value as gender_name, nat.option_value as nationality_name, cc.option_value as contact_category_name, GROUP_CONCAT(distinct CONCAT(usz.first_name,' ', IFNULL(usz.last_name, ''))) as assign_to_name, ca.locality as locality, ca.country as country, ca.state as state, ca.city as city, cou.name as country_name, st.name as state_name, ci.name as city_name,
        (SELECT reply FROM lz_notes where module_name = 1 and module_id = c.id order by id desc limit 1) as last_note
        FROM lz_contacts as c
        LEFT JOIN lz_contact_address as ca on (ca.contact_id = c.id)
        LEFT JOIN lz_contact_details as cd on (cd.contact_id = c.id)
        LEFT JOIN lz_properties as p on (p.id = c.property_id)
        LEFT JOIN lz_property_addresses as pas on (pas.property_id = p.id)
        LEFT JOIN lz_masters as ct on (ct.id = c.contact_type)
        LEFT JOIN lz_masters as cc on (cc.id = c.contact_category)
        LEFT JOIN lz_masters as cg on (cg.id = c.contact_group)
        LEFT JOIN lz_masters as cs on (c.contact_status = cs.id)
        LEFT JOIN lz_masters as cso on (c.source = cso.id)
        LEFT JOIN lz_masters as gen on (cd.gender = gen.id)
        LEFT JOIN lz_masters as nat on (cd.nationality = nat.id)
        LEFT JOIN ${DbName}.lz_country as cou on (cou.id = ca.country)
        LEFT JOIN ${DbName}.lz_state as st on (st.id = ca.state)
        LEFT JOIN ${DbName}.lz_city as ci on (ci.id = ca.city)
        LEFT JOIN lz_user as us on FIND_IN_SET(us.id,c.assign_to)>0
        LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)      
        LEFT JOIN lz_user as us2 on (us2.id = us.portfolio_head)
        LEFT JOIN lz_user as usz on FIND_IN_SET(usz.id,c.assign_to) > 0 
        where c.status = 1 ${querydatebetween} and (FIND_IN_SET(${userID},c.assign_to)>0) `
      }
      else if (userID == 0) {
        thisQuery1 += ` SELECT c.*, cs.option_value as contact_status_name, CONCAT(c.first_name,' ', IFNULL(c.last_name, '')) as contact_name, DATE_FORMAT(c.created_at,'%Y-%m-%d') as created_at, pas.name_of_building as property_name, cso.option_value as source_name, ct.option_value as contact_type_name, cg.option_value as contact_group_name, gen.option_value as gender_name, nat.option_value as nationality_name, cc.option_value as contact_category_name, GROUP_CONCAT(distinct CONCAT(usz.first_name,' ', IFNULL(usz.last_name, ''))) as assign_to_name, ca.locality as locality, ca.country as country, ca.state as state, ca.city as city, cou.name as country_name, st.name as state_name, ci.name as city_name,
        (SELECT reply FROM lz_notes where module_name = 1 and module_id = c.id order by id desc limit 1) as last_note
        FROM lz_contacts as c
        LEFT JOIN lz_contact_address as ca on (ca.contact_id = c.id)
        LEFT JOIN lz_contact_details as cd on (cd.contact_id = c.id)
        LEFT JOIN lz_properties as p on (p.id = c.property_id)
        LEFT JOIN lz_property_addresses as pas on (pas.property_id = p.id)
        LEFT JOIN lz_masters as ct on (ct.id = c.contact_type)
        LEFT JOIN lz_masters as cc on (cc.id = c.contact_category)
        LEFT JOIN lz_masters as cg on (cg.id = c.contact_group)
        LEFT JOIN lz_masters as cs on (c.contact_status = cs.id)
        LEFT JOIN lz_masters as cso on (c.source = cso.id)
        LEFT JOIN lz_masters as gen on (cd.gender = gen.id)
        LEFT JOIN lz_masters as nat on (cd.nationality = nat.id)
        LEFT JOIN ${DbName}.lz_country as cou on (cou.id = ca.country)
        LEFT JOIN ${DbName}.lz_state as st on (st.id = ca.state)
        LEFT JOIN ${DbName}.lz_city as ci on (ci.id = ca.city)
        LEFT JOIN lz_user as us on FIND_IN_SET(us.id,c.assign_to)>0
        LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)      
        LEFT JOIN lz_user as us2 on (us2.id = us.portfolio_head)
        LEFT JOIN lz_user as usz on FIND_IN_SET(usz.id,c.assign_to) > 0 
        where c.status = 1 ${querydatebetween}
        ${findTeamAdmin == 1 ? `` : 
        findTeamAdmin == 2 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or us.team_leader = ${teamID} or us.portfolio_head = ${teamID}) ` : 
        findTeamAdmin == 3 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or us.portfolio_head = ${teamID}) ` : 
        findTeamAdmin == 4 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0) ` : ` and (FIND_IN_SET(${teamID},c.assign_to)>0) ` 
        } `
      }
    }
    // Contact CityWise
    if (module == 2) {
      if (teamID == 0) {
        thisQuery1 += ` SELECT c.*, lr2.city as city, ci.name as city_name, DATE_FORMAT(c.created_at,'%Y-%m-%d') as created_date, CONCAT(c.first_name,' ', IFNULL(c.last_name, '')) as contact_name, ct.option_value as contact_type_name, pas.name_of_building as property_name,cso.option_value as source_name,GROUP_CONCAT(distinct CONCAT(usz.first_name,' ', IFNULL(usz.last_name, ''))) as assign_to_name,cs.option_value as contact_status_name,
        (SELECT reply FROM lz_notes where module_name = 1 and module_id = c.id order by id desc limit 1) as last_note
          FROM lz_contacts as c
          LEFT JOIN lz_contact_address as lr2 on (c.id = lr2.contact_id)
          LEFT JOIN lz_properties as p on (p.id = c.property_id)
          LEFT JOIN lz_property_addresses as pas on (pas.property_id = p.id)
          LEFT JOIN lz_masters as cso on (c.source = cso.id)
          LEFT JOIN lz_masters as cs on (c.contact_status = cs.id)
          LEFT JOIN lz_masters as ct on (ct.id = c.contact_type)
          LEFT JOIN ${DbName}.lz_city as ci on (ci.id = lr2.city)
          LEFT JOIN lz_user as usz on FIND_IN_SET(usz.id,c.assign_to) > 0 
          where c.status = 1 ${querydatebetween} and (FIND_IN_SET(${userID},c.assign_to)>0 or c.created_by = ${userID}) `
      }
      else if (userID == 0) {
        thisQuery1 += ` SELECT c.*, lr2.city as city, ci.name as city_name, DATE_FORMAT(c.created_at,'%Y-%m-%d') as created_date,CONCAT(c.first_name,' ', IFNULL(c.last_name, '')) as contact_name, ct.option_value as contact_type_name, pas.name_of_building as property_name,cso.option_value as source_name,GROUP_CONCAT(distinct CONCAT(usz.first_name,' ', IFNULL(usz.last_name, ''))) as assign_to_name,cs.option_value as contact_status_name,
        (SELECT reply FROM lz_notes where module_name = 1 and module_id = c.id order by id desc limit 1) as last_note
          FROM lz_contacts as c
          LEFT JOIN lz_contact_address as lr2 on (c.id = lr2.contact_id)
          LEFT JOIN lz_masters as ct on (ct.id = c.contact_type)
          LEFT JOIN lz_properties as p on (p.id = c.property_id)
          LEFT JOIN lz_property_addresses as pas on (pas.property_id = p.id)
          LEFT JOIN lz_masters as cso on (c.source = cso.id)
          LEFT JOIN lz_masters as cs on (c.contact_status = cs.id)
          LEFT JOIN ${DbName}.lz_city as ci on (ci.id = lr2.city)
          LEFT JOIN lz_user as us on (us.id = c.assign_to)
          LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
          LEFT JOIN lz_user as us2 on (us2.id = us.portfolio_head)
          LEFT JOIN lz_user as usz on FIND_IN_SET(usz.id,c.assign_to) > 0 
          where c.status = 1 ${querydatebetween} 
          ${findTeamAdmin == 1 ? `` : 
          findTeamAdmin == 2 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or us.team_leader = ${teamID} or us.portfolio_head = ${teamID} or c.created_by = ${teamID}) ` : 
          findTeamAdmin == 3 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or us.portfolio_head = ${teamID} or c.created_by = ${teamID}) ` : 
          findTeamAdmin == 4 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or c.created_by = ${teamID}) ` : ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or c.created_by = ${teamID}) ` 
          } `
      }
    }
    // Numbers Of Contacts
    if (module == 3) {
      if (teamID == 0) {
        thisQuery1 += ` SELECT CONCAT(user.first_name,' ', IFNULL(user.last_name, '')) as user_name,
        (SELECT COUNT(id) FROM lz_contacts where status = 1 ${querydatebetween} and (FIND_IN_SET(${userID},assign_to)>0)) as no_of_contacts,
        (SELECT COUNT(id) FROM lz_leads where status = 1 ${querydatebetween} and (FIND_IN_SET(${userID},assign_to)>0)) as no_of_leads,
        (SELECT COUNT(id) FROM lz_transactions where status = 1 ${querydatebetween} and (FIND_IN_SET(${userID},assign_to)>0)) as no_of_transactions,
        (SELECT COUNT(id) FROM lz_tasks where status = 1 ${querydatebetween} and (FIND_IN_SET(${userID},assign_to)>0)) as no_of_tasks,
        (SELECT COUNT(contact_status) FROM lz_contacts where status = 1 ${querydatebetween} and (contact_status = 2 and FIND_IN_SET(${userID},assign_to)>0)) as no_of_new_contacts,
        (SELECT COUNT(id) FROM lz_leads where status = 1 ${querydatebetween} and (lead_status = 55 and FIND_IN_SET(${userID},assign_to)>0)) as no_of_site_visit,
        (SELECT COUNT(id) FROM lz_leads where status = 1 ${querydatebetween} and (lead_status = 57 and FIND_IN_SET(${userID},assign_to)>0)) as no_of_site_visit_completed
        FROM lz_contacts as c
        LEFT JOIN lz_masters as cs on (cs.id = c.contact_status)
        LEFT JOIN lz_user as user on (user.id = ${userID})
        where c.status = 1 limit 1 `
      }
    else if (userID == 0) {
        thisQuery1 += ` SELECT CONCAT(user.first_name,' ', IFNULL(user.last_name, '')) as team_leader_name, CONCAT(us.first_name,' ', IFNULL(us.last_name, '')) as user_name,
        (SELECT COUNT(id) FROM lz_contacts where status = 1 ${querydatebetween} 
        ${findTeamAdmin == 1 ? ` and (FIND_IN_SET(us.id,assign_to)>0) ` : 
          findTeamAdmin == 2 ? ` and (FIND_IN_SET(us.id,assign_to)>0 or us.team_leader = us.id or us.portfolio_head = us.id) ` : 
          findTeamAdmin == 3 ? ` and (FIND_IN_SET(us.id,assign_to)>0 or us.portfolio_head = us.id) ` : 
          findTeamAdmin == 4 ? ` and (FIND_IN_SET(us.id,assign_to)>0) ` : ` and (FIND_IN_SET(us.id,assign_to)>0) ` 
        } 
        ) as no_of_contacts,
        (SELECT COUNT(id) FROM lz_leads where status = 1 ${querydatebetween} 
        ${findTeamAdmin == 1 ? ` and (FIND_IN_SET(us.id,assign_to)>0) ` : 
        findTeamAdmin == 2 ? ` and (FIND_IN_SET(us.id,assign_to)>0 or us.team_leader = us.id or us.portfolio_head = us.id) ` : 
        findTeamAdmin == 3 ? ` and (FIND_IN_SET(us.id,assign_to)>0 or us.portfolio_head = us.id) ` : 
        findTeamAdmin == 4 ? ` and (FIND_IN_SET(us.id,assign_to)>0) ` : ` and (FIND_IN_SET(us.id,assign_to)>0) ` 
        } 
        ) as no_of_leads,
        (SELECT COUNT(lz_transactions.id) FROM lz_transactions LEFT JOIN lz_leads as lee on (lee.id = lz_transactions.lead_id) where lz_transactions.status = 1 ${querydatebetween} 
        ${findTeamAdmin == 1 ? ` and (FIND_IN_SET(us.id,assign_to)>0) ` : 
        findTeamAdmin == 2 ? ` and (FIND_IN_SET(us.id,lee.assign_to)>0 or us.team_leader = us.id or us.portfolio_head = us.id) ` : 
        findTeamAdmin == 3 ? ` and (FIND_IN_SET(us.id,lee.assign_to)>0 or us.portfolio_head = us.id) ` : 
        findTeamAdmin == 4 ? ` and (FIND_IN_SET(us.id,lee.assign_to)>0) ` : ` and (FIND_IN_SET(us.id,assign_to)>0) ` 
        } 
        ) as no_of_transactions,
        (SELECT COUNT(id) FROM lz_tasks where status = 1 ${querydatebetween} 
        ${findTeamAdmin == 1 ? ` and (FIND_IN_SET(us.id,assign_to)>0) ` : 
        findTeamAdmin == 2 ? ` and (FIND_IN_SET(us.id,assign_to)>0 or us.team_leader = us.id or us.portfolio_head = us.id) ` : 
        findTeamAdmin == 3 ? ` and (FIND_IN_SET(us.id,assign_to)>0 or us.portfolio_head = us.id) ` : 
        findTeamAdmin == 4 ? ` and (FIND_IN_SET(us.id,assign_to)>0) ` : ` and (FIND_IN_SET(us.id,assign_to)>0) ` 
        } 
        ) as no_of_tasks,
        (SELECT COUNT(contact_status) FROM lz_contacts where status = 1 ${querydatebetween} and (contact_status = 2 
          ${findTeamAdmin == 1 ? ` and (FIND_IN_SET(us.id,assign_to)>0) ` : 
          findTeamAdmin == 2 ? ` and (FIND_IN_SET(us.id,assign_to)>0 or us.team_leader = us.id or us.portfolio_head = us.id) ` : 
          findTeamAdmin == 3 ? ` and (FIND_IN_SET(us.id,assign_to)>0 or us.portfolio_head = us.id) ` : 
          findTeamAdmin == 4 ? ` and (FIND_IN_SET(us.id,assign_to)>0) ` : ` and (FIND_IN_SET(us.id,assign_to)>0) ` 
          } 
        )) as no_of_new_contacts,
        (SELECT COUNT(id) FROM lz_leads where status = 1 ${querydatebetween} and (lead_status = 55 
          ${findTeamAdmin == 1 ? ` and (FIND_IN_SET(us.id,assign_to)>0) ` : 
          findTeamAdmin == 2 ? ` and (FIND_IN_SET(us.id,assign_to)>0 or us.team_leader = us.id or us.portfolio_head = us.id) ` : 
          findTeamAdmin == 3 ? ` and (FIND_IN_SET(us.id,assign_to)>0 or us.portfolio_head = us.id) ` : 
          findTeamAdmin == 4 ? ` and (FIND_IN_SET(us.id,assign_to)>0) ` : ` and (FIND_IN_SET(us.id,assign_to)>0) ` 
          } 
          )) as no_of_site_visit,
        (SELECT COUNT(id) FROM lz_leads where status = 1 ${querydatebetween} and (lead_status = 57 
          ${findTeamAdmin == 1 ? ` and (FIND_IN_SET(us.id,assign_to)>0) ` : 
          findTeamAdmin == 2 ? ` and (FIND_IN_SET(us.id,assign_to)>0 or us.team_leader = us.id or us.portfolio_head = us.id) ` : 
          findTeamAdmin == 3 ? ` and (FIND_IN_SET(us.id,assign_to)>0 or us.portfolio_head = us.id) ` : 
          findTeamAdmin == 4 ? ` and (FIND_IN_SET(us.id,assign_to)>0) ` : ` and (FIND_IN_SET(us.id,assign_to)>0) ` 
          })) as no_of_site_visit_completed
        FROM lz_contacts as c
        LEFT JOIN lz_masters as cs on (cs.id = c.contact_status)
        LEFT JOIN lz_user as user on (user.id = ${teamID})
        LEFT JOIN lz_user as us on FIND_IN_SET(us.id,c.assign_to)>0
        LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
        LEFT JOIN lz_user as us2 on (us2.id = us.portfolio_head)
        where c.status = 1 and us.id IS NOT NULL ${findTeamAdmin == 1 ? ` group by us.id ` : `and us.team_leader = ${teamID} or us.portfolio_head = ${teamID} or us.id = ${teamID} group by us.id `}`
    }
    }
    // Contact Assign To
    if (module == 4) {
      if (teamID == 0) {
        thisQuery1 += ` SELECT c.*, cs.option_value as contact_status_name, DATE_FORMAT(c.created_at,'%Y-%m-%d') as created_date, pas.name_of_building as property_name, cso.option_value as source_name, ct.option_value as contact_type_name, GROUP_CONCAT(distinct CONCAT(usz.first_name,' ', IFNULL(usz.last_name, ''),'-',us.id)) as assign_to_name,
        CONCAT(user.first_name,' ', IFNULL(user.last_name, '')) as user_name,
        (SELECT reply FROM lz_notes where module_name = 1 and module_id = c.id order by id desc limit 1 ) as last_note
        FROM lz_contacts as c
        LEFT JOIN lz_property_addresses as pas on (pas.property_id = c.property_id)
        LEFT JOIN lz_masters as cs on (c.contact_status = cs.id)
        LEFT JOIN lz_masters as cso on (c.source = cso.id)
        LEFT JOIN lz_masters as ct on (ct.id = c.contact_type)
        LEFT JOIN lz_user as us on (us.id = c.created_by)
        LEFT JOIN lz_user as user on (user.id = ${userID})
        LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
        LEFT JOIN lz_user as usz on FIND_IN_SET(usz.id,c.assign_to) > 0 
        where c.status = 1 ${querydatebetween} and (FIND_IN_SET(${userID},c.assign_to)>0) group by user.id `
      }
      else if (userID == 0) {
        thisQuery1 += ` SELECT c.*, cs.option_value as contact_status_name, DATE_FORMAT(c.created_at,'%Y-%m-%d') as created_date, pas.name_of_building as property_name, cso.option_value as source_name, ct.option_value as contact_type_name, GROUP_CONCAT(distinct CONCAT(usz.first_name,' ', IFNULL(usz.last_name, ''),'-',us.id)) as assign_to_name,
        CONCAT(user.first_name,' ', IFNULL(user.last_name, '')) as user_name,
        (SELECT reply FROM lz_notes where module_name = 1 and module_id = c.id order by id desc limit 1 ) as last_note
        FROM lz_contacts as c
        LEFT JOIN lz_property_addresses as pas on (pas.property_id = c.property_id)
        LEFT JOIN lz_masters as cs on (c.contact_status = cs.id)
        LEFT JOIN lz_masters as cso on (c.source = cso.id)
        LEFT JOIN lz_masters as ct on (ct.id = c.contact_type)
        LEFT JOIN lz_user as us on (us.id = c.created_by)
        LEFT JOIN lz_user as user on (user.id = ${teamID})
        LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
        LEFT JOIN lz_user as usz on FIND_IN_SET(usz.id,c.assign_to) > 0 
        where c.status = 1 ${querydatebetween}
        ${findTeamAdmin == 1 ? `` : 
        findTeamAdmin == 2 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or us.team_leader = ${teamID} or us.portfolio_head = ${teamID}) ` : 
        findTeamAdmin == 3 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or us.portfolio_head = ${teamID}) ` : 
        findTeamAdmin == 4 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0) ` : ` and (FIND_IN_SET(${teamID},c.assign_to)>0) ` 
        } group by us.team_leader `
      }
    }
    const filters = req.query;

    // Contacts Masters M1
    if (filters.contact_type) {
      thisQuery1 += " and ct.option_value = " + `'${filters.contact_type}'`
    }
    if (filters.contact_category) {
      thisQuery1 += " and cc.option_value = " + `'${filters.contact_category}'`
    }
    if (filters.contact_group) {
      thisQuery1 += " and cg.option_value = " + `'${filters.contact_group}'`
    }
    if (filters.contact_status) {
      thisQuery1 += " and cs.option_value = " + `'${filters.contact_status}'`
    }
    if (filters.nationality) {
      thisQuery1 += " and nat.option_value = " + `'${filters.nationality}'`
    }
    if (filters.gender) {
      thisQuery1 += "  and gen.option_value = " + `'${filters.gender}'`
    }
    if (filters.gender) {
      thisQuery1 += "and cd.gender !=0 "
    }
    // Contacts Source M1
    if (filters.source) {
      thisQuery1 += " and cso.option_value = " + `'${filters.source}'`
    }
    // Contacts Assign To M1
    if (filters.assign_to) {
      var a = filters.assign_to;
      var b = a.replace(/[,]/g, ",");
      thisQuery1 += `and CONCAT(',', c.assign_to, ',') REGEXP ',(${a}),' `
    }
    // Contacts CityWise M2
    if (filters.project_name) {
      thisQuery1 += " and pas.name_of_building = " + `'${filters.project_name}'`
    }
    if (filters.company_name) {
      thisQuery1 += " and c.company_name = " + `'${filters.company_name}'`
    }
    if (filters.locality) {
      thisQuery1 += " and ca.locality = " + `'${filters.locality}'`
    }
    if (filters.country) {
      thisQuery1 += " and cou.name = " + `'${filters.country}'`
    }
    if (filters.state) {
      thisQuery1 += " and st.name = " + `'${filters.state}'`
    }
    if (filters.city) {
      thisQuery1 += " and ci.name = " + `'${filters.city}'`
    }


    if (module == 3) {
      thisQuery1 += ` `
    }
    if (module == 1) {
      thisQuery1 += ` group by c.id order by c.id desc `
    }
    if (module == 2) {
      thisQuery1 += ` group by c.id order by c.id desc `
    }
    

    const data = await db2.sequelize.query(thisQuery1);
    console.log("data", thisQuery1);

    res.status(200).send({
      status: 200,
      message: 'Success',
      count: data[0].length,
      output: data[0]
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
// OverAll Count
exports.getReportCount = async (req, res) => {
  try {
    const module = req.params.moduleId;
    const masterId = req.params.option_type;

    const created_id = req.user.id
    const created_by = created_id.id
    console.log('created_by', created_by);

    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    const role = req.user.id
    const role_id = role.designation
    console.log('role_id', role_id);

    const userID = req.params.created_by;
    const teamID = req.params.team_leader;

    const queryString = req.query;

    let querydatebetween = await datebetween(queryString).then(dateBetween => {
      return dateBetween;
    });
    const timeLimit = req.params.id;

    let thisQuery123 = ` select designation from lz_user where id = ${userID} `
    const adminData = await db2.sequelize.query(thisQuery123);

    let thisQuery1234 = ` select designation from lz_user where id = ${teamID} `
    const adminTeamData = await db2.sequelize.query(thisQuery1234);

    const findAdmin = adminData[0][0]?.designation
    console.log('adminData', findAdmin);

    const findTeamAdmin = adminTeamData[0][0]?.designation
    console.log('findTeamAdmin', findTeamAdmin);

    let thisQuery1 = ` `
// TASK
    // Task Status Count
    if (module == 1) {
      if (teamID == 0) {
        thisQuery1 += ` SELECT COUNT(c.task_status) as task_status_count, ts.option_value as task_status_name
        FROM lz_tasks as c
        LEFT JOIN lz_masters as ts on (c.task_status = ts.id)
        LEFT JOIN lz_user as us on (us.id = c.created_by)
        LEFT JOIN lz_user as user on (user.id = ${userID})
        LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
        where c.status = 1 ${querydatebetween} and (FIND_IN_SET(${userID},c.assign_to)>0 or c.created_by = ${userID}) group by ts.option_value `
      }
      else if (userID == 0) {
        thisQuery1 += ` SELECT COUNT(c.task_status) as task_status_count, COUNT(c.task_type) as task_type_count 
        FROM lz_tasks as c
        LEFT JOIN lz_masters as ts on (c.task_status = ts.id)
        LEFT JOIN lz_masters as tt on (c.task_type = tt.id)
        LEFT JOIN lz_user as us on (us.id = c.created_by)
        LEFT JOIN lz_user as user on (user.id = ${teamID})
        LEFT JOIN lz_user as user on (user.id = us.id)
        LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
        where c.status = 1 ${querydatebetween} 
        ${findTeamAdmin == 1 ? `` :
            findTeamAdmin == 2 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or us.team_leader = ${teamID} or us.portfolio_head = ${teamID} or c.created_by = ${teamID}) ` :
              findTeamAdmin == 3 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or us.portfolio_head = ${teamID} or c.created_by = ${teamID}) ` :
                findTeamAdmin == 4 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or c.created_by = ${teamID}) ` : ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or c.created_by = ${teamID}) `} `
      }
    }
    // Task Type Count
    if (module == 2) {
      if (teamID == 0) {
        thisQuery1 += ` SELECT COUNT(c.task_type) as task_status_count, tt.option_value as task_type_name
        FROM lz_tasks as c
        LEFT JOIN lz_masters as tt on (c.task_type = tt.id)
        LEFT JOIN lz_user as us on (us.id = c.created_by)
        LEFT JOIN lz_user as user on (user.id = ${userID})
        LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
        where c.status = 1 ${querydatebetween} and (FIND_IN_SET(${userID},c.assign_to)>0 or c.created_by = ${userID}) group by tt.option_value `
      }
      else if (userID == 0) {
        thisQuery1 += ` SELECT COUNT(c.task_status) as task_status_count, COUNT(c.task_type) as task_type_count 
        FROM lz_tasks as c
        LEFT JOIN lz_masters as ts on (c.task_status = ts.id)
        LEFT JOIN lz_masters as tt on (c.task_type = tt.id)
        LEFT JOIN lz_user as us on (us.id = c.created_by)
        LEFT JOIN lz_user as user on (user.id = ${teamID})
        LEFT JOIN lz_user as user on (user.id = us.id)
        LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
        where c.status = 1 ${querydatebetween} 
        ${findTeamAdmin == 1 ? `` :
            findTeamAdmin == 2 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or us.team_leader = ${teamID} or us.portfolio_head = ${teamID} or c.created_by = ${teamID}) ` :
              findTeamAdmin == 3 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or us.portfolio_head = ${teamID} or c.created_by = ${teamID}) ` :
                findTeamAdmin == 4 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or c.created_by = ${teamID}) ` : ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or c.created_by = ${teamID}) `} `
      }
    }
// HR
    // Attendance Status Count
    if (module == 3) {
      if (teamID == 0) {
        thisQuery1 += ` SELECT COUNT(c.attendance_status) as count, ats.option_value as attendance_status_name
        FROM lz_attendance as c
        LEFT JOIN lz_masters as ats on (c.attendance_status = ats.id)
        LEFT JOIN lz_user as us on (us.id = c.user_id)
        LEFT JOIN lz_user as user on (user.id = ${userID})
        LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
        where c.status = 1 ${querydatebetween} and (c.user_id = ${userID}) group by ats.option_value `
      }
      else if (userID == 0) {
        thisQuery1 += ` SELECT COUNT(c.attendance_status) as count, ats.option_value as attendance_status_name
        FROM lz_attendance as c
        LEFT JOIN lz_masters as ats on (c.attendance_status = ats.id)
        LEFT JOIN lz_user as us on (us.id = c.user_id)
        LEFT JOIN lz_user as user on (user.id = ${teamID})
        LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
        where c.status = 1 ${querydatebetween} 
        ${findTeamAdmin == 1 ? `` :
            findTeamAdmin == 2 ? ` and (us.team_leader = ${teamID} or us.portfolio_head = ${teamID} or c.user_id = ${teamID}) ` :
              findTeamAdmin == 3 ? ` and (us.portfolio_head = ${teamID} or c.user_id = ${teamID}) ` :
                findTeamAdmin == 4 ? ` and (c.user_id = ${teamID}) ` : ` and (c.user_id = ${teamID}) `} group by ats.option_value `
      }
    }
    // Attendance Leave-Type Count
    if (module == 4) {
      if (teamID == 0) {
        thisQuery1 += ` SELECT COUNT(c.leave_type) as count, ats.option_value as leave_type_name, atts.option_value as attendance_status_name
        FROM lz_attendance as c
        LEFT JOIN lz_masters as ats on (c.leave_type = ats.id)
        LEFT JOIN lz_masters as atts on (c.attendance_status = atts.id)
        LEFT JOIN lz_user as us on (us.id = c.user_id)
        LEFT JOIN lz_user as user on (user.id = ${userID})
        LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
        where c.status = 1 and c.leave_type IS NOT NULL
        ${querydatebetween} and (c.user_id = ${userID}) group by ats.option_value `
      }
      else if (userID == 0) {
        thisQuery1 += ` SELECT COUNT(c.leave_type) as count, ats.option_value as leave_type_name, atts.option_value as attendance_status_name
        FROM lz_attendance as c
        LEFT JOIN lz_masters as ats on (c.leave_type = ats.id)
        LEFT JOIN lz_masters as atts on (c.attendance_status = atts.id)
        LEFT JOIN lz_user as us on (us.id = c.user_id)
        LEFT JOIN lz_user as user on (user.id = ${teamID})
        LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
        where c.status = 1 and c.leave_type IS NOT NULL
        ${querydatebetween} 
        ${findTeamAdmin == 1 ? `` :
            findTeamAdmin == 2 ? ` and (us.team_leader = ${teamID} or us.portfolio_head = ${teamID} or c.user_id = ${teamID}) ` :
              findTeamAdmin == 3 ? ` and (us.portfolio_head = ${teamID} or c.user_id = ${teamID}) ` :
                findTeamAdmin == 4 ? ` and (c.user_id = ${teamID}) ` : ` and (c.user_id = ${teamID}) `} group by ats.option_value `
      }
    }
// CONTACT
    // Contact City-Wise
    if (module == 5) {
      if (teamID == 0) {
        thisQuery1 += ` SELECT COUNT(lr2.city) as count, ci.name as name
          FROM lz_contacts as c
          LEFT JOIN lz_contact_address as lr2 on (c.id = lr2.contact_id)
          LEFT JOIN ${DbName}.lz_city as ci on (ci.id = lr2.city)
          LEFT JOIN lz_user as user on (user.id = ${userID})
          where c.status = 1 and ci.status = 1 and ci.id IS NOT NULL ${querydatebetween} and (FIND_IN_SET(${userID},c.assign_to)>0 or c.created_by = ${userID}) group by ci.name `
      }
      else if (userID == 0) {
      thisQuery1 += ` SELECT COUNT(lr2.city) as count, ci.name as name
        FROM lz_contacts as c
        LEFT JOIN lz_contact_address as lr2 on (c.id = lr2.contact_id)
        LEFT JOIN ${DbName}.lz_city as ci on (ci.id = lr2.city)
        LEFT JOIN lz_user as user on (user.id = ${teamID})
        LEFT JOIN lz_user as us on (user.id = us.id)
        LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
        where c.status = 1 and ci.status = 1 and ci.id IS NOT NULL ${querydatebetween} 
        ${findTeamAdmin == 1 ? `` :
            findTeamAdmin == 2 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or us.team_leader = ${teamID} or us.portfolio_head = ${teamID} or c.created_by = ${teamID}) ` :
              findTeamAdmin == 3 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or us.portfolio_head = ${teamID} or c.created_by = ${teamID}) ` :
                findTeamAdmin == 4 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or c.created_by = ${teamID}) ` : ` and (c.created_by = ${teamID}) `} group by ci.name `
      }
    }
    // Contact Assign
    if (module == 6) {
      if (teamID == 0) {
        thisQuery1 += ` SELECT CONVERT(c.assign_to USING utf8) as assign_to, 
          GROUP_CONCAT(distinct CONCAT(us.first_name,' ', IFNULL(us.last_name, ''))) as assign_to_name, CONCAT(user.first_name,' ', IFNULL(user.last_name, '')) as user_name
          FROM lz_contacts as c
          LEFT JOIN lz_contact_address as lr2 on (c.id = lr2.contact_id)
          LEFT JOIN lz_user as user on (user.id = ${userID})
          LEFT JOIN lz_user as us on FIND_IN_SET(us.id,c.assign_to)>0
          where c.status = 1 ${querydatebetween} and (FIND_IN_SET(${userID},c.assign_to)>0 or c.created_by = ${userID}) `
      }
      else if (userID == 0) {
      thisQuery1 += ` SELECT CONVERT(c.assign_to USING utf8) as assign_to, 
        GROUP_CONCAT(distinct CONCAT(us.first_name,' ', IFNULL(us.last_name, ''))) as assign_to_name, CONCAT(user.first_name,' ', IFNULL(user.last_name, '')) as user_name
        FROM lz_contacts as c
        LEFT JOIN lz_contact_address as lr2 on (c.id = lr2.contact_id)
        LEFT JOIN lz_user as user on (user.id = ${teamID})
        LEFT JOIN lz_user as us on (user.id = us.id)
        LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
        where c.status = 1 ${querydatebetween} 
        ${findTeamAdmin == 1 ? `` :
            findTeamAdmin == 2 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or us.team_leader = ${teamID} or us.portfolio_head = ${teamID} or c.created_by = ${teamID}) ` :
              findTeamAdmin == 3 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or us.portfolio_head = ${teamID} or c.created_by = ${teamID}) ` :
                findTeamAdmin == 4 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or c.created_by = ${teamID}) ` : ` and (c.created_by = ${teamID}) `} `
      }
    }
// PROPERTY 
    // Project Wise 
    if (module == 7) {
      if (teamID == 0) {
        thisQuery1 += ` SELECT COUNT(le.property_id) as property_count, lr2.name_of_building as property_name,
          CONCAT(user.first_name,' ', IFNULL(user.last_name, '')) as user_name
          FROM lz_properties as c
          LEFT JOIN lz_leads as le on (c.id = le.property_id)
          LEFT JOIN lz_property_addresses as lr2 on (c.id = lr2.property_id)
          LEFT JOIN lz_user as user on (user.id = ${userID})
          LEFT JOIN lz_user as us on FIND_IN_SET(us.id,c.assign_to)>0
          where c.status = 1 ${querydatebetween} and (FIND_IN_SET(${userID},c.assign_to)>0 or c.created_by = ${userID}) `
      }
      else if (userID == 0) {
      thisQuery1 += ` SELECT COUNT(le.property_id) as property_count, lr2.name_of_building as property_name,
        CONCAT(user.first_name,' ', IFNULL(user.last_name, '')) as user_name
        FROM lz_properties as c
        LEFT JOIN lz_leads as le on (c.id = le.property_id)
        LEFT JOIN lz_property_addresses as lr2 on (c.id = lr2.property_id)
        LEFT JOIN lz_user as user on (user.id = ${teamID})
        LEFT JOIN lz_user as us on FIND_IN_SET(us.id,c.assign_to)>0
        where c.status = 1 ${querydatebetween} 
        ${findTeamAdmin == 1 ? `` :
            findTeamAdmin == 2 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or us.team_leader = ${teamID} or us.portfolio_head = ${teamID} or c.created_by = ${teamID}) ` :
              findTeamAdmin == 3 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or us.portfolio_head = ${teamID} or c.created_by = ${teamID}) ` :
                findTeamAdmin == 4 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or c.created_by = ${teamID}) ` : ` and (c.created_by = ${teamID}) `} `
      }
    }
    // Project City-Wise
    if (module == 8) {
      if (teamID == 0) {
        thisQuery1 += ` SELECT COUNT(lr2.city) as count, ci.name as name
          FROM lz_properties as c
          LEFT JOIN lz_property_addresses as lr2 on (c.id = lr2.property_id)
          LEFT JOIN ${DbName}.lz_city as ci on (ci.id = lr2.city)
          LEFT JOIN lz_user as user on (user.id = ${userID})
          where c.status = 1 and ci.status = 1 and ci.id IS NOT NULL ${querydatebetween} and (FIND_IN_SET(${userID},c.assign_to)>0 or c.created_by = ${userID}) group by ci.name `
      }
      else if (userID == 0) {
      thisQuery1 += ` SELECT COUNT(lr2.city) as count, ci.name as name
        FROM lz_properties as c
        LEFT JOIN lz_property_addresses as lr2 on (c.id = lr2.property_id)
        LEFT JOIN ${DbName}.lz_city as ci on (ci.id = lr2.city)
        LEFT JOIN lz_user as user on (user.id = ${teamID})
        LEFT JOIN lz_user as us on (user.id = us.id)
        LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
        where c.status = 1 and ci.status = 1 and ci.id IS NOT NULL ${querydatebetween} 
        ${findTeamAdmin == 1 ? `` :
            findTeamAdmin == 2 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or us.team_leader = ${teamID} or us.portfolio_head = ${teamID} or c.created_by = ${teamID}) ` :
              findTeamAdmin == 3 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or us.portfolio_head = ${teamID} or c.created_by = ${teamID}) ` :
                findTeamAdmin == 4 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or c.created_by = ${teamID}) ` : ` and (c.created_by = ${teamID}) `} group by ci.name `
      }
    }
    // Builder Wise 
    if (module == 9) {
      if (teamID == 0) {
        thisQuery1 += ` SELECT COUNT(con.company_name) as builder_count, con.company_name as company_name,
          CONCAT(user.first_name,' ', IFNULL(user.last_name, '')) as user_name
          FROM lz_properties as c
          LEFT JOIN lz_contacts as con on (con.id = c.contact_id)
          LEFT JOIN lz_user as user on (user.id = ${userID})
          LEFT JOIN lz_user as us on (us.id = c.assign_to)
          where c.status = 1 ${querydatebetween} and con.company_name != '' and (FIND_IN_SET(${userID},c.assign_to)>0 or c.created_by = ${userID}) group by c.contact_id `
      }
      else if (userID == 0) {
      thisQuery1 += ` SELECT COUNT(con.company_name) as builder_count, con.company_name as company_name,
        CONCAT(user.first_name,' ', IFNULL(user.last_name, '')) as user_name
        FROM lz_properties as c
        LEFT JOIN lz_contacts as con on (con.id = c.contact_id)
        LEFT JOIN lz_user as user on (user.id = ${teamID})
        LEFT JOIN lz_user as us on (us.id = c.assign_to)
        LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
        where c.status = 1 ${querydatebetween} and con.company_name != '' 
        ${findTeamAdmin == 1 ? `` :
            findTeamAdmin == 2 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or us.team_leader = ${teamID} or us.portfolio_head = ${teamID} or c.created_by = ${teamID}) ` :
              findTeamAdmin == 3 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or us.portfolio_head = ${teamID} or c.created_by = ${teamID}) ` :
                findTeamAdmin == 4 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or c.created_by = ${teamID}) ` : ` and (c.created_by = ${teamID}) `} group by c.contact_id `
      }
    }
// TRANSACTION
    // Property wise
    if (module == 10) {
      if (teamID == 0) {
        thisQuery1 += ` SELECT COUNT(lr2.name_of_building) as count, lr2.name_of_building as property_name,
          CONCAT(user.first_name,' ', IFNULL(user.last_name, '')) as user_name
          FROM lz_transactions as c
          LEFT JOIN lz_properties as p on (p.id = c.project_name)
          LEFT JOIN lz_property_addresses as lr2 on (p.id = lr2.property_id)
          LEFT JOIN lz_contacts as con on (con.id = c.client_name)
          LEFT JOIN lz_user as user on (user.id = ${userID})
          where c.status = 1 and lr2.name_of_building IS NOT NULL
          ${querydatebetween} and (c.created_by = ${userID}) group by lr2.name_of_building `
      }
      else if (userID == 0) {
      thisQuery1 += ` SELECT COUNT(lr2.name_of_building) as count, lr2.name_of_building as property_name,
        CONCAT(user.first_name,' ', IFNULL(user.last_name, '')) as user_name
        FROM lz_transactions as c
        LEFT JOIN lz_properties as p on (p.id = c.project_name)
        LEFT JOIN lz_property_addresses as lr2 on (p.id = lr2.property_id)
        LEFT JOIN lz_contacts as con on (con.id = c.client_name)
        LEFT JOIN lz_user as user on (user.id = ${teamID})
        LEFT JOIN lz_user as us on (us.id = c.created_by)
        LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
        where c.status = 1 and lr2.name_of_building IS NOT NULL
        ${querydatebetween} 
        ${findTeamAdmin == 1 ? `` :
            findTeamAdmin == 2 ? ` and (us.team_leader = ${teamID} or us.portfolio_head = ${teamID} or c.created_by = ${teamID}) ` :
              findTeamAdmin == 3 ? ` and (us.portfolio_head = ${teamID} or c.created_by = ${teamID}) ` :
                findTeamAdmin == 4 ? ` and (c.created_by = ${teamID}) ` : ` and (c.created_by = ${teamID}) `} group by lr2.name_of_building `
      }
    }
    // TRANSACTION City-Wise
    if (module == 11) {
      if (teamID == 0) {
        thisQuery1 += ` SELECT COUNT(c.city) as count, ci.name as name
          FROM lz_transactions as c
          LEFT JOIN ${DbName}.lz_city as ci on (ci.id = c.city)
          LEFT JOIN lz_user as user on (user.id = ${userID})
          where c.status = 1 and ci.status = 1 and ci.id IS NOT NULL ${querydatebetween} and (c.created_by = ${userID}) group by ci.name `
      }
      else if (userID == 0) {
      thisQuery1 += ` SELECT COUNT(c.city) as count, ci.name as name
        FROM lz_transactions as c
        LEFT JOIN ${DbName}.lz_city as ci on (ci.id = c.city)
        LEFT JOIN lz_user as user on (user.id = ${teamID})
        LEFT JOIN lz_user as us on (user.id = us.id)
        LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
        where c.status = 1 and ci.status = 1 and ci.id IS NOT NULL ${querydatebetween} 
        ${findTeamAdmin == 1 ? `` :
            findTeamAdmin == 2 ? ` and (us.team_leader = ${teamID} or us.portfolio_head = ${teamID} or c.created_by = ${teamID}) ` :
              findTeamAdmin == 3 ? ` and (us.portfolio_head = ${teamID} or c.created_by = ${teamID}) ` :
                findTeamAdmin == 4 ? ` and (c.created_by = ${teamID}) ` : ` and (c.created_by = ${teamID}) `} group by ci.name `
      }
    }
// LEADS
    // Budget wise
    if (module == 12) {
      if (teamID == 0) {
        thisQuery1 += ` SELECT COUNT(c.id) as count, CONCAT(user.first_name,' ', IFNULL(user.last_name, '')) as user_name, CONCAT(ROUND(lr.budget_min),' - ',ROUND(lr.budget_max)) as budget
          FROM lz_leads as c
          LEFT JOIN lz_lead_requirements as lr on (c.id = lr.lead_id)
          LEFT JOIN lz_user as user on (user.id = ${userID})
          where c.status = 1 and lr.budget_min IS NOT NULL and lr.budget_max IS NOT NULL ${querydatebetween} and (c.created_by = ${userID}) group by lr.budget_min `
      }
      else if (userID == 0) {
      thisQuery1 += ` SELECT COUNT(c.id) as count, CONCAT(user.first_name,' ', IFNULL(user.last_name, '')) as user_name, CONCAT(ROUND(lr.budget_min),' - ',ROUND(lr.budget_max)) as budget
      FROM lz_leads as c
        LEFT JOIN lz_lead_requirements as lr on (c.id = lr.lead_id)
        LEFT JOIN lz_user as user on (user.id = ${teamID})
        LEFT JOIN lz_user as us on (us.id = c.created_by)
        LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
        where c.status = 1 and lr.budget_min IS NOT NULL and lr.budget_max IS NOT NULL ${querydatebetween} 
        ${findTeamAdmin == 1 ? `` :
            findTeamAdmin == 2 ? ` and (us.team_leader = ${teamID} or us.portfolio_head = ${teamID} or c.created_by = ${teamID}) ` :
              findTeamAdmin == 3 ? ` and (us.portfolio_head = ${teamID} or c.created_by = ${teamID}) ` :
                findTeamAdmin == 4 ? ` and (c.created_by = ${teamID}) ` : ` and (c.created_by = ${teamID}) `} group by lr.budget_min `
      }
    }
    // Lead-Wise
    if (module == 13) {
      if (teamID == 0) {
        thisQuery1 += ` SELECT COUNT(c.id) as count, CONCAT(user.first_name,' ', IFNULL(user.last_name, '')) as user_name
          FROM lz_leads as c
          LEFT JOIN lz_lead_requirements as lr on (c.id = lr.lead_id)
          LEFT JOIN lz_user as user on (user.id = ${userID})
          where c.status = 1 ${querydatebetween} and (c.created_by = ${userID}) group by user.id `
      }
      else if (userID == 0) {
      thisQuery1 += ` SELECT COUNT(c.id) as count, CONCAT(user.first_name,' ', IFNULL(user.last_name, '')) as user_name
        FROM lz_leads as c
        LEFT JOIN lz_lead_requirements as lr on (c.id = lr.lead_id)
        LEFT JOIN lz_user as user on (user.id = ${teamID})
        LEFT JOIN lz_user as us on (us.id = c.created_by)
        LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
        where c.status = 1 ${querydatebetween} 
        ${findTeamAdmin == 1 ? `` :
            findTeamAdmin == 2 ? ` and (us.team_leader = ${teamID} or us.portfolio_head = ${teamID} or c.created_by = ${teamID}) ` :
              findTeamAdmin == 3 ? ` and (us.portfolio_head = ${teamID} or c.created_by = ${teamID}) ` :
                findTeamAdmin == 4 ? ` and (c.created_by = ${teamID}) ` : ` and (c.created_by = ${teamID}) `} group by us.team_leader `
      }
    }
    // Leads City-Wise
    if (module == 14) {
      if (teamID == 0) {
        thisQuery1 += ` SELECT COUNT(lr.city) as count, ci.name as name
          FROM lz_leads as c
          LEFT JOIN lz_lead_requirements as lr on (c.id = lr.lead_id)
          LEFT JOIN ${DbName}.lz_city as ci on (ci.id = lr.city)
          LEFT JOIN lz_user as user on (user.id = ${userID})
          where c.status = 1 and ci.status = 1 and ci.id IS NOT NULL ${querydatebetween} and (c.created_by = ${userID}) group by ci.name `
      }
      else if (userID == 0) {
      thisQuery1 += ` SELECT COUNT(lr.city) as count, ci.name as name
        FROM lz_leads as c
        LEFT JOIN lz_lead_requirements as lr on (c.id = lr.lead_id)
        LEFT JOIN ${DbName}.lz_city as ci on (ci.id = lr.city)
        LEFT JOIN lz_user as user on (user.id = ${teamID})
        LEFT JOIN lz_user as us on (us.id = c.created_by)
        LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
        where c.status = 1 and ci.status = 1 and ci.id IS NOT NULL ${querydatebetween} 
        ${findTeamAdmin == 1 ? `` :
            findTeamAdmin == 2 ? ` and (us.team_leader = ${teamID} or us.portfolio_head = ${teamID} or c.created_by = ${teamID}) ` :
              findTeamAdmin == 3 ? ` and (us.portfolio_head = ${teamID} or c.created_by = ${teamID}) ` :
                findTeamAdmin == 4 ? ` and (c.created_by = ${teamID}) ` : ` and (c.created_by = ${teamID}) `} group by ci.name `
      }
    }
    // Lost Lead
    if (module == 15) {
      if (teamID == 0) {
        thisQuery1 += ` SELECT COUNT(c.lead_status) as count,
          CONCAT(user.first_name,' ', IFNULL(user.last_name, '')) as user_name
          FROM lz_leads as c
          LEFT JOIN lz_lead_requirements as lr on (c.id = lr.lead_id)
          LEFT JOIN lz_masters as ls on (ls.id = c.lead_status)
          LEFT JOIN lz_user as user on (user.id = ${userID})
          where c.status = 1 and ls.option_type = 'lead_lost_reason'
          ${querydatebetween} and (c.created_by = ${userID}) group by ls.option_value `
      }
      else if (userID == 0) {
      thisQuery1 += ` SELECT COUNT(c.lead_status) as count,
        CONCAT(user.first_name,' ', IFNULL(user.last_name, '')) as user_name
        FROM lz_leads as c
        LEFT JOIN lz_lead_requirements as lr on (c.id = lr.lead_id)
        LEFT JOIN lz_masters as ls on (ls.id = c.lead_status)
        LEFT JOIN lz_user as user on (user.id = ${teamID})
        LEFT JOIN lz_user as us on (us.id = c.created_by)
        LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
        where c.status = 1 and ls.option_type = 'lead_lost_reason' ${querydatebetween} 
        ${findTeamAdmin == 1 ? `` :
            findTeamAdmin == 2 ? ` and (us.team_leader = ${teamID} or us.portfolio_head = ${teamID} or c.created_by = ${teamID}) ` :
              findTeamAdmin == 3 ? ` and (us.portfolio_head = ${teamID} or c.created_by = ${teamID}) ` :
                findTeamAdmin == 4 ? ` and (c.created_by = ${teamID}) ` : ` and (c.created_by = ${teamID}) `} group by ls.option_value `
      }
    }
    // Lead Task
    if (module == 16) {
      if (teamID == 0) {
        thisQuery1 += ` SELECT COUNT(c.task_status) as task_status_count, ts.option_value as task_status_name
        FROM lz_tasks as c
        LEFT JOIN lz_contacts as co on (c.contact = co.id)
        LEFT JOIN lz_leads as le on (le.contact_id = co.id)
        LEFT JOIN lz_masters as ts on (c.task_status = ts.id)
        LEFT JOIN lz_user as us on (us.id = c.created_by)
        LEFT JOIN lz_user as user on (user.id = ${userID})
        where c.status = 1 ${querydatebetween} and (FIND_IN_SET(${userID},c.assign_to)>0 or c.created_by = ${userID}) group by ts.option_value `
      }
      else if (userID == 0) {
        thisQuery1 += ` SELECT COUNT(c.task_status) as task_status_count, ts.option_value as task_status_name
        FROM lz_tasks as c
        LEFT JOIN lz_contacts as co on (c.contact = co.id)
        LEFT JOIN lz_leads as le on (le.contact_id = co.id)
        LEFT JOIN lz_masters as ts on (c.task_status = ts.id)
        LEFT JOIN lz_user as us on (us.id = c.created_by)
        LEFT JOIN lz_user as user on (user.id = ${teamID})
        LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
        where c.status = 1 ${querydatebetween} 
        ${findTeamAdmin == 1 ? `` :
            findTeamAdmin == 2 ? ` and (us.team_leader = ${teamID} or us.portfolio_head = ${teamID} or c.created_by = ${teamID}) ` :
              findTeamAdmin == 3 ? ` and (us.portfolio_head = ${teamID} or c.created_by = ${teamID}) ` :
                findTeamAdmin == 4 ? ` and (c.created_by = ${teamID}) ` : ` and (c.created_by = ${teamID}) `} group by ts.option_value `
      }
    }
    // Lead ReAssign
    if (module == 17) {
      if (teamID == 0) {
        thisQuery1 += ` SELECT COUNT(co.contact_status) as count, cs.option_value as re_assign_name
        FROM lz_leads as c
        LEFT JOIN lz_contacts as co on (c.contact_id = co.id)
        LEFT JOIN lz_masters as cs on (co.contact_status = cs.id)
        LEFT JOIN lz_user as us on (us.id = c.created_by)
        LEFT JOIN lz_user as user on (user.id = ${userID})
        where c.status = 1 and co.contact_status = '7'
        ${querydatebetween} and (FIND_IN_SET(${userID},c.assign_to)>0 or c.created_by = ${userID}) group by cs.option_value `
      }
      else if (userID == 0) {
        thisQuery1 += ` SELECT COUNT(co.contact_status) as count, cs.option_value as re_assign_name
        FROM lz_leads as c
        LEFT JOIN lz_contacts as co on (c.contact_id = co.id)
        LEFT JOIN lz_masters as cs on (co.contact_status = cs.id)
        LEFT JOIN lz_user as us on (us.id = c.created_by)
        LEFT JOIN lz_user as user on (user.id = ${userID})
        LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
        where c.status = 1 and co.contact_status = '7'
        ${querydatebetween} 
        ${findTeamAdmin == 1 ? `` :
            findTeamAdmin == 2 ? ` and (us.team_leader = ${teamID} or us.portfolio_head = ${teamID} or c.created_by = ${teamID}) ` :
              findTeamAdmin == 3 ? ` and (us.portfolio_head = ${teamID} or c.created_by = ${teamID}) ` :
                findTeamAdmin == 4 ? ` and (c.created_by = ${teamID}) ` : ` and (c.created_by = ${teamID}) `} group by cs.option_value `
      }
    }
    // HR
    // Gender Count
    if (module == 18) {
      if (teamID == 0) {
        thisQuery1 += ` SELECT COUNT(upd.gender) as count,
        ats.option_value as gender_name
        FROM lz_attendance as c
        LEFT JOIN lz_user as us on (us.id = c.user_id)
        LEFT JOIN lz_users_personal_details as upd on (us.id = upd.user_id)
        LEFT JOIN lz_masters as ats on (upd.gender = ats.id)
        LEFT JOIN lz_user as user on (user.id = ${userID})
        LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
        where c.status = 1 and upd.gender IS NOT NULL ${querydatebetween} and (c.user_id = ${userID}) group by ats.option_value `
      }
      else if (userID == 0) {
        thisQuery1 += ` SELECT COUNT(upd.gender) as count,
        ats.option_value as gender_name
        FROM lz_attendance as c
        LEFT JOIN lz_user as us on (us.id = c.user_id)
        LEFT JOIN lz_users_personal_details as upd on (us.id = upd.user_id)
        LEFT JOIN lz_masters as ats on (upd.gender = ats.id)
        LEFT JOIN lz_user as user on (user.id = ${teamID})
        LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
        where c.status = 1 and upd.gender IS NOT NULL ${querydatebetween} 
        ${findTeamAdmin == 1 ? `` :
            findTeamAdmin == 2 ? ` and (us.team_leader = ${teamID} or us.portfolio_head = ${teamID} or c.user_id = ${teamID}) ` :
              findTeamAdmin == 3 ? ` and (us.portfolio_head = ${teamID} or c.user_id = ${teamID}) ` :
                findTeamAdmin == 4 ? ` and (c.user_id = ${teamID}) ` : ` and (c.user_id = ${teamID}) `} group by ats.option_value `
      }
    }
    // Age Count
    if (module == 19) {
      if (teamID == 0) {
        thisQuery1 += ` SELECT COUNT(REPLACE(DATE_FORMAT(FROM_DAYS(DATEDIFF(NOW(), us.dob)), '%Y'), '00', '')) as count, c.user_id as user_id,
        IF(REPLACE(DATE_FORMAT(FROM_DAYS(DATEDIFF(NOW(), us.dob)), '%Y'), '00', '') = null , 0 , REPLACE(DATE_FORMAT(FROM_DAYS(DATEDIFF(NOW(), us.dob)), '%Y'), '00', '')) as dob,
        us.dob as date_of_birth
        FROM lz_attendance as c
        LEFT JOIN lz_masters as ats on (c.attendance_status = ats.id)
        LEFT JOIN lz_user as us on (us.id = c.user_id)
        LEFT JOIN lz_user as user on (user.id = ${userID})
        LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
        where c.status = 1 and us.dob IS NOT NULL ${querydatebetween} and (c.user_id = ${userID}) group by us.dob `
      }
      else if (userID == 0) {
        thisQuery1 += ` SELECT COUNT(REPLACE(DATE_FORMAT(FROM_DAYS(DATEDIFF(NOW(), us.dob)), '%Y'), '00', '')) as count, c.user_id as user_id,
        IF(REPLACE(DATE_FORMAT(FROM_DAYS(DATEDIFF(NOW(), us.dob)), '%Y'), '00', '') = null , 0 , REPLACE(DATE_FORMAT(FROM_DAYS(DATEDIFF(NOW(), us.dob)), '%Y'), '00', '')) as dob,
        us.dob as date_of_birth
        FROM lz_attendance as c
        LEFT JOIN lz_masters as ats on (c.attendance_status = ats.id)
        LEFT JOIN lz_user as us on (us.id = c.user_id)
        LEFT JOIN lz_user as user on (user.id = ${teamID})
        LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
        where c.status = 1 and us.dob IS NOT NULL ${querydatebetween} 
        ${findTeamAdmin == 1 ? `` :
            findTeamAdmin == 2 ? ` and (us.team_leader = ${teamID} or us.portfolio_head = ${teamID} or c.user_id = ${teamID}) ` :
              findTeamAdmin == 3 ? ` and (us.portfolio_head = ${teamID} or c.user_id = ${teamID}) ` :
                findTeamAdmin == 4 ? ` and (c.user_id = ${teamID}) ` : ` and (c.user_id = ${teamID}) `} group by us.dob `
      }
    }
    // User Location Count
    if (module == 20) {
      if (teamID == 0) {
        thisQuery1 += ` SELECT COUNT(uf.branch_name) as count,
        uf.branch_name as branch_name
        FROM lz_attendance as c
        LEFT JOIN lz_user as us on (us.id = c.user_id)
        LEFT JOIN lz_users_personal_details as upd on (us.id = upd.user_id)
        LEFT JOIN lz_users_finance as uf on (us.id = uf.user_id)
        LEFT JOIN lz_user as user on (user.id = ${userID})
        LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
        where c.status = 1 and uf.branch_name IS NOT NULL ${querydatebetween} and (c.user_id = ${userID}) group by uf.branch_name `
      }
      else if (userID == 0) {
        thisQuery1 += ` SELECT COUNT(uf.branch_name) as count,
        uf.branch_name as branch_name
        FROM lz_attendance as c
        LEFT JOIN lz_user as us on (us.id = c.user_id)
        LEFT JOIN lz_users_personal_details as upd on (us.id = upd.user_id)
        LEFT JOIN lz_users_finance as uf on (us.id = uf.user_id)
        LEFT JOIN lz_user as user on (user.id = ${teamID})
        LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
        where c.status = 1 and uf.branch_name IS NOT NULL ${querydatebetween} 
        ${findTeamAdmin == 1 ? `` :
            findTeamAdmin == 2 ? ` and (us.team_leader = ${teamID} or us.portfolio_head = ${teamID} or c.user_id = ${teamID}) ` :
              findTeamAdmin == 3 ? ` and (us.portfolio_head = ${teamID} or c.user_id = ${teamID}) ` :
                findTeamAdmin == 4 ? ` and (c.user_id = ${teamID}) ` : ` and (c.user_id = ${teamID}) `} group by uf.branch_name `
      }
    }
    // TASKS
    // Project Task Count
    if (module == 21) {
      if (teamID == 0) {
        thisQuery1 += ` SELECT COUNT(c.task_status) as task_status_count, ts.option_value as task_status_name
        FROM lz_tasks as c
        LEFT JOIN lz_properties as p on (c.project = p.id)
        LEFT JOIN lz_property_addresses as pa on (pa.property_id = p.id)
        LEFT JOIN lz_masters as ts on (c.task_status = ts.id)
        LEFT JOIN lz_user as us on (us.id = c.created_by)
        LEFT JOIN lz_user as user on (user.id = ${userID})
        LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
        where c.status = 1 ${querydatebetween} and (FIND_IN_SET(${userID},c.assign_to)>0 or c.created_by = ${userID}) group by ts.option_value `
      }
      else if (userID == 0) {
        thisQuery1 += ` SELECT COUNT(c.task_status) as task_status_count, ts.option_value as task_status_name
        FROM lz_tasks as c
        LEFT JOIN lz_properties as p on (c.project = p.id)
        LEFT JOIN lz_property_addresses as pa on (pa.property_id = p.id)
        LEFT JOIN lz_masters as ts on (c.task_status = ts.id)
        LEFT JOIN lz_masters as tt on (c.task_type = tt.id)
        LEFT JOIN lz_user as us on (us.id = c.created_by)
        LEFT JOIN lz_user as user on (user.id = ${teamID})
        LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
        where c.status = 1 ${querydatebetween} 
        ${findTeamAdmin == 1 ? `` :
            findTeamAdmin == 2 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or us.team_leader = ${teamID} or us.portfolio_head = ${teamID} or c.created_by = ${teamID}) ` :
              findTeamAdmin == 3 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or us.portfolio_head = ${teamID} or c.created_by = ${teamID}) ` :
                findTeamAdmin == 4 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or c.created_by = ${teamID}) ` : ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or c.created_by = ${teamID}) `} `
      }
    }
    // 
    if (module == 22) {
      if (teamID == 0) {
        thisQuery1 += ` SELECT COUNT(c.id) as count, expm.option_value as expense_type_name
        FROM lz_finance_invoice as c
        LEFT JOIN lz_expenses as exp on (c.expense_id = exp.id)
        LEFT JOIN lz_masters as expm on (exp.expense_type = expm.id)
        LEFT JOIN lz_user as us on (us.id = c.created_by)
        LEFT JOIN lz_user as user on (user.id = ${userID})
        LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
        where c.status = 1 ${querydatebetween} and (c.created_by = ${userID}) group by c.id `
      }
      else if (userID == 0) {
        thisQuery1 += ` SELECT COUNT(c.id) as count, expm.option_value as expense_type_name
        FROM lz_finance_invoice as c
        LEFT JOIN lz_expenses as exp on (c.expense_id = exp.id)
        LEFT JOIN lz_masters as expm on (exp.expense_type = expm.id)
        LEFT JOIN lz_user as us on (us.id = c.created_by)
        LEFT JOIN lz_user as user on (user.id = ${teamID})
        LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
        where c.status = 1 ${querydatebetween} 
        ${findTeamAdmin == 1 ? `` :
            findTeamAdmin == 2 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or us.team_leader = ${teamID} or us.portfolio_head = ${teamID} or c.created_by = ${teamID}) ` :
              findTeamAdmin == 3 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or us.portfolio_head = ${teamID} or c.created_by = ${teamID}) ` :
                findTeamAdmin == 4 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or c.created_by = ${teamID}) ` : ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or c.created_by = ${teamID}) `} `
      }
    }
    // SITE VISIT 
    if (module == 23) {
      if (teamID == 0) {
        thisQuery1 += ` SELECT COUNT(c.id) as count, lr2.name_of_building as property_name, tt.option_value as task_type_name, ts.option_value as task_status_name,
          CONCAT(user.first_name,' ', IFNULL(user.last_name, '')) as user_name
          FROM lz_properties as c
          LEFT JOIN lz_property_addresses as lr2 on (c.id = lr2.property_id)
          LEFT JOIN lz_tasks as ta on (c.id = ta.project)
          LEFT JOIN lz_masters as tt on (tt.id = ta.task_type)
          LEFT JOIN lz_masters as ts on (ts.id = ta.task_status)
          LEFT JOIN lz_user as user on (user.id = ${userID})
          LEFT JOIN lz_user as us on FIND_IN_SET(us.id,c.assign_to)>0          
          where c.status = 1 and tt.option_value = "Site Visit" ${querydatebetween} and (FIND_IN_SET(${userID},c.assign_to)>0 or c.created_by = ${userID}) `
      }
      else if (userID == 0) {
        thisQuery1 += ` SELECT COUNT(c.id) as count, lr2.name_of_building as property_name, tt.option_value as task_type_name, ts.option_value as task_status_name,
          CONCAT(user.first_name,' ', IFNULL(user.last_name, '')) as user_name
          FROM lz_properties as c
          LEFT JOIN lz_property_addresses as lr2 on (c.id = lr2.property_id)
          LEFT JOIN lz_tasks as ta on (c.id = ta.project)
          LEFT JOIN lz_masters as tt on (tt.id = ta.task_type)
          LEFT JOIN lz_masters as ts on (ts.id = ta.task_status)
          LEFT JOIN lz_user as user on (user.id = ${teamID})
          LEFT JOIN lz_user as us on FIND_IN_SET(us.id,c.assign_to)>0   
        LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
        where c.status = 1 and tt.option_value = "Site Visit" ${querydatebetween} 
        ${findTeamAdmin == 1 ? `` :
            findTeamAdmin == 2 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or us.team_leader = ${teamID} or us.portfolio_head = ${teamID} or c.created_by = ${teamID}) ` :
              findTeamAdmin == 3 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or us.portfolio_head = ${teamID} or c.created_by = ${teamID}) ` :
                findTeamAdmin == 4 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or c.created_by = ${teamID}) ` : ` and (c.created_by = ${teamID}) `} `
      }
    }

    if(module == 6) {
      thisQuery1 += ` group by c.id `
    }
    if(module == 7) {
      thisQuery1 += ` group by lr2.name_of_building `
    }

    const data = await db2.sequelize.query(thisQuery1);
    console.log("data", thisQuery1);
    console.log("dataCheck", data[0])

    res.status(200).send({
      status: 200,
      message: 'Success',
      count: data[0].length,
      output: data[0]
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
