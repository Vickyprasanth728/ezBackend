const orgDbConfig = require("../orgConfig/orgDb.config.js");
const db2 = require("../orgModel/orgIndex.js");
const Op = db2.Sequelize.Op;
const Moment = require('moment');
const mailer = require("../orgModel/mailer.model.js");

exports.saveTasks = async (req, res) => {
  try {
    const created_id = req.user.id
    const created_by = created_id.id
    console.log('created_by', created_by.id);

    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    const desCreatedUser = await db2.sequelize.query(`select designation, CONCAT(first_name,' ', IFNULL(last_name, '')) as user_name, email from lz_user where status = 1 and id = ${created_by} `);
    const cDesignation = desCreatedUser[0][0]?.designation
    const CUserName = desCreatedUser[0][0]?.user_name
    console.log("cDesignation", cDesignation);
    console.log("CUserName", CUserName);

    const mailTri = await db2.sequelize.query(`select designation from lz_email_trigger where options = 'task_created' and status = 1 `);
    const cTriDes = mailTri[0][0]?.designation ?? 0

    // const finish_time =  req.body.finish_time;
    const startTime  = Moment(req.body.task_time).format('YYYY-MM-DD hh:mm:ss')
    const finishTime  = Moment(req.body.finish_time).format('YYYY-MM-DD hh:mm:ss')
    
    const data = await db2['tasks'].create({
      org_id: org_id,
      task_type: req.body.task_type,
      priority: req.body.priority,
      task_time: req.body.task_time,
      finish_time: req.body.finish_time,
      project: req.body.project,
      contact: req.body.contact,
      agenda: req.body.agenda,
      assign_to: req.body.assign_to,
      reminder: req.body.reminder,
      task_status: req.body.task_status,
      created_by: created_by
    });
    let taskId = data?.dataValues.id

    const TasksLogs = await db2['logs'].create({
        org_id: org_id,
        module_id: taskId,
        module_name: "4",
        note: "Tasks created at",
        user_id: created_by
    })

    const TasksNotes = await db2['notes'].create({
      org_id: org_id,
      reply: req.body.agenda ?? '',
      parent_id: "0",
      module_id: taskId,
      module_name: "4",
      user_id: created_by,
      created_by: created_by
    })

    // Email Trigger
    const email_settings = await db2.sequelize.query(`select status from lz_email_trigger where FIND_IN_SET('${cDesignation}', '${cTriDes},1') > 0 and options = 'task_created' and status = 1 `);
    // const emailTri = email_settings[0][0] ? email_settings[0][0]["active_status"] : 0
    const emailTri = email_settings[0][0]?.status ?? 0
    console.log("emailTri", emailTri);

    //nodemailer
      if(emailTri == 1) {

      let thisQueryDes = ` select us.team_leader as tl, us.portfolio_head as sub_tl 
      from lz_user as us where id = ${created_by} `
      const desCheck = await db2.sequelize.query(thisQueryDes);
      const desCheckTL = desCheck[0][0].tl
      const desCheckSubTL = desCheck[0][0].sub_tl
    
      // TL
      const checkTl = await db2.sequelize.query(`select email from lz_user where id = ${desCheckTL} `);
      const checkTl1 = checkTl[0][0].email
      // Sub TL
      const checksubTL = await db2.sequelize.query(`select email from lz_user where id = ${desCheckSubTL} `);
      const checksubTL1 = checksubTL[0][0].email
      // Admin
      const checkAdmin = await db2.sequelize.query(`select email from lz_user where designation = 1 group by id `);
      const checkAdmin1 = checkAdmin[0].map(item => item.email).join(', ');
      // Assign To
      const assignEmail = await db2.sequelize.query(`select us.id as id, us.email as email from lz_user as us where us.id IN (${req.body.assign_to}) `);
      const assEmail = assignEmail[0].map(item => item.email).join(', ')
    
      console.log("checkTl", checkTl1);
      console.log("checksubTL1", checksubTL1);
      console.log("checkAdmin1", checkAdmin1);
      console.log("assign_to",assEmail);
    
      const createdEmail = await db2.sequelize.query(`select email from lz_user where id = ${created_by} `);
      const cEmail = createdEmail[0][0].email
      console.log("cEmail", cEmail);

      let thisQueryPro = `select p.id as id, pa.name_of_building as property_name
      from lz_properties p
      left join lz_property_addresses as pa on (p.id = pa.property_id)
      where p.status = 1 and pa.property_id = '${req.body.project}' `;

      const project_name_data = await db2.sequelize.query(thisQueryPro)
      console.log("project_name_data", project_name_data[0][0]);

      const project_name = project_name_data[0][0] ? project_name_data[0][0].property_name : 0
      console.log('project_name', project_name);

      let message = {
        from: cEmail,
        to: [checkAdmin1,checkTl1,checksubTL1,assEmail].join(', '),
        subject: "New Task Created",
        html:
          "<h3> New Task has been created with </h3>" +
          "<h3> Project Id: </h3>" +
          req.body.project +
          "<h3>Project Name:</h3>" +
          project_name + "",
      };
      console.log("message", message);
      mailer.sendMail(message, function(error, info){
        if (error) {
          console.log('Error');
        } else {
          console.log('Email sent: ' + info.response);
        }
      });
    }

    res.status(200).send({
      status:200,
      message:'Success',
      output:data
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.getTasks = async (req, res) => {
    try {
    const created_id = req.user.id
    const created_by = created_id.id
    console.log('created_by', created_by);

    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    const role = req.user.id
    const role_id = role.designation
    console.log('role_id', role_id);
    
    let thisQuery = ` SELECT t.*, c.id as contact_id, c.company_name as company_name, CONCAT(c.first_name,' ', IFNULL(c.last_name, '')) as contact_name, c.email as contact_email, c.mobile as contact_mobile, c.profile_image as contact_profile_image, c.profile_image_original_name as contact_profile_image_original_name,
    pra.name_of_building as property_name, GROUP_CONCAT(us.first_name,'-',us.id) as assign_to_name, org.organization_name as org_name, ms2.option_value as task_type_name, ms.option_value as task_status_name, ms1.option_value as priority_name, rem.option_value as reminder_name, DATE_FORMAT(t.task_time,'%Y-%m-%d %H:%i:%s') as task_time_at ,DATE_FORMAT(t.finish_time,'%Y-%m-%d %H:%i:%s') as finish_time_at, CONCAT(us1.first_name) as created_by_name, t.created_at as created_at_time,
    
    (SELECT COUNT(id) FROM lz_notes where status = 1 and (module_id = t.id and module_name = 4 or (module_id = t.contact and module_name = 1) or (module_id = t.project and module_name = 3) or (module_id = le.id and module_name = 4) )) as notes_count,
    (SELECT COUNT(id) FROM lz_file_uploads where module_id = t.id and module_name = 4) as files_count, DATE_FORMAT(t.created_at,'%Y-%m-%d %H:%i:%s') as created_at
    FROM lz_tasks as t 
    LEFT JOIN lz_properties as pr on (pr.id = t.project) 
    LEFT JOIN lz_property_addresses as pra on (pra.id=pr.id)
    LEFT JOIN lz_contacts as c on (c.id = t.contact)
    LEFT JOIN lz_user as us on FIND_IN_SET(us.id,t.assign_to)>0
    LEFT JOIN lz_user as us1 on (us1.id = t.created_by)
    left join lz_leads as le on (c.id = le.contact_id)
    LEFT JOIN lz_organization as org on (org.id = t.org_id)
    LEFT JOIN lz_masters as ms on (ms.id = t.task_status)
    LEFT JOIN lz_masters as ms1 on (ms1.id = t.priority)
    LEFT JOIN lz_masters as ms2 on (ms2.id = t.task_type)
    LEFT JOIN lz_masters as rem on (rem.id = t.reminder)

    LEFT JOIN lz_user as us5 on FIND_IN_SET(us5.id,c.assign_to) > 0 
    left join lz_user as us4 on (us5.team_leader = us4.id) 
    LEFT JOIN lz_user as us6 on FIND_IN_SET(us6.id,c.assign_to) > 0 
    left join lz_user as us7 on (us6.portfolio_head = us7.id) 

    WHERE ${role_id == 1 ? `t.status IN (1,2) ` : `t.status = 1`} `

    if (role_id == 1) {
      thisQuery += ` `
    }
    if (role_id == 2) {
      thisQuery += ` and (FIND_IN_SET(${created_by},t.assign_to)>0 or us.team_leader = ${created_by} or us.portfolio_head = ${created_by} or t.created_by = ${created_by}) `
      // thisQuery += ` and c.created_by = ${created_by} `
    }
    if (role_id == 3) {
      thisQuery += ` and (FIND_IN_SET(${created_by},t.assign_to)>0 or us.portfolio_head = ${created_by} or t.created_by = ${created_by}) `
      // thisQuery += ` and c.created_by = ${created_by} `
    }
    if (role_id == 4) {
      thisQuery += ` and (FIND_IN_SET(${created_by},t.assign_to)>0 or t.created_by = ${created_by}) `
    }
    if (role_id == 5) {
      thisQuery += ` `
    }
    if (role_id == 6) {
      thisQuery += `and t.created_by = ${created_by} `
    }
    if (role_id >= 7) {
      thisQuery += `and t.created_by = ${created_by} `
    }


    // LEFT JOIN lz_user as us5 on (c.created_by = us5.id) 
    // LEFT JOIN lz_user as us4 on (us5.team_leader = us4.id) 
    // if (role_id == 1) {
    //   thisQuery += ` `
    // }
    // if (role_id == 2) {
  
    //   let thisQuery1 =`select GROUP_CONCAT(distinct CONCAT(us.id)) as exec, us.team_leader as team_leader from lz_user as us where us.team_leader = ${created_by} limit 1 `
    //   const data = await db2.sequelize.query(thisQuery1);
    //   console.log('dataaaaaaaaaaaaa',data[0]);
  
    //   thisQuery += ` and t.status= 1 and FIND_IN_SET(${created_by},t.assign_to)>0 or us5.team_leader = ${created_by} `
  
    //   // thisQuery += ` and t.status= 1 and t.created_by = ${created_by} `
    // }
    // if (role_id >= 3) {
    //   thisQuery += ` and t.status= 1 and FIND_IN_SET(${created_by},t.assign_to)>0 `
    // }
    
    const filters = req.query;
    if (filters.task_type) {
        thisQuery += " and t.task_type = " + `${filters.task_type} `
    }
    if (filters.priority) {
        thisQuery += " and t.priority = " + `${filters.priority} `
    }
    if (filters.assign_to) {
      var a = filters.assign_to;
      var b = a.replace(/[,]/g, ",");
      thisQuery += `and CONCAT(',', t.assign_to, ',') REGEXP ',(${a}),' `
    }
    if (filters.task_status) {
        thisQuery += " and t.task_status = " + `${filters.task_status} `
    }
    // if (filters.created_at) {
    //     thisQuery += " and t.created_at = " + `${filters.created_at} `
    // }
    if (filters.created_date) {
      thisQuery += ` and (DATE_FORMAT(t.created_at,'%Y-%m-%d') = '${filters.created_date}' ) `
    }
    if (filters.project) {
      thisQuery += " and t.project = " + `${filters.project} `
    }
    if (filters.contact) {
        thisQuery += " and t.contact = " + `${filters.contact} `
    }

    thisQuery += ' group by t.id '

    if (filters.order_by) {
      let orderByString = filters.order_by.split('|')
      thisQuery += " order by " + `${orderByString[0]} ${orderByString[1]}  `
    }
    const data1 = await db2.sequelize.query(thisQuery);

    if (filters.order_by =="" || filters.order_by == undefined) {
      thisQuery += ' order by t.id DESC'
    }
  
    // thisQuery += ' order by t.updated_at DESC '
  
    if (filters.limit) {
      thisQuery += ` limit ${filters.limit},12 `
    }

    const data = await db2.sequelize.query(thisQuery);

    const count_filter = (data1[0])

      res.status(200).send({
        status:200,
        message:'Success',
        count:count_filter.length,
        output:data[0]
      });
    } catch (error) {
      res.status(500).send({
        message: error.message,
      });
    }
};
exports.editTask = async (req, res) => {
    try {
      
    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    const role = req.user.id
    const role_id = role.designation
    console.log('role_id', role_id);

    const taskID = req.params.id
    
    let thisQuery = ` SELECT t.*,  c.id as contact_id, c.company_name as company_name,CONCAT(c.first_name,' ', IFNULL(c.last_name, '')) as contact_name, c.email as contact_email, c.mobile as contact_mobile, c.profile_image as contact_profile_image, c.profile_image_original_name as contact_profile_image_original_name, CONCAT(us1.first_name) as created_by_name,
    pra.name_of_building as property_name, GROUP_CONCAT(CONCAT(us.first_name,'-',us.id)) as assign_to_name, org.organization_name as org_name, ms2.option_value as task_type_name, ms.option_value as task_status_name, ms1.option_value as priority_name, rem.option_value as reminder_name, DATE_FORMAT(t.task_time,'%Y-%m-%d %H:%i:%s') as task_time_at , DATE_FORMAT(t.finish_time,'%Y-%m-%d %H:%i:%s') as finish_time_at FROM lz_tasks as t 
    LEFT JOIN lz_properties as pr on (pr.id = t.project)
    LEFT JOIN lz_property_addresses as pra on (pra.id=pr.id)
    LEFT JOIN lz_contacts as c on (c.id = t.contact)
    LEFT JOIN lz_user as us on FIND_IN_SET(us.id,t.assign_to)>0
    LEFT JOIN lz_user as us1 on (us1.id = t.created_by)
    LEFT JOIN lz_organization as org on (org.id = t.org_id)
    LEFT JOIN lz_masters as ms on (ms.id = t.task_status)
    LEFT JOIN lz_masters as ms1 on (ms1.id = t.priority)
    LEFT JOIN lz_masters as ms2 on (ms2.id = t.task_type)
    LEFT JOIN lz_masters as rem on (rem.id = t.reminder)
    WHERE ${role_id == 1 ? `t.status IN (1,2) ` : `t.status = 1`} and t.id = ${taskID}
    `
    thisQuery += ' group by t.id '
    thisQuery += ' order by t.id DESC '

    const data = await db2.sequelize.query(thisQuery);

    const count_filter = (data[0])

      res.status(200).send({
        status:200,
        message:'Success',
        count:count_filter.length,
        output:data[0]
      });
    } catch (error) {
      res.status(500).send({
        message: error.message,
      });
    }
};
exports.updateTask = async (req, res) => {
  try {
    const id = req.params.id;

    const created_by = req.user.id
    console.log('created_by', created_by.id);

    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    const role = req.user.id
    const role_id = role.designation
    console.log('role_id', role_id);

    let thisQuery = ` select t.contact as contact_id, c.first_name as contact_name, t.task_status as task_status, cs.option_value as task_status_name, t.project as property_id, pa.name_of_building as property_name
    from lz_tasks as t
    left join lz_contacts as c on (c.id = t.contact)
    left join lz_properties as p on (p.id = t.project)
    left join lz_property_addresses as pa on (p.id = pa.property_id)
    left join lz_masters as cs on (cs.id = t.task_status)
    where ${role_id == 1 ? `t.status IN (1,2) ` : `t.status = 1`} and t.id = ${id} `

    const data123= await db2.sequelize.query(thisQuery);
    const dataContactID = data123[0][0]?.contact_id
    const dataContactName = data123[0][0]?.contact_name
    const dataStatus = data123[0][0]?.task_status
    const dataStatusName = data123[0][0]?.task_status_name
    const dataProperty = data123[0][0]?.property_id
    const dataPropertyName = data123[0][0]?.property_name

    console.log("dataContactID", dataContactID);
    console.log("dataContactName", dataContactName);
    console.log("dataStatus", dataStatus);
    console.log("dataStatusName", dataStatusName);
    console.log("dataProperty", dataProperty);
    console.log("dataPropertyName", dataPropertyName);


    const num = await db2['tasks'].update(req.body, {
      where: {id: id, status:1}, 
    });

    if (num == 1) {
        // const TasksLogs = await db2['logs'].create({
        //     org_id: org_id,
        //     module_id: id,
        //     module_name: "4",
        //     note: "Tasks updated at",
        //     user_id: created_by.id
        // })
        const data = {
          reply: req.body.agenda
        }
        const num1 = await db2['notes'].update(data, {
          where: {module_id:id, module_name : 4},
          limit:1 
        });

        const TaskID = req.params.id;

        // Task Status
        if(req.body.task_status) {
          let thisQuery456 = ` select t.task_status as l_status, cs.option_value as l_status_name
          from lz_tasks as t
          left join lz_masters as cs on (cs.id = t.task_status)
          where ${role_id == 1 ? `t.status IN (1,2) ` : `t.status = 1`} and t.task_status = ${req.body.task_status}
          `
          const dataCS = await db2.sequelize.query(thisQuery456);
          const dataCS1 = dataCS[0][0]?.l_status
          const dataCS2 = dataCS[0][0]?.l_status_name
          console.log("dataCS1", dataCS1);
          console.log("dataCS2", dataCS2);

        if(dataStatus?.toString() !== req.body.task_status?.toString()) {
          const TaskStatusLog = await db2['logs'].create({
            org_id: org_id,
            module_id: TaskID,
            module_name: "4",
            // note: 'Task status : ' + dataStatusName + ' to '+ dataCS2,
            note: 'Task status : ' + `${dataStatusName == null || "" ? dataCS2 : dataStatusName + ' to '+ dataCS2}`,
            user_id: created_by.id
          })
          console.log("Task Status",TaskStatusLog.dataValues.note);
        }
        }
        // Contact Name
        if(req.body.contact) {
          let thisQuery456 = ` select t.contact as l_contact_id, c.first_name as l_contact_name
          from lz_tasks as t
          left join lz_contacts as c on (c.id = t.contact)
          where ${role_id == 1 ? `t.status IN (1,2) ` : `t.status = 1`} and t.contact = ${req.body.contact}
          `
          const dataC = await db2.sequelize.query(thisQuery456);
          const dataC1 = dataC[0][0]?.l_contact_id
          const dataC2 = dataC[0][0]?.l_contact_name
          console.log("dataC1", dataC1);
          console.log("dataC2", dataC2);

        if(dataContactID?.toString() !== req.body.contact?.toString()) {
          const TaskContactLog = await db2['logs'].create({
            org_id: org_id,
            module_id: TaskID,
            module_name: "4",
            // note: 'Task contact name : ' + dataContactName + ' to '+ dataC2,
            note: 'Task contact name : ' + `${dataContactName == null || "" ? dataC2 : dataContactName + ' to '+ dataC2}`,
            user_id: created_by.id
          })
          console.log("Task Contact name",TaskContactLog.dataValues.note);
        }
        }
        // Property Name
        if(req.body.project) {
          let thisQueryPro = ` select t.project as l_property_id, pa1.name_of_building as l_property_name
          from lz_tasks as t
          left join lz_properties as p on (p.id = t.project)
          left join lz_property_addresses as pa1 on (p.id = pa1.property_id)
          where ${role_id == 1 ? `t.status IN (1,2) ` : `t.status = 1`} and t.project = ${req.body.project}
          `
          const dataPro = await db2.sequelize.query(thisQueryPro);
          const dataPro1 = dataPro[0][0]?.l_property_id
          const dataPro2 = dataPro[0][0]?.l_property_name
          console.log("dataPro1", dataPro1);
          console.log("dataPro2", dataPro2);

        if(dataProperty?.toString() !== req.body.project?.toString()) {
          const TaskPropertyLog = await db2['logs'].create({
            org_id: org_id,
            module_id: TaskID,
            module_name: "4",
            // note: 'Task propery name : ' + dataPropertyName + ' to '+ dataPro2,
            note: 'Task propery name : ' + `${dataPropertyName == null || "" ? dataPro2 : dataPropertyName + ' to '+ dataPro2}`,
            user_id: created_by.id
          })
          console.log("Lead Property",TaskPropertyLog.dataValues.note);
        }
        }

      res.status(200).send({
        status:200,
        message: "Updated successfully."
      });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot update with id : ${id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.deleteTask = async (req, res) => {
  const organ_id = req.user.id
  const org_id = organ_id.org_id
  console.log('organ_id', org_id);

  const created_by = req.user.id
  console.log('created_by', created_by.id);

    try {
      let x = req.params.id
      
      console.log("id111", x);

      let thisQuery  = ` UPDATE lz_tasks SET status = 0 `;
          thisQuery += " WHERE id IN (" + x + ") "
          thisQuery += ` and status = 1 `;

      const data = await db2.sequelize.query(thisQuery);

      res.status(200).send({
        status:200,
        message: "Deleted successfully!"
      });
    } 
    catch (error) {
      res.status(500).send({
      message: error.message,
    });
  }
}
exports.updateTaskPriorityStatus = async (req, res) => {
  try {
    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    const created_by = req.user.id
    console.log('created_by', created_by.id);

    const id = req.params.id;

    const data = {
      priority: req.body.priority,
    }

    const prior = req.body.priority
    console.log("priorrrrrr", prior);
    const num = await db2['tasks'].update(data, {
      where: {id: id},
    });
    if (num == 1) {

      let thisQuery = ` select option_value from lz_masters where option_type = "priority" and id = ${prior}`
      const data = await db2.sequelize.query(thisQuery);
      const dataValue = data[0][0].option_value
      console.log("dataaaaa", dataValue);

      const taskLogs = await db2['logs'].create({
        org_id: org_id,
        module_id: id,
        module_name: "4",
        note: "Priority status updated to " + ' - ' + dataValue,
        user_id: created_by.id,
        created_by: created_by.id
      })
      const taskNotes = await db2['notes'].create({
        org_id: org_id,
        module_id: id,
        module_name: '4',
        reply: req.body.reply,
        parent_id: "0",
        user_id: created_by.id,
        created_by: created_by.id
      })

      res.status(200).send({
        status:200,
        message: "Updated successfully."
      });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot update with id : ${id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.updateTaskStatus = async (req, res) => {
  try {
    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    const role = req.user.id
    const role_id = role.designation
    console.log('role_id', role_id);

    const created_by = req.user.id
    console.log('created_by', created_by.id);

    const id = req.params.id;

    let thisQuery = ` select t.task_status as task_status, cs.option_value as task_status_name
    from lz_tasks as t
    left join lz_masters as cs on (cs.id = t.task_status)
    where ${role_id == 1 ? `t.status IN (1,2) ` : `t.status = 1`} and t.id = ${id} `
    const data123= await db2.sequelize.query(thisQuery);

    const dataStatus = data123[0][0]?.task_status
    const dataStatusName = data123[0][0]?.task_status_name

    console.log("dataStatus", dataStatus);
    console.log("dataStatusName", dataStatusName);


    const data = {
      task_status: req.body.task_status,
    }

    const taskStatus = req.body.task_status
    console.log("taskStatusssss", taskStatus);

    const num = await db2['tasks'].update(data, {
      where: { id: id },
    });
    if (num == 1) {

      // let thisQuery = ` select option_value from lz_masters where option_type = "task_status" and id = ${taskStatus}`
      // const data = await db2.sequelize.query(thisQuery);
      // const dataValue = data[0][0]?.option_value
      // console.log("dataaaaa", dataValue);

      // const taskLogs = await db2['logs'].create({
      //   org_id: org_id,
      //   module_id: id,
      //   module_name: "4",
      //   note: "Task status updated to" +' - '+ dataValue,
      //   user_id: created_by.id,
      //   created_by: created_by.id
      // })

      const taskNotes = await db2['notes'].create({
        org_id: org_id,
        module_id: id,
        module_name: '4',
        reply: req.body.reply,
        parent_id: "0",
        user_id: created_by.id,
        created_by: created_by.id
      })

      const TaskID = req.params.id;

      // Task Status
      if(req.body.task_status) {
        let thisQuery456 = ` select t.task_status as l_status, cs.option_value as l_status_name
        from lz_tasks as t
        left join lz_masters as cs on (cs.id = t.task_status)
        where ${role_id == 1 ? `t.status IN (1,2) ` : `t.status = 1`} and t.task_status = ${req.body.task_status}
        `
        const dataCS = await db2.sequelize.query(thisQuery456);
        const dataCS1 = dataCS[0][0]?.l_status
        const dataCS2 = dataCS[0][0]?.l_status_name
        console.log("dataCS1", dataCS1);
        console.log("dataCS2", dataCS2);

        if(taskStatus == 158) {
          const TaskData = {
            status: 2,
          }
          const taskDrop = await db2['tasks'].update(TaskData,{
            where: { id: id },
          });
        }

      if(dataStatus.toString() !== req.body.task_status.toString()) {
        const TaskStatusLog = await db2['logs'].create({
          org_id: org_id,
          module_id: TaskID,
          module_name: "4",
          // note: 'Task status : ' + dataStatusName + ' to '+ dataCS2,
          note: 'Task status : ' + `${dataStatusName == null || "" ? dataCS2 : dataStatusName + ' to '+ dataCS2}`,
          user_id: created_by.id
        })
        console.log("Task Status",TaskStatusLog.dataValues.note);
      }
      }

      res.status(200).send({
        status:200,
        message: "Updated successfully."
      });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot update with id : ${id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};

// Task Filter
exports.saveTaskFilter = async (req, res) => {
  try {
    const created_by = req.user.id
    console.log('created_by', created_by.id);

    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    let thisQuery1 = ` SELECT id FROM lz_task_filter `
    const data1 = await db2.sequelize.query(thisQuery1);
    const totalTask = data1[0].length
    console.log("totalTask", totalTask);

    if (totalTask < 5) {
      const data = await db2['taskFilter'].create({
        org_id: org_id,
        task_type: req.body.task_type,
        priority: req.body.priority,
        assign_to: req.body.assign_to,
        project: req.body.project,
        contact: req.body.contact,
        filter_name: req.body.filter_name,
        agenda: req.body.agenda,
        reminder: req.body.reminder,
        task_status: req.body.task_status,
        created_date: req.body.created_date,
        updated_date: req.body.updated_date,
        created_by: created_by.id,
      });

      res.status(200).send({
        status: 200,
        message: 'Success',
        output: data
      });

    } else {
      res.status(200).send({
        status: 400,
        message: 'Only 5 filters can add',
        output: []
      });
    }

  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.getTaskFilter = async (req, res) => {
  try {
      
      const created_id = req.user.id
      const created_by = created_id.id
      console.log('created_by', created_by);
    
      const organ_id = req.user.id
      const org_id = organ_id.org_id
      console.log('organ_id', org_id);
    
      const role = req.user.id
      const role_id = role.designation
      console.log('role_id', role_id);
  
      let thisQuery = ` SELECT tf.*, GROUP_CONCAT(distinct CONCAT(us.first_name,' ', IFNULL(us.last_name, ''),'-',us.id)) as assign_to_name, ts.option_value as task_status_name, tt.option_value as task_type_name, pri.option_value as priority_name, rem.option_value as reminder_name, pas.name_of_building as property_name,  CONCAT(us.first_name,' ', IFNULL(us.last_name, '')) as contact_name
  
      FROM lz_task_filter as tf   
      left join lz_contacts as c on (c.id = tf.contact) 
      left join lz_property_addresses as pas on (pas.property_id = tf.project) 
      LEFT JOIN lz_user as us on FIND_IN_SET(us.id,tf.assign_to) > 0 
      LEFT JOIN lz_user as us3 on FIND_IN_SET(us3.id,tf.created_by) > 0 
      left join lz_masters as ts on (ts.id = tf.task_status) 
      left join lz_masters as tt on (tt.id = tf.task_type) 
      left join lz_masters as pri on (pri.id = tf.priority) 
      left join lz_masters as rem on (rem.id = tf.reminder) 
      where tf.id IS NOT NULL group by tf.id `;
    
    const data = await db2.sequelize.query(thisQuery);

      res.status(200).send({
          status: 200,
          message: 'Success',
          output: data[0]
      });
  } catch (error) {
      res.status(500).send({
          message: error.message,
      });
  }
};
exports.deleteTaskFilter = async (req, res) => {
  try {
    const id = req.params.id;
    const num = await db2['taskFilter'].destroy({
      where: { id: id },
    });
    if (num == 1) {
      res.status(200).send({
        status:200,
        message: "Deleted successfully."
      });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot delete with id : ${id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};

exports.bulkTaskReAssign = async (req, res) => {
  const organ_id = req.user.id
  const org_id = organ_id.org_id
  console.log('organ_id', org_id);

  const created_by = req.user.id
  console.log('created_by', created_by.id);

    try {
      let x = req.params.id
      console.log("id111", x);

      let thisQuery  = ` UPDATE lz_tasks SET assign_to = '${req.body.assign_to}' `;
          thisQuery += " WHERE id IN (" + x + ") "
          thisQuery += ` and status = 1 `;

      const data = await db2.sequelize.query(thisQuery);

      res.status(200).send({
        status:200,
        message:'Success',
        output:data[0]
      });

    } catch (error) {
      res.status(500).send({
        message: error.message,
      });
    }
};