const db2 = require("../orgModel/orgIndex.js");
const Op = db2.Sequelize.Op;
const mailer = require("../orgModel/mailer.model.js");

exports.saveFeeConfirmation = async (req, res) => {
  try {
    const created_id = req.user.id
    const created_by = created_id.id
    console.log('created_by', created_by.id);

    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    const data = await db2['financeFeeConfirmation'].create({
      transaction_id: req.body.transaction_id,
      fee_confirmation_date: req.body.fee_confirmation_date,
      contact_name: req.body.contact_name,
      developer_name: req.body.developer_name,
      project_name: req.body.project_name,
      brokerage_value: req.body.brokerage_value,
      due_date: req.body.due_date,
      transaction_status: req.body.transaction_status,
      description: req.body.description,
      created_by: created_by
    });

    // Email Trigger
    const email_settings = await db2.sequelize.query(`select status from lz_email_trigger where status = 1 `);
    // const emailTri = email_settings[0][0] ? email_settings[0][0]["active_status"] : 0
    const emailTri = email_settings[0][0]["status"]
    console.log("emailTri", emailTri);

    //nodemailer
      if(emailTri == 1) {

      let thisQueryDes = ` select us.team_leader as tl, us.portfolio_head as sub_tl 
      from lz_user as us where id = ${created_by} `
      const desCheck = await db2.sequelize.query(thisQueryDes);
      const desCheckTL = desCheck[0][0].tl
      const desCheckSubTL = desCheck[0][0].sub_tl
    
      const checkTl = await db2.sequelize.query(`select email from lz_user where id = ${desCheckTL} `);
      const checkTl1 = checkTl[0][0].email
      const checksubTL = await db2.sequelize.query(`select email from lz_user where id = ${desCheckSubTL} `);
      const checksubTL1 = checksubTL[0][0].email
      const checkAdmin = await db2.sequelize.query(`select email from lz_user where designation = 1 group by id `);
      const checkAdmin1 = checkAdmin[0].map(item => item.email).join(', ');
    
      console.log("checkTl", checkTl1);
      console.log("checksubTL1", checksubTL1);
      console.log("checkAdmin1", checkAdmin1);
    
      const createdEmail = await db2.sequelize.query(`select email from lz_user where id = ${created_by} `);
      const cEmail = createdEmail[0][0].email
      console.log("cEmail", cEmail);

      let thisQueryPro = `select p.id as id, pa.name_of_building as property_name
      from lz_properties p
      left join lz_property_addresses as pa on (p.id = pa.property_id)
      where p.status = 1 and pa.property_id = '${req.body.project_name}' `;

      const project_name_data = await db2.sequelize.query(thisQueryPro)
      console.log("project_name_data", project_name_data[0][0]);

      const project_name = project_name_data[0][0] ? project_name_data[0][0].property_name : 0
      console.log('project_name', project_name);

      let message = {
        from: cEmail,
        to: [checkAdmin1,checkTl1,checksubTL1].join(', '),
        subject: "Fee Confirmation Created",
        html:
          "<h3> Fee Confirmation has been created </h3>" +
          "<h3> Project Id: </h3>" +
          req.body.project_name +
          "<h3>Project Name:</h3>" +
          project_name + "",
      };
      console.log("message", message);
      mailer.sendMail(message, function(error, info){
        if (error) {
          console.log('Error');
        } else {
          console.log('Email sent: ' + info.response);
        }
      });
    }

    res.status(200).send({
      status:200,
      message:'Success',
      output:data
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.getFeeConfirmation = async (req, res) => {
  try {
      const organ_id = req.user.id
      const org_id = organ_id.org_id
      console.log('organ_id', org_id);

      let thisQuery = ` SELECT fec.*,
      CONCAT(us.first_name,' ',IFNULL(us.last_name, '')) as created_name,
      CONCAT(c.first_name,' ',IFNULL(c.last_name, '')) as client_fullname, CONCAT(c1.first_name,' ',IFNULL(c1.last_name, '')) as developer_fullname, pa.name_of_building as property_name, tr.lead_source as source,
      CONCAT(c1.first_name,' ',IFNULL(c1.last_name, '')) as developer_fullname, 
      GROUP_CONCAT(distinct CONCAT(IFNULL(us1.first_name, ''))) as team_leader_name, 
      GROUP_CONCAT(distinct CONCAT(IFNULL(us2.first_name, ''))) as shared_with_name, 
      ls.option_value as source_name, ts.option_value as transaction_status_name
      FROM lz_finance_fee_confirmation as fec
      LEFT JOIN lz_transactions as tr on (tr.id = fec.transaction_id)
      LEFT JOIN lz_contacts as c on (c.id = fec.contact_name) 
      LEFT JOIN lz_contacts as c1 on (c1.id = tr.developer_name) 
      LEFT JOIN lz_property_addresses as pa on (pa.property_id = tr.project_name)
      LEFT JOIN lz_leads as l on (l.id = tr.lead_id)
      LEFT JOIN lz_masters as ls on (ls.id = tr.lead_source)
      LEFT JOIN lz_masters as ts on (ts.id = fec.transaction_status)
      LEFT JOIN lz_user as us on (us.id = fec.created_by)
      LEFT JOIN lz_user as us2 on FIND_IN_SET(us2.id,tr.shared_with)>0 
      LEFT JOIN lz_user as us1 on FIND_IN_SET(us1.id,tr.team_leader)>0
      where fec.status = 1 
      group by fec.id
      `
      const data = await db2.sequelize.query(thisQuery);

    res.status(200).send({
      status:200,
      message:'Success',
      output:data[0]
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.editFeeConfirmation = async (req, res) => {

try {
  const organ_id = req.user.id
  const org_id = organ_id.org_id
  console.log('organ_id', org_id);

  const id = req.params.id;

  let thisQuery = ` SELECT fec.*,
  CONCAT(us.first_name,' ',IFNULL(us.last_name, '')) as created_name,
  CONCAT(c.first_name,' ',IFNULL(c.last_name, '')) as client_fullname, CONCAT(c1.first_name,' ',IFNULL(c1.last_name, '')) as developer_fullname, pa.name_of_building as property_name,
  CONCAT(c1.first_name,' ',IFNULL(c1.last_name, '')) as developer_fullname, 
  GROUP_CONCAT(distinct CONCAT(IFNULL(us1.first_name, ''))) as team_leader_name, 
  GROUP_CONCAT(distinct CONCAT(IFNULL(us2.first_name, ''))) as shared_with_name, 
  ls.name as source_name, ts.option_value as transaction_status_name
  FROM lz_finance_fee_confirmation as fec
  LEFT JOIN lz_transactions as tr on (tr.id = fec.transaction_id)
  LEFT JOIN lz_contacts as c on (c.id = fec.contact_name) 
  LEFT JOIN lz_contacts as c1 on (c1.id = tr.developer_name) 
  LEFT JOIN lz_property_addresses as pa on (pa.property_id = tr.project_name)
  LEFT JOIN lz_leads as l on (l.id = tr.lead_id)
  LEFT JOIN lz_source as ls on (ls.id = tr.lead_source)
  LEFT JOIN lz_masters as ts on (ts.id = fec.transaction_status)
  LEFT JOIN lz_user as us on (us.id = fec.created_by)
  LEFT JOIN lz_user as us2 on FIND_IN_SET(us2.id,tr.shared_with)>0 
  LEFT JOIN lz_user as us1 on FIND_IN_SET(us1.id,tr.team_leader)>0
  where fec.status = 1 and fec.id = ${id}
  group by fec.id
  `
  const data = await db2.sequelize.query(thisQuery);
  
  if (data) {
  res.status(200).send({
      status:200,
      message:'Success',
      output:data[0]
      });
  } else {
  res.status(200).send({
      status:404,
      message: `Cannot find with id : ${id}.`
  });
  }
} catch (error) {
  res.status(500).send({
  message: error.message,
  });
}
};
exports.updateFeeConfirmation = async (req, res) => {
try {
  const id = req.params.id;
  const data = {
    transaction_id: req.body.transaction_id,
    fee_confirmation_date: req.body.fee_confirmation_date,
    contact_name: req.body.contact_name,
    developer_name: req.body.developer_name,
    project_name: req.body.project_name,
    brokerage_value: req.body.brokerage_value,
    due_date: req.body.due_date,
    transaction_status: req.body.transaction_status,
    description: req.body.description,
  }
  const num = await db2['financeFeeConfirmation'].update(data, {
  where: { id: id },
  });
  if (num == 1) {
  res.status(200).send({
      status:200,
      message: "Updated successfully."
  });
  } else {
  res.status(200).send({
      status:404,
      message: `Cannot update with id : ${id}.`
  });
  }
} catch (error) {
  res.status(500).send({
  message: error.message,
  });
}
};
exports.deleteFeeConfirmation = async (req, res) => {
const financeData = {
  status: 0,
}
try {
  const id = req.params.id;
  const num = await db2['financeFeeConfirmation'].update(financeData,{
  where: { id: id },
  });
  if (num == 1) {
  res.status(200).send({
      status:200,
      message: "Deleted successfully!"
  });
  } else {
  res.status(200).send({
      status:404,
      message: `Cannot delete with id : ${id}.`
  });
  }
} catch (error) {
  res.status(500).send({
  message: error.message,
  });
}
};

exports.saveProInvoice = async (req, res) => {
  try {
    const created_by = req.user.id
    console.log('created_by', created_by.id);

    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    const data = await db2['financeProInvoice'].create({
      transaction_id: req.body.transaction_id,
      date: req.body.date,
      fee_confirmation_id: req.body.fee_confirmation_id,
      contact_name: req.body.contact_name,
      developer_name: req.body.developer_name,
      project_name: req.body.project_name,
      due_date: req.body.due_date,
      expense_id: req.body.expense_id,
      tax: req.body.tax,
      total_amount: req.body.total_amount,
      description: req.body.description,
      created_by: created_by.id
    });

    res.status(200).send({
      status:200,
      message:'Success',
      output:data
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.getProInvoice = async (req, res) => {
  try {
      const organ_id = req.user.id
      const org_id = organ_id.org_id
      console.log('organ_id', org_id);

      let thisQuery = `  select f.*, 
      CONCAT(c.first_name,' ',IFNULL(c.last_name, '')) as client_fullname , 
      CONCAT(us.first_name,' ',IFNULL(us.last_name, ''))  as created_name, 
      pa.name_of_building as property_name,
      CONCAT(c1.first_name,' ',IFNULL(c1.last_name, '')) as developer_fullname, 
      CONVERT(t.team_leader USING utf8) as team_leader, 
      CONVERT(t.shared_with USING utf8) as shared_with, 
      GROUP_CONCAT(distinct CONCAT(IFNULL(us1.first_name, ''))) as team_leader_name, 
      GROUP_CONCAT(distinct CONCAT(IFNULL(us2.first_name, ''))) as shared_with_name, 
      t.agreement_value as aggrement_value, 
      t.brokerage_value as brokerage_value, 
      ls.option_value as lead_source_name, 
      GROUP_CONCAT(distinct CONCAT(ett1.option_value)) as expense_name
      from lz_finance_pro_invoice as f
      left join lz_transactions as t on (t.id=f.transaction_id) 
      left join lz_leads as l on (l.id=t.lead_id) 
      left join lz_masters as ls on (ls.id = t.lead_source) 
      left join lz_expenses as e1 on FIND_IN_SET(e1.id,f.expense_id)>0 
      left join lz_expense_details as ed on (ed.expense_id = e1.id)
      left join lz_property_addresses as pa1 on (pa1.id = ed.project_id)
      left join lz_contacts as c on (c.id = f.contact_name)
      left join lz_contacts as c1 on (c1.id = f.developer_name)
      left join lz_properties as pro on (pro.id = f.project_name)
      left join lz_property_addresses as pa on (pa.property_id = pro.id)
      left join lz_masters as ett on (ett.id = f.expense_id)
      left join lz_masters as ett1 on FIND_IN_SET(ett1.id,f.expense_id)>0
      left join lz_user as us on (us.id=f.created_by)
      left join lz_user as us2 on FIND_IN_SET(us2.id,t.shared_with)>0
      left join lz_user as us1 on FIND_IN_SET(us1.id,t.team_leader)>0 
      where f.status = 1 
      group by f.id
      order by f.id desc
      `
      const data = await db2.sequelize.query(thisQuery);

    res.status(200).send({
      status:200,
      message:'Success',
      output:data[0]
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.editProInvoice = async (req, res) => {

try {
  const organ_id = req.user.id
  const org_id = organ_id.org_id
  console.log('organ_id', org_id);

  const id = req.params.id;

  let thisQuery = ` SELECT fec.*,
  CONCAT(us.first_name,' ',IFNULL(us.last_name, '')) as created_name,
  CONCAT(c.first_name,' ',IFNULL(c.last_name, '')) as client_fullname, CONCAT(c1.first_name,' ',IFNULL(c1.last_name, '')) as developer_fullname, pa.name_of_building as property_name,
  CONCAT(c1.first_name,' ',IFNULL(c1.last_name, '')) as developer_fullname, 
  GROUP_CONCAT(distinct CONCAT(IFNULL(us1.first_name, ''))) as team_leader_name, 
  GROUP_CONCAT(distinct CONCAT(IFNULL(us2.first_name, ''))) as shared_with_name, 
  ls.option_value as lead_source_name, ett.option_value as expense_name
  FROM lz_finance_pro_invoice as fec
  LEFT JOIN lz_transactions as tr on (tr.id = fec.transaction_id)
  LEFT JOIN lz_contacts as c on (c.id = fec.contact_name) 
  LEFT JOIN lz_contacts as c1 on (c1.id = tr.developer_name) 
  LEFT JOIN lz_property_addresses as pa on (pa.property_id = tr.project_name)
  LEFT JOIN lz_leads as l on (l.id = tr.lead_id)
  left join lz_masters as ls on (ls.id = tr.lead_source) 
  left join lz_masters as ett on (ett.id = fec.expense_id)
  LEFT JOIN lz_user as us on (us.id = fec.created_by)
  LEFT JOIN lz_user as us2 on FIND_IN_SET(us2.id,tr.shared_with)>0 
  LEFT JOIN lz_user as us1 on FIND_IN_SET(us1.id,tr.team_leader)>0
  where fec.status = 1 and fec.id = ${id}
  group by fec.id
  `
  const data = await db2.sequelize.query(thisQuery);
  
  if (data) {
  res.status(200).send({
      status:200,
      message:'Success',
      output:data[0]
      });
  } else {
  res.status(200).send({
      status:404,
      message: `Cannot find with id : ${id}.`
  });
  }
} catch (error) {
  res.status(500).send({
  message: error.message,
  });
}
};
exports.updateProInvoice = async (req, res) => {
try {
  const id = req.params.id;
  const data = {
    transaction_id: req.body.transaction_id,
    date: req.body.date,
    fee_confirmation_id: req.body.fee_confirmation_id,
    contact_name: req.body.contact_name,
    developer_name: req.body.developer_name,
    project_name: req.body.project_name,
    due_date: req.body.due_date,
    expense_id: req.body.expense_id,
    tax: req.body.tax,
    total_amount: req.body.total_amount,
    description: req.body.description,
  }
  const num = await db2['financeProInvoice'].update(data, {
  where: { id: id },
  });
  if (num == 1) {
  res.status(200).send({
      status:200,
      message: "Updated successfully."
  });
  } else {
  res.status(200).send({
      status:404,
      message: `Cannot update with id : ${id}.`
  });
  }
} catch (error) {
  res.status(500).send({
  message: error.message,
  });
}
};
exports.deleteProInvoice = async (req, res) => {
const financeData = {
  status: 0,
}
try {
  const id = req.params.id;
  const num = await db2['financeProInvoice'].update(financeData,{
  where: { id: id },
  });
  if (num == 1) {
  res.status(200).send({
      status:200,
      message: "Deleted successfully!"
  });
  } else {
  res.status(200).send({
      status:404,
      message: `Cannot delete with id : ${id}.`
  });
  }
} catch (error) {
  res.status(500).send({
  message: error.message,
  });
}
};

exports.saveInvoice = async (req, res) => {
  try {
    const created_id = req.user.id
    const created_by = created_id.id
    console.log('created_by', created_by.id);

    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    const data = await db2['financeInvoice'].create({
      transaction_id: req.body.transaction_id,
      fee_confirmation_id: req.body.fee_confirmation_id,
      pro_invoice_id: req.body.pro_invoice_id,
      contact_name: req.body.contact_name,
      developer_name: req.body.developer_name,
      project_name: req.body.project_name,
      due_date: req.body.due_date,
      expense_id: req.body.expense_id,
      tax: req.body.tax,
      total_amount: req.body.total_amount,
      invoice_status: req.body.invoice_status,
      created_by: created_by
    });

    // Email Trigger
    const email_settings = await db2.sequelize.query(`select status from lz_email_trigger where status = 1 `);
    // const emailTri = email_settings[0][0] ? email_settings[0][0]["active_status"] : 0
    const emailTri = email_settings[0][0]["status"]
    console.log("emailTri", emailTri);

    //nodemailer
      if(emailTri == 1) {

      let thisQueryDes = ` select us.team_leader as tl, us.portfolio_head as sub_tl 
      from lz_user as us where id = ${created_by} `
      const desCheck = await db2.sequelize.query(thisQueryDes);
      const desCheckTL = desCheck[0][0].tl
      const desCheckSubTL = desCheck[0][0].sub_tl
    
      const checkTl = await db2.sequelize.query(`select email from lz_user where id = ${desCheckTL} `);
      const checkTl1 = checkTl[0][0].email
      const checksubTL = await db2.sequelize.query(`select email from lz_user where id = ${desCheckSubTL} `);
      const checksubTL1 = checksubTL[0][0].email
      const checkAdmin = await db2.sequelize.query(`select email from lz_user where designation = 1 group by id `);
      const checkAdmin1 = checkAdmin[0].map(item => item.email).join(', ');
    
      console.log("checkTl", checkTl1);
      console.log("checksubTL1", checksubTL1);
      console.log("checkAdmin1", checkAdmin1);
    
      const createdEmail = await db2.sequelize.query(`select email from lz_user where id = ${created_by} `);
      const cEmail = createdEmail[0][0].email
      console.log("cEmail", cEmail);

      let thisQueryPro = `select p.id as id, pa.name_of_building as property_name
      from lz_properties p
      left join lz_property_addresses as pa on (p.id = pa.property_id)
      where p.status = 1 and pa.property_id = '${req.body.project_name}' `;

      const project_name_data = await db2.sequelize.query(thisQueryPro)
      console.log("project_name_data", project_name_data[0][0]);

      const project_name = project_name_data[0][0] ? project_name_data[0][0].property_name : 0
      console.log('project_name', project_name);

      let message = {
        from: cEmail,
        to: [checkAdmin1,checkTl1,checksubTL1].join(', '),
        subject: "Finance Invoice Created",
        html:
          "<h3> Finance Invoice has been created </h3>" +
          "<h3> Project Id: </h3>" +
          req.body.project_name +
          "<h3>Project Name:</h3>" +
          project_name + "",
      };
      console.log("message", message);
      mailer.sendMail(message, function(error, info){
        if (error) {
          console.log('Error');
        } else {
          console.log('Email sent: ' + info.response);
        }
      });
    }

    res.status(200).send({
      status:200,
      message:'Success',
      output:data
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.getInvoice = async (req, res) => {
  try {
      const organ_id = req.user.id
      const org_id = organ_id.org_id
      console.log('organ_id', org_id);

      let thisQuery = `select f.*, CONCAT(c1.first_name,' ',IFNULL(c1.last_name, '')) as developer_fullname, CONCAT(c.first_name,' ',IFNULL(c.last_name, '')) as client_fullname , 
      CONCAT(us.first_name,' ',IFNULL(us.last_name, ''))  as created_name, 
      pa.name_of_building as property_name,
      CONCAT(c1.first_name,' ',IFNULL(c1.last_name, '')) as developer_fullname, 
      CONVERT(t.team_leader USING utf8) as team_leader, 
      CONVERT(t.shared_with USING utf8) as shared_with, 
      GROUP_CONCAT(distinct CONCAT(IFNULL(us1.first_name, ''))) as team_leader_name, 
      GROUP_CONCAT(distinct CONCAT(IFNULL(us2.first_name, ''))) as shared_with_name, 
      t.agreement_value as aggrement_value, 
      t.brokerage_value as brokerage_value, 
      ls.option_value as lead_source_name,
      ins.option_value as invoice_status_name,
      GROUP_CONCAT(distinct CONCAT(ett1.option_value)) as expense_name
      from lz_finance_invoice as f
      left join lz_transactions as t on (t.id=f.transaction_id)
      left join lz_leads as l on (l.id=t.lead_id)
      left join lz_masters as ls on (ls.id = t.lead_source)
      left join lz_masters as ins on (ins.id = f.invoice_status)
      LEFT JOIN lz_contacts as c on (c.id = f.contact_name)
      LEFT JOIN lz_contacts as c1 on (c1.id = f.developer_name)
      LEFT JOIN lz_property_addresses as pa on (pa.property_id = f.project_name)
      LEFT JOIN lz_finance_fee_confirmation as ffc on (ffc.id = f.fee_confirmation_id)
      LEFT JOIN lz_finance_pro_invoice as fpi on (fpi.id = f.pro_invoice_id)
      left join lz_expenses as e1 on FIND_IN_SET(e1.id,f.expense_id)>0
      left join lz_masters as ett1 on FIND_IN_SET(ett1.id,f.expense_id)>0
      left join lz_expense_details as ed on (ed.expense_id = e1.id)
      left join lz_property_addresses as pa1 on (pa1.id = ed.project_id)
      LEFT JOIN lz_user as us on (us.id = f.created_by)
      left join lz_user as us2 on FIND_IN_SET(us2.id,t.shared_with)>0
      left join lz_user as us1 on FIND_IN_SET(us1.id,t.team_leader)>0
      where f.status = 1 
      group by f.id
      order by f.id
      `
      const data = await db2.sequelize.query(thisQuery);

    res.status(200).send({
      status:200,
      message:'Success',
      output:data[0]
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.editInvoice = async (req, res) => {

try {
  const organ_id = req.user.id
  const org_id = organ_id.org_id
  console.log('organ_id', org_id);

  const id = req.params.id;

  let thisQuery = `select f.*, CONCAT(c1.first_name,' ',IFNULL(c1.last_name, '')) as developer_fullname, CONCAT(c.first_name,' ',IFNULL(c.last_name, '')) as client_fullname , 
  CONCAT(us.first_name,' ',IFNULL(us.last_name, ''))  as created_name, 
  pa.name_of_building as property_name,
  CONCAT(c1.first_name,' ',IFNULL(c1.last_name, '')) as developer_fullname, 
  CONVERT(t.team_leader USING utf8) as team_leader, 
  CONVERT(t.shared_with USING utf8) as shared_with, 
  GROUP_CONCAT(distinct CONCAT(IFNULL(us1.first_name, ''))) as team_leader_name, 
  GROUP_CONCAT(distinct CONCAT(IFNULL(us2.first_name, ''))) as shared_with_name, 
  t.agreement_value as aggrement_value, 
  t.brokerage_value as brokerage_value, 
  ls.option_value as lead_source_name,
  ins.option_value as invoice_status_name,
  GROUP_CONCAT(distinct CONCAT(ett1.option_value)) as expense_name
  from lz_finance_invoice as f
  left join lz_transactions as t on (t.id=f.transaction_id)
  left join lz_leads as l on (l.id=t.lead_id)
  left join lz_masters as ls on (ls.id = t.lead_source)
  left join lz_masters as ins on (ins.id = f.invoice_status)
  LEFT JOIN lz_contacts as c on (c.id = f.contact_name)
  LEFT JOIN lz_contacts as c1 on (c1.id = f.developer_name)
  LEFT JOIN lz_property_addresses as pa on (pa.property_id = f.project_name)
  LEFT JOIN lz_finance_fee_confirmation as ffc on (ffc.id = f.fee_confirmation_id)
  LEFT JOIN lz_finance_pro_invoice as fpi on (fpi.id = f.pro_invoice_id)
  left join lz_expenses as e1 on FIND_IN_SET(e1.id,f.expense_id)>0
  left join lz_masters as ett1 on FIND_IN_SET(ett1.id,f.expense_id)>0
  left join lz_expense_details as ed on (ed.expense_id = e1.id)
  left join lz_property_addresses as pa1 on (pa1.id = ed.project_id)
  LEFT JOIN lz_user as us on (us.id = f.created_by)
  left join lz_user as us2 on FIND_IN_SET(us2.id,t.shared_with)>0
  left join lz_user as us1 on FIND_IN_SET(us1.id,t.team_leader)>0
  where f.status = 1 and f.id = ${id}
  group by f.id 
  order by f.id DESC
  `
  const data = await db2.sequelize.query(thisQuery);
  
  if (data) {
  res.status(200).send({
      status:200,
      message:'Success',
      output:data[0]
      });
  } else {
  res.status(200).send({
      status:404,
      message: `Cannot find with id : ${id}.`
  });
  }
} catch (error) {
  res.status(500).send({
  message: error.message,
  });
}
};  
exports.updateInvoice = async (req, res) => {
try {
  const id = req.params.id;
  const data = {
    transaction_id: req.body.transaction_id,
    fee_confirmation_id: req.body.fee_confirmation_id,
    pro_invoice_id: req.body.pro_invoice_id,
    contact_name: req.body.contact_name,
    developer_name: req.body.developer_name,
    project_name: req.body.project_name,
    due_date: req.body.due_date,
    expense_id: req.body.expense_id,
    tax: req.body.tax,
    total_amount: req.body.total_amount,
    invoice_status: req.body.invoice_status,
  }
  const num = await db2['financeInvoice'].update(data, {
  where: { id: id },
  });
  if (num == 1) {
  res.status(200).send({
      status:200,
      message: "Updated successfully."
  });
  } else {
  res.status(200).send({
      status:404,
      message: `Cannot update with id : ${id}.`
  });
  }
} catch (error) {
  res.status(500).send({
  message: error.message,
  });
}
};
exports.deleteInvoice = async (req, res) => {
const financeData = {
  status: 0,
}
try {
  const id = req.params.id;
  const num = await db2['financeInvoice'].update(financeData,{
  where: { id: id },
  });
  if (num == 1) {
  res.status(200).send({
      status:200,
      message: "Deleted successfully!"
  });
  } else {
  res.status(200).send({
      status:404,
      message: `Cannot delete with id : ${id}.`
  });
  }
} catch (error) {
  res.status(500).send({
  message: error.message,
  });
}
};

exports.saveInvoiceCollection = async (req, res) => {
  try {
    const created_id = req.user.id
    const created_by = created_id.id
    console.log('created_by', created_by);

    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    const data = await db2['financeCollection'].create({
      transaction_id: req.body.transaction_id,
      fee_confirmation_id: req.body.fee_confirmation_id,
      invoice_number: req.body.invoice_number,
      invoice_date: req.body.invoice_date,
      total_invoiced_value: req.body.total_invoiced_value,
      total_collection_value: req.body.total_collection_value,
      total_due_value: req.body.total_due_value,
      bad_debts: req.body.bad_debts,
      notes: req.body.notes,
      collection_status: req.body.collection_status,
      created_by: created_by
    });

    // Email Trigger
    const email_settings = await db2.sequelize.query(`select status from lz_email_trigger where module_id = 1 and status = 1 `);
    // const emailTri = email_settings[0][0] ? email_settings[0][0]["active_status"] : 0
    const emailTri = email_settings[0][0]["status"]
    console.log("emailTri", emailTri);

    //nodemailer
      if(emailTri == 1) {

      let thisQueryDes = ` select us.team_leader as tl, us.portfolio_head as sub_tl 
      from lz_user as us where id = ${created_by} `
      const desCheck = await db2.sequelize.query(thisQueryDes);
      const desCheckTL = desCheck[0][0].tl
      const desCheckSubTL = desCheck[0][0].sub_tl
      // Team Leader
      const checkTl = await db2.sequelize.query(`select email from lz_user where id = ${desCheckTL} `);
      const checkTl1 = checkTl[0][0].email
      // Sub TL
      const checksubTL = await db2.sequelize.query(`select email from lz_user where id = ${desCheckSubTL} `);
      const checksubTL1 = checksubTL[0][0].email
      // Admin
      const checkAdmin = await db2.sequelize.query(`select email from lz_user where designation = 1 group by id `);
      const checkAdmin1 = checkAdmin[0].map(item => item.email).join(', ');
    
      console.log("checkTl", checkTl1);
      console.log("checksubTL1", checksubTL1);
      console.log("checkAdmin1", checkAdmin1);
    
      const createdEmail = await db2.sequelize.query(`select email from lz_user where id = ${created_by} `);
      const cEmail = createdEmail[0][0].email
      console.log("cEmail", cEmail);

      let message = {
        from: cEmail,
        to: [checkAdmin1,checkTl1,checksubTL1].join(', '),
        subject: "New Collection Created",
        html:
          "<h3> New Collection created </h3>"
      };
      console.log("message", message);
      mailer.sendMail(message, function(error, info){
        if (error) {
          console.log('Error');
        } else {
          console.log('Email sent: ' + info.response);
        }
      });
    }

    res.status(200).send({
      status:200,
      message:'Success',
      output:data
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.getInvoiceCollection = async (req, res) => {
  try {
      const organ_id = req.user.id
      const org_id = organ_id.org_id
      console.log('organ_id', org_id);

      let thisQuery = `SELECT f.*, CONCAT(us.first_name,' ',IFNULL(us.last_name, '')) as created_name, CONCAT(c.first_name,' ',IFNULL(c.last_name, '')) as client_fullname, CONCAT(c1.first_name,' ',IFNULL(c1.last_name, '')) as developer_fullname, pa.name_of_building as property_name,
      CONCAT(c1.first_name,' ',IFNULL(c1.last_name, '')) as developer_fullname, 
      CONVERT(t.team_leader USING utf8) as team_leader, 
      CONVERT(t.shared_with USING utf8) as shared_with, 
      GROUP_CONCAT(distinct CONCAT(IFNULL(us1.first_name, ''))) as team_leader_name, 
      GROUP_CONCAT(distinct CONCAT(IFNULL(us2.first_name, ''))) as shared_with_name, 
      t.agreement_value as aggrement_value, 
      t.brokerage_value as brokerage_value, 
      ls.option_value as lead_source_name,
      cs.option_value as collection_status_name,
      fc.due_date as due_date
      FROM lz_finance_invoice_collection as f 

      LEFT JOIN lz_transactions as t on (t.id = f.transaction_id) 
      LEFT JOIN lz_contacts as c on (c.id = t.client_name) 
      LEFT JOIN lz_contacts as c1 on (c1.id = t.developer_name) 
      LEFT JOIN lz_leads as l on (l.id=t.lead_id) 
      LEFT JOIN lz_masters as ls on (ls.id = t.lead_source) 
      LEFT JOIN lz_masters as cs on (cs.id = f.collection_status)
      LEFT JOIN lz_property_addresses as pa on (pa.property_id = t.project_name) 
      LEFT JOIN lz_finance_fee_confirmation as fc on (fc.id = f.fee_confirmation_id) 
      LEFT JOIN lz_user as us on (us.id = f.created_by) 
      LEFT JOIN lz_user as us2 on FIND_IN_SET(us2.id,t.shared_with)>0 
      LEFT JOIN lz_user as us1 on FIND_IN_SET(us1.id,t.team_leader)>0 
      where f.status = 1 
      group by f.id
      `
      const data = await db2.sequelize.query(thisQuery);

    res.status(200).send({
      status:200,
      message:'Success',
      output:data[0]
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.editInvoiceCollection = async (req, res) => {

try {
  const organ_id = req.user.id
  const org_id = organ_id.org_id
  console.log('organ_id', org_id);

  const id = req.params.id;

  let thisQuery = `SELECT f.*, CONCAT(us.first_name,' ',IFNULL(us.last_name, '')) as created_name, CONCAT(c.first_name,' ',IFNULL(c.last_name, '')) as client_fullname, CONCAT(c1.first_name,' ',IFNULL(c1.last_name, '')) as developer_fullname, pa.name_of_building as property_name,
  CONCAT(c1.first_name,' ',IFNULL(c1.last_name, '')) as developer_fullname, 
  CONVERT(t.team_leader USING utf8) as team_leader, 
  CONVERT(t.shared_with USING utf8) as shared_with, 
  GROUP_CONCAT(distinct CONCAT(IFNULL(us1.first_name, ''))) as team_leader_name, 
  GROUP_CONCAT(distinct CONCAT(IFNULL(us2.first_name, ''))) as shared_with_name, 
  t.agreement_value as aggrement_value, 
  t.brokerage_value as brokerage_value, 
  ls.option_value as lead_source_name,
  cs.option_value as collection_status_name,
  fc.due_date as due_date
  FROM lz_finance_invoice_collection as f 

  LEFT JOIN lz_transactions as t on (t.id = f.transaction_id) 
  LEFT JOIN lz_contacts as c on (c.id = t.client_name) 
  LEFT JOIN lz_contacts as c1 on (c1.id = t.developer_name) 
  LEFT JOIN lz_leads as l on (l.id=t.lead_id) 
  LEFT JOIN lz_masters as ls on (ls.id = t.lead_source) 
  LEFT JOIN lz_masters as cs on (cs.id = f.collection_status) 
  LEFT JOIN lz_property_addresses as pa on (pa.property_id = t.project_name) 
  LEFT JOIN lz_finance_fee_confirmation as fc on (fc.id = f.fee_confirmation_id) 
  LEFT JOIN lz_user as us on (us.id = f.created_by) 
  LEFT JOIN lz_user as us2 on FIND_IN_SET(us2.id,t.shared_with)>0 
  LEFT JOIN lz_user as us1 on FIND_IN_SET(us1.id,t.team_leader)>0 
  where f.status = 1 and f.id = ${id}
  group by f.id
  `
  const data = await db2.sequelize.query(thisQuery);
  
  if (data) {
  res.status(200).send({
      status:200,
      message:'Success',
      output:data[0]
      });
  } else {
  res.status(200).send({
      status:404,
      message: `Cannot find with id : ${id}.`
  });
  }
} catch (error) {
  res.status(500).send({
  message: error.message,
  });
}
};
exports.updateInvoiceCollection = async (req, res) => {
try {
  const id = req.params.id;
  const data = {
    transaction_id: req.body.transaction_id,
    fee_confirmation_id: req.body.fee_confirmation_id,
    invoice_number: req.body.invoice_number,
    invoice_date: req.body.invoice_date,
    total_invoiced_value: req.body.total_invoiced_value,
    total_collection_value: req.body.total_collection_value,
    total_due_value: req.body.total_due_value,
    bad_debts: req.body.bad_debts,
    notes: req.body.notes,
    collection_status: req.body.collection_status,
  }
  const num = await db2['financeCollection'].update(data, {
  where: { id: id },
  });
  if (num == 1) {
  res.status(200).send({
      status:200,
      message: "Updated successfully."
  });
  } else {
  res.status(200).send({
      status:404,
      message: `Cannot update with id : ${id}.`
  });
  }
} catch (error) {
  res.status(500).send({
  message: error.message,
  });
}
};
exports.deleteInvoiceCollection = async (req, res) => {
const financeData = {
  status: 0,
}
try {
  const id = req.params.id;
  const num = await db2['financeCollection'].update(financeData,{
  where: { id: id },
  });
  if (num == 1) {
  res.status(200).send({
      status:200,
      message: "Deleted successfully!"
  });
  } else {
  res.status(200).send({
      status:404,
      message: `Cannot delete with id : ${id}.`
  });
  }
} catch (error) {
  res.status(500).send({
  message: error.message,
  });
}
};

exports.saveIncentives = async (req, res) => {
    try {
      const created_by = req.user.id
      console.log('created_by', created_by.id);

      const organ_id = req.user.id
      const org_id = organ_id.org_id
      console.log('organ_id', org_id);

      const data = await db2['financeIncentives'].create({
        transaction_id: req.body.transaction_id,
        invoice_number: req.body.invoice_number,
        select_brokers: req.body.select_brokers,
        total_incentive: req.body.total_incentive,
        incentive_payable: req.body.incentive_payable,
        paid_amount: req.body.paid_amount,
        incentive_due: req.body.incentive_due,
        description: req.body.description,
        created_by: created_by.id
      });
  
      res.status(200).send({
        status:200,
        message:'Success',
        output:data
      });
    } catch (error) {
      res.status(500).send({
        message: error.message,
      });
    }
};
exports.getIncentives = async (req, res) => {
    try {
        const organ_id = req.user.id
        const org_id = organ_id.org_id
        console.log('organ_id', org_id);

        let thisQuery = ` SELECT fi.*,
        GROUP_CONCAT(distinct CONCAT(us3.first_name,' ',IFNULL(us3.last_name, ''))) as brokers_name,
        fiv.transaction_id as transaction_id,
        tr.client_name as client_name,
        tr.project_name as project_name,
        tr.developer_name as developer_name,
        tr.team_leader as team_leader,
        tr.shared_with as shared_with,
        tr.closed_by as closed_by,
        pa.name_of_building as property_name,
        GROUP_CONCAT(distinct CONCAT(us1.first_name,' ',IFNULL(us1.last_name, ''))) as team_leader_name, 
        GROUP_CONCAT(distinct CONCAT(us.first_name,' ',IFNULL(us.last_name, ''))) as shared_with_name, 
        GROUP_CONCAT(distinct CONCAT(us2.first_name,' ',IFNULL(us2.last_name, ''))) as closed_by_name,
        CONCAT(c.first_name,' ',IFNULL(c.last_name, '')) as client_fullname, 
        c1.developer_name as developer_full_name
        FROM lz_finance_incentives as fi
        LEFT JOIN lz_finance_invoice as fiv on (fiv.id = fi.invoice_number)
        LEFT JOIN lz_transactions as tr on (tr.id = fiv.transaction_id)
        LEFT JOIN lz_contacts as c on (c.id = tr.client_name)
        LEFT JOIN lz_contacts as c1 on (c1.id = tr.developer_name)
        LEFT JOIN lz_properties as pro on (pro.id = tr.project_name)
        LEFT JOIN lz_property_addresses as pa on (pro.id = pa.property_id)
        LEFT JOIN lz_user as us on FIND_IN_SET(us.id,tr.shared_with)>0
        LEFT JOIN lz_user as us1 on FIND_IN_SET(us1.id,tr.team_leader)>0
        LEFT JOIN lz_user as us2 on FIND_IN_SET(us2.id,tr.closed_by)>0
        LEFT JOIN lz_user as us3 on FIND_IN_SET(us3.id,fi.select_brokers)>0
        where fi.status = 1 
        group by fi.id
        `
        const data = await db2.sequelize.query(thisQuery);

      res.status(200).send({
        status:200,
        message:'Success',
        output:data[0]
      });
    } catch (error) {
      res.status(500).send({
        message: error.message,
      });
    }
};
exports.editIncentives = async (req, res) => {

try {
    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    const id = req.params.id;

    let thisQuery = ` SELECT fi.*,
    GROUP_CONCAT(distinct CONCAT(us3.first_name,' ',IFNULL(us3.last_name, ''))) as brokers_name,
    fiv.transaction_id as transaction_id,
    tr.client_name as client_name,
    tr.project_name as project_name,
    tr.developer_name as developer_name,
    tr.team_leader as team_leader,
    tr.shared_with as shared_with,
    tr.closed_by as closed_by,
    pa.name_of_building as property_name,
    GROUP_CONCAT(distinct CONCAT(us1.first_name,' ',IFNULL(us1.last_name, ''))) as team_leader_name, 
    GROUP_CONCAT(distinct CONCAT(us.first_name,' ',IFNULL(us.last_name, ''))) as shared_with_name, 
    GROUP_CONCAT(distinct CONCAT(us2.first_name,' ',IFNULL(us2.last_name, ''))) as closed_by_name,
    CONCAT(c.first_name,' ',IFNULL(c.last_name, '')) as client_fullname, 
    c1.developer_name as developer_full_name
    FROM lz_finance_incentives as fi
    LEFT JOIN lz_finance_invoice as fiv on (fiv.id = fi.invoice_number)
    LEFT JOIN lz_transactions as tr on (tr.id = fiv.transaction_id)
    LEFT JOIN lz_contacts as c on (c.id = tr.client_name)
    LEFT JOIN lz_contacts as c1 on (c1.id = tr.developer_name)
    LEFT JOIN lz_properties as pro on (pro.id = tr.project_name)
    LEFT JOIN lz_property_addresses as pa on (pro.id = pa.property_id)
    LEFT JOIN lz_user as us on FIND_IN_SET(us.id,tr.shared_with)>0
    LEFT JOIN lz_user as us1 on FIND_IN_SET(us1.id,tr.team_leader)>0
    LEFT JOIN lz_user as us2 on FIND_IN_SET(us2.id,tr.closed_by)>0
    LEFT JOIN lz_user as us3 on FIND_IN_SET(us3.id,fi.select_brokers)>0
    where fi.status = 1 and fi.id = ${id}
    group by fi.id
    `
    const data = await db2.sequelize.query(thisQuery);
    if (data) {
    res.status(200).send({
        status:200,
        message:'Success',
        output:data[0]
        });
    } else {
    res.status(200).send({
        status:404,
        message: `Cannot find with id : ${id}.`
    });
    }
} catch (error) {
    res.status(500).send({
    message: error.message,
    });
}
};
exports.updateIncentives = async (req, res) => {
try {
    const id = req.params.id;
    const data = {
      transaction_id: req.body.transaction_id,
      invoice_number: req.body.invoice_number,
      select_brokers: req.body.select_brokers,
      total_incentive: req.body.total_incentive,
      incentive_payable: req.body.incentive_payable,
      paid_amount: req.body.paid_amount,
      incentive_due: req.body.incentive_due,
      description: req.body.description,
    }
    const num = await db2['financeIncentives'].update(data, {
    where: { id: id },
    });
    if (num == 1) {
    res.status(200).send({
        status:200,
        message: "Updated successfully."
    });
    } else {
    res.status(200).send({
        status:404,
        message: `Cannot update with id : ${id}.`
    });
    }
} catch (error) {
    res.status(500).send({
    message: error.message,
    });
}
};
exports.deleteIncentives = async (req, res) => {
const financeData = {
    status: 0,
}
try {
    const id = req.params.id;
    const num = await db2['financeIncentives'].update(financeData,{
    where: { id: id },
    });
    if (num == 1) {
    res.status(200).send({
        status:200,
        message: "Deleted successfully!"
    });
    } else {
    res.status(200).send({
        status:404,
        message: `Cannot delete with id : ${id}.`
    });
    }
} catch (error) {
    res.status(500).send({
    message: error.message,
    });
}
};

exports.saveCashback = async (req, res) => {
  try {
    const created_by = req.user.id
    console.log('created_by', created_by.id);

    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    const data = await db2['financeCashback'].create({
      transaction_id: req.body.transaction_id,
      invoice_id: req.body.invoice_id,
      client_name: req.body.client_name,
      transaction_amount: req.body.transaction_amount,
      due_date: req.body.due_date,
      release_amount: req.body.release_amount,
      release_mode: req.body.release_mode,
      description: req.body.description,
      created_by: created_by.id
    });

    res.status(200).send({
      status:200,
      message:'Success',
      output:data
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.getCashback = async (req, res) => {
  try {

    let thisQuery = ` SELECT fc.*,  
    CONCAT(us.first_name,' ',IFNULL(us.last_name, '')) as created_name,
    GROUP_CONCAT(distinct CONCAT(c.first_name,' ',IFNULL(c.last_name, ''))) as client_fullname, 
    GROUP_CONCAT(distinct CONCAT(us1.first_name,' ',IFNULL(us1.last_name, ''))) as team_leader_name, 
    CONCAT(c1.first_name,' ',IFNULL(c1.last_name, '')) as developer_fullname, 
    pa.name_of_building as property_name,
    ls.option_value as source_name
    FROM lz_finance_cashback as fc
    LEFT JOIN lz_finance_invoice as fiv on (fiv.id = fc.invoice_id)
    LEFT JOIN lz_transactions as tr on (tr.id = fiv.transaction_id)
    LEFT JOIN lz_contacts as c on (c.id = tr.client_name)
    LEFT JOIN lz_contacts as c1 on (c1.id = tr.developer_name)
    LEFT JOIN lz_properties as pro on (pro.id = tr.project_name)
    LEFT JOIN lz_property_addresses as pa on (pro.id = pa.property_id)
    LEFT JOIN lz_leads as l on (l.id = tr.lead_id)
    LEFT JOIN lz_masters as ls on (ls.id = tr.lead_source)
    LEFT JOIN lz_user as us on (us.id = fc.created_by)
    LEFT JOIN lz_user as us1 on FIND_IN_SET(us1.id,tr.team_leader)>0
    where fc.status = 1 
    group by fc.id
    `
    const data = await db2.sequelize.query(thisQuery);

    res.status(200).send({
      status:200,
      message:'Success',
      output:data[0]
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.editCashback = async (req, res) => {

try {
  const organ_id = req.user.id
  const org_id = organ_id.org_id
  console.log('organ_id', org_id);

  const id = req.params.id;
  
  let thisQuery = ` SELECT fc.*,  
  CONCAT(us.first_name,' ',IFNULL(us.last_name, '')) as created_name,
  GROUP_CONCAT(distinct CONCAT(c.first_name,' ',IFNULL(c.last_name, ''))) as client_fullname, 
  GROUP_CONCAT(distinct CONCAT(us1.first_name,' ',IFNULL(us1.last_name, ''))) as team_leader_name, 
  CONCAT(c1.first_name,' ',IFNULL(c1.last_name, '')) as developer_fullname, 
  pa.name_of_building as property_name,
  ls.option_value as source_name
  FROM lz_finance_cashback as fc
  LEFT JOIN lz_finance_invoice as fiv on (fiv.id = fc.invoice_id)
  LEFT JOIN lz_transactions as tr on (tr.id = fiv.transaction_id)
  LEFT JOIN lz_contacts as c on (c.id = tr.client_name)
  LEFT JOIN lz_contacts as c1 on (c1.id = tr.developer_name)
  LEFT JOIN lz_properties as pro on (pro.id = tr.project_name)
  LEFT JOIN lz_property_addresses as pa on (pro.id = pa.property_id)
  LEFT JOIN lz_leads as l on (l.id = tr.lead_id)
  LEFT JOIN lz_masters as ls on (ls.id = tr.lead_source)
  LEFT JOIN lz_user as us on (us.id = fc.created_by)
  LEFT JOIN lz_user as us1 on FIND_IN_SET(us1.id,tr.team_leader)>0
  where fc.status = 1 and fc.id = ${id}
  group by fc.id
  `
  const data = await db2.sequelize.query(thisQuery);

  if (data) {
  res.status(200).send({
      status:200,
      message:'Success',
      output:data[0]
      });
  } else {
  res.status(200).send({
      status:404,
      message: `Cannot find with id : ${id}.`
  });
  }
} catch (error) {
  res.status(500).send({
  message: error.message,
  });
}
};
exports.updateCashback = async (req, res) => {
try {
  const id = req.params.id;
  const data = {
    transaction_id: req.body.transaction_id,
    invoice_id: req.body.invoice_id,
    client_name: req.body.client_name,
    transaction_amount: req.body.transaction_amount,
    due_date: req.body.due_date,
    release_amount: req.body.release_amount,
    release_mode: req.body.release_mode,
    description: req.body.description,
  }
  const num = await db2['financeCashback'].update(data, {
  where: { id: id },
  });
  if (num == 1) {
  res.status(200).send({
      status:200,
      message: "Updated successfully."
  });
  } else {
  res.status(200).send({
      status:404,
      message: `Cannot update with id : ${id}.`
  });
  }
} catch (error) {
  res.status(500).send({
  message: error.message,
  });
}
};
exports.deleteCashback = async (req, res) => {
const financeData = {
  status: 0,
}
try {
  const id = req.params.id;
  const num = await db2['financeCashback'].update(financeData,{
  where: { id: id },
  });
  if (num == 1) {
  res.status(200).send({
      status:200,
      message: "Deleted successfully!"
  });
  } else {
  res.status(200).send({
      status:404,
      message: `Cannot delete with id : ${id}.`
  });
  }
} catch (error) {
  res.status(500).send({
  message: error.message,
  });
}
};