const db2 = require("../orgModel/orgIndex.js");
const db = require("../../models");
const Op = db2.Sequelize.Op;
const path = require("path");
const fs = require("fs");
const mailer = require("../orgModel/mailer.model.js");
var cron = require('node-cron');

exports.saveFileUploads = async (req, res) => {
    try {
        const id = req.params.id
        const created_id = req.user.id
        const created_by = created_id.id
        console.log('created_by', created_by);

        const organ_id = req.user.id
        const org_id = organ_id.org_id
        console.log('organ_id', org_id);

        const desCreatedUser = await db2.sequelize.query(`select designation, CONCAT(first_name,' ', IFNULL(last_name, '')) as user_name, email from lz_user where status = 1 and id = ${created_by} `);
        const cDesignation = desCreatedUser[0][0]?.designation
        const CUserName = desCreatedUser[0][0]?.user_name
        console.log("cDesignation", cDesignation);
        console.log("CUserName", CUserName);

        const mailTriC = await db2.sequelize.query(`select designation from lz_email_trigger where options = 'contact_uploads' and status = 1 `);
        const mailTriL = await db2.sequelize.query(`select designation from lz_email_trigger where options = 'lead_uploads' and status = 1 `);
        const mailTriP = await db2.sequelize.query(`select designation from lz_email_trigger where options = 'property_uploads' and status = 1 `);
        const mailTriTA = await db2.sequelize.query(`select designation from lz_email_trigger where options = 'task_uploads' and status = 1 `);
        const mailTriTR = await db2.sequelize.query(`select designation from lz_email_trigger where options = 'transaction_uploads' and status = 1 `);
        const cTriDesC = mailTriC[0][0]?.designation ?? 0
        const cTriDesL = mailTriL[0][0]?.designation ?? 0
        const cTriDesP = mailTriP[0][0]?.designation ?? 0
        const cTriDesTA = mailTriTA[0][0]?.designation ?? 0
        const cTriDesTR = mailTriTR[0][0]?.designation ?? 0
        console.log("cTriDesL", cTriDesL);

        // Email Trigger
        const emailCNotes = await db2.sequelize.query(`select status from lz_email_trigger where FIND_IN_SET('${cDesignation}', '${cTriDesC},1') > 0 and options = 'contact_uploads' and status = 1 `);
        const emailLNotes = await db2.sequelize.query(`select status from lz_email_trigger where FIND_IN_SET('${cDesignation}', '${cTriDesL},1') > 0 and options = 'lead_uploads' and status = 1 `);
        const emailPNotes = await db2.sequelize.query(`select status from lz_email_trigger where FIND_IN_SET('${cDesignation}', '${cTriDesP},1') > 0 and options = 'property_uploads' and status = 1 `);
        const emailTANotes = await db2.sequelize.query(`select status from lz_email_trigger where FIND_IN_SET('${cDesignation}', '${cTriDesTA},1') > 0 and options = 'task_uploads' and status = 1 `);
        const emailTRotes = await db2.sequelize.query(`select status from lz_email_trigger where FIND_IN_SET('${cDesignation}', '${cTriDesTR},1') > 0 and options = 'transaction_uploads' and status = 1 `);
        const emailC1 = emailCNotes[0][0]?.status ?? 0
        const emailL1 = emailLNotes[0][0]?.status ?? 0
        const emailP1 = emailPNotes[0][0]?.status ?? 0
        const emailTA1 = emailTANotes[0][0]?.status ?? 0
        const emailTR1 = emailTRotes[0][0]?.status ?? 0
        console.log("emailC1", emailC1);
        console.log("emailL1", emailL1);
        console.log("emailP1", emailP1);
        console.log("emailTA1", emailTA1);
        console.log("emailTR1", emailTR1);

        if (req.files.length > 0) {
            for (i = 0; i < req.files.length; i++) {
                //extension
                let additionalFiles = "";
                let additionalFiles_original_name = "";
                if (req.files[i]) {
                    const extension = req.files[i]["mimetype"].split('/')[1]
                    additionalFiles = req.files[i]["filename"] + '.' + extension
                    additionalFiles_original_name = req.files[i]["originalname"]
                }

                const fileData = {
                    module_id: req.params.id,
                    module_name: req.body.module_name,
                    file: additionalFiles,
                    fileoriginalname: additionalFiles_original_name,
                    user_id: created_by,
                    created_by: created_by,
                };

                x = fileData.module_id
                console.log('xxxxxxxxxxxxx', x);
                const data = await db2['files'].create(fileData);
                //move the file to directory
                const currentPath = path.join(process.cwd(), "uploads", req.files[i]["filename"]);
                const destinationPath = path.join(process.cwd(), "uploads/contacts/files/" + `${x}`, additionalFiles);

                const baseUrl = process.cwd() + '/uploads/contacts/files/' + `${x}`
                fs.mkdirSync(baseUrl, { recursive: true })
                fs.rename(currentPath, destinationPath, function (err) {
                    if (err) {
                        throw err
                    } else {
                        console.log("Successfully moved the file!")
                    }
                })
            }
        }

        const ModuleID = req.params.id
        const ModuleName = req.body.module_name

        let thisQuery = `select * from lz_file_uploads where module_id = ${ModuleID} and module_name = ${ModuleName} order by id desc  `
        const fileData = await db2.sequelize.query(thisQuery);
        console.log("thisQueryyyyyyyyyy", thisQuery);

        //nodemailer
        if (emailC1 || emailL1 || emailP1 || emailTA1 || emailTR1 == 1) {
            let thisQueryDes = ` select us.team_leader as tl, us.portfolio_head as sub_tl 
            from lz_user as us where id = ${created_by} `
            const desCheck = await db2.sequelize.query(thisQueryDes);
            const desCheckTL = desCheck[0][0].tl
            const desCheckSubTL = desCheck[0][0].sub_tl
            // Team Leader
            const checkTl = await db2.sequelize.query(`select email from lz_user where id = ${desCheckTL} `);
            const checkTl1 = checkTl[0][0].email
            // Sub TL
            const checksubTL = await db2.sequelize.query(`select email from lz_user where id = ${desCheckSubTL} `);
            const checksubTL1 = checksubTL[0][0].email
            // Admin
            const checkAdmin = await db2.sequelize.query(`select email from lz_user where designation = 1 group by id `);
            const checkAdmin1 = checkAdmin[0].map(item => item.email).join(', ');

            console.log("checkTl", checkTl1);
            console.log("checksubTL1", checksubTL1);
            console.log("checkAdmin1", checkAdmin1);

            const createdEmail = await db2.sequelize.query(`select CONCAT(first_name,' ', IFNULL(last_name, '')) as user_name, email from lz_user where id = ${created_by} `);
            const cEmail = createdEmail[0][0].email
            const createdUserName = createdEmail[0][0].user_name
            console.log("cEmail", cEmail);
            console.log("createdUserName", createdUserName);


            if (req.body.module_name == 1 && emailC1 == 1) {
            let message = {
                from: cEmail,
                to: [checkAdmin1, checkTl1, checksubTL1].join(', '),
                subject: "Contacts file upload",
                html:
                createdUserName + "- New contact file uploaded "
            };
            mailer.sendMail(message, function (error, info) {
                if (error) {
                console.log('Error');
                } else {
                console.log('Email sent: ' + info.response);
                }
            });
            console.log("message", message);
            }
            if (req.body.module_name == 2 && emailL1 == 1) {
            let message2 = {
                from: cEmail,
                to: [checkAdmin1, checkTl1, checksubTL1].join(', '),
                subject: "Leads file upload",
                html:
                createdUserName + "- New lead file uploaded "
            };
            mailer.sendMail(message2, function (error, info) {
                if (error) {
                console.log('Error');
                } else {
                console.log('Email sent: ' + info.response);
                }
            });
            console.log("message", message2);
            }
            if (req.body.module_name == 3 && emailP1 == 1) {
            let message3 = {
                from: cEmail,
                to: [checkAdmin1, checkTl1, checksubTL1].join(', '),
                subject: "Property file upload",
                html:
                createdUserName + "- New property file uploaded "
            };
            mailer.sendMail(message3, function (error, info) {
                if (error) {
                console.log('Error');
                } else {
                console.log('Email sent: ' + info.response);
                }
            });
            console.log("message", message3);
            }
            if (req.body.module_name == 4 && emailTA1 == 1) {
            let message4 = {
                from: cEmail,
                to: [checkAdmin1, checkTl1, checksubTL1].join(', '),
                subject: "Task file upload",
                html:
                createdUserName + "- New task file uploaded "
            };
            mailer.sendMail(message4, function (error, info) {
                if (error) {
                console.log('Error');
                } else {
                console.log('Email sent: ' + info.response);
                }
            });
            console.log("message", message4);
            }
            if (req.body.module_name == 5 && emailTR1 == 1) {
            let message5 = {
                from: cEmail,
                to: [checkAdmin1, checkTl1, checksubTL1].join(', '),
                subject: "Transactions file upload",
                html:
                createdUserName + "- New transaction file uploaded "
            };
            mailer.sendMail(message5, function (error, info) {
                if (error) {
                console.log('Error');
                } else {
                console.log('Email sent: ' + info.response);
                }
            });
            console.log("message", message5);
            }
        }

        res.status(200).send({
            status: 200,
            message: 'Success',
            output: fileData[0]
        });

    } catch (error) {
        res.status(500).send({
            message: error.message,
        });
    }
};
exports.getFileUploads = async (req, res) => {
    try {
        const id = req.params.id
        const module_id = req.params.module_id
        const module_name = req.params.module_name

        const created_by = req.user.id
        console.log('created_by', created_by.id);

        const organ_id = req.user.id
        const org_id = organ_id.org_id
        console.log('organ_id', org_id);

        var condition = {
            where: {
                status: 1, module_id: module_id, module_name: module_name
            },
            order: [['id', 'DESC']], // ASC, DESC
            attributes: { exclude: ['createdAt', 'updatedAt'] },
        };

        const data = await db2['files'].findAll(condition);

        res.status(200).send({
            status: 200,
            message: 'Success',
            output: data
        });
    } catch (error) {
        res.status(500).send({
            message: error.message,
        });
    }
};
exports.deleteFileUpload = async (req, res) => {
    try {
      const id = req.params.id;
      const module_id = req.body.module_id;
      const module_name = req.body.module_name;

      const num = await db2['files'].destroy({
        where: { id: id},
      });
      if (num == 1) {
        
        var condition = {
            where: {
                status: 1, module_id: module_id, module_name: module_name
            },
            order: [['id', 'DESC']], // ASC, DESC
            attributes: { exclude: ['createdAt', 'updatedAt'] },
        };

        const data = await db2['files'].findAll(condition);

        res.status(200).send({
            status: 200,
            message: 'Success',
            output: data
        });
      } else {

        var condition = {
            where: {
                status: 1, module_id: module_id, module_name: module_name
            },
            order: [['id', 'DESC']], // ASC, DESC
            attributes: { exclude: ['createdAt', 'updatedAt'] },
        };

        const data1 = await db2['files'].findAll(condition);

        res.status(200).send({
            status: 404,
            message: `Cannot delete with id : ${id}.`,
            output: data1
        });
      }
    } catch (error) {
      res.status(500).send({
        message: error.message,
      });
    }
};



// cron.schedule('* * * * * *', () => {
//     const date = new Date();
//     const seconds = date.getSeconds();
//     console.log(seconds, 'Running a task every second');
// });