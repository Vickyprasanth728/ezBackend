const orgDbConfig = require("../orgConfig/orgDb.config.js");
const db2 = require("../orgModel/orgIndex.js");
const db = require("../../models");
const Op = db2.Sequelize.Op;
const path = require("path");
const fs = require("fs");
var Sequelize = require('sequelize');
let fetch = require('node-fetch');
const sqs = require('sequelize-querystring');
const { group, error, log } = require("console");
const readXlsxFile = require('read-excel-file/node');
const util = require('util');
const sql = require("../../zOrganizationFile/orgConfig/orgDb.config.js");
const mailer = require("../orgModel/mailer.model.js");

exports.saveContacts = async (req, res) => {
  try {
    const created_id = req.user.id
    const created_by = created_id.id
    console.log('created_by', created_by);

    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    const desCreatedUser = await db2.sequelize.query(`select designation, CONCAT(first_name,' ', IFNULL(last_name, '')) as user_name, email from lz_user where status = 1 and id = ${created_by} `);
    const cDesignation = desCreatedUser[0][0]?.designation
    const CUserName = desCreatedUser[0][0]?.user_name
    console.log("cDesignation", cDesignation);
    console.log("CUserName", CUserName);

    const mailTriC = await db2.sequelize.query(`select designation from lz_email_trigger where options = 'contact_created' and status = 1 `);
    const cTriDesC = mailTriC[0][0]?.designation ?? 0
    console.log("cTriDesC", cTriDesC);

    let profile_image = "";
    let profile_image_original_name = "";
    if (req.files.profile_image) {
      const extension = req.files.profile_image[0]["mimetype"].split('/')[1]
      profile_image = req.files.profile_image[0]["filename"] + '.' + extension
      profile_image_original_name = req.files.profile_image[0]["originalname"]
    }

    let documents = "";
    if (req.files.documents) {
    const extension = req.files.documents[0]["mimetype"].split('/')[1]
    documents = req.files.documents[0]["filename"] + '.' + extension
    documents = req.files.documents[0]["originalname"]
    }
    
    const data = await db2['contacts'].create({
      org_id: org_id,
      salutation: req.body.salutation,
      first_name: req.body.first_name,
      last_name: req.body.last_name,
      company_name: req.body.company_name,
      developer_name: req.body.developer_name,
      email: req.body.email,
      phone_number_type: req.body.phone_number_type,
      code: req.body.code,
      mobile: req.body.mobile,
      assign_to: req.body.assign_to,
      property_id: req.body.property_id,
      contact_group: req.body.contact_group,
      source: req.body.source,
      contact_type: req.body.contact_type,
      contact_category: req.body.contact_category,
      contact_status: req.body.contact_status,
      remarks: req.body.remarks,
      profile_image: profile_image,
      profile_image_original_name: profile_image_original_name,
      is_secondary_contact: req.body.is_secondary_contact,
      secondary_contact_id: req.body.secondary_contact_id,
      refid: req.body.refid,
      created_by: created_by.id
    });
    let contactId = data?.dataValues.id

    const data1 = await db2['contactDetails'].create({
        contact_id: contactId,
        gst_number: req.body.gst_number,
        invoice_name: req.body.invoice_name,
        gender: req.body.gender,
        dob: req.body.dob,
        marital_status: req.body.marital_status,
        wedding_anniversary: req.body.wedding_anniversary,
        number_of_children: req.body.number_of_children,
        pet_owner: req.body.pet_owner,
        nationality: req.body.nationality,
        language: req.body.language,
        designation: req.body.designation,
        national_id: req.body.national_id,
        do_not_disturb: req.body.do_not_disturb,
        documents: documents,
    });
    const data2 = await db2['contactAddress'].create({
        contact_id: contactId,
        address_1: req.body.address_1,
        address_2: req.body.address_2,
        locality: req.body.locality,
        country: req.body.country,
        city: req.body.city,
        state: req.body.state,
        zip_code: req.body.zip_code,
        facebook: req.body.facebook,
        instagram: req.body.instagram,
        linkedin: req.body.linkedin,
        twitter: req.body.twitter,
    });

    console.log('contactIddd',contactId);

    if (req.files.profile_image) {
      // move profile image
      const currentPath = path.join(process.cwd(), "uploads", req.files.profile_image[0]["filename"]);
      const destinationPath = path.join(process.cwd(), "uploads/contacts/profile_image/" + `${contactId}`, profile_image);

      const baseUrl = process.cwd() + '/uploads/contacts/profile_image/' + `${contactId}`
      fs.mkdirSync(baseUrl, { recursive: true })
      fs.rename(currentPath, destinationPath, function (err) {
        if (err) {
          throw err
        } else {
          console.log("Successfully moved the profile image!")
        }
      });
    }

    let j = 1
    console.log("jjjjjj", j);
    var files_length = Object.keys(req.files).length

    for (let i = 0; i < files_length; i++) {
      if (req.files[`document${j}`]) {
        const documentsExtension = req.files[`document${j}`][0]["mimetype"].split('/')[1]
        const contactDocumentsData = {
          contact_id: contactId,
          file: req.files[`document${j}`][0]["filename"] + '.' + documentsExtension,
          fileoriginalname: req.files[`document${j}`][0]["originalname"],
          person_id_documents: req.body[`id_document${j}`],
          id_number: req.body[`id_number${j}`]
        };
        const data3 = await db2['contactDocuments'].create(contactDocumentsData)
        console.log("dgdgygd", data3);
        
        //move the file to directory
        const currentPath = path.join(process.cwd(), "uploads", req.files[`document${j}`][0]["filename"]);
        const destinationPath = path.join(process.cwd(), "uploads/contacts/documents/" + `${contactId}`, req.files[`document${j}`][0]["filename"] + '.' + documentsExtension);

        const baseUrl = process.cwd() + '/uploads/contacts/documents/' + `${contactId}`
        fs.mkdirSync(baseUrl, { recursive: true })
        fs.rename(currentPath, destinationPath, function (err) {
          if (err) {
            throw err
          } else {
            console.log("Successfully moved the file!")
          }
        })
      }
      j++
    }
    console.log("org_idddddd", org_id);

    const contactLogs = await db2['logs'].create({
      org_id: org_id,
      module_id: contactId,
      module_name: "1",
      note: "Contact created at",
      user_id: created_by
    })
    console.log("contactLogss", contactLogs);

    // Email Trigger
    const email_settings = await db2.sequelize.query(`select status from lz_email_trigger where FIND_IN_SET('${cDesignation}', '${cTriDesC},1') > 0 and options = 'contact_created' and status = 1 `);
    // const emailTri = email_settings[0][0] ? email_settings[0][0]["active_status"] : 0
    const emailTri = email_settings[0][0]?.status ?? 0
    console.log("emailTri", emailTri);

    //nodemailer
      if(emailTri == 1) {

      let thisQueryDes = ` select us.team_leader as tl, us.portfolio_head as sub_tl 
      from lz_user as us where id = ${created_by} `
      const desCheck = await db2.sequelize.query(thisQueryDes);
      const desCheckTL = desCheck[0][0].tl
      const desCheckSubTL = desCheck[0][0].sub_tl
      // Team Leader
      const checkTl = await db2.sequelize.query(`select email from lz_user where id = ${desCheckTL} `);
      const checkTl1 = checkTl[0][0].email
      // Sub TL
      const checksubTL = await db2.sequelize.query(`select email from lz_user where id = ${desCheckSubTL} `);
      const checksubTL1 = checksubTL[0][0].email
      // Admin
      const checkAdmin = await db2.sequelize.query(`select email from lz_user where designation = 1 group by id `);
      const checkAdmin1 = checkAdmin[0].map(item => item.email).join(', ');
      // Assign To
      const assignEmail = await db2.sequelize.query(`select us.id as id, us.email as email from lz_user as us where us.id IN (${req.body.assign_to}) `);
      const assEmail = assignEmail[0].map(item => item.email).join(', ')
    
      console.log("checkTl", checkTl1);
      console.log("checksubTL1", checksubTL1);
      console.log("checkAdmin1", checkAdmin1);
      console.log("assign_to",assEmail);
    
      const createdEmail = await db2.sequelize.query(`select email from lz_user where id = ${created_by} `);
      const cEmail = createdEmail[0][0].email
      console.log("cEmail", cEmail);

      let thisQueryPro = `select p.id as id, pa.name_of_building as property_name
      from lz_properties p
      left join lz_property_addresses as pa on (p.id = pa.property_id)
      where p.status = 1 and pa.property_id = '${req.body.property_id}' `;

      const project_name_data = await db2.sequelize.query(thisQueryPro)
      console.log("project_name_data", project_name_data[0][0]);

      const project_name = project_name_data[0][0] ? project_name_data[0][0].property_name : 0
      console.log('project_name', project_name);

      let thisQueryTemp = `select mt.*
      from lz_mail_template mt
      where mt.status = 1 `;

      const orgCheck = await db2.sequelize.query(`select organization_name, logo from lz_organization where company_ref_id = ${org_id} `);
      const OrgC = orgCheck[0][0].organization_name
      const OrgLogo = orgCheck[0][0].logo
      console.log("OrgC", OrgC);
      console.log("OrgLogo", OrgLogo);

      const emailTemp = await db2.sequelize.query(thisQueryTemp)
      let emailT = emailTemp[0][0].body
      // const content = 'creation of contact'

      const placeholders = {
        '{{content}}': 'creation of contact',
        'org__logo' : OrgLogo,
        '{{org_name}}' : OrgC
      }

      for (const placeholder in placeholders) {
        emailT = emailT.replace(placeholder, placeholders[placeholder]);
      }

      let message = {
        from: cEmail,
        to: [checkAdmin1,checkTl1,checksubTL1, assEmail].join(', '),
        // from: 'gowshickvts@gmail.com',
        // to: 'vignesh@vrikshatech.in',
        subject: "New Contact Created",
        html: emailT
      };
      console.log("message", message);
      
      mailer.sendMail(message, function(error, info){
        if (error) {
          console.log('Error');
        } else {
          console.log('Email sent: ' + info.response);
        }
      });
    }

    if(req.body.assign_to) {
      const getUserPhoneNumber = await db2.sequelize.query(`SELECT p_phone_number FROM lz_user where id IN (${req.body.assign_to}) `);
      const getPropertyID = await db2.sequelize.query(`SELECT pa.name_of_building as property_name FROM lz_properties as p left join lz_property_addresses as pa on (p.id = pa.property_id) where p.status = 1 and pa.property_id = ${req.body.property_id} `);
      const getUserMobile = getUserPhoneNumber[0]?.map(item => item.p_phone_number).join(', ') ?? 0 ;
      const getPropertyName = getPropertyID[0][0]?.property_name;
      if(getUserMobile) {
        var contactName = req.body.first_name || 'Customer'
        var contactNumber = req.body.mobile
        var projectName = getPropertyName
        var email = req.body.email
        var toNumber = getUserMobile
        whatsAppMessageSend(contactName,contactNumber,projectName,email,toNumber)
      console.log('toNumber',toNumber);
      }
      console.log('getUserMobile', getUserMobile);
    }

    res.status(200).send({
      status:200,
      message:'Success',
      output:data
    });

  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};

async function whatsAppMessageSend(contactName, contactNumber, projectName, email, toNumber) {
  var phoneNumber = toNumber ?? 0;
  var templateValue = {
    name: "listez",
    language: { code: "en" },
    components: [{ 
      type: "body", parameters: 
      [
        {type: "text", text: contactName},
        {type: "text", text:contactNumber}, 
        {type: "text", text: projectName}, 
        {type: "text", text: email}, 
        {type: "text", text: "google ppc"}
      ] 
    }]
  }
  var params = {
    messaging_product: 'whatsapp',
    to: phoneNumber,
    type: 'template',
    template: templateValue
  };
  // console.log(params);
  try {
    const response = await fetch('https://graph.facebook.com/v15.0/102284452719874/messages', {
      method: 'post',
      body: JSON.stringify(params),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer EAAGZCewXTNRQBALKUKrKx81d1T4qFxZAqRqZAt4tHFq6EHOZBZCzMw0MzFT3ZBjY1w3R0vmNUicTIbsYC7sQuSUcKtWeBskGk5BbazOKUn6vU1YESJ0trGPBge2UyQCprUkjVHMxkaKUUp2FNuctK8aRNJ0b1gYo8bt9YTAK14bW7wNvXUPMFckW6k91CEA8JzCanZCS1RsRAZDZD'}
        // EAAGZCewXTNRQBALKUKrKx81d1T4qFxZAqRqZAt4tHFq6EHOZBZCzMw0MzFT3ZBjY1w3R0vmNUicTIbsYC7sQuSUcKtWeBskGk5BbazOKUn6vU1YESJ0trGPBge2UyQCprUkjVHMxkaKUUp2FNuctK8aRNJ0b1gYo8bt9YTAK14bW7wNvXUPMFckW6k91CEA8JzCanZCS1RsRAZDZD
    });
    const data = await response.json();
    console.log('data',data);
    // res.send(data)
  } catch (error) {
    console.log('error', error)
    // res.send(e)
  }
};

exports.getContacts = async (req, res) => {
  try {
    const created_id = req.user.id
    const created_by = created_id.id
    console.log('created_by', created_by);
  
    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);
  
    const role = req.user.id
    const role_id = role.designation
    console.log('role_id', role_id);

  let thisQuery = `select c.*, CONVERT(c.assign_to USING utf8) as assign_to, GROUP_CONCAT(distinct CONCAT(us.first_name,' ', IFNULL(us.last_name, ''),'-',us.id)) as assign_to_name, s.option_value as source_name, ct.option_value as contact_type_name, cs.option_value as contact_status_name, cg.option_value as contact_group_name, cc.option_value as contact_category_name, ca.address_1,ca.address_2,ca.locality,ca.country,ca.city,ca.state,ca.zip_code,cd.national_id,cd.gst_number,cd.gender,cd.dob,cd.marital_status,cd.wedding_anniversary,cd.number_of_children,cd.pet_owner,cd.nationality,cd.language,cd.designation,cd.do_not_disturb,cd.invoice_name,ca.facebook,ca.instagram,ca.linkedin,ca.twitter, CONCAT(us3.first_name,' ',us3.last_name) as created_by_name, DATE_FORMAT(c.created_at,'%Y-%m-%d') as created_date, pas.name_of_building as property_name,

  (SELECT COUNT(id) FROM lz_notes where module_id = c.id and module_name = 1 and status = 1) as notes_count,
  (SELECT COUNT(id) FROM lz_file_uploads where module_id = c.id and module_name = 1 ) as files_count,
  (SELECT ifnull(COUNT(*),0) FROM lz_leads as l LEFT JOIN lz_contacts on (lz_contacts.id = l.contact_id) where l.status = 1 and contact_id = c.id) as lead_count,
  (SELECT ifnull(COUNT(*),0) FROM lz_tasks as t LEFT JOIN lz_contacts on (lz_contacts.id = t.contact) where t.status = 1 and t.contact = c.id) as task_count,
  (SELECT COUNT(secondary_contact_id) FROM lz_contacts where c.status = 1 and c.secondary_contact_id = id) as sec_count,
  (SELECT COUNT(mobile) FROM lz_contacts where c.mobile = mobile and c.property_id = property_id and status = 1 and c.id != id) as duplicate_count,
  (SELECT reply FROM lz_notes where module_name = 1 and module_id = c.id order by id desc limit 1 ) as last_note,
  (SELECT DATE_FORMAT(ta.task_time,'%Y-%m-%d') FROM lz_tasks as ta where ta.contact = c.id and ta.task_time <= curdate() order by ta.task_time DESC limit 1) as last_task_date,
  (SELECT DATE_FORMAT(ta.task_time,'%Y-%m-%d') FROM lz_tasks as ta where ta.contact = c.id and ta.task_time >= curdate() order by ta.task_time limit 1) as next_task_date

  from lz_contacts as c   
  left join lz_contact_address as ca on (ca.contact_id = c.id) 
  left join lz_contact_details as cd on (cd.contact_id = c.id)
  left join lz_properties as p on (p.id = c.property_id) 
  left join lz_property_addresses as pas on (p.id = pas.property_id) 
  LEFT JOIN lz_user as us on FIND_IN_SET(us.id,c.assign_to) > 0 
  LEFT JOIN lz_user as us3 on FIND_IN_SET(us3.id,c.created_by) > 0 
  left join lz_masters as s on (s.id = c.source) 

  LEFT JOIN lz_user as us5 on FIND_IN_SET(us5.id,c.assign_to) > 0 
  left join lz_user as us4 on (us5.team_leader = us4.id) 
  
  LEFT JOIN lz_user as us6 on FIND_IN_SET(us6.id,c.assign_to) > 0 
  left join lz_user as us7 on (us6.portfolio_head = us7.id) 

  left join lz_masters as ct on (ct.id = c.contact_type) 
  left join lz_masters as cs on (cs.id = c.contact_status) 
  left join lz_masters as cg on (cg.id = c.contact_group) 
  left join lz_masters as cc on (cc.id = c.contact_category)

  where ${role_id == 1 ? `c.status IN (1,2) ` : `c.status = 1`} `;

  if (role_id == 1) {
    thisQuery += ` `
  }
  if (role_id == 2) {
    thisQuery += ` and (FIND_IN_SET(${created_by},c.assign_to)>0 or us.team_leader = ${created_by} or us.portfolio_head = ${created_by} or c.created_by = ${created_by} ) `
    // thisQuery += ` and c.created_by = ${created_by} `
  }
  if (role_id == 3) {
    thisQuery += ` and (FIND_IN_SET(${created_by},c.assign_to)>0 or us.team_leader = ${created_by} or us.portfolio_head = ${created_by} or c.created_by = ${created_by} ) `
    // thisQuery += ` and c.created_by = ${created_by} `
  }
  if (role_id == 4) {
    thisQuery += ` and (FIND_IN_SET(${created_by},c.assign_to)>0 or c.created_by = ${created_by} ) `
  }
  if (role_id == 5) {
    thisQuery += ` `
  }
  if (role_id == 6) {
    thisQuery += `and c.created_by = ${created_by} `
  }

  const filters = req.query;
  // for (key in filters) {
    if (filters.contact_type) {
      thisQuery += " and c.contact_type = " + `${filters.contact_type}`
    }
    if (filters.contact_category) {
      thisQuery += " and c.contact_category = " + `${filters.contact_category} `
    }
    if (filters.property) {
      thisQuery += " and c.property_id = " + `${filters.property} `
    }
    if (filters.company_name) {
      thisQuery += "and c.company_name = " + `'${filters.company_name}'`
    }
    if (filters.contact_status) {
      thisQuery += "and c.contact_status = " + `${filters.contact_status} `
    }
    if (filters.assign_to) {
      var a = filters.assign_to;
      let a1 = a.split(',').map(item => `'${item}'`).join(',');
      // thisQuery += `and CONCAT(',', c.assign_to, ',') REGEXP ',(${a1}),' `
      thisQuery += " and (c.assign_to IN (" + a1 + ")" + ` OR CONCAT(',', c.assign_to, ',') REGEXP ',(${a}),' )`
    }
    if (filters.source) {
      thisQuery += "and c.source = " + `${filters.source} `
    }
    if (filters.locality) {
      thisQuery += "and ca.locality = " + `${filters.locality} `
    }
    if (filters.contact_group) {
      thisQuery += "and c.contact_group = " + `${filters.contact_group} `
    }
    if (filters.created_by) {
      thisQuery += "and c.created_by = " + `${filters.created_by} `
    }
    if (filters.created_date !="" && filters.created_end_date) {
      // thisQuery += "and c.created_at = " + `'${filters.created_at}' `
      thisQuery += ` and (DATE_FORMAT(c.created_at,'%Y-%m-%d') >= '${filters.created_date}' AND DATE_FORMAT(c.created_at,'%Y-%m-%d') <= '${filters.created_end_date}') `
    }
    if (filters.created_date !="" && filters.created_end_date=='') {
      // thisQuery += "and c.created_at = " + `'${filters.created_at}' `
      thisQuery += ` and (DATE_FORMAT(c.created_at,'%Y-%m-%d') >= '${filters.created_date}') `
    }
    if (filters.created_date =="" && filters.created_end_date !='') {
      // thisQuery += "and c.created_at = " + `'${filters.created_at}' `
      thisQuery += ` and (DATE_FORMAT(c.created_at,'%Y-%m-%d') <= '${filters.created_end_date}') `
    }
    if (filters.dob) {
      thisQuery += " and cd.dob = " + `'${filters.dob}'`
    }
    if (filters.gender) {
      thisQuery += " and cd.gender = " + `${filters.gender} `
    }
    if (filters.city) {
      thisQuery += " and ca.city = " + `${filters.city} `
    }
    if (filters.country) {
      thisQuery += " and ca.country = " + `${filters.country} `
    }
    if (filters.nationality) {
      thisQuery += " and cd.nationality = " + `${filters.nationality} `
    }
    if (filters.state) {
      thisQuery += " and ca.state = " + `${filters.state} `
    }
    if (filters.zip_code) {
      thisQuery += " and ca.zip_code = " + `${filters.zip_code} `
    }
  // }
  thisQuery += ' group by c.id '

  if (filters.order_by) {
    let orderByString = filters.order_by.split('|')
    thisQuery += " order by " + `${orderByString[0]} ${orderByString[1]} `
  }
  const data1 = await db2.sequelize.query(thisQuery);

  if (filters.order_by =="" || filters.order_by == undefined) {
    thisQuery += '  order by c.id DESC '
  }

  // thisQuery += ' order by c.updated_at DESC '

  if (filters.limit) {
    thisQuery += ` limit ${filters.limit},12 `
  }

  const data = await db2.sequelize.query(thisQuery);

  const count_filter = (data1[0])

    res.status(200).send({
      status:200,
      message:'Success',
      count: count_filter.length,
      output: data[0],
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.editContact = async (req, res) => {
  try {
    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    const role = req.user.id
    const role_id = role.designation
    console.log('role_id', role_id);

    const ContactID = req.params.id
  
    let thisQuery = `select c.*, CONVERT(c.assign_to USING utf8) as assign_to, GROUP_CONCAT(distinct CONCAT(us.first_name,' ', IFNULL(us.last_name, ''),'-',us.id)) as assign_to_name,s.option_value as source_name, ct.option_value as contact_type_name, cs.option_value as contact_status_name, cg.option_value as contact_group_name, cc.option_value as contact_category_name, ca.address_1,ca.address_2,ca.locality,ca.country,ca.city,ca.state,ca.zip_code,cd.national_id,cd.gst_number,cd.gender,cd.dob,cd.marital_status,cd.wedding_anniversary,cd.number_of_children,cd.pet_owner,cd.nationality,cd.language,cd.designation,cd.do_not_disturb,cd.invoice_name,ca.facebook,ca.instagram,ca.linkedin,ca.twitter,pas.name_of_building as property_name, CONCAT(us3.first_name,' ',us3.last_name) as created_by_name
    from lz_contacts as c
    left join lz_property_addresses as pas on (pas.property_id = c.property_id) 
    left join lz_contact_address as ca on (ca.contact_id = c.id) 
    left join lz_contact_details as cd on (cd.contact_id = c.id) 
    LEFT JOIN lz_user as us on FIND_IN_SET(us.id,c.assign_to)>0 
    LEFT JOIN lz_user as us3 on FIND_IN_SET(us3.id,c.created_by)>0 
    left join lz_masters as s on (s.id = c.source) 
    left join lz_masters as ct on (ct.id = c.contact_type) 
    left join lz_masters as cs on (cs.id = c.contact_status) 
    left join lz_masters as cg on (cg.id = c.contact_group) 
    left join lz_masters as cc on (cc.id = c.contact_category) 
    where ${role_id == 1 ? `c.status IN (1,2) ` : `c.status = 1`} and c.id = ${ContactID} `;

   const data = await db2.sequelize.query(thisQuery);
   console.log("dataaaaaaa", data);

   const localityCountryData = data[0][0]?.country
   const localityStateData = data[0][0]?.state
   const localityCityData = data[0][0]?.city
   const countryData = await db['country'].findOne({
     where: {
       status: 1, id:localityCountryData
     },
     attributes:['name'],
   });
   const stateData = await db['state'].findOne({
     where: {
       status: 1, id:localityStateData
     },
     attributes:['name'],
   });
   const cityData = await db['city'].findOne({
     where: {
       status: 1, id:localityCityData
     },
     attributes:['name'],
   });

    if (data) {
      res.status(200).send({
        status: 200,
        message: 'Success',
        output: {...data[0][0], country_name: countryData?.dataValues.name ?? "",  state_name: stateData?.dataValues.name ?? "",  city_name: cityData?.dataValues.name ?? "" },
      });
    } else {
      res.status(200).send({
        status: 404,
        message: `Cannot find with id : ${id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.updateContact = async (req, res) => {
  try {
    const id = req.params.id;

    const created_by = req.user.id
    console.log('created_by', created_by.id);

    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    const role = req.user.id
    const role_id = role.designation
    console.log('role_id', role_id);

    let profile_image = "";
    let profile_image_original_name = "";
    if (req.files.profile_image) {
      const extension = req.files.profile_image[0]["mimetype"].split('/')[1]
      profile_image = req.files.profile_image[0]["filename"] + '.' + extension
      profile_image_original_name = req.files.profile_image[0]["originalname"]
    }

    let thisQuery = ` select c.first_name as contact_name, c.mobile as mobile, c.email as email, c.source as source, so.option_value as source_name, c.contact_status as contact_status, cs.option_value as contact_status_name, c.property_id as property_id, pa.name_of_building as property_name
    from lz_contacts as c 
    left join lz_properties as p on (p.id = c.property_id)
    left join lz_property_addresses as pa on (p.id = pa.property_id)
    left join lz_masters as so on (so.id = c.source)
    left join lz_masters as cs on (cs.id = c.contact_status)
    where ${role_id == 1 ? `c.status IN (1,2) ` : `c.status = 1`} and c.id = ${id} `
    const data123= await db2.sequelize.query(thisQuery);
    const dataContactName = data123[0][0]?.contact_name
    const dataMobile = data123[0][0]?.mobile
    const dataSource = data123[0][0]?.source
    const dataSourceName = data123[0][0]?.source_name
    const dataEmail = data123[0][0]?.email
    const dataStatus = data123[0][0]?.contact_status
    const dataStatusName = data123[0][0]?.contact_status_name
    const dataProperty = data123[0][0]?.property_id
    const dataPropertyName = data123[0][0]?.property_name
    console.log("dataContactName", dataContactName);
    console.log("dataMobile", dataMobile);
    console.log("dataSource", dataSource);
    console.log("dataSourceName", dataSourceName);
    console.log("dataEmail", dataEmail);
    console.log("dataStatus", dataStatus);
    console.log("dataStatusName", dataStatusName);
    console.log("dataProperty", dataProperty);
    console.log("dataPropertyName", dataPropertyName);

    // if(req.body.source) {
    // let thisQuery456 = ` select c.source as c_source, so.option_value as c_source_name
    // from lz_contacts as c
    // left join lz_masters as so on (so.id = c.source)
    // where c.status = 1 and c.source = ${req.body.source}
    // `
    // const dataSO = await db2.sequelize.query(thisQuery456);
    // const dataSO1 = dataSO[0][0]?.c_source
    // const dataSO2 = dataSO[0][0]?.c_source_name
    // console.log("dataSO1", dataSO1);
    // console.log("dataSO2", dataSO2);
    // }

    // if(req.body.contact_status) {
    // let thisQueryCS = ` select c.contact_status as c_contact_status, cs.option_value as c_contact_status_name
    // from lz_contacts as c
    // left join lz_masters as cs on (cs.id = c.contact_status)
    // where c.status = 1 and c.contact_status = ${req.body.contact_status}
    // `
    // const dataCS = await db2.sequelize.query(thisQueryCS);
    // const dataCS1 = dataCS[0][0]?.c_contact_status
    // const dataCS2 = dataCS[0][0]?.c_contact_status_name
    // console.log("dataCS1", dataCS1);
    // console.log("dataCS2", dataCS2);
    // }

    // if(req.body.property_id) {
    // let thisQueryPro = ` select c.property_id as c_property_id, pa1.name_of_building as property_name
    // from lz_contacts as c
    // left join lz_properties as p on (p.id = c.property_id)
    // left join lz_property_addresses as pa1 on (p.id = pa1.property_id)
    // where c.status = 1 and c.property_id = ${req.body.property_id}
    // `
    // const dataPro = await db2.sequelize.query(thisQueryPro);
    // const dataPro1 = dataPro[0][0]?.c_property_id
    // const dataPro2 = dataPro[0][0]?.property_name
    // console.log("dataPro1", dataPro1);
    // console.log("dataPro2", dataPro2);
    // }
    let data = {};
    if(profile_image) {
      data = {
          salutation: req.body.salutation,
          first_name: req.body.first_name,
          last_name: req.body.last_name,
          company_name: req.body.company_name,
          developer_name: req.body.developer_name,
          email: req.body.email,
          phone_number_type: req.body.phone_number_type,
          code: req.body.code,
          mobile: req.body.mobile,
          assign_to: req.body.assign_to,
          property_id: req.body.property_id,
          contact_group: req.body.contact_group,
          source: req.body.source,
          contact_type: req.body.contact_type,
          contact_category: req.body.contact_category,
          contact_status: req.body.contact_status,
          remarks: req.body.remarks,
          profile_image: profile_image,
          profile_image_original_name: profile_image_original_name,
          is_secondary_contact: req.body.is_secondary_contact,
          secondary_contact_id: req.body.secondary_contact_id,
          refid: req.body.refid,
        }
    } else {
      data = {
        salutation: req.body.salutation,
        first_name: req.body.first_name,
        last_name: req.body.last_name,
        company_name: req.body.company_name,
        developer_name: req.body.developer_name,
        email: req.body.email,
        phone_number_type: req.body.phone_number_type,
        code: req.body.code,
        mobile: req.body.mobile,
        assign_to: req.body.assign_to,
        property_id: req.body.property_id,
        contact_group: req.body.contact_group,
        source: req.body.source,
        contact_type: req.body.contact_type,
        contact_category: req.body.contact_category,
        contact_status: req.body.contact_status,
        remarks: req.body.remarks,
        // profile_image: profile_image,
        // profile_image_original_name: profile_image_original_name,
        is_secondary_contact: req.body.is_secondary_contact,
        secondary_contact_id: req.body.secondary_contact_id,
        refid: req.body.refid,
      }
    }

    const num = await db2['contacts'].update(data, {
      where: { id: id },
    });
    if (num == 1) {

        let contactId = req.params.id

        if (req.files.profile_image) {
          // move profile image
          const currentPath = path.join(process.cwd(), "uploads", req.files.profile_image[0]["filename"]);
          const destinationPath = path.join(process.cwd(), "uploads/contacts/profile_image/" + `${contactId}`, profile_image);
    
          const baseUrl = process.cwd() + '/uploads/contacts/profile_image/' + `${contactId}`
          fs.mkdirSync(baseUrl, { recursive: true })
          fs.rename(currentPath, destinationPath, function (err) {
            if (err) {
              throw err
            } else {
              console.log("Successfully profile image uploded!")
            }
          });
        }
        // Contact Name
        if(req.body.first_name) {
        if(dataContactName !== req.body.first_name) {
          const contactContactNameLog = await db2['logs'].create({
            org_id: org_id,
            module_id: contactId,
            module_name: "1",
            // note: 'Contact Name : ' + dataContactName + ' TO '+ req.body.first_name,
            note: 'Contact Name : ' + `${dataContactName == null || "" ? req.body.first_name : dataContactName + ' to '+ req.body.first_name}`,
            user_id: created_by.id
          })
          console.log("Contact Name",contactContactNameLog.dataValues.note);
        }
      }
        // Mobile
        if(req.body.mobile) {
        if(dataMobile.toString() !== req.body.mobile.toString()) {
          const contactMobLog = await db2['logs'].create({
            org_id: org_id,
            module_id: contactId,
            module_name: "1",
            // note: 'Contact Mobile : ' + dataMobile + ' TO '+ req.body.mobile,
            note: 'Contact Mobile : ' + `${dataMobile == null || "" ? req.body.mobile : dataMobile + ' to '+ req.body.mobile}`,
            user_id: created_by.id
          })
          console.log("Mobile_no",contactMobLog.dataValues.note);
        }
      }
        // Email
        if(req.body.email) {
        if(dataEmail !== req.body.email) {
          const contactEmailLog = await db2['logs'].create({
            org_id: org_id,
            module_id: contactId,
            module_name: "1",
            // note: 'Contact Email : ' + dataEmail + ' TO '+ req.body.email,
            note: 'Contact Email : ' + `${dataEmail == null || "" ? req.body.email : dataEmail + ' to '+ req.body.email}`,
            user_id: created_by.id
          })
          console.log("email",contactEmailLog.dataValues.note);
        }
      }
        // Source
        if(req.body.source) {
          let thisQuery456 = ` select c.source as c_source, so.option_value as c_source_name
          from lz_contacts as c
          left join lz_masters as so on (so.id = c.source)
          where ${role_id == 1 ? `c.status IN (1,2) ` : `c.status = 1`} and c.source = ${req.body.source}
          `
          const dataSO = await db2.sequelize.query(thisQuery456);
          const dataSO1 = dataSO[0][0]?.c_source
          const dataSO2 = dataSO[0][0]?.c_source_name
          console.log("dataSO1", dataSO1);
          console.log("dataSO2", dataSO2);

        if(dataSource?.toString() !== req.body.source?.toString()) {
          const contactSourceLog = await db2['logs'].create({
            org_id: org_id,
            module_id: contactId,
            module_name: "1",
            // note: 'Contact Source : ' + dataSourceName + ' TO '+ dataSO2,
            note: 'Contact Source : ' + `${dataSourceName == null ? dataSO2 : dataSourceName + ' to '+ dataSO2}`,
            user_id: created_by.id
          })
          console.log("Source",contactSourceLog.dataValues.note);
        }
      }
        // Contact Status
      //   if(req.body.contact_status) {
      //     let thisQueryCS = ` select c.contact_status as c_contact_status, cs.option_value as c_contact_status_name
      //     from lz_contacts as c
      //     left join lz_masters as cs on (cs.id = c.contact_status)
      //     where c.status = 1 and c.contact_status = ${req.body.contact_status}
      //     `
      //     const dataCS = await db2.sequelize.query(thisQueryCS);
      //     const dataCS1 = dataCS[0][0]?.c_contact_status
      //     const dataCS2 = dataCS[0][0]?.c_contact_status_name
      //     console.log("dataCS1", dataCS1);
      //     console.log("dataCS2", dataCS2);

      //   if(dataStatus.toString() !== req.body.contact_status.toString()) {
      //     const contactStatusLog = await db2['logs'].create({
      //       org_id: org_id,
      //       module_id: contactId,
      //       module_name: "1",
      //       note: 'Contact Status : ' + dataStatusName + ' TO '+ dataCS2,
      //       user_id: created_by.id
      //     })
      //     console.log("Contact Status",contactStatusLog.dataValues.note);
      //   }
      // }
        // Property
        if(req.body.property_id) {
          let thisQueryPro = ` select c.property_id as c_property_id, pa1.name_of_building as property_name
          from lz_contacts as c
          left join lz_properties as p on (p.id = c.property_id)
          left join lz_property_addresses as pa1 on (p.id = pa1.property_id)
          where ${role_id == 1 ? `c.status IN (1,2) ` : `c.status = 1`} and c.property_id = ${req.body.property_id}
          `
          const dataPro = await db2.sequelize.query(thisQueryPro);
          const dataPro1 = dataPro[0][0]?.c_property_id
          const dataPro2 = dataPro[0][0]?.property_name
          console.log("dataPro1", dataPro1);
          console.log("dataPro2", dataPro2);
        if(dataProperty.toString() !== req.body.property_id.toString()) {
          const contactPropertyLog = await db2['logs'].create({
            org_id: org_id,
            module_id: contactId,
            module_name: "1",
            // note: 'Contact propery : ' + dataPropertyName + ' TO '+ dataPro2,
            note: 'Contact propery : ' + `${dataPropertyName == null ? dataPro2 : dataPropertyName + ' TO '+ dataPro2}`,
            user_id: created_by.id
          })
          console.log("Contact Property",contactPropertyLog.dataValues.note);
        }
      }
      res.status(200).send({
        status:200,
        message: "Updated successfully."
      });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot update with id : ${id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.deleteContact = async (req, res) => {
  const organ_id = req.user.id
  const org_id = organ_id.org_id
  console.log('organ_id', org_id);

  const created_by = req.user.id
  console.log('created_by', created_by.id);

    try {
      let x = req.params.id
      
      console.log("id111", x);

      let thisQuery  = ` UPDATE lz_contacts SET status = 0 `;
          thisQuery += " WHERE id IN (" + x + ") "
          thisQuery += ` and status = 1 `;

      const data = await db2.sequelize.query(thisQuery);

      res.status(200).send({
        status:200,
        message:'Success',
        output:data[0]
      });

    } catch (error) {
      res.status(500).send({
        message: error.message,
      });
    }
};
// Contact Details
exports.updateContactDetails = async (req, res) => {
    try {
      const organ_id = req.user.id
      const org_id = organ_id.org_id
      console.log('organ_id', org_id);

      const created_by = req.user.id
      console.log('created_by', created_by.id);

      const id = req.params.contact_id;
  
      const data = {
          gst_number: req.body.gst_number,
          invoice_name: req.body.invoice_name,
          gender: req.body.gender,
          dob: req.body.dob,
          marital_status: req.body.marital_status,
          wedding_anniversary: req.body.wedding_anniversary,
          number_of_children: req.body.number_of_children,
          pet_owner: req.body.pet_owner,
          nationality: req.body.nationality,
          language: req.body.language,
          designation: req.body.designation,
          national_id: req.body.national_id,
          do_not_disturb: req.body.do_not_disturb,
          documents: req.body.documents,
        }
  
      const num = await db2['contactDetails'].update(data, {
        where: { contact_id: id },
      });
      if (num == 1) {
  
        const contactLogs = await db2['logs'].create({
          org_id: org_id,
          module_id: id,
          module_name: "1",
          note: "Contact details updated at",
          user_id: created_by.id
        })
        console.log("contactLogss", contactLogs);

        res.status(200).send({
          status:200,
          message: "Updated successfully."
        });
      } else {
        res.status(200).send({
          status:404,
          message: `Cannot update with id : ${id}.`
        });
      }
    } catch (error) {
      res.status(500).send({
        message: error.message,
      });
    }
};
// Contact Address
exports.updateContactAddress = async (req, res) => {
    try {
      const organ_id = req.user.id
      const org_id = organ_id.org_id
      console.log('organ_id', org_id);

      const created_by = req.user.id
      console.log('created_by', created_by.id);

      const id = req.params.contact_id;
  
      const data = {
          address_1: req.body.address_1,
          address_2: req.body.address_2,
          locality: req.body.locality,
          country: req.body.country,
          city: req.body.city,
          state: req.body.state,
          zip_code: req.body.zip_code,
          facebook: req.body.facebook,
          instagram: req.body.instagram,
          linkedin: req.body.linkedin,
          twitter: req.body.twitter,
        }
  
      const num = await db2['contactAddress'].update(data, {
        where: { contact_id: id },
      });
      if (num == 1) {
  
        const contactLogs = await db2['logs'].create({
          org_id: org_id,
          module_id: id,
          module_name: "1",
          note: "Contact address updated at",
          user_id: created_by.id
        })
        console.log("contactLogss", contactLogs);

        res.status(200).send({
          status:200,
          message: "Updated successfully."
        });
      } else {
        res.status(200).send({
          status:404,
          message: `Cannot update with id : ${id}.`
        });
      }
    } catch (error) {
      res.status(500).send({
        message: error.message,
      });
    }
};
exports.updateContactStatus = async (req, res) => {
  try {
    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    const role = req.user.id
    const role_id = role.designation
    console.log('role_id', role_id);

    const created_id = req.user.id
    const created_by = created_id.id
    console.log('created_by', created_by);

    const desCreatedUser = await db2.sequelize.query(`select designation, CONCAT(first_name,' ', IFNULL(last_name, '')) as user_name, email from lz_user where status = 1 and id = ${created_by} `);
    const cDesignation = desCreatedUser[0][0]?.designation
    const CUserName = desCreatedUser[0][0]?.user_name
    console.log("cDesignation", cDesignation);
    console.log("CUserName", CUserName);

    const mailTriC = await db2.sequelize.query(`select designation from lz_email_trigger where options = 'contact_status_update' and status = 1 `);
    const cTriDesC = mailTriC[0][0]?.designation ?? 0
    console.log("cTriDesC", cTriDesC);

    const id = req.params.id;

    let thisQuery1 = ` select c.contact_status as contact_status, cs.option_value as contact_status_name
    from lz_contacts as c 
    left join lz_masters as cs on (cs.id = c.contact_status)
    where ${role_id == 1 ? `c.status IN (1,2) ` : `c.status = 1`} and c.id = ${id} `

    const data123= await db2.sequelize.query(thisQuery1);
    const dataStatus = data123[0][0]?.contact_status
    const dataStatusName = data123[0][0]?.contact_status_name
    console.log("dataStatus", dataStatus);
    console.log("dataStatusName", dataStatusName);

    const data = {
      contact_status: req.body.contact_status,
      }

      const contactStatus = req.body.contact_status
      console.log("contactStatussssss", contactStatus);

    const num = await db2['contacts'].update(data, {
      where: { id: id },
    });
    if (num == 1) {

      let thisQuery = ` select option_value from lz_masters where option_type = "contact_status" and id = ${contactStatus}`
      const data = await db2.sequelize.query(thisQuery);
      const dataValue = data[0][0].option_value
      console.log("dataaaaa", dataValue);

      let thisQueryCS = ` select c.contact_status as c_contact_status, cs.option_value as c_contact_status_name
      from lz_contacts as c
      left join lz_masters as cs on (cs.id = c.contact_status)
      where ${role_id == 1 ? `c.status IN (1,2) ` : `c.status = 1`} and c.contact_status = ${req.body.contact_status}
      `
      const dataCS = await db2.sequelize.query(thisQueryCS);
      const dataCS1 = dataCS[0][0]?.c_contact_status
      const dataCS2 = dataCS[0][0]?.c_contact_status_name
      console.log("dataCS1", dataCS1);
      console.log("dataCS2", dataCS2);

      if(contactStatus == 6) {
        const ContatData = {
          status: 2,
        }
        const contactDrop = await db2['contacts'].update(ContatData,{
          where: { id: id },
        });
      }

      if(dataStatus.toString() !== req.body.contact_status.toString()) {
        const contactLogs = await db2['logs'].create({
          org_id: org_id,
          module_id: id,
          module_name: "1",
          note: 'Contact Status : ' + dataStatusName + ' TO '+ dataCS2,
          user_id: created_by
        })
      }

      if(dataStatus.toString() !== req.body.contact_status.toString()) {
        // Email Trigger
        const email_settings = await db2.sequelize.query(`select status from lz_email_trigger where FIND_IN_SET('${cDesignation}', '${cTriDesC},1') > 0 and options = 'contact_status_update' and status = 1 `);
        // const emailTri = email_settings[0][0] ? email_settings[0][0]["active_status"] : 0
        const emailTri = email_settings[0][0]?.status
        console.log("emailTri", emailTri);

        //nodemailer
        if(emailTri == 1) {

        let thisQueryDes = ` select us.team_leader as tl, us.portfolio_head as sub_tl 
        from lz_user as us where id = ${created_by} `
        const desCheck = await db2.sequelize.query(thisQueryDes);
        const desCheckTL = desCheck[0][0].tl
        const desCheckSubTL = desCheck[0][0].sub_tl
        // Team Leader
        const checkTl = await db2.sequelize.query(`select email from lz_user where id = ${desCheckTL} `);
        const checkTl1 = checkTl[0][0].email
        // Sub TL
        const checksubTL = await db2.sequelize.query(`select email from lz_user where id = ${desCheckSubTL} `);
        const checksubTL1 = checksubTL[0][0].email
        // Admin
        const checkAdmin = await db2.sequelize.query(`select email from lz_user where designation = 1 group by id `);
        const checkAdmin1 = checkAdmin[0].map(item => item.email).join(', ');
        // Assign To
        const assignEmail = await db2.sequelize.query(`
        select c.assign_to as assign_to, us.email as email
        from lz_contacts as c
        left join lz_user as us on FIND_IN_SET(us.id,c.assign_to) > 0
        where c.id = ${id} `);
        const assEmail = assignEmail[0].map(item => item.email).join(', ')
      
        console.log("checkTl", checkTl1);
        console.log("checksubTL1", checksubTL1);
        console.log("checkAdmin1", checkAdmin1);
        console.log("assign_to",assEmail);
      
        const createdEmail = await db2.sequelize.query(`select email from lz_user where id = ${created_by} `);
        const cEmail = createdEmail[0][0].email
        console.log("cEmail", cEmail);

        let message = {
          from: cEmail,
          to: [checkAdmin1,checkTl1,checksubTL1, assEmail].join(', '),
          subject: "Contact Status Changed",
          html:
            " Contact Status changed " + dataStatusName + ' TO '+ dataCS2 + "",
        };
        console.log("message", message);
        mailer.sendMail(message, function(error, info){
          if (error) {
            console.log('Error');
          } else {
            console.log('Email sent: ' + info.response);
          }
        });
      }
      }
      res.status(200).send({
        status:200,
        message: "Updated successfully."
      });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot update with id : ${id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
// Contact Dropdown
exports.getContactDropdown = async (req, res) => {
    try {
      const created_id = req.user.id
      const created_by = 2
      console.log('created_by', created_by);
    
      const organ_id = req.user.id
      const org_id = organ_id.org_id
      console.log('organ_id', org_id);
    
      const role = req.user.id
      const role_id = 2
      console.log('role_id', role_id);
      
        let values = ['source', 'contact_group','contact_type','contact_category','contact_status','phone_number_type','country_code','do_not_disturb','marital_status', 'gender','nationality','pet_owner','id_documents']
        var condition = {
            where:{status:1},
            order: [
              ['id', 'ASC'],
            ],
            attributes:{exclude:['createdAt','updatedAt', 'created_by','status']}
          }
  
        // const dataFromOrg = await Modelv1.getAllFromOrg();
        
        const dataFromCity = await db['city'].findAll(condition);
        const dataFromState = await db['state'].findAll(condition);
        const dataFromCountry = await db['country'].findAll(condition);
        // const dataFromAssignTo = await db2['user'].findAll({
        //   attributes:['id','first_name','last_name']
        // });

        let thisQuery = ` SELECT lz_user.id as id, CONCAT(lz_user.first_name,' ', IFNULL(lz_user.last_name, '')) as assign_to_name 
        FROM lz_user
        left join lz_user as us5 on (lz_user.created_by = us5.id) 
        left join lz_user as us4 on (us5.team_leader = us4.id) 
        left join lz_user as us6 on (lz_user.created_by = us6.id) 
        left join lz_user as us7 on (us6.portfolio_head = us7.id)
        where lz_user.status = 1 `

        if (role_id == 1) {
          thisQuery += ` `
        }
        if (role_id == 2) {
          thisQuery += ` and lz_user.team_leader = ${created_by} or lz_user.portfolio_head = ${created_by} or lz_user.id = ${created_by} `
          // thisQuery += ` and c.created_by = ${created_by} `
        }
        if (role_id == 3) {
          thisQuery += ` and lz_user.team_leader = ${created_by} or lz_user.portfolio_head = ${created_by} or lz_user.id = ${created_by} `
          // thisQuery += ` and c.created_by = ${created_by} `
        }
        if (role_id == 4) {
          thisQuery += ` and lz_user.id = ${created_by} `
        }

        thisQuery += ` group by lz_user.id `

        const dataFromAssignTo = await db2.sequelize.query(thisQuery);

        // const dataFromProject = await db2['propertyAddress'].findAll({
        //   where:{status:1},
        //   attributes:['id','name_of_building']
        // });
        let thisQueryP = ` SELECT property_id as property_id, pa.name_of_building as name_of_building
        FROM lz_properties as p
        left join lz_property_addresses as pa on (p.id = pa.property_id)
        where p.status = 1 and pa.name_of_building IS NOT NULL 
        `
        const dataFromProject = await db2.sequelize.query(thisQueryP);
        // const dataFromSecContact = await db2['contacts'].findAll({
        //   attributes:['id','first_name']
        //  });
        let thisQuery1 = ` SELECT id as id, CONCAT(first_name,' ', IFNULL(last_name, '')) as secondary_contact_name FROM lz_contacts where status = 1 `
        const dataFromSecContact = await db2.sequelize.query(thisQuery1);
        
        const dataFromMasters = await db2['masters'].findAll(condition);
        let model4Datafetch = Object.values(JSON.parse(JSON.stringify(dataFromMasters)));
        const source = model4Datafetch.filter((obj) => obj.option_type == 'source');
        const contact_group = model4Datafetch.filter((obj) => obj.option_type == 'contact_group');
        const contact_type = model4Datafetch.filter((obj) => obj.option_type == 'contact_type');
        const contact_category = model4Datafetch.filter((obj) => obj.option_type == 'contact_category');
        const contact_status = model4Datafetch.filter((obj) => obj.option_type == 'contact_status');
        const contact_phone_number_type = model4Datafetch.filter((obj) => obj.option_type == 'phone_number_type');
        const country_code = model4Datafetch.filter((obj) => obj.option_type == 'country_code');
        const do_not_disturb = model4Datafetch.filter((obj) => obj.option_type == 'do_not_disturb');
        const marital_status = model4Datafetch.filter((obj) => obj.option_type == 'marital_status');
        const gender = model4Datafetch.filter((obj) => obj.option_type == 'gender');
        const nationality = model4Datafetch.filter((obj) => obj.option_type == 'nationality');
        const pet_owner = model4Datafetch.filter((obj) => obj.option_type == 'pet_owner');
        const id_documents = model4Datafetch.filter((obj) => obj.option_type == 'id_documents');
  
        const combinedData = {
          assign_to: dataFromAssignTo[0],
            city: dataFromCity,
            state: dataFromState,
            country: dataFromCountry,
            source: source,
            contact_type: contact_type,
            contact_category: contact_category,
            contact_group: contact_group,
            contact_status: contact_status,
            phone_number_type: contact_phone_number_type,
            country_code: country_code,
            do_not_disturb: do_not_disturb,
            marital_status: marital_status,
            gender: gender,
            nationality: nationality,
            pet_owner: pet_owner,
            id_documents: id_documents,
            property: dataFromProject[0],
            secondary_contact:dataFromSecContact[0],
        };
        res.status(200).send({
            message: "Contacts dropdown data",
            status: 200,
            output: combinedData
        })
    }
    catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Internal Server Error' });
    }
};
exports.getAllLocation = async(req,res) =>  {
  const pincode = req.params.pincode;
  const url = `https://api.postalpincode.in/pincode/${pincode}`;
  
    const response = await fetch(url).then(response => {
      return response.json();
    }).catch(err => {
      console.log(err);
      res.send({
          status:200,
          message : "error", err
      })
  });
    res.send({
      status:200,
      output :response[0].PostOffice ?? []
    })
    console.log(response);
}

exports.saveContactFilter = async (req, res) => {
  try {
    const created_by = req.user.id
    console.log('created_by', created_by.id);

    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    let thisQuery1 = ` SELECT id FROM lz_contact_filter `
    const data1 = await db2.sequelize.query(thisQuery1);
    const totalContact = data1[0].length
    console.log("totalContact", totalContact);
    
    if (totalContact < 5) {

    const data = await db2['contactFilter'].create({
      contact_type: req.body.contact_type,
      contact_status: req.body.contact_status,
      gender: req.body.gender,
      contact_category: req.body.contact_category,
      assign_to: req.body.assign_to,
      source: req.body.source,
      property_id: req.body.property_id,
      locality: req.body.locality,
      country: req.body.country,
      state: req.body.state,
      city: req.body.city,
      date_of_birth: req.body.date_of_birth,
      nationality: req.body.nationality,
      contact_group: req.body.contact_group,
      filter_name: req.body.filter_name,
      created_date: req.body.created_date,
      created_end_date: req.body.created_end_date,
      updated_date: req.body.updated_date,
      created_by: created_by.id
    });  
    
    res.status(200).send({
      status: 200,
      message: 'Success',
      output: data
    });
  }
  else {
    res.status(200).send({
      status: 400,
      message: 'Only 5 filters can add',
      output: []
    });
  }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.getContactFilter = async (req, res) => {
  try {
    
    const created_id = req.user.id
    const created_by = created_id.id
    console.log('created_by', created_by);
  
    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);
  
    const role = req.user.id
    const role_id = role.designation
    console.log('role_id', role_id);

    let thisQuery = `select c.*, CONVERT(c.assign_to USING utf8) as assign_to, GROUP_CONCAT(distinct CONCAT(us.first_name,' ', IFNULL(us.last_name, ''),'-',us.id)) as assign_to_name, s.option_value as source_name, ct.option_value as contact_type_name, cs.option_value as contact_status_name, cg.option_value as contact_group_name, cc.option_value as contact_category_name, gen.option_value as gender_name, CONCAT(us3.first_name,' ',us3.last_name) as created_by_name, DATE_FORMAT(c.created_date,'%Y-%m-%d') as created_date, DATE_FORMAT(c.created_end_date,'%Y-%m-%d') as created_end_date, DATE_FORMAT(c.updated_date,'%Y-%m-%d') as updated_date, pas.name_of_building as property_name
  
    from lz_contact_filter as c   
    left join lz_contact_address as ca on (ca.contact_id = c.id) 
    left join lz_contact_details as cd on (cd.contact_id = c.id)
    left join lz_property_addresses as pas on (pas.property_id = c.property_id) 
    LEFT JOIN lz_user as us on FIND_IN_SET(us.id,c.assign_to) > 0 
    LEFT JOIN lz_user as us3 on FIND_IN_SET(us3.id,c.created_by) > 0 
    left join lz_masters as s on (s.id = c.source) 
    left join lz_masters as ct on (ct.id = c.contact_type) 
    left join lz_masters as cs on (cs.id = c.contact_status) 
    left join lz_masters as cg on (cg.id = c.contact_group) 
    left join lz_masters as cc on (cc.id = c.contact_category)
    left join lz_masters as gen on (gen.id = c.gender)
    where c.id IS NOT NULL group by c.id `;
  
  const data = await db2.sequelize.query(thisQuery);

    res.status(200).send({
      status:200,
      message:'Success',
      output: data[0],
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.deleteContactFilter = async (req, res) => {
  try {
    const id = req.params.id;
    const num = await db2['contactFilter'].destroy({
      where: { id: id },
    });
    if (num == 1) {
      res.status(200).send({
        status:200,
        message: "Deleted successfully."
      });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot delete with id : ${id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};

exports.getContactLeads = async (req, res) => {
  try {
  const contactID = req.params.contact_id;
  console.log('contactIDDDD', contactID);

  const organ_id = req.user.id
  const org_id = organ_id.org_id
  console.log('organ_id', org_id);
  
  let thisQuery = `SELECT l.*, CONCAT(c.first_name,' ',IFNULL(c.last_name, '')) as contact_name, GROUP_CONCAT(distinct CONCAT(us.first_name,' ', IFNULL(us.last_name, ''),'-',us.id)) as assign_to_name, c.email as email, c.mobile as mobile,  CONCAT(us1.first_name,' ',IFNULL(us1.last_name, '')) as created_by_name, pas.name_of_building as property_name, lr.budget_min as budget_min, lr.budget_max as budget_max,
  lrn.option_value as looking_for_name, 
  pt.option_value as property_type_name, 
  ls.option_value as lead_source_name,
  lg.option_value as lead_group_name,
  seg.option_value as segment_name,
  lp.option_value as lead_priority_name,
  lss.option_value as lead_status_name,
  aop.option_value as age_of_property_name,
  vc.option_value as vasthu_compliant_name,
  pf.option_value as property_facing_name
  FROM lz_leads as l 
  LEFT JOIN lz_contacts as c on (c.id = l.contact_id) 
  LEFT JOIN lz_lead_requirements as lr on (l.id = lr.lead_id) 
  LEFT JOIN lz_property_addresses as pas on (pas.property_id = c.property_id) 
  LEFT JOIN lz_user as us on FIND_IN_SET(us.id,l.assign_to) > 0 
  LEFT JOIN lz_user as us1 on (us1.id = l.created_by)
  LEFT JOIN lz_masters as lrn on (lrn.id = l.looking_for) 
  LEFT JOIN lz_masters as pt on (pt.id = l.property_type)
  LEFT JOIN lz_masters as ls on (ls.id = l.lead_source)
  LEFT JOIN lz_masters as lg on (lg.id = l.lead_group)
  LEFT JOIN lz_masters as seg on (seg.id = l.segment)
  LEFT JOIN lz_masters as lp on (lp.id = l.lead_priority)
  LEFT JOIN lz_masters as lss on (lss.id = l.lead_status)
  LEFT JOIN lz_masters as aop on (aop.id = lr.age_of_property)
  LEFT JOIN lz_masters as vc on (vc.id = lr.vasthu_compliant)
  LEFT JOIN lz_masters as pf on (pf.id = lr.property_facing) 
  where l.status = 1 and l.contact_id = ${contactID} group by l.id `

  const data = await db2.sequelize.query(thisQuery);

    res.status(200).send({
      status:200,
      message:'Success',
      output:data[0]
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.getContactTasks = async (req, res) => {
  try {
  const contactID = req.params.contact_id;
  console.log('contactIDDDD', contactID);

  const organ_id = req.user.id
  const org_id = organ_id.org_id
  console.log('organ_id', org_id);
  
  let thisQuery = `SELECT t.*, DATE_FORMAT(t.task_time,'%Y-%m-%d %H:%i:%s') as task_time, c.id as contact_id, c.company_name as company_name, CONCAT(c.first_name,' ',c.last_name)as contact_name, c.email as contact_email, c.mobile as contact_mobile, c.profile_image as contact_profile_image, c.profile_image_original_name as contact_profile_image_original_name,
  pra.name_of_building as property_name, GROUP_CONCAT(us.first_name,' ',us.last_name,'-',us.id) as assign_to_name, org.organization_name as org_name, ms2.option_value as task_type_name, ms.option_value as task_status_name, ms1.option_value as priority_name, rem.option_value as reminder_name
  FROM lz_tasks as t
  LEFT JOIN lz_properties as pr on (pr.id = t.project) 
  LEFT JOIN lz_property_addresses as pra on (pra.id=pr.id)
  LEFT JOIN lz_contacts as c on (c.id = t.contact)
  LEFT JOIN lz_user as us on FIND_IN_SET(us.id,t.assign_to)>0
  LEFT JOIN lz_organization as org on (org.id = t.org_id)
  LEFT JOIN lz_masters as ms on (ms.id = t.task_status)
  LEFT JOIN lz_masters as ms1 on (ms1.id = t.priority)
  LEFT JOIN lz_masters as ms2 on (ms2.id = t.task_type)
  LEFT JOIN lz_masters as rem on (rem.id = t.reminder)
  where t.contact = ${contactID} group by t.id `

  const data = await db2.sequelize.query(thisQuery);

    res.status(200).send({
      status:200,
      message:'Success',
      output:data[0]
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.getDuplicateContact = async (req, res) => {
  try {
  const contactID = req.params.contact_id;
  let thisQuery = `SELECT c.*, CONCAT(us.first_name,' ',IFNULL(us.last_name, '')) as created_by_name FROM lz_contacts as c 
  left join lz_user as us on (us.id = c.created_by)
  where c.status = 1 and c.mobile in (SELECT mobile FROM lz_contacts where c.status = 1 and id = ${contactID}) and c.property_id in (SELECT property_id FROM lz_contacts where c.status = 1 and id = ${contactID}) and c.id != ${contactID} `
  const data = await db2.sequelize.query(thisQuery);

    res.status(200).send({
      status:200,
      message:'Success',
      output:data[0]
    });
    
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.getSecondaryContacts = async (req, res) => {
  try {
  const contactID = req.params.id;
  let thisQuery = ` SELECT c.*, CONCAT(us.first_name,' ', IFNULL(us.last_name, '')) as created_by_name 
  FROM lz_contacts as c 
  left join lz_user as us on (us.id = c.created_by)
  where c.id in (SELECT secondary_contact_id FROM lz_contacts where c.status = 1 and c.secondary_contact_id = ${contactID} or id = ${contactID}) limit 1 `
  const data = await db2.sequelize.query(thisQuery);

    res.status(200).send({
      status:200,
      message:'Success',
      output:data[0]
    });

  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};

exports.updateReAssign = async (req, res) => {
  try {
    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    const created_by = req.user.id
    console.log('created_by', created_by.id);

    const id = req.params.id;
    console.log('id', id);

    const data = {
      assign_to: req.body.assign_to
    }

    const num = await db2['contacts'].update(data, {
      where: { id: id },
    });
    console.log("nummmm", num[0]);
    if (num == 1) {

      const contactLogs = await db2['logs'].create({
        org_id: org_id,
        module_id: id,
        module_name: "1",
        note: "Re-Assign updated at",
        user_id: created_by.id,
        created_by: created_by.id
      })

      res.status(200).send({
        status:200,
        message: "Updated successfully."
      });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot update with id : ${id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.ReAssignDropdown1 = async (req, res) => {  
  try {

    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    const created_id = req.user.id
    const created_by = created_id.id
    console.log('created_by', created_by);

    const id = req.params.id
    console.log('id', id);
    
    // let thisQuery = `select us.id as id, us.first_name as first_name, us.id as team_leader, us.first_name as team_leader_name, lower(us.first_name) as team_name_lower, IF(@uuid:=us.id, "YES", "NO") as mytl from lz_user us where us.id
    // and us.id = us.team_leader group by us.id`

    let thisQuery = ` SELECT us.id as id, us1.id as user_id, us.first_name as user_name, us1.first_name as team_leader_name
     FROM lz_user as us 
     LEFT JOIN lz_user as us1 on (us1.id = us.team_leader) 
     where us.status = 1 and us.id = ${created_by}
     group by us.id
     `
    let thisQuery1 = ` SELECT us.id as id, us2.id as user_id, us.first_name as user_name, us2.first_name as team_leader_name
     FROM lz_user as us 
     LEFT JOIN lz_user as us2 on (us2.id = us.portfolio_head) 
     where us.status = 1 and us.id = ${created_by}
     group by us.id
     `
    let thisQuery2 = ` SELECT ${created_by} as id, us3.id as user_id, us.first_name as user_name, us3.first_name as team_leader_name
     FROM lz_user as us 
     LEFT JOIN lz_user as us3 on (us3.id = us.id) 
     where us.designation = 1 
     group by us.id
     `
    const dataTl = await db2.sequelize.query(thisQuery1);
    const dataPh = await db2.sequelize.query(thisQuery);
    const dataAd = await db2.sequelize.query(thisQuery2);

    const aaa = dataTl[0]
    const bbb = dataPh[0]
    const ccc = dataAd[0]

    console.log("cccccc", ccc);
    let contactWithdata = [];
    for(let i=0; aaa.length > i;i++) {

    let dataPush = [bbb[0], ...aaa, ...ccc];
    contactWithdata.push(dataPush);
    }

    res.status(200).send({
      status:200,
      message:'Success',
      output:contactWithdata[0]
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.ReAssignDropdown = async (req, res) => {  
  try {

    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    const created_id = req.user.id
    const created_by = created_id.id
    console.log('created_by', created_by);

    const id = req.params.id
    console.log('id', id);
    
    // let thisQuery = `select us.id as id, us.first_name as first_name, us.id as team_leader, us.first_name as team_leader_name, lower(us.first_name) as team_name_lower, IF(@uuid:=us.id, "YES", "NO") as mytl from lz_user us where us.id
    // and us.id = us.team_leader group by us.id`

    let thisQuery1 = ` SELECT us.id as id, us.first_name as user_name
     FROM lz_user as us 
     LEFT JOIN lz_user as us1 on (us.id = us1.team_leader)
     LEFT JOIN lz_user as us2 on (us.id = us2.portfolio_head)
     where us.status = 1 and (us.designation = 1 or us1.id = ${created_by} or us2.id = ${created_by})
     group by us.id
     `
    const dataTl = await db2.sequelize.query(thisQuery1);

    const aaa = dataTl[0]

    console.log("aaaaaaa", aaa);
    res.status(200).send({
      status:200,
      message:'Success',
      output:dataTl[0]
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};

// left join lz_contact_address as ca on (ca.contact_id = c.id) left join lz_contact_details as cd on (cd.contact_id = c.id)

exports.getContactFinal = async (req, res) => {
  try {
    
  const organ_id = req.user.id
  const org_id = organ_id.org_id
  console.log('organ_id', org_id);
  
    var condition = {
      where:{
        status:1, 
      },
      // order: [['id', 'DESC']], // ASC, DESC
      order: req.query.sort ? sqs.sort(req.query.sort) : [['id', 'DESC']],
      // attributes: {exclude :['createdAt','updatedAt']},
      // attributes: {
      //   include: [
      //     [
      //       Sequelize.literal(`(
      //             select GROUP_CONCAT(distinct CONCAT(us.first_name,' ',us.last_name)) as assign_to_name from lz_contacts as c LEFT JOIN lz_user as us on FIND_IN_SET(us.id,c.assign_to) > 0 
      //           )`),
      //       'assign_to_name_list',
      //     ],
      //   ]
      // },
      include: [
        // {
        //   model: db2['contactDetails'],
        //   attributes:{exclude:['createdAt','updatedAt']},
        //   where: {},
        //   as:'contact_details_name',
        //   required: false,
        // },
        // {
        //   model: db2['contactAddress'],
        //   attributes:{exclude:['createdAt','updatedAt']},
        //   where: {},
        //   as:'contact_address_name',
        //   required: false,
        // },
          {
            model: db2['masters'],
            attributes: ['option_type','option_value'],
            where: {},
            as:'source_name',
            required: false,
          },
          {
            model: db2['masters'],
            attributes: ['option_type','option_value'],
            where: {},
            as:'contact_group_name',
            required: false,
          },
          {
            model: db2['masters'],
            attributes: ['option_type','option_value'],
            where: {},
            as:'contact_type_name',
            required: false,
          },
          {
            model: db2['masters'],
            attributes: ['option_type','option_value'],
            where: {},
            as:'contact_category_name',
            required: false,
          },
          {
            model: db2['masters'],
            attributes: ['option_type','option_value'],
            where: {},
            as:'contact_status_name',
            required: false,
          },
          {
            model: db2['user'],
            attributes: ['id','first_name','last_name'],
            where: {},
            as:'created_by_name',
            required: false,
          },
          {
            model: db2['user'],
            attributes: ['id','first_name','last_name'],

            // attributes: [
            //   Sequelize.literal(`(
            //     select GROUP_CONCAT(distinct CONCAT(us.first_name,' ',us.last_name)) as assign_to_name from lz_contacts as c LEFT JOIN lz_user as us on FIND_IN_SET(us.id,c.assign_to)>0
            //   )`),
            // ],

            as:'assign_to_name',
            required: false,
          },
        ],
        offset : parseInt(req.query.offset) || 0,
      //  limit: parseInt(req.query.limit) || 12
        limit : (req.query.offset ? 12 : null)
    };

    const data = await db2['contacts'].findAll()

    // let contactData = [];
    // for(let i=0; data.length > i;i++) {
    //   const data11 = await db2['contactDetails'].findAll({
    //     attributes:{exclude:['id','contact_id','createdAt','updatedAt']}
    //   });
    //   const data12 = await db2['contactAddress'].findAll({
    //     attributes:{exclude:['id','contact_id','createdAt','updatedAt']}
    //   });

    //   const a = data11[0]?.dataValues
    //   const b = data12[0]?.dataValues
    //   let dataPush1 = {...data[i]?.dataValues, ...a, ...b};
    //   contactData.push(dataPush1);
    // }
    // console.log("contactData", contactData);

    // const filters = req.query;
    // const filteredContact = data.filter(user => {
    //   let isValid = true;
    //   for (key in filters) {
    //     if(key != "offset" ) {
    //     console.log('keyyyyyyy',key, user[key], filters[key]);
    //     isValid = isValid && user[key] == filters[key];
    //     }
    //   }
    //   return isValid;
    // });

    let contactWithdata = [];
    for(let i=0; data.length > i;i++) {
      const data11 = await db2['contactDetails'].findAll({
        attributes:{exclude:['id','contact_id','createdAt','updatedAt']}
      });
      const data12 = await db2['contactAddress'].findAll({
        attributes:{exclude:['id','contact_id','createdAt','updatedAt']}
      });
      const a = data11[i]?.dataValues
      const b = data12[i]?.dataValues
    const dataFinal = await db2.sequelize.query(`select GROUP_CONCAT(distinct CONCAT(us.first_name,' ',us.last_name)) as assign_to_name from lz_contacts as c LEFT JOIN lz_user as us on FIND_IN_SET(us.id,c.assign_to)>0 GROUP BY c.id DESC `)
    const contactCheck =  dataFinal[0]
    console.log("dataFinallll",dataFinal);
    let dataPush = {...data[i]?.dataValues, ...a, ...b, assign_to_name:contactCheck[i].assign_to_name};
    contactWithdata.push(dataPush);
    }

    const filters = req.query;
    const filteredContact = contactWithdata.filter(user => {
      let isValid = true;
      for (key in filters) {
        if(key != "offset")  {
        console.log('keyyyyyyy',key, user[key], filters[key]);
        isValid = isValid && user[key] == filters[key];
        }
      }
      return isValid;
    });
    const filter1s = req.query;
    const filteredContact1 = data.filter(user => {
      let isValid = true;
      for (key in filters) {
        if(key != "offset")  {
        console.log('keyyyyyyy',key, user[key], filters[key]);
        isValid = isValid && user[key] == filters[key];
        }
      }
      return isValid;
    });

    // console.log("filteredUsers", filteredUsers);

    const count_filter = (filteredContact)

    res.status(200).send({
      status:200,
      message:'Success',
      count: count_filter.length,
      output: data,
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.editContactFinal = async (req, res) => {
try {
  const organ_id = req.user.id
  const org_id = organ_id.org_id
  console.log('organ_id', org_id);

  const id = req.params.id;
  const data = await db2['contacts'].findOne({
    where: {
      id: id, status: 1
    },
    attributes: { exclude: ['createdAt', 'updatedAt'] },
    include: [
      {
        model: db2['contactDetails'],
        attributes: { exclude: ['createdAt', 'updatedAt'] },
        where: {},
        as: 'contact_details_name',
        required: false,
      },
      {
        model: db2['contactAddress'],
        attributes: { exclude: ['createdAt', 'updatedAt'] },
        where: {},
        as: 'contact_address_name',
        required: false,
      },
      {
        model: db['masters'],
        attributes: ['option_type', 'option_value'],
        where: {},
        as: 'source_name',
        required: false,
      },
      {
        model: db['masters'],
        attributes: ['option_type', 'option_value'],
        where: {},
        as: 'contact_group_name',
        required: false,
      },
      {
        model: db['masters'],
        attributes: ['option_type', 'option_value'],
        where: {},
        as: 'contact_type_name',
        required: false,
      },
      {
        model: db['masters'],
        attributes: ['option_type', 'option_value'],
        where: {},
        as: 'contact_category_name',
        required: false,
      },
      {
        model: db2['user'],
        attributes: ['id', 'first_name', 'last_name'],
        where: {},
        as: 'created_by_name',
        required: false,
      },
    ]
  }
  );
  const dataFinal = await db2.sequelize.query(`select GROUP_CONCAT(distinct CONCAT(us.first_name,' ',us.last_name)) as assign_to_name from lz_contacts as c LEFT JOIN lz_user as us on FIND_IN_SET(us.id,c.assign_to)>0 where c.id = ${id} GROUP BY c.id DESC `)
  const contactCheck = dataFinal[0]
  const assign = contactCheck[0].assign_to_name

  if (data) {
    res.status(200).send({
      status: 200,
      message: 'Success',
      output: {...data?.dataValues, assign:assign},
    });
  } else {
    res.status(200).send({
      status: 404,
      message: `Cannot find with id : ${id}.`
    });
  }
} catch (error) {
  res.status(500).send({
    message: error.message,
  });
}
};

exports.getContactCheck = async (req, res) => {
  try {

  const created_id = req.user.id
  const created_by = created_id.id
  console.log('created_by', created_by);

  const organ_id = req.user.id
  const org_id = organ_id.org_id
  console.log('organ_id', org_id);

  const role = req.user.id
  const role_id = role.designation
  console.log('role_id', role_id);

  let thisQuery = `select c.*, CONVERT(c.assign_to USING utf8) as assign_to, GROUP_CONCAT(distinct CONCAT(us.first_name,' ', IFNULL(us.last_name, ''))) as assign_to_name ,s.option_value as source_name, ct.option_value as contact_type_name, cs.option_value as contact_status_name, cg.option_value as contact_group_name, cc.option_value as contact_category_name, ca.address_1,ca.address_2,ca.locality,ca.country,ca.city,ca.state,ca.zip_code,cd.national_id,cd.gst_number,cd.gender,cd.dob,cd.marital_status,cd.wedding_anniversary,cd.number_of_children,cd.pet_owner,cd.nationality,cd.language,cd.designation,cd.do_not_disturb,cd.invoice_name,ca.facebook,ca.instagram,ca.linkedin,ca.twitter, CONCAT(us3.first_name,' ',us3.last_name) as created_by_name, DATE_FORMAT(c.created_at,'%Y-%m-%d') as created_date,pas.name_of_building as property_name,
  (SELECT COUNT(id) FROM lz_notes where module_id = c.id and module_name = 1 and status = 1) as notes_count,
  (SELECT COUNT(id) FROM lz_file_uploads where module_id = c.id and module_name = 1 ) as files_count,
  (SELECT ifnull(COUNT(*),0) FROM lz_leads as l LEFT JOIN lz_contacts on (lz_contacts.id = l.contact_id) where contact_id = c.id) as lead_count,
  (SELECT ifnull(COUNT(*),0) FROM lz_tasks as t LEFT JOIN lz_contacts on (lz_contacts.id = t.contact) where t.contact = c.id) as task_count,
  (SELECT ifnull(COUNT(*),0) FROM lz_contacts where secondary_contact_id = c.id) as sec_count 
  from lz_contacts as c
  left join lz_contact_address as ca on (ca.contact_id = c.id) 
  left join lz_contact_details as cd on (cd.contact_id = c.id)
  left join lz_property_addresses as pas on (pas.property_id = c.property_id) 
  LEFT JOIN lz_user as us on FIND_IN_SET(us.id,c.assign_to) > 0 
  LEFT JOIN lz_user as us3 on FIND_IN_SET(us3.id,c.created_by) > 0 
  left join lz_masters as s on (s.id = c.source) 
  left join lz_masters as ct on (ct.id = c.contact_type) 
  left join lz_masters as cs on (cs.id = c.contact_status) 
  left join lz_masters as cg on (cg.id = c.contact_group) 
  left join lz_masters as cc on (cc.id = c.contact_category)
  where c.status = 1 `;

  if (role_id == 1) {
    thisQuery += ` `
  }
  if (role_id == 2) {

    let thisQuery1 =`select GROUP_CONCAT(distinct CONCAT(us.id)) as exec, us.team_leader as team_leader from lz_user as us where us.team_leader = ${created_by} limit 1 `
    const data = await db2.sequelize.query(thisQuery1);
    console.log('dataaaaaaaaaaaaa',data[0]);

    // if (data[0]) {
    //   const executives = data[0] ? data[0][0].exec : 0
    //   console.log("executivesssss", executives);
    //   const tl = data[0] ? data[0][0].team_leader : 0
    //   console.log("team_leader", tl);
    //   var a = executives;
    //   var b = a.replace(/[,]/g, "|");
    //   var c = b.concat('|', tl)
    //   thisQuery += ` and CONCAT(',', c.assign_to, ',') REGEXP ',(${c}),' or c.created_by = ${created_by} `
    // } else {
      thisQuery += ` and FIND_IN_SET(${created_by},c.assign_to)>0 or c.created_by = ${created_by}  `
    // }

    thisQuery += ` and c.status= 1 and c.created_by = ${created_by} `
  }
  if (role_id >= 3) {
    thisQuery += ` and c.status= 1 and c.created_by = ${created_by} `
  }

  const filters = req.query;
  // for (key in filters) {
    if (filters.contact_type) {
      thisQuery += " and c.contact_type = " + `${filters.contact_type}`
    }
    if (filters.contact_category) {
      thisQuery += " and c.contact_category = " + `${filters.contact_category} `
    }
    if (filters.company_name) {
      thisQuery += "and c.company_name = " + `'${filters.company_name}'`
    }
    if (filters.contact_status) {
      thisQuery += "and c.contact_status = " + `${filters.contact_status} `
    }
    if (filters.assign_to) {
      var a = filters.assign_to;
      var b = a.replace(/[,]/g, ",");
      thisQuery += `and CONCAT(',', c.assign_to, ',') REGEXP ',(${a}),' `
    }
    if (filters.source) {
      thisQuery += "and c.source = " + `${filters.source} `
    }
    if (filters.locality) {
      thisQuery += "and ca.locality = " + `${filters.locality} `
    }
    if (filters.contact_group) {
      thisQuery += "and c.contact_group = " + `${filters.contact_group} `
    }
    if (filters.created_by) {
      thisQuery += "and c.created_by = " + `${filters.created_by} `
    }
    if (filters.created_at) {
      thisQuery += "and c.created_at = " + `'${filters.created_at}' `
    }
    if (filters.dob) {
      thisQuery += " and cd.dob = " + `${filters.dob} `
    }
    if (filters.city) {
      thisQuery += " and ca.city = " + `${filters.city} `
    }
    if (filters.nationality) {
      thisQuery += " and cd.nationality = " + `${filters.nationality} `
    }
    if (filters.state) {
      thisQuery += " and ca.state = " + `${filters.state} `
    }
    if (filters.zip_code) {
      thisQuery += " and ca.zip_code = " + `${filters.zip_code} `
    }
  // }
  thisQuery += ' group by c.id '

  if (filters.order_by) {
    let orderByString = filters.order_by.split('|')
    thisQuery += " order by " + `${orderByString[0]} ${orderByString[1]} `
  }
  const data1 = await db2.sequelize.query(thisQuery);

  if (filters.order_by =="") {
    thisQuery += ' order by c.created_at DESC '
  }

  // thisQuery += ' order by c.created_at DESC '

  if (filters.limit) {
    thisQuery += ` limit ${filters.limit},12 `
  }

  const data = await db2.sequelize.query(thisQuery);

  const count_filter = (data1[0])

    res.status(200).send({
      status:200,
      message:'Success',
      count: count_filter.length,
      output: data[0],
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};

exports.saveContactAutoAssign = async (req, res) => {
  try {
    const created_id = req.user.id
    const created_by = created_id.id
    console.log('created_by', created_by);
  
    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);
  
    const role = req.user.id
    const role_id = role.designation
    console.log('role_id', role_id);

    const id = req.params.id;

    const propertyIdFetch = await db2.sequelize.query(`select property_id from lz_property_addresses where property_id='${req.body.property_id}' limit 1`);
    const propertyId = propertyIdFetch[0][0] ? propertyIdFetch[0][0].property_id : 0
    console.log("propertyyyy", propertyId);

    const DuplicateFetch = await db2.sequelize.query(`select id from lz_contacts where mobile ='${req.body.mobile}' or property_id ='${propertyId}' and date(created_at) = curdate() limit 1`);
    const duplicateId = DuplicateFetch[0][0] ? DuplicateFetch[0][0]['id'] : 0
    console.log("duplicateId", duplicateId);

    // if (!duplicateId) {
    //     res.status(200).send({
    //         status:400,
    //         message: "your contact has been already exists.",
    //     }); 
    // } else {

      const CSCheck123 = await db2.sequelize.query(`select csm.sorting_order as sorting_order, csm.user_id as user_id, csm.contact_setting_id, cs.project_id as project_id, cs.source_id as source_id 
      from lz_contact_setting_members as csm 
      left join lz_contact_settings as cs on (cs.id = csm.contact_setting_id) 
      where (cs.project_id = ${propertyId} and cs.source_id = ${req.body.source})
      group by csm.id
       `);

      const checkOut = CSCheck123[0].length
      console.log("checkOut", checkOut);


      const autoAssignFetch = await db2.sequelize.query(`select last_assign_to,position from lz_auto_assign where project_id ='${propertyId}' and source_id ='${req.body.source}' order by id desc limit 1`);
      const assignToId = autoAssignFetch[0][0] ? autoAssignFetch[0][0]["last_assign_to"] : 0
      let positionId = ((autoAssignFetch[0][0]?.position ?? 0) +1) <= checkOut ? (autoAssignFetch[0][0]?.position ?? 0) +1 : autoAssignFetch[0][0]?.position - checkOut+1

      console.log("assignToId", assignToId);
      console.log("positionId", positionId);

if (autoAssignFetch) {

      const CSCheck = await db2.sequelize.query(`select csm.sorting_order as sorting_order, csm.user_id as user_id, csm.contact_setting_id, cs.project_id as project_id, cs.source_id as source_id 
      from lz_contact_setting_members as csm 
      left join lz_contact_settings as cs on (cs.id = csm.contact_setting_id) 
      where cs.project_id = ${propertyId} and cs.source_id = ${req.body.source} ${!positionId ? ``:`and csm.sorting_order = ${positionId}`}
      limit 1
       `);

      const conSetCheck = CSCheck[0][0] ? CSCheck[0][0]["user_id"] : 0
      console.log("CSCheckkkkk", CSCheck[0]);
        
      var assign_to = CSCheck[0][0] ? CSCheck[0][0]["user_id"] : 0
      var position_id = CSCheck[0][0] ? CSCheck[0][0]["sorting_order"] : 0

      console.log("aaaaaaaaa", assign_to);
      console.log("ppppppppp", position_id);
}
        const data = await db2['contacts'].create({
          first_name: req.body.first_name || 'Customer',
          last_name: req.body.last_name || null,
          email: req.body.email || null,
          mobile: req.body.mobile || null,
          property_id: propertyId || null,
          source: req.body.source,
          contact_status: req.body.contact_status,
          contact_type: 8,
          assign_to: assign_to,
          created_by: created_by
        });

      let contactSettingId = data?.dataValues.id
      let sourceData = data?.dataValues.source

      if (propertyId > 0) {
        const updateAutoAssignTable = await db2.sequelize.query(`INSERT INTO lz_auto_assign (project_id, source_id, last_assign_to, position) VALUES (${propertyId},${sourceData},${assign_to},${position_id})`)
      }

      const contactLogs = await db2['logs'].create({
        org_id: org_id,
        module_id: contactSettingId,
        module_name: "1",
        note: "Contact created at OMGGGGGGGG ",
        user_id: created_by
      })
      console.log("contactLogss", contactLogs);

    res.status(200).send({
      status:200,
      message:'Success',
      output:data
    });

  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};

exports.saveResponder = async (req, res) => {
  try {
    const created_id = req.user.id
    const created_by = created_id.id
    console.log('created_by', created_by);
  
    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);
    
    const role = req.user.id
    const role_id = role.designation
    console.log('role_id', role_id);

    const id = req.params.id;

    const data = await db2['contacts'].create({
      org_id: org_id,
      property_id: req.body.property_id,
      first_name: req.body.first_name,
      email: req.body.email,
      mobile: req.body.mobile,
    });

    let contactId = data?.dataValues.id
    let propertyId = data?.dataValues.property_id

    const data1 = await db2['contactAddress'].create({
      contact_id: contactId,
      country: req.body.country,
      state: req.body.state,
      city: req.body.city,
      locality: req.body.locality,
    });
    
    const data3 = await db2['leads'].create({
      org_id: org_id,
      contact_id: contactId,
      property_id: propertyId,
    });
    let leadId = data3?.dataValues.id

    const data4 = await db2['leadRequirement'].create({
      lead_id: leadId,
      budget_min: req.body.budget_min,
      budget_max: req.body.budget_max
    });
    const data5 = await db2['tasks'].create({
      contact: contactId,
      project: propertyId,
      task_time: req.body.task_time,
      finish_time: req.body.finish_time
    });

    console.log("data", data);

    res.status(200).send({
      status:200,
      message:'Success',
      output:data
    });

  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};

exports.bulkReAssign = async (req, res) => {
  const organ_id = req.user.id
  const org_id = organ_id.org_id
  console.log('organ_id', org_id);

  const created_by = req.user.id
  console.log('created_by', created_by.id);

    try {
      let x = req.params.id
      console.log("id111", x);

      let thisQuery  = ` UPDATE lz_contacts SET assign_to = '${req.body.assign_to}' `;
          thisQuery += " WHERE id IN (" + x + ") "
          thisQuery += ` and status = 1 `;

      const data = await db2.sequelize.query(thisQuery);

      res.status(200).send({
        status:200,
        message:'Success',
        output:data[0]
      });

    } catch (error) {
      res.status(500).send({
        message: error.message,
      });
    }
};

exports.uploadFile = (async (req, res) => {
  // const query = util.promisify;
  readXlsxFile('./uploads/' + req.file.filename).then(async (rows) => {

    const created_id = req.user.id
    const created_by = created_id.id
    console.log('created_by', created_by);
  
    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);
    
    const role = req.user.id
    const role_id = role.designation
    console.log('role_id', role_id);

    console.log("designa");
    const rowing = [];
    console.log('rowing', rowing);

    rows.shift();
    rows.map(async (row, i) => {
        const company_nameIdFetch = await db2.sequelize.query(`select id from lz_contacts where company_name ='${row[3]}' limit 1`);
        const company_nameId = company_nameIdFetch[0][0] ? company_nameIdFetch[0][0]["id"] : 0

        const property_IdFetch = await db2.sequelize.query(`select property_id from lz_property_addresses where name_of_building ='${row[10]}' limit 1`);
        const property_Id = property_IdFetch[0][0] ? property_IdFetch[0][0]["property_id"] : 0
        console.log("property_IdFetch", property_IdFetch[0][0]);
        console.log("property_Id", property_Id);
        const contact_groupIdFetch = await db2.sequelize.query(`select id from lz_masters where option_value ='${row[11]}' limit 1`);
        const contact_groupId = contact_groupIdFetch[0][0] ? contact_groupIdFetch[0][0]["id"] : 0
        // source
        const sourceIdFetch = await db2.sequelize.query(`select id from lz_masters where option_value ='${row[12]}' limit 1`);
        const sourceId = sourceIdFetch[0][0] ? sourceIdFetch[0][0]["id"] : 0
        console.log("sourceId", sourceId);
        // contact_type
        const contactTypeIdFetch = await db2.sequelize.query(`select id from lz_masters where option_value ='${row[13]}' limit 1`);
        const contactTypeId = contactTypeIdFetch[0][0] ? contactTypeIdFetch[0][0]["id"] : 0
        // contact_category
        const contact_categoryIdFetch = await db2.sequelize.query(`select id from lz_masters where option_value ='${row[14]}' limit 1`);
        const contact_categoryId = contact_categoryIdFetch[0][0] ? contact_categoryIdFetch[0][0]["id"] : 0
        // contact status
        const statusIdFetch = await db2.sequelize.query(`select id from lz_masters where option_value ='${row[15]}' limit 1`);
        const statusId = statusIdFetch[0][0] ? statusIdFetch[0][0]["id"] : 2
        // Gender
        const genderIdFetch = await db2.sequelize.query(`select id from lz_masters where option_value ='${row[33]}' limit 1`);
        const genderId = genderIdFetch[0][0] ? genderIdFetch[0][0]["id"] : 0
        // marital_status
        const marital_statusIdFetch = await db2.sequelize.query(`select id from lz_masters where option_value ='${row[35]}' limit 1`);
        const marital_statusId = marital_statusIdFetch[0][0] ? marital_statusIdFetch[0][0]["id"] : 0
        // pet_owner
        const pet_ownerIdFetch = await db2.sequelize.query(`select id from lz_masters where option_value ='${row[38]}' limit 1`);
        const pet_ownerId = pet_ownerIdFetch[0][0] ? pet_ownerIdFetch[0][0]["id"] : 0
        // nationality
        const nationalityIdFetch = await db2.sequelize.query(`select id from lz_masters where option_value ='${row[39]}' limit 1`);
        const nationalityId = nationalityIdFetch[0][0] ? nationalityIdFetch[0][0]["id"] : 0
        // Do_not_disturb
        const do_not_disturbIdFetch = await db2.sequelize.query(`select id from lz_masters where option_value ='${row[43]}' limit 1`);
        const do_not_disturbId = do_not_disturbIdFetch[0][0] ? do_not_disturbIdFetch[0][0]["id"] : 0
        // country
        const countryIdFetch = await db.sequelize.query(`select id from lz_country where name ='${row[23]}' limit 1`);
        const countryId = countryIdFetch[0][0] ? countryIdFetch[0][0]["id"] : 0
        // city
        const cityIdFetch = await db.sequelize.query(`select id from lz_city where name ='${row[24]}' limit 1`);
        const cityId = cityIdFetch[0][0] ? cityIdFetch[0][0]["id"] : 0
        // state
        const stateIdFetch = await db.sequelize.query(`select id from lz_state where name ='${row[25]}' limit 1`);
        const stateId = stateIdFetch[0][0] ? stateIdFetch[0][0]["id"] : 0
        // Multiple Select
        // Assign To
        let userValue = `${row[9]}`;
        let userValue1 = userValue.split(',').map(item => `'${item}'`).join(',');

        const assignIdFetch = await db2.sequelize.query("select id from lz_user where first_name IN (" + userValue1 + ") group by id " );
        const assignId = assignIdFetch[0][0] ? assignIdFetch[0].map(params => params.id).join(',') : 0
        console.log("assignIdFetch", assignIdFetch[0]);
        console.log("assignId", assignId);
        
        const data = await db2['contacts'].create({
          salutation: row[0] ?? null,
          first_name: row[1] ?? null,
          last_name: row[2] ?? null,
          company_name: row[3] ?? null,
          developer_name: row[4] ?? null,
          email: row[5] ?? null,
          phone_number_type: row[6] ?? null,
          code: row[7] ?? null,
          mobile: row[8] ?? null,
          assign_to: assignId ?? null,
          property_id: property_Id ?? null,
          contact_group: contact_groupId ?? null,
          source: sourceId ?? null,
          contact_type: contactTypeId ?? null,
          contact_category: contact_categoryId ?? null,
          contact_status: statusId ?? null,
          remarks: row[16] ?? null,
          is_secondary_contact: row[17] ?? null,
          secondary_contact_id:row[18] ?? null,
          refid: row[19] ?? null,
          created_by: created_by,
        })

        let contactId = data?.dataValues.id
        console.log('contactID', contactId);

        const data3 = await db2['contactAddress'].create({
          contact_id: contactId,
          address_1: row[20],
          address_2: row[21],
          locality: row[22],
          country: countryId,
          city: cityId,
          state: stateId,
          zip_code: row[26],
          facebook: row[27],
          instagram: row[28],
          linkedin: row[29],
          twitter: row[30]
        })

        const data2 = await db2['contactDetails'].create({
          contact_id: contactId,
          gst_number: row[31],
          invoice_name: row[32],
          gender: genderId ,
          dob: row[34],
          marital_status: marital_statusId,
          wedding_anniversary: row[36],
          number_of_children: row[37],
          pet_owner: pet_ownerId,
          nationality: nationalityId,
          language: row[40],
          designation: row[41],
          national_id: row[42],
          do_not_disturb:do_not_disturbId,
        })
        // const data4 = await db2['logs'].create({
        //   org_id: org_id,
        //   user_id: created_by,
        //   module_id: contactId,
        //   module_name: "1",
        //   note: " contact created at"
        // })
        return rowing.push(data);
    });

   console.log("rowing", rowing);

    // res.send("Contact Saved Succesfully");
      res.status(200).send({
        status: 200,
        message: 'Bulk Contacts Successfully',
      });
  });
});

// MAIN GET CONTACTS
// exports.getContacts = async (req, res) => {
//   try {
//     const created_id = req.user.id
//     const created_by = created_id.id
//     console.log('created_by', created_by);
  
//     const organ_id = req.user.id
//     const org_id = organ_id.org_id
//     console.log('organ_id', org_id);
  
//     const role = req.user.id
//     const role_id = role.designation
//     console.log('role_id', role_id);

//   let thisQuery = `select c.*, CONVERT(c.assign_to USING utf8) as assign_to, GROUP_CONCAT(distinct CONCAT(us.first_name,' ', IFNULL(us.last_name, ''),'-',us.id)) as assign_to_name, s.option_value as source_name, ct.option_value as contact_type_name, cs.option_value as contact_status_name, cg.option_value as contact_group_name, cc.option_value as contact_category_name, ca.address_1,ca.address_2,ca.locality,ca.country,ca.city,ca.state,ca.zip_code,cd.national_id,cd.gst_number,cd.gender,cd.dob,cd.marital_status,cd.wedding_anniversary,cd.number_of_children,cd.pet_owner,cd.nationality,cd.language,cd.designation,cd.do_not_disturb,cd.invoice_name,ca.facebook,ca.instagram,ca.linkedin,ca.twitter, CONCAT(us3.first_name,' ',us3.last_name) as created_by_name, DATE_FORMAT(c.created_at,'%Y-%m-%d') as created_date, pas.name_of_building as property_name,

//   (SELECT COUNT(id) FROM lz_notes where module_id = c.id and module_name = 1 and status = 1) as notes_count,
//   (SELECT COUNT(id) FROM lz_file_uploads where module_id = c.id and module_name = 1 ) as files_count,
//   (SELECT ifnull(COUNT(*),0) FROM lz_leads as l LEFT JOIN lz_contacts on (lz_contacts.id = l.contact_id) where l.status = 1 and contact_id = c.id) as lead_count,
//   (SELECT ifnull(COUNT(*),0) FROM lz_tasks as t LEFT JOIN lz_contacts on (lz_contacts.id = t.contact) where t.status = 1 and t.contact = c.id) as task_count,
//   (SELECT COUNT(secondary_contact_id) FROM lz_contacts where c.status = 1 and c.secondary_contact_id = id) as sec_count,
//   (SELECT COUNT(mobile) FROM lz_contacts where c.mobile = mobile and c.property_id = property_id and status = 1 and c.id != id) as duplicate_count,
//   (SELECT reply FROM lz_notes where module_name = 1 and module_id = c.id order by id desc limit 1 ) as last_note,
//   (SELECT DATE_FORMAT(ta.task_time,'%Y-%m-%d') FROM lz_tasks as ta where ta.contact = c.id and ta.task_time <= curdate() order by ta.task_time DESC limit 1) as last_task_date,
//   (SELECT DATE_FORMAT(ta.task_time,'%Y-%m-%d') FROM lz_tasks as ta where ta.contact = c.id and ta.task_time >= curdate() order by ta.task_time limit 1) as next_task_date

//   from lz_contacts as c   
//   left join lz_contact_address as ca on (ca.contact_id = c.id) 
//   left join lz_contact_details as cd on (cd.contact_id = c.id)
//   left join lz_property_addresses as pas on (pas.property_id = c.property_id) 
//   LEFT JOIN lz_user as us on FIND_IN_SET(us.id,c.assign_to) > 0 
//   LEFT JOIN lz_user as us3 on FIND_IN_SET(us3.id,c.created_by) > 0 
//   left join lz_masters as s on (s.id = c.source) 

//   LEFT JOIN lz_user as us5 on FIND_IN_SET(us5.id,c.assign_to) > 0 
//   left join lz_user as us4 on (us5.team_leader = us4.id) 
  
//   LEFT JOIN lz_user as us6 on FIND_IN_SET(us6.id,c.assign_to) > 0 
//   left join lz_user as us7 on (us6.portfolio_head = us7.id) 

//   left join lz_masters as ct on (ct.id = c.contact_type) 
//   left join lz_masters as cs on (cs.id = c.contact_status) 
//   left join lz_masters as cg on (cg.id = c.contact_group) 
//   left join lz_masters as cc on (cc.id = c.contact_category)

//   where ${role_id == 1 ? `c.status IN (1,2) ` : `c.status = 1`} `;

//   if (role_id == 1) {
//     thisQuery += ` `
//   }
//   if (role_id == 2) {
//     thisQuery += ` and (FIND_IN_SET(${created_by},c.assign_to)>0 or us.team_leader = ${created_by} or us.portfolio_head = ${created_by}) `
//     // thisQuery += ` and c.created_by = ${created_by} `
//   }
//   if (role_id == 3) {
//     thisQuery += ` and (FIND_IN_SET(${created_by},c.assign_to)>0 or us.team_leader = ${created_by} or us.portfolio_head = ${created_by}) `
//     // thisQuery += ` and c.created_by = ${created_by} `
//   }
//   if (role_id == 4) {
//     thisQuery += ` and (FIND_IN_SET(${created_by},c.assign_to)>0) `
//   }
//   if (role_id == 5) {
//     thisQuery += ` `
//   }
//   if (role_id == 6) {
//     thisQuery += `and c.created_by = ${created_by} `
//   }

//   const filters = req.query;
//   // for (key in filters) {
//     if (filters.contact_type) {
//       thisQuery += " and c.contact_type = " + `${filters.contact_type}`
//     }
//     if (filters.contact_category) {
//       thisQuery += " and c.contact_category = " + `${filters.contact_category} `
//     }
//     if (filters.property) {
//       thisQuery += " and c.property_id = " + `${filters.property} `
//     }
//     if (filters.company_name) {
//       thisQuery += "and c.company_name = " + `'${filters.company_name}'`
//     }
//     if (filters.contact_status) {
//       thisQuery += "and c.contact_status = " + `${filters.contact_status} `
//     }
//     if (filters.assign_to) {
//       var a = filters.assign_to;
//       let a1 = a.split(',').map(item => `'${item}'`).join(',');
//       // thisQuery += `and CONCAT(',', c.assign_to, ',') REGEXP ',(${a1}),' `
//       thisQuery += " and (c.assign_to IN (" + a1 + ")" + ` OR CONCAT(',', c.assign_to, ',') REGEXP ',(${a}),' )`
//     }
//     if (filters.source) {
//       thisQuery += "and c.source = " + `${filters.source} `
//     }
//     if (filters.locality) {
//       thisQuery += "and ca.locality = " + `${filters.locality} `
//     }
//     if (filters.contact_group) {
//       thisQuery += "and c.contact_group = " + `${filters.contact_group} `
//     }
//     if (filters.created_by) {
//       thisQuery += "and c.created_by = " + `${filters.created_by} `
//     }
//     if (filters.created_date !="" && filters.created_end_date) {
//       // thisQuery += "and c.created_at = " + `'${filters.created_at}' `
//       thisQuery += ` and (DATE_FORMAT(c.created_at,'%Y-%m-%d') >= '${filters.created_date}' AND DATE_FORMAT(c.created_at,'%Y-%m-%d') <= '${filters.created_end_date}') `
//     }
//     if (filters.created_date !="" && filters.created_end_date=='') {
//       // thisQuery += "and c.created_at = " + `'${filters.created_at}' `
//       thisQuery += ` and (DATE_FORMAT(c.created_at,'%Y-%m-%d') >= '${filters.created_date}') `
//     }
//     if (filters.created_date =="" && filters.created_end_date !='') {
//       // thisQuery += "and c.created_at = " + `'${filters.created_at}' `
//       thisQuery += ` and (DATE_FORMAT(c.created_at,'%Y-%m-%d') <= '${filters.created_end_date}') `
//     }
//     if (filters.dob) {
//       thisQuery += " and cd.dob = " + `'${filters.dob}'`
//     }
//     if (filters.gender) {
//       thisQuery += " and cd.gender = " + `${filters.gender} `
//     }
//     if (filters.city) {
//       thisQuery += " and ca.city = " + `${filters.city} `
//     }
//     if (filters.country) {
//       thisQuery += " and ca.country = " + `${filters.country} `
//     }
//     if (filters.nationality) {
//       thisQuery += " and cd.nationality = " + `${filters.nationality} `
//     }
//     if (filters.state) {
//       thisQuery += " and ca.state = " + `${filters.state} `
//     }
//     if (filters.zip_code) {
//       thisQuery += " and ca.zip_code = " + `${filters.zip_code} `
//     }
//   // }
//   thisQuery += ' group by c.id '

//   if (filters.order_by) {
//     let orderByString = filters.order_by.split('|')
//     thisQuery += " order by " + `${orderByString[0]} ${orderByString[1]} `
//   }
//   const data1 = await db2.sequelize.query(thisQuery);

//   if (filters.order_by =="" || filters.order_by == undefined) {
//     thisQuery += '  order by c.id DESC '
//   }

//   // thisQuery += ' order by c.updated_at DESC '

//   if (filters.limit) {
//     thisQuery += ` limit ${filters.limit},12 `
//   }

//   const data = await db2.sequelize.query(thisQuery);

//   const count_filter = (data1[0])

//     res.status(200).send({
//       status:200,
//       message:'Success',
//       count: count_filter.length,
//       output: data[0],
//     });
//   } catch (error) {
//     res.status(500).send({
//       message: error.message,
//     });
//   }
// };

// ++++++++++++++++++++++++++++++++++++++++===============================>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>


// Speed Loop Api
// exports.getContacts = async (req, res) => {
//   try {
//     const created_id = req.user.id
//     const created_by = created_id.id
//     console.log('created_by', created_by);
  
//     const organ_id = req.user.id
//     const org_id = organ_id.org_id
//     console.log('organ_id', org_id);
  
//     const role = req.user.id
//     const role_id = role.designation
//     console.log('role_id', role_id);

//   let thisQuery = `select c.*, CONVERT(c.assign_to USING utf8) as assign_to, GROUP_CONCAT(distinct CONCAT(us.first_name,' ', IFNULL(us.last_name, ''),'-',us.id)) as assign_to_name, s.option_value as source_name, ct.option_value as contact_type_name, cs.option_value as contact_status_name, cg.option_value as contact_group_name, cc.option_value as contact_category_name, ca.address_1,ca.address_2,ca.locality,ca.country,ca.city,ca.state,ca.zip_code,cd.national_id,cd.gst_number,cd.gender,cd.dob,cd.marital_status,cd.wedding_anniversary,cd.number_of_children,cd.pet_owner,cd.nationality,cd.language,cd.designation,cd.do_not_disturb,cd.invoice_name,ca.facebook,ca.instagram,ca.linkedin,ca.twitter, CONCAT(us3.first_name,' ',us3.last_name) as created_by_name, DATE_FORMAT(c.created_at,'%Y-%m-%d') as created_date, pas.name_of_building as property_name

//   from lz_contacts as c  
//   left join lz_contact_address as ca on (ca.contact_id = c.id) 
//   left join lz_contact_details as cd on (cd.contact_id = c.id)
//   left join lz_property_addresses as pas on (pas.property_id = c.property_id) 
//   LEFT JOIN lz_user as us on FIND_IN_SET(us.id,c.assign_to) > 0 
//   LEFT JOIN lz_user as us3 on FIND_IN_SET(us3.id,c.created_by) > 0 
//   left join lz_masters as s on (s.id = c.source) 

//   LEFT JOIN lz_user as us5 on FIND_IN_SET(us5.id,c.assign_to) > 0 
//   left join lz_user as us4 on (us5.team_leader = us4.id) 
  
//   LEFT JOIN lz_user as us6 on FIND_IN_SET(us6.id,c.assign_to) > 0 
//   left join lz_user as us7 on (us6.portfolio_head = us7.id) 

//   left join lz_masters as ct on (ct.id = c.contact_type) 
//   left join lz_masters as cs on (cs.id = c.contact_status) 
//   left join lz_masters as cg on (cg.id = c.contact_group) 
//   left join lz_masters as cc on (cc.id = c.contact_category)

//   where ${role_id == 1 ? `c.status IN (1,2) ` : `c.status = 1`} `;

//   if (role_id == 1) {
//     thisQuery += ` `
//   }
//   if (role_id == 2) {
//     thisQuery += ` and (FIND_IN_SET(${created_by},c.assign_to)>0 or us.team_leader = ${created_by} or us.portfolio_head = ${created_by}) `
//     // thisQuery += ` and c.created_by = ${created_by} `
//   }
//   if (role_id == 3) {
//     thisQuery += ` and (FIND_IN_SET(${created_by},c.assign_to)>0 or us.team_leader = ${created_by} or us.portfolio_head = ${created_by}) `
//     // thisQuery += ` and c.created_by = ${created_by} `
//   }
//   if (role_id == 4) {
//     thisQuery += ` and (FIND_IN_SET(${created_by},c.assign_to)>0) `
//   }
//   if (role_id == 5) {
//     thisQuery += ` `
//   }
//   if (role_id == 6) {
//     thisQuery += `and c.created_by = ${created_by} `
//   }

//   const filters = req.query;
//   // for (key in filters) {
//     if (filters.contact_type) {
//       thisQuery += " and c.contact_type = " + `${filters.contact_type}`
//     }
//     if (filters.contact_category) {
//       thisQuery += " and c.contact_category = " + `${filters.contact_category} `
//     }
//     if (filters.property) {
//       thisQuery += " and c.property_id = " + `${filters.property} `
//     }
//     if (filters.company_name) {
//       thisQuery += "and c.company_name = " + `'${filters.company_name}'`
//     }
//     if (filters.contact_status) {
//       thisQuery += "and c.contact_status = " + `${filters.contact_status} `
//     }
//     if (filters.assign_to) {
//       var a = filters.assign_to;
//       let a1 = a.split(',').map(item => `'${item}'`).join(',');
//       // thisQuery += `and CONCAT(',', c.assign_to, ',') REGEXP ',(${a1}),' `
//       thisQuery += " and (c.assign_to IN (" + a1 + ")" + ` OR CONCAT(',', c.assign_to, ',') REGEXP ',(${a}),' )`
//     }
//     if (filters.source) {
//       thisQuery += "and c.source = " + `${filters.source} `
//     }
//     if (filters.locality) {
//       thisQuery += "and ca.locality = " + `${filters.locality} `
//     }
//     if (filters.contact_group) {
//       thisQuery += "and c.contact_group = " + `${filters.contact_group} `
//     }
//     if (filters.created_by) {
//       thisQuery += "and c.created_by = " + `${filters.created_by} `
//     }
//     if (filters.created_date !="" && filters.created_end_date) {
//       // thisQuery += "and c.created_at = " + `'${filters.created_at}' `
//       thisQuery += ` and (DATE_FORMAT(c.created_at,'%Y-%m-%d') >= '${filters.created_date}' AND DATE_FORMAT(c.created_at,'%Y-%m-%d') <= '${filters.created_end_date}') `
//     }
//     if (filters.created_date !="" && filters.created_end_date=='') {
//       // thisQuery += "and c.created_at = " + `'${filters.created_at}' `
//       thisQuery += ` and (DATE_FORMAT(c.created_at,'%Y-%m-%d') >= '${filters.created_date}') `
//     }
//     if (filters.created_date =="" && filters.created_end_date !='') {
//       // thisQuery += "and c.created_at = " + `'${filters.created_at}' `
//       thisQuery += ` and (DATE_FORMAT(c.created_at,'%Y-%m-%d') <= '${filters.created_end_date}') `
//     }
//     if (filters.dob) {
//       thisQuery += " and cd.dob = " + `'${filters.dob}'`
//     }
//     if (filters.gender) {
//       thisQuery += " and cd.gender = " + `${filters.gender} `
//     }
//     if (filters.city) {
//       thisQuery += " and ca.city = " + `${filters.city} `
//     }
//     if (filters.country) {
//       thisQuery += " and ca.country = " + `${filters.country} `
//     }
//     if (filters.nationality) {
//       thisQuery += " and cd.nationality = " + `${filters.nationality} `
//     }
//     if (filters.state) {
//       thisQuery += " and ca.state = " + `${filters.state} `
//     }
//     if (filters.zip_code) {
//       thisQuery += " and ca.zip_code = " + `${filters.zip_code} `
//     }
//   // }
//   thisQuery += ' group by c.id '

//   if (filters.order_by) {
//     let orderByString = filters.order_by.split('|')
//     thisQuery += " order by " + `${orderByString[0]} ${orderByString[1]} `
//   }
//   const data1 = await db2.sequelize.query(thisQuery);

//   if (filters.order_by =="" || filters.order_by == undefined) {
//     thisQuery += '  order by c.id DESC '
//   }

//   // thisQuery += ' order by c.updated_at DESC '

//   if (filters.limit) {
//     thisQuery += ` limit ${filters.limit},12 `
//   }

//   const data = await db2.sequelize.query(thisQuery);

//   let array = [];

//   for(let a in data[0]) {

//     let thisQueryNotes = ` 
//     SELECT COUNT(id) as notes_count 
//     FROM lz_notes 
//     where module_id = ${data[0][a]?.id} and module_name = 1 `
//     const cNotesData = await db2.sequelize.query(thisQueryNotes);

//     let thisQueryFiles = ` 
//     SELECT COUNT(id)  as files_count 
//     FROM lz_file_uploads 
//     where module_id = ${data[0][a]?.id} and module_name = 1 `
//     const CfilesData = await db2.sequelize.query(thisQueryFiles);

//     let thisQueryLead = ` 
//     SELECT ifnull(COUNT(*),0) as lead_count 
//     FROM lz_leads as l 
//     LEFT JOIN lz_contacts on (lz_contacts.id = l.contact_id) 
//     where ${role_id == 1 ? `l.status IN (1,2) ` : `l.status = 1`} and l.contact_id = ${data[0][a]?.id} `
//     const CleadData = await db2.sequelize.query(thisQueryLead);

//     let thisQueryTask = ` 
//     SELECT ifnull(COUNT(*),0) as task_count FROM lz_tasks as t 
//     LEFT JOIN lz_contacts on (lz_contacts.id = t.contact) 
//     where ${role_id == 1 ? `t.status IN (1,2) ` : `t.status = 1`} and t.contact = ${data[0][a]?.id} `
//     const CTaskData = await db2.sequelize.query(thisQueryTask);

//     let thisQueryMob = ` 
//     SELECT COUNT(mobile) as duplicate_count FROM lz_contacts where ${data[0][a]?.mobile} = mobile and ${data[0][a]?.property_id} = property_id and status = 1 and ${data[0][a]?.id} != id `
//     const CMobData = await db2.sequelize.query(thisQueryMob);

//     let thisQueryNote = ` 
//     SELECT reply as last_note FROM lz_notes where module_name = 1 and module_id = ${data[0][a]?.id} order by id desc limit 1  `
//     const CNotesData = await db2.sequelize.query(thisQueryNote);

//     let thisQueryLast = ` 
//     SELECT DATE_FORMAT(ta.task_time,'%Y-%m-%d') last_task_date FROM lz_tasks as ta where ${role_id == 1 ? `ta.status IN (1,2) ` : `ta.status = 1`} and ta.contact = ${data[0][a]?.id} and ta.task_time <= curdate() order by ta.task_time DESC limit 1 `
//     const CLastData = await db2.sequelize.query(thisQueryLast);

//     let thisQueryNext = ` 
//     SELECT DATE_FORMAT(ta.task_time,'%Y-%m-%d') FROM lz_tasks as ta where ${role_id == 1 ? `ta.status IN (1,2) ` : `ta.status = 1`} and ta.contact = ${data[0][a]?.id} and ta.task_time >= curdate() order by ta.task_time limit 1 `
//     const CNextData = await db2.sequelize.query(thisQueryNext);

//     // let thisQuery123 = ` select ${data[0][a]?.id} as id,
//     // (SELECT COUNT(id) FROM lz_notes where module_id = ${data[0][a]?.id} and module_name = 1 and status = 1) as notes_count,
//     // (SELECT COUNT(id) FROM lz_file_uploads where module_id = ${data[0][a]?.id} and module_name = 1 ) as files_count,
//     // (SELECT ifnull(COUNT(*),0) FROM lz_leads as l LEFT JOIN lz_contacts on (lz_contacts.id = l.contact_id) where l.status = 1 and contact_id = ${data[0][a]?.id}) as lead_count,
//     // (SELECT ifnull(COUNT(*),0) FROM lz_tasks as t LEFT JOIN lz_contacts on (lz_contacts.id = t.contact) where t.status = 1 and t.contact = ${data[0][a]?.id}) as task_count,
//     // (SELECT COUNT(secondary_contact_id) FROM lz_contacts where c.status = 1 and c.secondary_contact_id = id) as sec_count,
//     // (SELECT COUNT(mobile) FROM lz_contacts where c.mobile = mobile and c.property_id = property_id and status = 1 and ${data[0][a]?.id} != id) as duplicate_count,
//     // (SELECT reply FROM lz_notes where module_name = 1 and module_id = ${data[0][a]?.id} order by id desc limit 1 ) as last_note,
//     // (SELECT DATE_FORMAT(ta.task_time,'%Y-%m-%d') FROM lz_tasks as ta where ta.contact = ${data[0][a]?.id} and ta.task_time <= curdate() order by ta.task_time DESC limit 1) as last_task_date,
//     // (SELECT DATE_FORMAT(ta.task_time,'%Y-%m-%d') FROM lz_tasks as ta where ta.contact = ${data[0][a]?.id} and ta.task_time >= curdate() order by ta.task_time limit 1) as next_task_date
//     // from lz_contacts as c 
//     // where ${role_id == 1 ? `c.status IN (1,2) ` : `c.status = 1`}
//     // `

//     let obj = {...data[0][a], ...cNotesData[0][0], ...CfilesData[0][0], ...CleadData[0][0], ...CTaskData[0][0], ...CMobData[0][0], ...CNotesData[0][0], ...CLastData[0][0], ...CNextData[0][0]  }
//     array.push(obj);
//   }

//   // console.log("arrayyyyyyy", array);

//   const count_filter = (data1[0])

//     res.status(200).send({
//       status:200,
//       message:'Success',
//       count: count_filter.length,
//       // output: data[0],
//       output:array
//     });
//   } catch (error) {
//     res.status(500).send({
//       message: error.message,
//     });
//   }
// };


// >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>






// const goop = async (data) => {
//   console.log("lkgkldggkldgklgklngl", data);

//   // let contactId = data?.dataValues.id
//   // console.log('contactID', contactId);
//   data.forEach(async(rows) => {

    
//   const data3 = await db2['contactAddress'].create({
//     contact_id: rows?.dataValues.id,
//     // address_1: row[20],
//     // address_2: row[21],
//     // locality: row[22],
//     // country: row[23],
//     // city: row[24],
//     // state: row[25],
//     // zip_code: row[26],
//     // facebook: row[27],
//     // instagram: row[28],
//     // linkedin: row[29],
//     // twitter: row[30]
//   })

//   const data2 = await db2['contactDetails'].create({
//     contact_id: rows?.dataValues.id,
//     // gst_number: row[31],
//     // invoice_name: row[32],
//     // gender: row[33],
//     // dob: row[34],
//     // marital_status: row[35],
//     // wedding_anniversary: row[36],
//     // number_of_children: row[37],
//     // pet_owner: row[38],
//     // nationality: row[39],
//     // language: row[40],
//     // designation: row[41],
//     // national_id: row[42],
//     // do_not_disturb: row[43],
//   })

//   })

// }

// exports.saveContactAutoAssign = async (req, res) => {
//   try {
//     const created_id = req.user.id
//     const created_by = created_id.id
//     console.log('created_by', created_by);
  
//     const organ_id = req.user.id
//     const org_id = organ_id.org_id
//     console.log('organ_id', org_id);
  
//     const role = req.user.id
//     const role_id = role.designation
//     console.log('role_id', role_id);

//     const id = req.params.id;

//     const propertyIdFetch = await db2.sequelize.query(`select property_id from lz_property_addresses where property_id='${req.body.property_id}' limit 1`);
//     const propertyId = propertyIdFetch[0][0] ? propertyIdFetch[0][0].property_id : 0
//     console.log("propertyyyy", propertyId);

//     const DuplicateFetch = await db2.sequelize.query(`select id from lz_contacts where mobile ='${req.body.mobile}' or property_id ='${propertyId}' and date(created_at) = curdate() limit 1`);
//     const duplicateId = DuplicateFetch[0][0] ? DuplicateFetch[0][0]['id'] : 0
//     console.log("duplicateId", duplicateId);

//     // if (!duplicateId) {
//     //     res.status(200).send({
//     //         status:400,
//     //         message: "your contact has been already exists.",
//     //     }); 
//     // } else {

//       const CSCheck123 = await db2.sequelize.query(`select csm.sorting_order as sorting_order, csm.user_id as user_id, csm.contact_setting_id, cs.project_id as project_id, cs.source_id as source_id 
//       from lz_contact_setting_members as csm 
//       left join lz_contact_settings as cs on (cs.id = csm.contact_setting_id) 
//       where (cs.project_id = ${propertyId} or cs.source_id = ${req.body.source})
//       group by csm.id
//        `);

//       const checkOut = CSCheck123[0].length
//       console.log("checkOut", checkOut);


//       const autoAssignFetch = await db2.sequelize.query(`select last_assign_to,position from lz_auto_assign where project_id ='${propertyId}' and source_id ='${req.body.source}' order by id desc limit 1`);
//       // const assignToId = autoAssignFetch[0][0] ? autoAssignFetch[0][0]["last_assign_to"] : 0
//       let positionId = ((autoAssignFetch[0][0]?.position ?? 0) +1) <= checkOut ? (autoAssignFetch[0][0]?.position ?? 0) +1 : autoAssignFetch[0][0]?.position - checkOut+1

//       // console.log("assignToId", assignToId);
//       console.log("positionId", positionId);

// if (autoAssignFetch) {

//       const CSCheck = await db2.sequelize.query(`select csm.sorting_order as sorting_order, csm.user_id as user_id, csm.contact_setting_id, cs.project_id as project_id, cs.source_id as source_id 
//       from lz_contact_setting_members as csm 
//       left join lz_contact_settings as cs on (cs.id = csm.contact_setting_id) 
//       where (cs.project_id = ${propertyId} or cs.source_id = ${req.body.source}) ${!positionId ? ``:`and csm.sorting_order = ${positionId}`} 
//       limit 1
//        `);

//       const conSetCheck = CSCheck[0][0] ? CSCheck[0][0]["user_id"] : 0
//       console.log("CSCheckkkkk", CSCheck[0]);
        
//       var assign_to = CSCheck[0][0] ? CSCheck[0][0]["user_id"] : 0
//       var position_id = CSCheck[0][0] ? CSCheck[0][0]["sorting_order"] : 0

//       console.log("aaaaaaaaa", assign_to);
//       console.log("ppppppppp", position_id);
// }
//         const data = await db2['contacts'].create({
//           first_name: req.body.first_name || 'Customer',
//           last_name: req.body.last_name || null,
//           email: req.body.email || null,
//           mobile: req.body.mobile || null,
//           property_id: propertyId || null,
//           source: req.body.source,
//           contact_status: req.body.contact_status,
//           contact_type: 8,
//           assign_to: assign_to,
//           created_by: created_by
//         });

//       let contactSettingId = data?.dataValues.id
//       let sourceData = data?.dataValues.source

//       if (propertyId > 0) {
//         const updateAutoAssignTable = await db2.sequelize.query(`INSERT INTO lz_auto_assign (project_id, source_id, last_assign_to, position) VALUES (${propertyId},${sourceData},${assign_to},${position_id})`)
//       }

//     res.status(200).send({
//       status:200,
//       message:'Success',
//       output:data
//     });

//   } catch (error) {
//     res.status(500).send({
//       message: error.message,
//     });
//   }
// };


// exports.saveContactAutoAssign = async (req, res) => {
//   try {
//     const created_id = req.user.id
//     const created_by = created_id.id
//     console.log('created_by', created_by);
  
//     const organ_id = req.user.id
//     const org_id = organ_id.org_id
//     console.log('organ_id', org_id);
  
//     const role = req.user.id
//     const role_id = role.designation
//     console.log('role_id', role_id);

//     const id = req.params.id;

//     const propertyIdFetch = await db2.sequelize.query(`select property_id from lz_property_addresses where name_of_building='${req.body.property_name}' limit 1`);
//     const propertyId = propertyIdFetch[0][0] ? propertyIdFetch[0][0].property_id : 0
//     console.log("propertyyyy", propertyId);

//     const DuplicateFetch = await db2.sequelize.query(`select id from lz_contacts where mobile ='${req.body.mobile}' and property_id ='${propertyId}' and date(created_at) = curdate() limit 1`);
//     const duplicateId = DuplicateFetch[0][0] ? DuplicateFetch[0][0]['id'] : 0
//     console.log("duplicateId", duplicateId);

//     if (duplicateId != 0) {
//         res.status(200).send({
//             status:400,
//             message: "your contact has been already exists.",
//         }); 
//     } else {

//       const aaPropertyIdFetch = await db2.sequelize.query(`select last_assign_to,position from lz_auto_assign where project_id ='${propertyId}' order by id desc limit 1`);

//       const assignToId = aaPropertyIdFetch[0][0] ? aaPropertyIdFetch[0][0]['last_assign_to'] : 0
//       let positionId = aaPropertyIdFetch[0][0] ? aaPropertyIdFetch[0][0]['position'] : 0

//       console.log("assignToId", assignToId);
//       console.log("positionId", positionId);

//       if (aaPropertyIdFetch) {
//         var aaPropertyIdFetchPosition = await db2.sequelize.query(`select csm.sorting_order,csm.user_id,csm.contact_setting_id from lz_contact_setting_members as csm left join lz_contact_settings as cs on (cs.id = csm.contact_setting_id) where cs.project_id = ${propertyId} limit 1`);
  
//         if (aaPropertyIdFetchPosition.length == 0) {
//           positionId = 0
//           aaPropertyIdFetchPosition = await db2.sequelize.query(`select csm.sorting_order,csm.user_id,csm.contact_setting_id from lz_contact_setting_members as csm  left join lz_contact_settings as cs on (cs.id = csm.contact_setting_id) where cs.project_id = ${propertyId} limit 1`);
//         }
  
//         var assign_to = aaPropertyIdFetchPosition[0][0] ? aaPropertyIdFetchPosition[0][0]['user_id'] : 0
//         var position_id = aaPropertyIdFetchPosition[0][0] ? aaPropertyIdFetchPosition[0][0]['sorting_order'] : 0

//         console.log("var assign_to", assign_to);
//         console.log("var position_id", position_id);
//       }
        
//         const data = await db2['contacts'].create({
//           first_name: req.body.first_name || 'Customer',
//           last_name: req.body.last_name || null,
//           email: req.body.email || null,
//           mobile: req.body.mobile || null,
//           property_id: propertyId || null,
//           source: 76,
//           contact_type: 8,
//           assign_to: assign_to,
//           created_by: created_by
//         });

//       let contactSettingId = data?.dataValues.id

//       if (propertyId > 0) {
//         const updateAutoAssignTable = await db2.sequelize.query(`INSERT INTO lz_auto_assign (project_id, last_assign_to, position) VALUES (${propertyId},${assign_to},${position_id})`)
//       }

//     res.status(200).send({
//       status:200,
//       message:'Success',
//       output:data
//     });

//   }} catch (error) {
//     res.status(500).send({
//       message: error.message,
//     });
//   }
// };