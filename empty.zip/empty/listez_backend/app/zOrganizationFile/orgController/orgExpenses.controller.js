const db2 = require("../orgModel/orgIndex.js");
const db = require("../../models");
const Op = db2.Sequelize.Op;
const path = require("path");
const fs = require("fs");

exports.saveExpenses = async (req, res) => {
  try {
    const created_by = req.user.id
    console.log('created_by', created_by.id);

    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    let receipt_name = "";
    let receipt_original_name = "";
  
    if (req.files.receipt_name) {
      const extension = req.files.receipt_name[0]["mimetype"].split('/')[1]
      receipt_name = req.files.receipt_name[0]["filename"] + '.' + extension
      receipt_original_name = req.files.receipt_name[0]["originalname"]
    }
    
    const data = await db2['expenses'].create({
      transaction_id: req.body.transaction_id || null,
      expense_type: req.body.expense_type || null,
      expense_date: req.body.expense_date || null,
      add_amount: req.body.add_amount || null,
      billable: req.body.billable || null,
      receipt_name: receipt_name || null,
      receipt_original_name: receipt_original_name || null,
      created_by: created_by.id
    });

    let expenseId = data?.dataValues.id

    const data1 = await db2['expenseDetails'].create({
        expense_id: expenseId,
        client: req.body.client || null,
        amount: req.body.amount || null,
        city_id: req.body.city_id || null,
        tl_id: req.body.tl_id || null,
        builder_id: req.body.builder_id || null,
        project_id: req.body.project_id || null,
        month: req.body.month || null,
        date: req.body.date || null,
        campaign_name: req.body.campaign_name || null,
        campaign_source_id: req.body.campaign_source_id || null,
        cost_of_campaign: req.body.cost_of_campaign || null,
        total_value: req.body.total_value || null,
        gst_value: req.body.gst_value || null,
      });

    if (req.files.receipt_name) {
        //move receipt_name
        const currentPath = path.join(process.cwd(), "uploads", req.files.receipt_name[0]["filename"]);
        const destinationPath = path.join(process.cwd(), "/uploads/expenses/receipt_name/" + `${expenseId}`, receipt_name);
        const baseUrl = process.cwd() + '/uploads/expenses/receipt_name/' + `${expenseId}`
        fs.mkdirSync(baseUrl, { recursive: true })
        fs.rename(currentPath, destinationPath, function (err) {
          if (err) {
            throw err
          } else {
            console.log("Successfully moved the receipt images !")
          }
        });
      }

    res.status(200).send({
      status:200,
      message:'Success',
      output:data
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.getExpenses = async (req, res) => {
    try {
    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    let thisQuery = ` SELECT exp.* , ed.expense_id as expense_id, ed.client as client, CONCAT(c.first_name,' ', IFNULL(c.last_name, '')) as client_name, ed.amount as amount, ed.city_id as city_id, ed.tl_id as TL_id, ed.builder_id as builder_id, ed.project_id as project_id, ed.month as month, ed.date as date, ed.campaign_name as campaign_name, ed.campaign_source_id as campaign_source_id, ed.cost_of_campaign as cost_of_campaign, ed.total_value as total_value, ed.gst_value as gst_value, et.option_value as expense_type_name, so.name as campaign_source_name, pa.name_of_building as property_name, us.first_name as teamleader_name, us1.first_name as created_name FROM lz_expenses as exp 
    LEFT JOIN lz_masters as et on (exp.expense_type = et.id) 
    LEFT JOIN lz_expense_details as ed on (ed.expense_id = exp.id)
    LEFT JOIN lz_contacts as c on (c.id = ed.client)
    LEFT JOIN lz_property_addresses as pa on (pa.id = ed.project_id)
    LEFT JOIN lz_source as so on (so.id = ed.campaign_source_id)
    LEFT JOIN lz_user as us on (us.id = ed.tl_id)
    LEFT JOIN lz_user as us1 on (us1.id = exp.created_by)
    where exp.status = 1 
    group by exp.id
    order by exp.id desc
    `
    const data = await db2.sequelize.query(thisQuery);

    res.status(200).send({
        status:200,
        message:'Success',
        output:data[0]
      });
    } catch (error) {
      res.status(500).send({
        message: error.message,
      });
    }
};
exports.editExpense = async (req, res) => {
  try {
    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    const id = req.params.id;

    let thisQuery = ` SELECT exp.* , ed.expense_id as expense_id, ed.client as client, CONCAT(c.first_name,' ', IFNULL(c.last_name, '')) as client_name, ed.amount as amount, ed.city_id as city_id, ed.tl_id as TL_id, ed.builder_id as builder_id, ed.project_id as project_id, ed.month as month, ed.date as date, ed.campaign_name as campaign_name, ed.campaign_source_id as campaign_source_id, ed.cost_of_campaign as cost_of_campaign, ed.total_value as total_value, ed.gst_value as gst_value, et.option_value as expense_type_name, so.name as campaign_source_name, pa.name_of_building as property_name, us.first_name as teamleader_name, us1.first_name as created_name FROM lz_expenses as exp 
    LEFT JOIN lz_masters as et on (exp.expense_type = et.id) 
    LEFT JOIN lz_expense_details as ed on (ed.expense_id = exp.id)
    LEFT JOIN lz_contacts as c on (c.id = ed.client)
    LEFT JOIN lz_property_addresses as pa on (pa.id = ed.project_id)
    LEFT JOIN lz_source as so on (so.id = ed.campaign_source_id)
    LEFT JOIN lz_user as us on (us.id = ed.tl_id)
    LEFT JOIN lz_user as us1 on (us1.id = exp.created_by)
    where exp.status = 1 and exp.id = ${id} `
    const data = await db2.sequelize.query(thisQuery);

    if (data) {
      res.status(200).send({
        status:200,
        message:'Success',
        output:data[0][0]
        });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot find with id : ${id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.updateExpense = async (req, res) => {
  try {
    const id = req.params.id;
    const created_by = req.user.id
    console.log('created_by', created_by.id);

    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    let receipt_name = "";
    let receipt_original_name = "";
  
    if (req.files.receipt_name) {
      const extension = req.files.receipt_name[0]["mimetype"].split('/')[1]
      receipt_name = req.files.receipt_name[0]["filename"] + '.' + extension
      receipt_original_name = req.files.receipt_name[0]["originalname"]
    }

    const data = {
        transaction_id: req.body.transaction_id,
        expense_type: req.body.expense_type,
        expense_date: req.body.expense_date,
        add_amount: req.body.add_amount,
        billable: req.body.billable,
        receipt_name: receipt_name,
        receipt_original_name: receipt_original_name,
        created_by: created_by.id
      };

    const num = await db2['expenses'].update(data, {
      where: { id: id },
    });
    if (num == 1) {
        const expenseId = req.params.id;

        if (req.files.receipt_name) {
            //move receipt_name
            const currentPath = path.join(process.cwd(), "uploads", req.files.receipt_name[0]["filename"]);
            const destinationPath = path.join(process.cwd(), "/uploads/expenses/receipt_name/" + `${expenseId}`, receipt_name);
            const baseUrl = process.cwd() + '/uploads/expenses/receipt_name/' + `${expenseId}`
            fs.mkdirSync(baseUrl, { recursive: true })
            fs.rename(currentPath, destinationPath, function (err) {
              if (err) {
                throw err
              } else {
                console.log("Successfully moved the receipt images !")
              }
            });
        }

      res.status(200).send({
        status:200,
        message: "Updated successfully."
      });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot update with id : ${id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.updateExpenseDetails = async (req, res) => {
  try {
    const id = req.params.id;
    const expense_id = req.params.expense_id;
    const created_by = req.user.id
    console.log('created_by', created_by.id);

    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    const data = {
        client: req.body.client,
        amount: req.body.amount,
        city_id: req.body.city_id,
        tl_id: req.body.tl_id,
        builder_id: req.body.builder_id,
        project_id: req.body.project_id,
        month: req.body.month,
        date: req.body.date,
        campaign_name: req.body.campaign_name,
        campaign_source_id: req.body.campaign_source_id,
        cost_of_campaign: req.body.cost_of_campaign,
        total_value: req.body.total_value,
        gst_value: req.body.gst_value,
      };

    const num = await db2['expenseDetails'].update(data, {
      where: { expense_id: expense_id },
    });
    if (num == 1) {

      res.status(200).send({
        status:200,
        message: "Updated successfully."
      });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot update with id : ${expense_id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.deleteExpense = async (req, res) => {
  const expensesData = {
    status: 0,
  }
  try {
    const id = req.params.id;

    console.log("id111", id);
    const num = await db2['expenses'].update(expensesData, {
      where: {id:id},
    });
    if (num == 1) {
      res.status(200).send({
        status:200,
        message: "Deleted successfully!"
      });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot delete with id : ${id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};