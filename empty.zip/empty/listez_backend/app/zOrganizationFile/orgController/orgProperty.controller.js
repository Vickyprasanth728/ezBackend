const db2 = require("../orgModel/orgIndex.js");
const db = require("../../models");
const Op = db2.Sequelize.Op;
const path = require("path");
const fs = require("fs");
const dbConfig = require("../../config/db.config.js");
const mailer = require("../orgModel/mailer.model.js");
const DbName = dbConfig.DB_DATABASE

exports.saveProperty = async (req, res) => {
    try {
        const created_id = req.user.id
        const created_by = created_id.id
        console.log('created_by', created_by);

        const organ_id = req.user.id
        const org_id = organ_id.org_id
        console.log('organ_id', org_id);

        const desCreatedUser = await db2.sequelize.query(`select designation, CONCAT(first_name,' ', IFNULL(last_name, '')) as user_name, email from lz_user where status = 1 and id = ${created_by} `);
        const cDesignation = desCreatedUser[0][0]?.designation
        const CUserName = desCreatedUser[0][0]?.user_name
        console.log("cDesignation", cDesignation);
        console.log("CUserName", CUserName);

        const mailTriP = await db2.sequelize.query(`select designation from lz_email_trigger where options = 'property_created' and status = 1 `);
        const cTriDesP = mailTriP[0][0]?.designation ?? 0
        console.log("cTriDesP", cTriDesP);

        let profile_image = "";
        let profile_image_original_name = "";
        if (req.files.profile_image) {
          const extension = req.files.profile_image[0]["mimetype"].split('/')[1]
          profile_image = req.files.profile_image[0]["filename"] + '.' + extension
          profile_image_original_name = req.files.profile_image[0]["originalname"]
        }

        const data = await db2['property'].create({
            org_id: org_id,
            contact_id: req.body.contact_id || null,
            available_for: req.body.available_for || null,
            assign_to: req.body.assign_to || null,
            commission: req.body.commission || null,
            property_indepth: req.body.property_indepth || null,
            segment: req.body.segment || null,
            property_type: req.body.property_type || null,
            property_source: req.body.property_source || null,
            property_status: req.body.property_status || null,
            gst: req.body.gst || null,
            invoice_name: req.body.invoice_name || null,
            legal_approval: req.body.legal_approval || null,
            description: req.body.description || null,
            profile_image: profile_image || null,
            profile_image_original_name: profile_image_original_name || null,
            description: req.body.description || null,
            // project_unit_type: req.body.project_unit_type || null,
            created_by: created_by,
        });

        let propertyId = data?.dataValues.id

        const data1 = await db2['propertyResidentials'].create({
            property_id: propertyId,
            project_stage: req.body.project_stage || null,
            age_of_property: req.body.age_of_property || null,
            furnishing: req.body.furnishing || null,
            built_up_area_min: req.body.built_up_area_min || null,
            built_up_area_max: req.body.built_up_area_max || null,
            builtup_area_min_ut: req.body.builtup_area_min_ut || null,
            builtup_area_max_ut: req.body.builtup_area_max_ut || null,
            plot_area_min: req.body.plot_area_min || null,
            plot_area_max: req.body.plot_area_max || null,
            plot_area_min_ut: req.body.plot_area_min_ut || null,
            plot_area_max_ut: req.body.plot_area_max_ut || null,
            tower: req.body.tower || null,
            uds_min: req.body.uds_min || null,
            uds_max: req.body.uds_max || null,
            uds_min_ut: req.body.uds_min_ut || null,
            uds_max_ut: req.body.uds_max_ut || null,
            no_of_floors: req.body.no_of_floors || null,
            no_of_units_min: req.body.no_of_units_min || null,
            no_of_units_max: req.body.no_of_units_max || null,
            unit_type_min: req.body.unit_type_min || null,
            unit_type_max: req.body.unit_type_max || null,
            ownership_type: req.body.ownership_type || null,
            balcony: req.body.balcony || null,
            property_facing: req.body.property_facing || null,
            kitchen_type: req.body.kitchen_type || null,
            flooring: req.body.flooring || null,
            vasthu_compliant: req.body.vasthu_compliant || null,
            currently_under_loan: req.body.currently_under_loan || null,
            available_from: req.body.available_from || null,
            site_visit_preference: req.body.site_visit_preference || null,
            key_custody: req.body.key_custody || null,
            no_of_car: req.body.no_of_car || null,
            car_park_type: req.body.car_park_type || null,
            water_supply: req.body.water_supply || null,
            gated_community: req.body.gated_community || null,
            amenities: req.body.amenities || null,
            property_highlight: req.body.property_highlight || null,
            rera_registered: req.body.rera_registered || null,
            rera_number: req.body.rera_number || null,
            completion_certificate: req.body.completion_certificate || null,
            project_unit_type: req.body.project_unit_type || null,
            specification: req.body.specification || null
        });
        const data2 = await db2['propertyAddress'].create({
            property_id: propertyId,
            name_of_building: req.body.name_of_building || null,
            door_number: req.body.door_number || null,
            address_line1: req.body.address_line1 || null,
            country: req.body.country || null,
            state: req.body.state || null,
            city: req.body.city || null,
            locality: req.body.locality || null,
            pincode: req.body.pincode || null,
            latitude: req.body.latitude || null,
            longitude: req.body.longitude || null,
            module_number: req.body.module_number || null
        });

        const PropertyLogs = await db2['logs'].create({
            org_id: org_id,
            module_id: propertyId,
            module_name: "3",
            note: "Property created at",
            user_id: created_by
        })

        if (req.files.profile_image) {
            // move profile image
            const currentPath = path.join(process.cwd(), "uploads", req.files.profile_image[0]["filename"]);
            const destinationPath = path.join(process.cwd(), "uploads/property/profile_image/" + `${propertyId}`, profile_image);
      
            const baseUrl = process.cwd() + '/uploads/property/profile_image/' + `${propertyId}`
            fs.mkdirSync(baseUrl, { recursive: true })
            fs.rename(currentPath, destinationPath, function (err) {
              if (err) {
                throw err
              } else {
                console.log("Successfully moved the profile image!")
              }
            });
          }

        if (req.files.length > 0) {
            for (i = 0; i < req.files.length; i++) {
                //extension
                let additionalFiles = "";
                let additionalFiles_original_name = "";
                if (req.files[i]) {
                    const extension = req.files[i]["mimetype"].split('/')[1]
                    additionalFiles = req.files[i]["filename"] + '.' + extension
                    additionalFiles_original_name = req.files[i]["originalname"]
                }

                const fileData = {
                    module_id: propertyId,
                    module_name: '3',
                    file: additionalFiles,
                    fileoriginalname: additionalFiles_original_name,
                    user_id: created_by,
                    created_by: created_by,
                };

                x = fileData.module_id
                console.log('xxxxxxxxxxxxx', x);
                const data = await db2['files'].create(fileData);
                //move the file to directory
                const currentPath = path.join(process.cwd(), "uploads", req.files[i]["filename"]);
                const destinationPath = path.join(process.cwd(), "uploads/contacts/files/" + `${x}`, additionalFiles);

                const baseUrl = process.cwd() + '/uploads/contacts/files/' + `${x}`
                fs.mkdirSync(baseUrl, { recursive: true })
                fs.rename(currentPath, destinationPath, function (err) {
                    if (err) {
                        throw err
                    } else {
                        console.log("Successfully moved the file!")
                    }
                })
            }
        }

        // Email Trigger
        const email_settings = await db2.sequelize.query(`select status from lz_email_trigger where FIND_IN_SET('${cDesignation}', '${cTriDesP},1') > 0 and options = 'property_created' and status = 1 `);
        // const emailTri = email_settings[0][0] ? email_settings[0][0]["active_status"] : 0
        const emailTri = email_settings[0][0]?.status ?? 0
        console.log("emailTri", emailTri);

        //nodemailer
        if(emailTri == 1) {

        let thisQueryDes = ` select us.team_leader as tl, us.portfolio_head as sub_tl 
        from lz_user as us where id = ${created_by} `
        const desCheck = await db2.sequelize.query(thisQueryDes);
        const desCheckTL = desCheck[0][0].tl
        const desCheckSubTL = desCheck[0][0].sub_tl
        // TL
        const checkTl = await db2.sequelize.query(`select email from lz_user where id = ${desCheckTL}`);
        const checkTl1 = checkTl[0][0].email
        // Sub TL
        const checksubTL = await db2.sequelize.query(`select email from lz_user where id = ${desCheckSubTL}`);
        const checksubTL1 = checksubTL[0][0].email
        // Admin
        const checkAdmin = await db2.sequelize.query(`select email from lz_user where designation = 1 group by id `);
        const checkAdmin1 = checkAdmin[0].map(item => item.email).join(', ');

        // Assign To
        const assignEmail = await db2.sequelize.query(`select us.id as id, us.email as email from lz_user as us where us.id IN (${req.body.assign_to}) `);
        const assEmail = assignEmail[0].map(item => item.email).join(', ')
        
        console.log("checkTl", checkTl1);
        console.log("checksubTL1", checksubTL1);
        console.log("checkAdmin1", checkAdmin1);
        console.log("assign_to",assEmail);
        
        const createdEmail = await db2.sequelize.query(`select email from lz_user where id = ${created_by} `);
        const cEmail = createdEmail[0][0].email
        console.log("cEmail", cEmail);

        let message = {
                from: cEmail,
                to: [checkAdmin1,checkTl1,checksubTL1,assEmail].join(', '),
                subject: "New Property Created",
                html:
                "<h3> New Property has been created </h3>"
            };
            console.log("message", message);
            mailer.sendMail(message, function(error, info){
                if (error) {
                console.log('Error');
                } else {
                console.log('Email sent: ' + info.response);
                }
            });
        }

        res.status(200).send({
            status: 200,
            message: 'Success',
            output: data
        });

    } catch (error) {
        res.status(500).send({
            message: error.message,
        });
    }
};
exports.getProperty = async (req, res) => {
    try {

        const created_id = req.user.id
        const created_by = created_id.id
        console.log('created_by', created_by);

        const organ_id = req.user.id
        const org_id = organ_id.org_id
        console.log('organ_id', org_id);

        const role = req.user.id
        const role_id = role.designation
        console.log('role_id', role_id);

        let thisQuery = `SELECT p.*, org.organization_name as org_name,  CONCAT(c.first_name,' ',c.last_name) as contact_name, pa.name_of_building as name_of_building,pa.door_number as addressline1,pa.address_line1 as address_line2,pa.country as country,pa.state as state,pa.city as city,pa.locality as locality,pa.pincode as pincode,pa.latitude as latitude,pa.longitude as longitude,pa.module_number as module_number,pr.project_stage as project_stage,pr.age_of_property as age_of_property,pr.furnishing as furnishing, pr.built_up_area_min as built_up_area_min, pr.built_up_area_max, pr.builtup_area_min_ut as builtup_area_min_ut, pr.builtup_area_max_ut, pr.plot_area_min as plot_area_min, pr.plot_area_max as plot_area_max, pr.plot_area_min_ut as plot_area_min_ut, pr.plot_area_max_ut as plot_area_max_ut, pr.tower as tower,pr.no_of_floors as no_of_floors,pr.no_of_units_min as no_of_units_min,pr.no_of_units_max as no_of_units_max,pr.unit_type_min as unit_type_min,pr.unit_type_max as unit_type_max,pr.ownership_type as ownership_type,pr.balcony as balcony,pr.property_facing as property_facing,pr.kitchen_type as kitchen_type,pr.flooring as flooring,pr.vasthu_compliant as vasthu_compliant,pr.currently_under_loan as currently_under_loan,pr.available_from as available_from,pr.key_custody as key_custody,pr.no_of_car as no_of_car,pr.car_park_type as car_park_type,pr.water_supply as water_supply,pr.gated_community as gated_community,pr.property_highlight as property_highlight,pr.rera_registered as rera_registered,pr.rera_number as rera_number,pr.completion_certificate as completion_certificate, CONVERT(pr.site_visit_preference USING utf8) as site_visit_preference, CONVERT(pr.amenities USING utf8) as amenities,pr.project_unit_type as project_unit_type, GROUP_CONCAT(distinct CONCAT(us.first_name,' ', IFNULL(us.last_name, ''),'-',us.id)) as assign_to_name, pid.option_value as property_indepth_name, s.option_value as segment_name, pt.option_value as property_type_name, ps.option_value as property_source_name, pss.option_value as property_status_name, pla.option_value as legal_approval_name, GROUP_CONCAT(distinct CONCAT(am.option_value,'-',am.id)) as amenities_for_name, GROUP_CONCAT(distinct CONCAT(af.option_value,'-',af.id)) as available_for_name, CONCAT(usz.first_name,' ',IFNULL(usz.last_name, '')) as created_by_name, c.email as email, c.mobile as mobile, c.developer_name as developer_name,cou.name as country_name,st.name as state_name,ci.name as city_name,
        pr.uds_min as uds_min, pr.uds_max as uds_max, pr.uds_min_ut as uds_min_ut, pr.uds_max_ut as uds_max_ut,

        (SELECT COUNT(id) FROM lz_notes where status = 1 and (module_id = p.id and module_name = 3 or module_id = p.contact_id and module_name = 1)) as notes_count,
        (SELECT COUNT(id) FROM lz_file_uploads where module_id = p.id and module_name = 3) as files_count,
        (SELECT ifnull(COUNT(*),0) FROM lz_leads as l LEFT JOIN lz_properties on (lz_properties.id = l.property_id) where property_id = p.id) as lead_count,
        (SELECT ifnull(COUNT(*),0) FROM lz_tasks as t LEFT JOIN lz_properties on (lz_properties.id = t.project) where t.project = p.id) as task_count

        FROM lz_properties as p
        LEFT JOIN lz_property_residentials as pr on (pr.property_id = p.id)
        LEFT JOIN lz_property_addresses as pa on (pa.property_id = p.id)
        LEFT JOIN lz_masters as pid on (pid.id = p.property_indepth)
        LEFT JOIN lz_masters as s on (s.id = p.segment)
        LEFT JOIN lz_masters as pt on (pt.id = p.property_type)
        LEFT JOIN lz_masters as ps on (ps.id = p.property_source)
        LEFT JOIN lz_masters as pss on (pss.id = p.property_status)
        LEFT JOIN lz_masters as pla on (pla.id = p.legal_approval)
        LEFT JOIN ${DbName}.lz_country as cou on (cou.id = pa.country)
        LEFT JOIN ${DbName}.lz_state as st on (st.id = pa.state)
        LEFT JOIN ${DbName}.lz_city as ci on (ci.id = pa.city)
        LEFT JOIN lz_masters as am on FIND_IN_SET (am.id, pr.amenities) > 0
        LEFT JOIN lz_masters as af on FIND_IN_SET (af.id, p.available_for ) > 0
        LEFT JOIN lz_user as us on FIND_IN_SET(us.id,p.assign_to)>0
        LEFT JOIN lz_organization as org on (org.id = p.org_id)
        LEFT JOIN lz_contacts as c on (c.id = p.contact_id) 
        LEFT JOIN lz_user as usz on (usz.id = p.created_by) 
       
        LEFT JOIN lz_user as us5 on FIND_IN_SET(us5.id,c.assign_to) > 0 
        left join lz_user as us4 on (us5.team_leader = us4.id) 
        LEFT JOIN lz_user as us6 on FIND_IN_SET(us6.id,c.assign_to) > 0 
        left join lz_user as us7 on (us6.portfolio_head = us7.id) 
      
        where p.status = 1 `

          if (role_id == 1) {
            thisQuery += ` `
          }
          if (role_id == 2) {
            thisQuery += ` and (FIND_IN_SET(${created_by},p.assign_to)>0 or us.team_leader = ${created_by} or us.portfolio_head = ${created_by} or p.created_by = ${created_by}) `
            // thisQuery += ` and c.created_by = ${created_by} `
          }
          if (role_id == 3) {
            thisQuery += ` and (FIND_IN_SET(${created_by},p.assign_to)>0 or us.team_leader = ${created_by} or us.portfolio_head = ${created_by} or p.created_by = ${created_by}) `
            // thisQuery += ` and c.created_by = ${created_by} `
          }
          if (role_id == 4) {
            thisQuery += ` and (FIND_IN_SET(${created_by},p.assign_to)>0 or p.created_by = ${created_by}) `
          }
          if (role_id == 5) {
            thisQuery += ` `
          }
          if (role_id == 6) {
            thisQuery += `and p.created_by = ${created_by} `
          }
          if (role_id >= 7) {
            thisQuery += `and p.created_by = ${created_by} `
          }


        // left join lz_user as us5 on (p.created_by = us5.id) 
        // left join lz_user as us4 on (us5.team_leader = us4.id) 
        // if (role_id == 1) {
        //     thisQuery += ` `
        // }
        // if (role_id == 2) {

        //     let thisQuery1 = `select GROUP_CONCAT(distinct CONCAT(us.id)) as exec, us.team_leader as team_leader from lz_user as us where us.team_leader = ${created_by} limit 1 `
        //     const data = await db2.sequelize.query(thisQuery1);
        //     console.log('dataaaaaaaaaaaaa', data[0]);

        //     thisQuery += ` and p.status= 1 and FIND_IN_SET(${created_by},p.assign_to)>0 or us5.team_leader = ${created_by} `

        //     // thisQuery += ` and p.status= 1 and p.created_by = ${created_by} `
        // }
        // if (role_id >= 3) {
        //     thisQuery += ` and p.status= 1 and FIND_IN_SET(${created_by},p.assign_to)>0 `
        // }

        const filters = req.query;
        if (filters.property_indepth) {
            thisQuery += " and p.property_indepth = " + `${filters.property_indepth} `
        }
        if (filters.segment) {
            thisQuery += " and p.segment = " + `${filters.segment} `
        }
        if (filters.property_source) {
            thisQuery += " and p.property_source = " + `${filters.property_source} `
        }
        if (filters.assign_to) {
            var a = filters.assign_to;
            var b = a.replace(/[,]/g, ",");
            thisQuery += `and CONCAT(',', p.assign_to, ',') REGEXP ',(${a}),' `
        }
        if (filters.available_for) {
            var a = filters.available_for;
            var b = a.replace(/[,]/g, ",");
            thisQuery += `and CONCAT(',', p.available_for, ',') REGEXP ',(${a}),' `
        }
        if (filters.property_id) {
            var a = filters.property_id;
            var b = a.replace(/[,]/g, ",");
            thisQuery += `and CONCAT(',', pa.property_id, ',') REGEXP ',(${a}),' `
        }
        if (filters.age_of_property) {
            var a = filters.age_of_property;
            var b = a.replace(/[,]/g, ",");
            thisQuery += `and CONCAT(',', pr.age_of_property, ',') REGEXP ',(${a}),' `
        }
        if (filters.locality) {
            var a = filters.locality;
            var b = a.replace(/[,]/g, ",");
            thisQuery += `and CONCAT(',', pa.locality, ',') REGEXP ',(${a}),' `
        }
        if (filters.country) {
            var a = filters.country;
            var b = a.replace(/[,]/g, ",");
            thisQuery += `and CONCAT(',', pa.country, ',') REGEXP ',(${a}),' `
        }
        if (filters.state) {
            var a = filters.state;
            var b = a.replace(/[,]/g, ",");
            thisQuery += `and CONCAT(',', pa.state, ',') REGEXP ',(${a}),' `
        }
        if (filters.city) {
            var a = filters.city;
            var b = a.replace(/[,]/g, ",");
            thisQuery += `and CONCAT(',', pa.city, ',') REGEXP ',(${a}),' `
        }
        if (filters.pincode) {
            var a = filters.pincode;
            var b = a.replace(/[,]/g, ",");
            thisQuery += `and CONCAT(',', pa.pincode, ',') REGEXP ',(${a}),' `
        }
        if (filters.amenities) {
            var a = filters.amenities;
            var b = a.replace(/[,]/g, ",");
            thisQuery += `and CONCAT(',', pr.amenities, ',') REGEXP ',(${a}),' `
        }
        if (filters.project_stage) {
            var a = filters.project_stage;
            var b = a.replace(/[,]/g, ",");
            thisQuery += `and CONCAT(',', pr.project_stage, ',') REGEXP ',(${a}),' `
        }
        if (filters.available_start_date && filters.available_end_date) {
            thisQuery += ` and (DATE_FORMAT(pr.available_from,'%Y-%m-%d') >= '${filters.start_date}' AND DATE_FORMAT(pr.available_from,'%Y-%m-%d') <= '${filters.end_date}') `
        }
        if (filters.commission_min && filters.commission_max) {
            thisQuery += ` and p.commission >= '${filters.commission_min}' AND p.commission <= '${filters.commission_max}' `
        }
        if (filters.no_of_floors_min && filters.no_of_floors_max) {
            thisQuery += ` and pr.no_of_floors >= '${filters.no_of_floors_min}' AND pr.no_of_floors <= '${filters.no_of_floors_max}' `
        }
        if (filters.no_of_units_min && filters.no_of_units_max) {
            thisQuery += ` and pr.no_of_units_min >= '${filters.no_of_units_min}' AND pr.no_of_units_max <= '${filters.no_of_units_max}' `
        }
        if (filters.property_type) {
            thisQuery += " and p.property_type = " + `${filters.property_type} `
        }
        if (filters.property_status) {
            thisQuery += " and p.property_status = " + `${filters.property_status} `
        }
        if (filters.property_facing) {
            thisQuery += " and pr.property_facing = " + `${filters.property_facing} `
        }
        if (filters.gated_community) {
            thisQuery += " and pr.gated_community = " + `${filters.gated_community} `
        }
        if (filters.vasthu_compliant) {
            thisQuery += " and pr.vasthu_compliant = " + `${filters.vasthu_compliant} `
        }
        if (filters.legal_approval) {
            thisQuery += " and p.legal_approval = " + `${filters.legal_approval} `
        }
        if (filters.rera_registered) {
            thisQuery += " and pr.rera_registered = " + `${filters.rera_registered} `
        }
        if (filters.created_date != "" && filters.created_end_date) {
            // thisQuery += "and c.created_at = " + `'${filters.created_at}' `
            thisQuery += ` and (DATE_FORMAT(p.created_at,'%Y-%m-%d') >= '${filters.created_date}' AND DATE_FORMAT(p.created_at,'%Y-%m-%d') <= '${filters.created_end_date}') `
        }
        if (filters.created_date != "" && filters.created_end_date == '') {
            // thisQuery += "and c.created_at = " + `'${filters.created_at}' `
            thisQuery += ` and (DATE_FORMAT(p.created_at,'%Y-%m-%d') >= '${filters.created_date}') `
        }
        if (filters.created_date == "" && filters.created_end_date != '') {
            // thisQuery += "and c.created_at = " + `'${filters.created_at}' `
            thisQuery += ` and (DATE_FORMAT(p.created_at,'%Y-%m-%d') <= '${filters.created_end_date}') `
        }
        // if (filters.unit_type_min && filters.unit_type_max) {
        //     // thisQuery += "and c.created_at = " + `'${filters.created_at}' `
        //     thisQuery += ` and REPLACE(JSON_EXTRACT(pr.project_unit_type,'$[0].unit_type'), '\"', '') >= '${filters.unit_type_min}' AND REPLACE(JSON_EXTRACT(pr.project_unit_type,'$[0].unit_type'), '\"', '') <= '${filters.unit_type_max}' `
        // }
        // if (filters.price_min && filters.price_max) {
        //     // thisQuery += "and c.created_at = " + `'${filters.created_at}' `
        //     thisQuery += ` and REPLACE(JSON_EXTRACT(pr.project_unit_type,'$[0].price_min'), '\"', '') >= '${filters.price_min}' AND REPLACE(JSON_EXTRACT(pr.project_unit_type,'$[0].price_max'), '\"', '') <= '${filters.price_max}' `
        // }
        // if (filters.builtup_area_min && filters.builtup_area_max) {
        //     // thisQuery += "and c.created_at = " + `'${filters.created_at}' `
        //     thisQuery += ` and REPLACE(JSON_EXTRACT(pr.project_unit_type,'$[0].builtup_area_min'), '\"', '') >= '${filters.builtup_area_min}' AND REPLACE(JSON_EXTRACT(pr.project_unit_type,'$[0].builtup_area_max'), '\"', '') <= '${filters.builtup_area_max}' `
        // }

        thisQuery += ' group by p.id '

        if (filters.order_by) {
            let orderByString = filters.order_by.split('|')
            thisQuery += " order by " + `${orderByString[0]} ${orderByString[1]} `
        }
        const data1 = await db2.sequelize.query(thisQuery);

        if (filters.order_by == "" || filters.order_by == undefined) {
            thisQuery += '  order by p.id DESC '
        }

        if (filters.limit) {
            thisQuery += ` limit ${filters.limit},12 `
        }

        const data = await db2.sequelize.query(thisQuery);

        // const data2 = await db['city'].findAll({attributes:[["name","city_name"]]});
        // const data3 = await db['state'].findAll({attributes:[["name","state_name"]]});
        // const data4 = await db['country'].findAll({attributes:[["name","country_name"]]});

        // let propertyWithdata = [];
        // const dataCheck = data[0]
        // for(let i=0; dataCheck.length > i;i++) {
        //     const a = data2[i]?.dataValues
        //     const b = data3[i]?.dataValues
        //     const c = data4[i]?.dataValues
        //     let dataPush = {...dataCheck[i], ...a, ...b, ...c};
        //     propertyWithdata.push(dataPush);
        // }
        // console.log('dataCheck', dataCheck);

        const count_filter = (data1[0])

        res.status(200).send({
            status: 200,
            message: 'Success',
            count: count_filter.length,
            output: data[0]
        });
    } catch (error) {
        res.status(500).send({
            message: error.message,
        });
    }
};
exports.editProperty = async (req, res) => {
    try {
        const organ_id = req.user.id
        const org_id = organ_id.org_id
        console.log('organ_id', org_id);

        const projectId = req.params.id

        let thisQuery = `SELECT p.*, org.organization_name as org_name,  CONCAT(c.first_name,' ',c.last_name) as contact_name, pa.name_of_building as name_of_building,pa.door_number as addressline1,pa.address_line1 as address_line2,pa.country as country,pa.state as state,pa.city as city,pa.locality as locality,pa.pincode as pincode,pa.latitude as latitude,pa.longitude as longitude,pa.module_number as module_number,pr.project_stage as project_stage,pr.age_of_property as age_of_property,pr.furnishing as furnishing, pr.built_up_area_min as built_up_area_min, pr.built_up_area_max, pr.builtup_area_min_ut as builtup_area_min_ut, pr.builtup_area_max_ut, pr.plot_area_min as plot_area_min, pr.plot_area_max as plot_area_max, pr.plot_area_min_ut as plot_area_min_ut, pr.plot_area_max_ut as plot_area_max_ut,pr.tower as tower,pr.no_of_floors as no_of_floors,pr.no_of_units_min as no_of_units_min,pr.no_of_units_max as no_of_units_max,pr.unit_type_min as unit_type_min,pr.unit_type_max as unit_type_max,pr.ownership_type as ownership_type,pr.balcony as balcony,pr.property_facing as property_facing,pr.kitchen_type as kitchen_type,pr.flooring as flooring,pr.vasthu_compliant as vasthu_compliant,pr.currently_under_loan as currently_under_loan,pr.available_from as available_from,pr.key_custody as key_custody,pr.no_of_car as no_of_car,pr.car_park_type as car_park_type,pr.water_supply as water_supply,pr.gated_community as gated_community,pr.property_highlight as property_highlight,pr.rera_registered as rera_registered,pr.rera_number as rera_number,pr.completion_certificate as completion_certificate, CONVERT(pr.site_visit_preference USING utf8) as site_visit_preference, CONVERT(pr.amenities USING utf8) as amenities, pr.project_unit_type as project_unit_type, GROUP_CONCAT(distinct CONCAT(us.first_name,' ', IFNULL(us.last_name, ''),'-',us.id)) as assign_to_name, pid.option_value as property_indepth_name, s.option_value as segment_name, pt.option_value as property_type_name, ps.option_value as property_source_name, pss.option_value as property_status_name, pla.option_value as legal_approval_name, GROUP_CONCAT(distinct CONCAT(am.option_value,'-',am.id)) as amenities_for_name, GROUP_CONCAT(distinct CONCAT(af.option_value,'-',af.id)) as available_for_name, CONCAT(us1.first_name,' ',IFNULL(us1.last_name, '')) as created_by_name,cou.name as country_name,st.name as state_name,ci.name as city_name,
        pr.uds_min as uds_min, pr.uds_max as uds_max, pr.uds_min_ut as uds_min_ut, pr.uds_max_ut as uds_max_ut
        FROM lz_properties as p
        LEFT JOIN lz_property_residentials as pr on (pr.property_id = p.id)
        LEFT JOIN lz_property_addresses as pa on (pa.property_id = p.id)
        LEFT JOIN lz_masters as pid on (pid.id = p.property_indepth)
        LEFT JOIN lz_masters as s on (s.id = p.segment)
        LEFT JOIN lz_masters as pt on (pt.id = p.property_type)
        LEFT JOIN lz_masters as ps on (ps.id = p.property_source)
        LEFT JOIN lz_masters as pss on (pss.id = p.property_status)
        LEFT JOIN lz_masters as pla on (pla.id = p.legal_approval)
        LEFT JOIN ${DbName}.lz_country as cou on (cou.id = pa.country)
        LEFT JOIN ${DbName}.lz_state as st on (st.id = pa.state)
        LEFT JOIN ${DbName}.lz_city as ci on (ci.id = pa.city)
        LEFT JOIN lz_masters as am on FIND_IN_SET (am.id, pr.amenities) > 0
        LEFT JOIN lz_masters as af on FIND_IN_SET ( af.id, p.available_for ) > 0
        LEFT JOIN lz_user as us on FIND_IN_SET(us.id,p.assign_to)>0
        LEFT JOIN lz_organization as org on (org.id = p.org_id)
        LEFT JOIN lz_contacts as c on (c.id=p.contact_id) 
        LEFT JOIN lz_user as us1 on (us1.id = p.created_by)
        where p.id = ${projectId} and p.status = 1 `

        thisQuery += ' group by p.id '

        const data = await db2.sequelize.query(thisQuery);

        res.status(200).send({
            status: 200,
            message: 'Success',
            output: data[0]
        });
    } catch (error) {
        res.status(500).send({
            message: error.message,
        });
    }
};
exports.updateProperty = async (req, res) => {
    try {
        const id = req.params.id;

        const created_id = req.user.id
        const created_by = created_id.id
        console.log('created_by', created_by);

        const organ_id = req.user.id
        const org_id = organ_id.org_id
        console.log('organ_id', org_id);

        let profile_image = "";
        let profile_image_original_name = "";
        if (req.files.profile_image) {
            const extension = req.files.profile_image[0]["mimetype"].split('/')[1]
            profile_image = req.files.profile_image[0]["filename"] + '.' + extension
            profile_image_original_name = req.files.profile_image[0]["originalname"]
        }

        let thisQuery = ` select p.contact_id as contact_id, c.first_name as contact_name, p.property_source as source, so.option_value as source_name, p.property_status as property_status, cs.option_value as property_status_name, p.id as property_id, pa.name_of_building as property_name
        from lz_properties as p
        left join lz_contacts as c on (p.contact_id = c.id)
        left join lz_property_addresses as pa on (p.id = pa.property_id)
        left join lz_masters as so on (so.id = p.property_source)
        left join lz_masters as cs on (cs.id = p.property_status)
        where p.status = 1 and p.id = ${id} `

        const data123 = await db2.sequelize.query(thisQuery);
        const dataContactID = data123[0][0]?.contact_id
        const dataContactName = data123[0][0]?.contact_name
        const dataSource = data123[0][0]?.source
        const dataSourceName = data123[0][0]?.source_name
        const dataStatus = data123[0][0]?.property_status
        const dataStatusName = data123[0][0]?.property_status_name
        const dataProperty = data123[0][0]?.property_id
        const dataPropertyName = data123[0][0]?.property_name

        console.log("dataContactID", dataContactID);
        console.log("dataContactName", dataContactName);
        console.log("dataSource", dataSource);
        console.log("dataSourceName", dataSourceName);
        console.log("dataStatus", dataStatus);
        console.log("dataStatusName", dataStatusName);
        console.log("dataProperty", dataProperty);
        console.log("dataPropertyName", dataPropertyName);

        let data = {};
        if (profile_image) {
            data = {
                contact_id: req.body.contact_id,
                available_for: req.body.available_for,
                assign_to: req.body.assign_to,
                commission: req.body.commission,
                property_indepth: req.body.property_indepth,
                segment: req.body.segment,
                property_type: req.body.property_type,
                property_source: req.body.property_source,
                property_status: req.body.property_status,
                gst: req.body.gst,
                invoice_name: req.body.invoice_name,
                legal_approval: req.body.legal_approval,
                description: req.body.description,
                profile_image: profile_image,
                profile_image_original_name: profile_image_original_name,
            }
        } else {
            data = {
                contact_id: req.body.contact_id,
                available_for: req.body.available_for,
                assign_to: req.body.assign_to,
                commission: req.body.commission,
                property_indepth: req.body.property_indepth,
                segment: req.body.segment,
                property_type: req.body.property_type,
                property_source: req.body.property_source,
                property_status: req.body.property_status,
                gst: req.body.gst,
                invoice_name: req.body.invoice_name,
                legal_approval: req.body.legal_approval,
                description: req.body.description,
            }
        }

        const num = await db2['property'].update(data, {
            where: { id: id },
        });
        if (num == 1) {

            let propertyId = req.params.id

            if (req.files.profile_image) {
                // move profile image
                const currentPath = path.join(process.cwd(), "uploads", req.files.profile_image[0]["filename"]);
                const destinationPath = path.join(process.cwd(), "uploads/property/profile_image/" + `${propertyId}`, profile_image);

                const baseUrl = process.cwd() + '/uploads/property/profile_image/' + `${propertyId}`
                fs.mkdirSync(baseUrl, { recursive: true })
                fs.rename(currentPath, destinationPath, function (err) {
                    if (err) {
                        throw err
                    } else {
                        console.log("Successfully moved the profile image!")
                    }
                });
            }
            // Source
            if (req.body.property_source) {
                let thisQuery456 = ` select p.property_source as l_source, so.option_value as l_source_name
                from lz_properties as p
                left join lz_masters as so on (so.id = p.property_source)
                where p.status = 1 and p.property_source = ${req.body.property_source}
                `
                const dataSO = await db2.sequelize.query(thisQuery456);
                const dataSO1 = dataSO[0][0]?.l_source
                const dataSO2 = dataSO[0][0]?.l_source_name
                console.log("dataSO1", dataSO1);
                console.log("dataSO2", dataSO2);

                if (dataSource.toString() !== req.body.property_source.toString()) {
                    const PropertySourceLog = await db2['logs'].create({
                        org_id: org_id,
                        module_id: propertyId,
                        module_name: "3",
                        note: 'Property source : ' + dataSourceName + ' to ' + dataSO2,
                        user_id: created_by
                    })
                    console.log("Property Source", PropertySourceLog.dataValues.note);
                }
            }

            // Property Status
            if (req.body.property_status) {
                let thisQuery456 = ` select p.property_status as l_status, cs.option_value as l_status_name
                from lz_properties as p
                left join lz_masters as cs on (cs.id = p.property_status)
                where p.status = 1 and p.property_status = ${req.body.property_status}
                `
                const dataCS = await db2.sequelize.query(thisQuery456);
                const dataCS1 = dataCS[0][0]?.l_status
                const dataCS2 = dataCS[0][0]?.l_status_name
                console.log("dataCS1", dataCS1);
                console.log("dataCS2", dataCS2);

                if (dataStatus.toString() !== req.body.property_status.toString()) {
                    const PropertyStatusLog = await db2['logs'].create({
                        org_id: org_id,
                        module_id: propertyId,
                        module_name: "3",
                        note: 'Property status : ' + dataStatusName + ' to ' + dataCS2,
                        user_id: created_by
                    })
                    console.log("Property Status", PropertyStatusLog.dataValues.note);
                }
            }

            // Contact Name
            if (req.body.contact_id) {
                let thisQuery456 = ` select p.contact_id as l_contact_id, c.first_name as l_contact_name
                from lz_properties as p
                left join lz_contacts as c on (c.id = p.contact_id)
                where p.status = 1 and p.contact_id = ${req.body.contact_id}
                `
                const dataC = await db2.sequelize.query(thisQuery456);
                const dataC1 = dataC[0][0]?.l_contact_id
                const dataC2 = dataC[0][0]?.l_contact_name
                console.log("dataC1", dataC1);
                console.log("dataC2", dataC2);

                if (dataContactID.toString() !== req.body.contact_id.toString()) {
                    const PropertyContactLog = await db2['logs'].create({
                        org_id: org_id,
                        module_id: propertyId,
                        module_name: "3",
                        note: 'Property contact name : ' + dataContactName + ' to ' + dataC2,
                        user_id: created_by
                    })
                    console.log("Property Contact name", PropertyContactLog.dataValues.note);
                }
            }

            // Email Trigger
            const email_settings = await db2.sequelize.query(`select status from lz_email_trigger where module_id = 1 and status = 1 `);
            // const emailTri = email_settings[0][0] ? email_settings[0][0]["active_status"] : 0
            const emailTri = email_settings[0][0]["status"]
            console.log("emailTri", emailTri);

            //nodemailer
            if(emailTri == 1) {

            let thisQueryDes = ` select us.team_leader as tl, us.portfolio_head as sub_tl 
            from lz_user as us where id = ${created_by} `
            const desCheck = await db2.sequelize.query(thisQueryDes);
            const desCheckTL = desCheck[0][0].tl
            const desCheckSubTL = desCheck[0][0].sub_tl
            // Team Leader
            const checkTl = await db2.sequelize.query(`select email from lz_user where id = ${desCheckTL} `);
            const checkTl1 = checkTl[0][0].email
            // Sub TL
            const checksubTL = await db2.sequelize.query(`select email from lz_user where id = ${desCheckSubTL} `);
            const checksubTL1 = checksubTL[0][0].email
            // Admin
            const checkAdmin = await db2.sequelize.query(`select email from lz_user where designation = 1 group by id `);
            const checkAdmin1 = checkAdmin[0].map(item => item.email).join(', ');
            // Assign To
            const assignEmail = await db2.sequelize.query(`
            select p.assign_to as assign_to, us.email as email
            from lz_properties as p
            left join lz_user as us on FIND_IN_SET(us.id,p.assign_to) > 0
            where p.id = ${id} `);
            const assEmail = assignEmail[0].map(item => item.email).join(', ')
            
            console.log("checkTl", checkTl1);
            console.log("checksubTL1", checksubTL1);
            console.log("checkAdmin1", checkAdmin1);
            console.log("assign_to",assEmail);
            
            const createdEmail = await db2.sequelize.query(`select email from lz_user where id = ${created_by} `);
            const cEmail = createdEmail[0][0].email
            console.log("cEmail", cEmail);

            let message = {
                from: cEmail,
                to: [checkAdmin1,checkTl1,checksubTL1, assEmail].join(', '),
                subject: "Project Updated",
                html:
                "Project Updated"
            };
            console.log("message", message);
            mailer.sendMail(message, function(error, info){
                if (error) {
                console.log('Error');
                } else {
                console.log('Email sent: ' + info.response);
                }
            });
            }

            res.status(200).send({
                status: 200,
                message: "Updated successfully."
            });
        } else {
            res.status(200).send({
                status: 404,
                message: `Cannot update with id : ${id}.`
            });
        }
    } catch (error) {
        res.status(500).send({
            message: error.message,
        });
    }
};
exports.updatePropertyResidential = async (req, res) => {
    try {
        const id = req.params.id;
        const property_id = req.params.property_id;

        const created_by = req.user.id
        console.log('created_by', created_by.id);

        const organ_id = req.user.id
        const org_id = organ_id.org_id
        console.log('organ_id', org_id);

        let data = {
            project_stage: req.body.project_stage,
            age_of_property: req.body.age_of_property,
            furnishing: req.body.furnishing,
            built_up_area_min: req.body.built_up_area_min,
            built_up_area_max: req.body.built_up_area_max,
            builtup_area_min_ut: req.body.builtup_area_min_ut,
            builtup_area_max_ut: req.body.builtup_area_max_ut,
            plot_area_min: req.body.plot_area_min,
            plot_area_max: req.body.plot_area_max,
            plot_area_min_ut: req.body.plot_area_min_ut,
            plot_area_max_ut: req.body.plot_area_max_ut,
            tower: req.body.tower,
            uds_min: req.body.uds_min,
            uds_max: req.body.uds_max,
            uds_min_ut: req.body.uds_min_ut,
            uds_max_ut: req.body.uds_max_ut,
            no_of_floors: req.body.no_of_floors,
            no_of_units_min: req.body.no_of_units_min,
            no_of_units_max: req.body.no_of_units_max,
            unit_type_min: req.body.unit_type_min,
            unit_type_max: req.body.unit_type_max,
            ownership_type: req.body.ownership_type,
            balcony: req.body.balcony,
            property_facing: req.body.property_facing,
            kitchen_type: req.body.kitchen_type,
            flooring: req.body.flooring,
            vasthu_compliant: req.body.vasthu_compliant,
            currently_under_loan: req.body.currently_under_loan,
            available_from: req.body.available_from,
            site_visit_preference: req.body.site_visit_preference,
            key_custody: req.body.key_custody,
            no_of_car: req.body.no_of_car,
            car_park_type: req.body.car_park_type,
            water_supply: req.body.water_supply,
            gated_community: req.body.gated_community,
            amenities: req.body.amenities,
            property_highlight: req.body.property_highlight,
            rera_registered: req.body.rera_registered,
            rera_number: req.body.rera_number,
            completion_certificate: req.body.completion_certificate,
            specification: req.body.specification,
        }

        const num = await db2['propertyResidentials'].update(data, {
            where: { property_id: property_id },
        });
        if (num == 1) {

            const propertyLogs = await db2['logs'].create({
                org_id: org_id,
                module_id: property_id,
                module_name: "3",
                note: "Property residentials updated at",
                user_id: created_by.id
            })

            res.status(200).send({
                status: 200,
                message: "Updated successfully."
            });
        } else {
            res.status(200).send({
                status: 404,
                message: `Cannot update with id : ${property_id}.`
            });
        }
    } catch (error) {
        res.status(500).send({
            message: error.message,
        });
    }
};
exports.updatePropertyAddress = async (req, res) => {
    try {
        const id = req.params.id;
        const property_id = req.params.property_id;

        const created_by = req.user.id
        console.log('created_by', created_by.id);

        const organ_id = req.user.id
        const org_id = organ_id.org_id
        console.log('organ_id', org_id);


        let thisQuery = ` select p.id as property_id, pa.name_of_building as property_name
        from lz_properties as p
        left join lz_property_addresses as pa on (p.id = pa.property_id)
        where p.status = 1 and pa.property_id = ${property_id} `

        const data123 = await db2.sequelize.query(thisQuery);
        const dataProperty = data123[0][0]?.property_id
        const dataPropertyName = data123[0][0]?.property_name

        console.log("dataProperty", dataProperty);
        console.log("dataPropertyName", dataPropertyName);


        let data = {
            name_of_building: req.body.name_of_building,
            door_number: req.body.door_number,
            address_line1: req.body.address_line1,
            country: req.body.country,
            state: req.body.state,
            city: req.body.city,
            locality: req.body.locality,
            pincode: req.body.pincode,
            latitude: req.body.latitude,
            longitude: req.body.longitude,
            module_number: req.body.module_number
        }

        const propertyID = req.params.id;

        const num = await db2['propertyAddress'].update(data, {
            where: { property_id: property_id },
        });
        if (num == 1) {
            // Property Name
            if (req.body.name_of_building) {
                let thisQueryPro = ` select p.id as l_property_id, pa.name_of_building as l_property_name
            from lz_properties as p
            left join lz_property_addresses as pa on (p.id = pa.property_id)
            where p.status = 1 and pa.property_id = ${property_id}
            `
                const dataPro = await db2.sequelize.query(thisQueryPro);
                const dataPro1 = dataPro[0][0]?.l_property_id
                const dataPro2 = dataPro[0][0]?.l_property_name
                console.log("dataPro1", dataPro1);
                console.log("dataPro2", dataPro2);

                if (dataPropertyName !== req.body.name_of_building) {
                    const contactPropertyLog = await db2['logs'].create({
                        org_id: org_id,
                        module_id: property_id,
                        module_name: "3",
                        note: 'Property name : ' + dataPropertyName + ' to ' + dataPro2,
                        user_id: created_by.id
                    })
                    console.log("Property Name", contactPropertyLog.dataValues.note);
                }
            }

            res.status(200).send({
                status: 200,
                message: "Updated successfully."
            });
        } else {
            res.status(200).send({
                status: 404,
                message: `Cannot update with id : ${property_id}.`
            });
        }
    } catch (error) {
        res.status(500).send({
            message: error.message,
        });
    }
};
exports.updatePropertyUnitType = async (req, res) => {

    try {
        const organ_id = req.user.id
        const org_id = organ_id.org_id
        console.log('organ_id', org_id);

        const created_by = req.user.id
        console.log('created_by', created_by.id);

        const propertyData = {
            project_unit_type: req.body.project_unit_type,
        }

        const id = req.params.id;
        const property_id = req.params.property_id;
        const num = await db2['propertyResidentials'].update(propertyData, {
            where: { property_id: property_id },
        });
        if (num == 1) {
            const propertyLogs = await db2['logs'].create({
                org_id: org_id,
                module_id: property_id,
                module_name: "3",
                note: "Project unit type updated at",
                user_id: created_by.id
            })
            res.status(200).send({
                status: 200,
                message: "Updated successfully!"
            });
        } else {
            res.status(200).send({
                status: 404,
                message: `Cannot updated with id : ${id}.`
            });
        }
    } catch (error) {
        res.status(500).send({
            message: error.message,
        });
    }
};
exports.updatePropertyStatus = async (req, res) => {
    try {
        const organ_id = req.user.id
        const org_id = organ_id.org_id
        console.log('organ_id', org_id);

        const created_by = req.user.id
        console.log('created_by', created_by.id);

        const id = req.params.id;

        const propertyId = req.params.id;

        let thisQuery = ` select p.property_status as property_status, cs.option_value as property_status_name
        from lz_properties as p
        left join lz_masters as cs on (cs.id = p.property_status)
        where p.status = 1 and p.id = ${id} `

        const data123 = await db2.sequelize.query(thisQuery);
        const dataStatus = data123[0][0]?.property_status
        const dataStatusName = data123[0][0]?.property_status_name

        console.log("dataStatus", dataStatus);
        console.log("dataStatusName", dataStatusName);

        const data = {
            property_status: req.body.property_status,
        }

        const propertyStatus = req.body.property_status
        console.log("propertyStatussss", propertyStatus);

        const num = await db2['property'].update(data, {
            where: { id: id },
        });
        if (num == 1) {

            let thisQuery = ` select option_value from lz_masters where option_type = "property_status" and id = ${propertyStatus} `
            const data = await db2.sequelize.query(thisQuery);
            const dataValue = data[0][0].option_value
            console.log("dataaaaa", dataValue);

            if (req.body.property_status) {
                let thisQuery456 = ` select p.property_status as l_status, cs.option_value as l_status_name
                from lz_properties as p
                left join lz_masters as cs on (cs.id = p.property_status)
                where p.status = 1 and p.property_status = ${req.body.property_status}
                `
                const dataCS = await db2.sequelize.query(thisQuery456);
                const dataCS1 = dataCS[0][0]?.l_status
                const dataCS2 = dataCS[0][0]?.l_status_name
                console.log("dataCS1", dataCS1);
                console.log("dataCS2", dataCS2);

                if (dataStatus.toString() !== req.body.property_status.toString()) {
                    const PropertyStatusLog = await db2['logs'].create({
                        org_id: org_id,
                        module_id: propertyId,
                        module_name: "3",
                        note: 'Property status : ' + dataStatusName + ' to ' + dataCS2,
                        user_id: created_by.id
                    })
                    console.log("Property Status", PropertyStatusLog.dataValues.note);
                }
            }

            res.status(200).send({
                status: 200,
                message: "Updated successfully."
            });
        } else {
            res.status(200).send({
                status: 404,
                message: `Cannot update with id : ${id}.`
            });
        }
    } catch (error) {
        res.status(500).send({
            message: error.message,
        });
    }
};
exports.delete = async (req, res) => {
    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    const created_by = req.user.id
    console.log('created_by', created_by.id);

    try {
        let x = req.params.id

        console.log("id111", x);

        let thisQuery = ` UPDATE lz_properties SET status = 0 `;
        thisQuery += " WHERE id IN (" + x + ") "
        thisQuery += ` and status = 1 `;

        const data = await db2.sequelize.query(thisQuery);

        res.status(200).send({
            status: 200,
            message: 'Success',
            output: data[0]
        });

    } catch (error) {
        res.status(500).send({
            message: error.message,
        });
    }
};

exports.getPropertyTask = async (req, res) => {
    try {

        const created_id = req.user.id
        const created_by = created_id.id
        console.log('created_by', created_by);

        const organ_id = req.user.id
        const org_id = organ_id.org_id
        console.log('organ_id', org_id);

        const role = req.user.id
        const role_id = role.designation
        console.log('role_id', role_id);

        const propertyId = req.params.id

        // let x = `(select contact_id from lz_properties where id = ${propertyId})`
        let thisQuery = ` select t.*, CONVERT(t.assign_to USING utf8) as assign_to, GROUP_CONCAT(distinct CONCAT(us.first_name,' ',IFNULL(us.last_name, ''),'-',us.id)) as assign_to_name, CONCAT(c.first_name,' ',IFNULL(c.last_name, '')) as contact_name, c.email as email, c.mobile as contact_mobile, c.profile_image as contact_profile_image, c.profile_image_original_name as contact_profile_image_original_name, pri.option_value as priority_name, tt.option_value as task_type_name FROM lz_tasks as t 
        LEFT JOIN lz_contacts as c on (c.id = t.contact) 
        LEFT JOIN lz_masters as pri on (pri.id = t.priority) 
        LEFT JOIN lz_masters as tt on (tt.id = t.task_type) 
        LEFT JOIN lz_user as us on FIND_IN_SET(us.id,t.assign_to)>0
        where t.status = 1
        and t.project = ${propertyId} group by t.id
        `
        const data = await db2.sequelize.query(thisQuery);

        res.status(200).send({
            status: 200,
            message: 'Success',
            output: data[0]
        });
    } catch (error) {
        res.status(500).send({
            message: error.message,
        });
    }
};
exports.getPropertyLead = async (req, res) => {
    try {

        const created_id = req.user.id
        const created_by = created_id.id
        console.log('created_by', created_by);

        const organ_id = req.user.id
        const org_id = organ_id.org_id
        console.log('organ_id', org_id);

        const role = req.user.id
        const role_id = role.designation
        console.log('role_id', role_id);

        const propertyId = req.params.id

        // let x = `(select contact_id from lz_properties where id = ${propertyId})`
        let thisQuery = ` select l.*, CONVERT(l.assign_to USING utf8) as assign_to, GROUP_CONCAT(distinct CONCAT(us.first_name,' ',IFNULL(us.last_name, ''),'-',us.id)) as assign_to_name, CONCAT(c.first_name,' ',IFNULL(c.last_name, '')) as contact_name, c.email as email, c.mobile as contact_mobile, c.profile_image as contact_profile_image, c.profile_image_original_name as contact_profile_image_original_name, ls.option_value as lead_status_name, so.option_value as lead_source_name, lr.budget_min as budget_min, lr.budget_max as budget_max FROM lz_leads as l
        LEFT JOIN lz_contacts as c on (c.id = l.contact_id) 
        LEFT JOIN lz_properties as p on (p.id = l.property_id) 
        LEFT JOIN  lz_lead_requirements as lr on (l.id = lr.lead_id) 
        LEFT JOIN lz_user as us on FIND_IN_SET(us.id,l.assign_to)>0
        LEFT JOIN lz_masters as ls on (ls.id = l.lead_status) 
        LEFT JOIN lz_masters as so on (so.id = l.lead_source) 
        where l.status = 1
        and l.property_id = ${propertyId} group by l.id
        `
        const data = await db2.sequelize.query(thisQuery);

        res.status(200).send({
            status: 200,
            message: 'Success',
            output: data[0]
        });
    } catch (error) {
        res.status(500).send({
            message: error.message,
        });
    }
};

// Property Filter
exports.SavePropertyFilter = async (req, res) => {
    try {
        const created_by = req.user.id
        console.log('created_by', created_by.id);

        const organ_id = req.user.id
        const org_id = organ_id.org_id
        console.log('organ_id', org_id);


        let thisQuery1 = ` SELECT id FROM lz_property_filter `
        const data1 = await db2.sequelize.query(thisQuery1);
        const totalProperty = data1[0].length
        console.log("totalProperty", totalProperty);

        if (totalProperty < 5) {

            const data = await db2['propertyFilter'].create({
                org_id: org_id,
                property_id: req.body.property_id,
                available_for: req.body.available_for,
                commission_min: req.body.commission_min,
                commission_max: req.body.commission_max,
                property_type: req.body.property_type,
                property_source: req.body.property_source,
                property_type: req.body.property_type,
                property_status: req.body.property_status,
                country: req.body.country,
                age_of_property_min: req.body.age_of_property_min,
                age_of_property_max: req.body.age_of_property_max,
                property_facing: req.body.property_facing,
                project_stage: req.body.project_stage,
                gated_community: req.body.gated_community,
                vasthu_compliant: req.body.vasthu_compliant,
                buildup_area_min: req.body.buildup_area_min,
                buildup_area_max: req.body.buildup_area_max,
                uds_min: req.body.uds_min,
                uds_max: req.body.uds_max,
                no_of_units_min: req.body.no_of_units_min,
                no_of_units_max: req.body.no_of_units_max,
                no_of_floors_min: req.body.no_of_floors_min,
                no_of_floors_max: req.body.no_of_floors_max,
                rera_registered: req.body.rera_registered,
                filter_name: req.body.filter_name,
                created_date: req.body.created_date,
                updated_date: req.body.updated_date,
                created_by: created_by.id,
            });
            res.status(200).send({
                status: 200,
                message: 'Success',
                output: data
            });
        }
        else {
            res.status(200).send({
                status: 400,
                message: 'Only 5 filters can add',
                output: []
            });
        }
    } catch (error) {
        res.status(500).send({
            message: error.message,
        });
    }
};
exports.getPropertyFilter = async (req, res) => {
    try {
        const organ_id = req.user.id
        const org_id = organ_id.org_id
        console.log('organ_id', org_id);

        const role = req.user.id
        const role_id = role.designation
        console.log('role_id', role_id);

        let thisQuery = `select pf.*
        from lz_property_filter as pf
        where pf.id IS NOT NULL group by pf.id `;

        const data = await db2.sequelize.query(thisQuery);

        res.status(200).send({
            status: 200,
            message: 'Success',
            output: data[0]
        });
    } catch (error) {
        res.status(500).send({
            message: error.message,
        });
    }
};
exports.deletePropertyFilter = async (req, res) => {
    try {
        const id = req.params.id;
        const num = await db2['propertyFilter'].destroy({
            where: { id: id },
        });
        if (num == 1) {
            res.status(200).send({
                status: 200,
                message: "Deleted successfully."
            });
        } else {
            res.status(200).send({
                status: 404,
                message: `Cannot delete with id : ${id}.`
            });
        }
    } catch (error) {
        res.status(500).send({
            message: error.message,
        });
    }
};