module.exports = (sequelize, Sequelize) => {
    return sequelize.define("lz_client_subscription", {
      org_id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        validate : {isInt: true}
      },
      subscription_id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        validate : {isInt: true}
      },
      paid_amount: {
        type: Sequelize.DECIMAL(20,4),
        allowNull: false,
        validate : {isDecimal: true}
      },
      start_date: {
        type: Sequelize.DATE,
        allowNull: false,
        validate: {isDate: true}
      },
      mode_of_payment: {
        type: Sequelize.INTEGER,
        allowNull: true,
        validate : {isInt: true}
      },
      transaction_id: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      transaction_status: {
        type: Sequelize.INTEGER,
        allowNull: true,
        defaultValue:1,
        validate : {isInt: true}
      },
      transaction_time: {
        type: 'TIMESTAMP',
        allowNull: false,
      },
      no_of_days: {
        type: Sequelize.INTEGER,
        allowNull: false,
        validate : {isInt: true}
      },
      created_by: {
        type: Sequelize.INTEGER,
        allowNull: false,
        validate : {isInt: true}
      },
      status: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue:1,
        validate : {isInt: true}
      },
      createdAt: {
        type: 'TIMESTAMP',
        allowNull: true,
        defaultValue:sequelize.literal('CURRENT_TIMESTAMP'),
        field:'created_at'
      },
      updatedAt: {
        type: 'TIMESTAMP',
        allowNull: true,
        defaultValue:sequelize.literal('CURRENT_TIMESTAMP'),
        field:'updated_at'
      },
    },{
      tableName:'lz_client_subscription'
    });
  };
  