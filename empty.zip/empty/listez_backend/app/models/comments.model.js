module.exports = (sequelize, Sequelize) => {
  return sequelize.define("comments", {
    title: {
      type: Sequelize.STRING,
      allowNull: false
    },
    postId: {
      type: Sequelize.INTEGER,
      allowNull: false
    },
  });
};