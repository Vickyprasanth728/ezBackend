module.exports = (sequelize, Sequelize) => {
    return sequelize.define("lz_subscription", {
      subscription_name: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      amount: {
        type: Sequelize.DECIMAL(20,4),
        allowNull: false,
        validate : {isDecimal: true, len: [1,10]}
      },
      no_of_days: {
        type: Sequelize.INTEGER,
        allowNull: false,
        validate : {isDecimal: true, len: [1,10]}
      },
      created_by: {
        type: Sequelize.INTEGER,
        allowNull: false,
        validate : {isInt: true} 
      },
      status: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue:1,
        validate : {isInt: true}
      },
      createdAt: {
        type: 'TIMESTAMP',
        allowNull: true,
        defaultValue:sequelize.literal('CURRENT_TIMESTAMP'),
        field:'created_at'
      },
      updatedAt: {
        type: 'TIMESTAMP',
        allowNull: true,
        defaultValue:sequelize.literal('CURRENT_TIMESTAMP'),
        field:'updated_at'
      },
    },{
      tableName:'lz_subscription'
    });
  };
  