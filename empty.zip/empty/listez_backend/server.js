const express = require("express");
const cors = require("cors");

const app = express();
const session = require('express-session');


global.__basedir = __dirname;

const cors_ = require("./app/config/cors.config");
var corsOptions = {
  origin: cors_.allowed_origins
};

app.use(cors(corsOptions));

app.use(express.json());

app.use(
  express.urlencoded({ extended: true })
);
app.use(session({
  resave: false,
  saveUninitialized: true,
  secret: 'nothing'
}));

const db = require("./app/models");
const db2 = require("./app/zOrganizationFile/orgModel/orgIndex");

async function testConnection() {
  try {
    await db.sequelize.authenticate();

    await db.sequelize.sync();

    // drop the table if it already exists
    // db.sequelize.sync({ force: true }).then(() => {
    //   console.log("Drop and re-sync db.");
    // });

    console.log("Super Admin Database Connected.");

  } catch (e) {
    console.log(e.message);
  }
}

testConnection();

async function testConnection1() {
  try {
    await db2.sequelize.authenticate();

    await db2.sequelize.sync();

    // drop the table if it already exists
    // db.sequelize.sync({ force: true }).then(() => {
    //   console.log("Drop and re-sync db.");
    // });

    console.log("Organization Database Connected.");

  } catch (e) {
    console.log(e.message);
  }
}

testConnection1();

app.get("/", (req, res) => {
  res.json({ message: "Welcome" });
});

require("./app/routes/automationRoutes/auth.routes")(app);
require("./app/routes/automationRoutes/social.routes")(app);
require("./app/routes/automationRoutes/authenticated.routes")(app);
require("./app/routes/automationRoutes/crud.routes")(app);
require("./app/routes/automationRoutes/where.routes")(app);
require("./app/routes/automationRoutes/file.routes")(app);
require("./app/routes/automationRoutes/email.routes")(app);
require("./app/routes/automationRoutes/rel.routes")(app);


require("./app/routes/automationRoutes/users.routes")(app);
require("./app/routes/automationRoutes/country.routes")(app);
require("./app/routes/automationRoutes/state.routes")(app);
require("./app/routes/automationRoutes/city.routes")(app);
require("./app/routes/automationRoutes/currency.routes")(app);
require("./app/routes/automationRoutes/language.routes")(app);
require("./app/routes/automationRoutes/translation.routes")(app);
require("./app/routes/automationRoutes/masters.routes")(app);
require("./app/routes/automationRoutes/subscription.routes")(app);
require("./app/routes/automationRoutes/clientSubscription.routes")(app);
require("./app/routes/automationRoutes/modules.routes")(app);
require("./app/routes/automationRoutes/roles.routes")(app);
require("./app/routes/automationRoutes/supportTicket.routes")(app);
require("./app/routes/automationRoutes/settings.routes")(app);
require("./app/routes/automationRoutes/businessSettings.routes")(app);
require("./app/routes/automationRoutes/userTimeline.routes")(app);
require("./app/routes/automationRoutes/template.routes")(app);
require("./app/routes/automationRoutes/dashboard.routes")(app);
require("./app/routes/automationRoutes/organization.routes")(app);
require("./app/routes/automationRoutes/dropdown.routes")(app);
require("./app/routes/automationRoutes/source.routes")(app);
require("./app/routes/automationRoutes/themeSettings.routes")(app);
require("./app/routes/automationRoutes/report.routes")(app);

// Org
require("./app/zOrganizationFile/orgRoutes/orgRoles.routes")(app);
require("./app/zOrganizationFile/orgRoutes/orgMaster.routes")(app);
require("./app/zOrganizationFile/orgRoutes/organization.routes")(app);
require("./app/zOrganizationFile/orgRoutes/orgUsers.routes")(app);
require("./app/zOrganizationFile/orgRoutes/orgTheme.routes")(app);
require("./app/zOrganizationFile/orgRoutes/orgAuth.routes")(app);
require("./app/zOrganizationFile/orgRoutes/orgTemplate.routes")(app);
require("./app/zOrganizationFile/orgRoutes/orgBranch.routes")(app);
require("./app/zOrganizationFile/orgRoutes/orgUser.routes")(app);
require("./app/zOrganizationFile/orgRoutes/orgSource.routes")(app);
require("./app/zOrganizationFile/orgRoutes/orgTeam.routes")(app);
require("./app/zOrganizationFile/orgRoutes/orgEmailTemplete.routes")(app);
require("./app/zOrganizationFile/orgRoutes/orgWhatsAppTemplate.routes")(app);
require("./app/zOrganizationFile/orgRoutes/orgContacts.routes")(app);
require("./app/zOrganizationFile/orgRoutes/orgLogs.routes")(app);
require("./app/zOrganizationFile/orgRoutes/orgLeads.routes")(app);
require("./app/zOrganizationFile/orgRoutes/orgDropdown.routes")(app);
require("./app/zOrganizationFile/orgRoutes/orgProperty.routes")(app);
require("./app/zOrganizationFile/orgRoutes/orgTasks.routes")(app);
require("./app/zOrganizationFile/orgRoutes/orgTransaction.routes")(app);
require("./app/zOrganizationFile/orgRoutes/orgNotes.routes")(app);
require("./app/zOrganizationFile/orgRoutes/orgFileUploads.routes")(app);
require("./app/zOrganizationFile/orgRoutes/orgExpenses.routes")(app);
require("./app/zOrganizationFile/orgRoutes/orgFinance.routes")(app);
require("./app/zOrganizationFile/orgRoutes/orgAttendance.routes")(app);
require("./app/zOrganizationFile/orgRoutes/orgBusinessSettings.routes")(app);
require("./app/zOrganizationFile/orgRoutes/orgDashboard.routes")(app);
require("./app/zOrganizationFile/orgRoutes/orgUserTimeline.routes")(app);
require("./app/zOrganizationFile/orgRoutes/orgContactSettings.routes")(app);
require("./app/zOrganizationFile/orgRoutes/orgReports.routes")(app);
require("./app/zOrganizationFile/orgRoutes/orgRoundRobin.routes")(app);
require("./app/zOrganizationFile/orgRoutes/emailSettings.routes")(app);


require("./app/routes/app.routes")(app);

const PORT = process.env.PORT || 8080;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}.`);
});