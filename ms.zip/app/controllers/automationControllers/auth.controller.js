const jwt = require("../../helpers/jwt");
const phone_gateway = require("../../helpers/phone-gateway");
const email_gateway = require("../../helpers/email-gateway");

const bcrypt = require("bcrypt");
const saltRounds = 10;

const db = require("../../models");
const Op = db.Sequelize.Op;

const Moment = require('moment')

exports.loginAuth = async (req, res) => {
  try {
    if (!req.body.email || !req.body.password) {
      res.status(200).send({
        status:401,
        message: "Email & Password required.",
      });
      return;
    }

    var condition = {
      where: {
        [Op.or]: [
          {
            email: req.body.email,
          },
        ],
      org_id:1
      },
      attributes: {exclude: ['createdAt','updatedAt']}
    };

    const data = await db[req.params.document].findOne(condition);

    if (!data) {
      res.status(200).send({
        status:404,
        message: "Email not found.",
      });
    } else {
      const match = await bcrypt.compare(req.body.password, data.password);
      if (match) {

        let id = data.id;
        let email = data.email;
        let org_id = data.org_id;
        let designation = data.designation;
        const token = jwt.accessTokenEncode(
          {id: id, email, org_id, designation},
          'the-super-strong-secrect',
          {
            expiresIn: "12h",
          }
        );

        console.log("tokennnnnnnn", token);
        console.log("org_idddddd",org_id);
        console.log("dataaaaaa", data?.dataValues.org_id);

        const data1 = await db['user_timeline'].create({
          login_time: req.body.login_time,
          user_id: id,
        });

        var condition1 = {
          where:{lang:'En'},
          attributes:['id','lang_key','lang_value']
        };

        const LangFetch = await db['translations'].findAll(condition1);
        console.log(LangFetch);

        const obj = LangFetch.reduce((acc, { lang_key, lang_value }) => {
          acc[lang_key] = lang_value;
          return acc;
        }, {});
        // console.log(obj);
        
        var condition2 = {
          where:{org_id:data.org_id}
        }
        const subscriptionFetch = await db['client_subscription'].findOne(condition2);

        var condition3 = {
          where:{id:data.org_id},
          attributes:["approval"]
        }
        const approvalFetch = await db['organization'].findOne(condition3);

        res.status(200).send({
          status:200,
          message:'success',
          access_token:token,
          refresh_token: jwt.refreshTokenEncode(data.id),
          output: data,
          language:obj,
          // subscription:subscriptionFetch,
          approval:approvalFetch.approval,
        });
      } else {
        res.status(200).send({
          status:403,
          message: "Incorrect password",
        });
      }
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};

exports.loginAdminAuth = async (req, res) => {
  try {
    if (!req.body.email || !req.body.password) {
      res.status(200).send({
        status:401,
        message: "Email & Password required.",
      });
      return;
    }

    var condition = {
      where: {
        [Op.or]: [
          {
            email: req.body.email,
          },
        ],
        org_id: {
          [Op.ne]: 1
        },
      },
      // attributes: {exclude: ['createdAt','updatedAt']}
    };

    const data = await db[req.params.document].findOne(condition);

    if (!data) {
      res.status(200).send({
        status:404,
        message: "Email not found.",
      });
    } else {
      const match = await bcrypt.compare(req.body.password, data.password);
      if (match) {

        let id = data.id;
        let email = data.email;
        let org_id = data.org_id;
        let designation = data.designation;
        const token = jwt.accessTokenEncode(
          {id: id, email, org_id:data.org_id, designation},
          'the-super-strong-secrect',
          {
            expiresIn: "12h",
          }
        );

        console.log("tokennnnnnnn", token);
        const data1 = await db['user_timeline'].create({
          login_time: req.body.login_time,
          user_id: id,
        });

        var condition1 = {
          attributes:['id','lang_key','lang_value']
        };

        const LangFetch = await db['translations'].findAll(condition1);
        console.log(LangFetch);

        const obj = LangFetch.reduce((acc, { lang_key, lang_value }) => {
          acc[lang_key] = lang_value;
          return acc;
        }, {});
        // console.log(obj);

        var condition2 = {
          where:{status:1, org_id:data.org_id}
        }
        const subscriptionFetch = await db['client_subscription'].findOne(condition2);

        var condition3 = {
          where:{id:data.org_id},
          attributes:["approval"]
        }
        const approvalFetch = await db['organization'].findOne(condition3);
        console.log('approvalFetchhhh', approvalFetch.dataValues.approval);

        const created_by = data.org_id
        console.log('created_by111', created_by);
    
        const id1 = req.params.id;
        const getData = await db['client_subscription'].findAll({
            where:{status:1,org_id :data.org_id},
            attributes:["id",'start_date','no_of_days','org_id']
        });

        console.log("clientSubs", getData[0]?.dataValues.org_id);
    
        const dateNum = getData[0]?.dataValues.start_date
        console.log('dateNum',dateNum);
    
        const NoOfDays = getData[0]?.dataValues.no_of_days
        console.log('NoOfDays',NoOfDays);
    
        const checkdate = (startingDate, number, add) => {
          if (add) {
            return new Date(new Date().setDate(startingDate?.getDate() + number));
          } else {
            return new Date(new Date().setDate(startingDate?.getDate() - number));
          }
        }
        // console.log('Today : ' + new Date());
        // console.log('Past : ' + checkdate(new Date(), 5, false));
        console.log('Future : ' + checkdate(dateNum, NoOfDays, true));
    
        const expireDate = checkdate(dateNum, NoOfDays, true)
        const TodayDate = new Date()
        console.log("expireDate", expireDate);
        console.log('TodayDate', TodayDate);
    
        const FinalExpiredDate = {
          expireDate: Moment(expireDate).format('YYYY-MM-DD'),
          }
          // console.log("FinalExpiredDate",FinalExpiredDate.expireDate);
    
        const FinalTodayDate = {
          TodayDate: Moment.utc().format('YYYY-MM-DD'),
          }
          console.log("FinalTodayDate",FinalTodayDate.TodayDate);
    
          const logindata = await db['user_timeline'].findOne({
            where:{user_id :created_by},
            order:[["id", "desc"]]
          });
          console.log("logindata", logindata.dataValues.user_id);
          console.log("logindataID", logindata.dataValues.id);
    
          const loginCheckDate = logindata?.dataValues.login_time
    
          const loginDate = {
            LoginDate: Moment.utc(loginCheckDate).format('YYYY-MM-DD'),
            }
          console.log("FinalExpiredDate",FinalExpiredDate.expireDate);
          console.log("loginDate",loginDate.LoginDate);
          
          let ed = FinalExpiredDate.expireDate
          let ld = loginDate.LoginDate

          console.log("PlanExpireDate",ed);
          console.log("AdminLogindate",ld);
            
        if(ed.toString() < ld.toString()) {
          const subsdata = {
            status: 0
          }
    
          const num = await db['client_subscription'].update(subsdata, {
            where: { status:1, org_id: data.org_id },
          });
        } 

        var condition4 = {
          where:{status:1, org_id:data.org_id},
          attributes:["status"]
        }
        const statusFetch = await db['client_subscription'].findOne(condition4);
        console.log('statusFetch', statusFetch?.status ? statusFetch?.status : null);

        // if (getData) {

        res.status(200).send({
          status:200,
          message:"success",
          access_token:token,
          refresh_token: jwt.refreshTokenEncode(data.id),
          output: data,
          language:obj,
          subscription:subscriptionFetch,
          approval:approvalFetch.approval,
          subscription_status:statusFetch?.status ? statusFetch?.status : null,
          expire_date: ed,
          // plan:getData,
        });
      // }
     }else {
        res.status(200).send({
          status:403,
          message: "Incorrect password",
        });
      }
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};

exports.createAuth = async (req, res) => {
  try {
    if (!req.body.email || !req.body.password) {
      res.status(400).send({
        message: "Email & Password required.",
      });
      return;
    }

    var condition = {
      where: {
        [Op.and]: [
          {
            email: req.body.email,
          },
        ],
      },
    };

    const user = await db[req.params.document].findOne(condition);

    if (user) {
      res.status(400).send({
        message: "Email already in use.",
      });
    } else {
      bcrypt.hash(req.body.password, saltRounds, async function (error, hash) {
        req.body.password = hash;
        const users = new db[req.params.document](req.body);
        const data = await users.save(users);

        res.send({
          access_token: jwt.accessTokenEncode(data.id),
          refresh_token: jwt.refreshTokenEncode(data.id),
          user: data,
        });
      });
    }
  } catch (error) {
    console.log(error);
    res.status(500).send({
      message: error.message,
    });
  }
};

exports.changePassword = async (req, res) => {
  try {
    bcrypt.hash(req.body.password, saltRounds, async function (error, hash) {
      req.body.password = hash;

      const id = req.params.id;

      const userIdFetch = await db['users'].findOne({
        where: {
          [Op.or]: [
            { email: req.body.email },
            { password: req.body.oldpassword },
          ]
        },
      });

      const match = await bcrypt.compare(req.body.oldpassword, userIdFetch?.dataValues.password);
      console.log("matchhhhhhh", match);

      const user_verification = userIdFetch?.dataValues ? userIdFetch?.dataValues["id"] : 0
      const x = userIdFetch?.dataValues
      console.log('userIdFetchhhhhhhhhh', userIdFetch?.dataValues);
      console.log('user_verificationnnnnnnnnnnn', user_verification);

      console.log('x', x);
      console.log('oldpassword', req.body.oldpassword);
      console.log('password', req.body.password);

      if (match) {
        const data = {
          password: req.body.password
        }
        const num = await db['users'].update(data, {
          where: { email: req.body.email },
        });
        if (num == 1) {
          res.status(200).send({
            status: 200,
            message: "Updated successfully."
          });
        } else {
          res.status(200).send({
            status: 404,
            message: `Cannot update with id : ${id}.`
          });
        }
      }
      else {
        res.status(200).send({
          status: 400,
          message: `Wrong old password.`
        });
      }
    })
  }
  catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};

exports.accessToken = async (req, res) => {
  if (!req.body.access_token) {
    res.status(400).send({
      message: "Access token is required.",
    });
    return;
  }

  jwt.accessTokenDecode(async function (e) {
    if (e.status) {
      try {
        const user = await db[req.params.document].findByPk(e.data.id);
        if (!user) {
          res.status(404).send({
            message: "No user found.",
          });
        } else {
          res.send(user);
        }
      } catch (error) {
        res.status(500).send({
          message: error.message || "Something went wrong.",
        });
      }
    } else {
      res.status(e.code).send({
        message: e.message,
      });
    }
  }, req.body.access_token);
};

exports.refreshToken = async (req, res) => {
  if (!req.body.refresh_token) {
    res.status(400).send({
      message: "Refresh token is required.",
    });
    return;
  }

  jwt.refreshTokenDecode(function (e) {
    if (e.status) {
      res.send({
        access_token: jwt.accessTokenEncode(e.data.id),
        refresh_token: jwt.refreshTokenEncode(e.data.id),
      });
    } else {
      res.status(e.code).send({
        message: e.message,
      });
    }
  }, req.body.refresh_token);
};

exports.sendResetCodeInEmail = async (req, res) => {
  try {
    if (!req.body.email) {
      res.status(400).send({
        message: "Email required.",
      });
      return;
    }

    var condition = {
      where: {
        [Op.or]: [
          {
            email: req.body.email,
          },
        ],
      },
    };

    const data = await db[req.params.document].findOne(condition);

    if (!data) {
      res.status(400).send({
        message: "Email not found.",
      });
    } else {
      req.body.token = Math.floor(1000 + Math.random() * 9000);
      data.token = req.body.token;

      const result = await email_gateway.forgotPassword(data);

      if (result) {
        const tokens = new db["tokens"](req.body);
        await tokens.save(tokens);
        res.send({
          message: "Verification code has been sent.",
          email: req.body.email,
        });
      } else {
        res.status(401).send({
          message: result,
        });
      }
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};

exports.resetPassword = async (req, res) => {
  try {
    if (!req.body.email || !req.body.password || !req.body.token) {
      res.status(400).send({
        message: "Email & Password & Verification code is required.",
      });
      return;
    }

    var condition = {
      where: {
        [Op.and]: [
          {
            email: req.body.email,
          },
          {
            token: req.body.token,
          },
        ],
      },
    };

    const token_data = await db["tokens"].findOne(condition);

    if (!token_data) {
      res.status(400).send({
        message: "Verification code is invalid.",
      });
    } else {
      bcrypt.hash(req.body.password, saltRounds, async function (error, hash) {
        req.body.password = hash;
        const data = await db[req.params.document].update(
          { password: req.body.password },
          { where: { email: req.body.email } }
        );

        await db["tokens"].destroy({
          where: { id: token_data.id },
        });

        res.send({
          message: "Password has been updated. Now you can login.",
        });
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};

exports.createAuthWithPhone = async (req, res) => {
  try {
    if (!req.body.phone) {
      res.status(400).send({
        message: "Phone is required.",
      });
      return;
    }

    req.body.token = Math.floor(1000 + Math.random() * 9000);

    const result = await phone_gateway.sendOTP(req.body.phone, req.body.token);
    if (result) {
      const tokens = new db["tokens"]({
        token: req.body.token,
        phone: req.body.phone,
      });
      await tokens.save(tokens);

      const auth_data = await db[req.params.document].findOne({
        where: {
          [Op.and]: {
            phone: req.body.phone,
          },
        },
      });
      if (auth_data) {
        res.send({
          message: result.message,
          phone: req.body.phone,
        });
      } else {
        const users = new db[req.params.document](req.body);
        await users.save(users);
        res.send({
          message: result.message,
          phone: req.body.phone,
        });
      }
    } else {
      res.status(401).send({
        message: result.message,
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.createAuthWithPhoneVerify = async (req, res) => {
  try {
    if (!req.body.phone || !req.body.token) {
      res.status(400).send({
        message: "Phone & Verification code is required.",
      });
      return;
    }

    var condition = {
      where: {
        [Op.and]: {
          phone: req.body.phone,
          token: req.body.token,
        },
      },
    };

    const token_data = await db["tokens"].findOne(condition);

    if (token_data) {
      const auth_data = await db[req.params.document].findOne({
        where: {
          [Op.and]: {
            phone: req.body.phone,
          },
        },
      });
      if (auth_data) {
        await db["tokens"].destroy({
          where: { phone: token_data.phone },
        });

        res.send({
          access_token: jwt.accessTokenEncode(auth_data),
          refresh_token: jwt.refreshTokenEncode(auth_data),
          user: auth_data,
        });
      } else {
        res.status(400).send({
          message: "No user has been found.",
        });
      }
    } else {
      res.status(400).send({
        message: "The verification code did not match.",
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
