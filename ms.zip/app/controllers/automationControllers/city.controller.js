const db = require("../../models");
const Op = db.Sequelize.Op;

exports.create = async (req, res) => {
  try {
    const created_by = req.user.id
    console.log('created_by', created_by.id);
    
    const cityData = await db['city'].findOne({
      where: {status:1, name:`${req.body.name}`},
      attributes:['name']
    });
    console.log("cityData", cityData);
    const executives = cityData?.dataValues ? cityData?.dataValues.name : 0

    if (executives !== 0) {
      res.status(200).send({
        status:400,
        message: "City Already Exists.",
      });
    } else {
    const data = await db[req.params.document].create({
      country_id: req.body.country_id,
      state_id: req.body.state_id,
      name: req.body.name,
      created_by: created_by.id
    });
    res.status(200).send({
      status:200,
      message:'Success',
      output:data
    });
  }} catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};

exports.findAll = async (req, res) => {
  try {
    var condition = {
      where:{
        status:1
      },
      order: [['name', 'ASC']], // ASC, DESC
      attributes:['id','name','country_id','state_id'],
      include: [
        {
          model: db["country"],
          attributes: [['name', 'country_name']],
          where: {},
          required: false,
        },
        {
          model: db["state"],
          attributes:[['name','state_name']],
          where: {},
          required: false,
        },
      ],
    };
    var offset = parseInt(req.query.offset);
    var limit = parseInt(req.query.limit);

    if (offset >= 0 && limit >= 0) {
      condition.offset = offset;
      condition.limit = limit;
    }

    const data = await db[req.params.document].findAll(condition);
    res.status(200).send({
      status:200,
      message:'Success',
      output:data
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};

exports.findOne = async (req, res) => {
  try {
    var condition = {
      where:{
        status:1
      },
    };
    const id = req.params.id;
    const data = await db[req.params.document].findByPk(id,condition);
    if (data) {
      res.status(200).send({
        status:200,
        message:'Success',
        output:data
        });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot find with id : ${id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};

exports.update = async (req, res) => {
  try {
    const id = req.params.id;
    const countryID = await db['city'].findOne({
      where: {status:1, id: id},
    });
    const countryData = countryID?.dataValues ? countryID?.dataValues.id : 0
    console.log("countryData", countryData);

    const countryCheck = await db['city'].findOne({
      where: {
        id: {
          [Op.ne]: countryData
        },
        name:`${req.body.name}`,
        status:1,
      },
      attributes:['name']
    });
    const checkData = countryCheck?.dataValues ? countryCheck?.dataValues.id : 0

    if (checkData !== 0) {
      res.status(200).send({
        status:400,
        message: "City Already Exists.",
      });
    } else {
    const id = req.params.id;
    const num = await db[req.params.document].update(req.body, {
      where: { id: id ,status:1},
    });
    if (num == 1) {
      res.status(200).send({
        status:200,
        message: "Updated successfully."
      });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot update with id : ${id}.`
      });
    }
  }} catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};

exports.delete = async (req, res) => {  
  const cityData = {
    status: 0,
  }
  try {
    const id = req.params.id;
    const num = await db[req.params.document].update(cityData, {
      where: { id: id },
    });
    if (num == 1) {
      res.status(200).send({
        status:200,
        message: "Deleted successfully!"
      });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot delete with id : ${id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};

exports.deleteAll = async (req, res) => {
  try {
    const num = await db[req.params.document].destroy({
      where: {},
      truncate: false,
    });
    res.send({
      message: `${num} has been deleted.`,
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};