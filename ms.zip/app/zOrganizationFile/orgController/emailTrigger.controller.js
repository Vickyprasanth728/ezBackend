const db2 = require("../orgModel/orgIndex.js");
const Op = db2.Sequelize.Op;


exports.getEmailTrigger = async (req, res) => {
    try {
      
    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);
    
    let thisQuery = ` SELECT et.*
    FROM lz_email_trigger as et
    WHERE et.id IS NOT NULL
    GROUP BY et.id
    `
    const data = await db2.sequelize.query(thisQuery);

    const obj = data[0].reduce((acc, { options, status }) => {
        acc[options] = status;
        return acc;
      }, {});
     
      res.status(200).send({
        status:200,
        message:'Success',
        output:obj
      });
    } catch (error) {
      res.status(500).send({
        message: error.message,
      });
    }
};
exports.updateEmailTrigger = async (req, res) => {
    try {
      const options = req.params.options;
      const data = {
          status: req.body.status
      }
      const num = await db2['emailTrigger'].update(data, {
        where: {options:options},
      });
      if (num == 1) {
        res.status(200).send({
          status:200,
          message: "Updated successfully."
        });
      } else {
        res.status(200).send({
          status:404,
          message: `Cannot update with options : ${options}.`
        });
      }
    } catch (error) {
      res.status(500).send({
        message: error.message,
      });
    }
};