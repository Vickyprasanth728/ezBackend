const orgDbConfig = require("../orgConfig/orgDb.config.js");
const db2 = require("../orgModel/orgIndex.js");
const db = require("../../models");
const Op = db2.Sequelize.Op;

exports.citySave = async (req, res) => {
try {
    const created_by = req.user.id
    console.log('created_by', created_by.id);
    
    const cityData = await db2['city'].findOne({
    where: {status:1, name:`${req.body.name}`},
    attributes:['name']
    });
    console.log("cityData", cityData);
    const executives = cityData?.dataValues ? cityData?.dataValues.name : 0

    if (executives !== 0) {
    res.status(200).send({
        status:400,
        message: "City Already Exists.",
    });
    } else {
    const data = await db2['city'].create({
    country_id: req.body.country_id,
    state_id: req.body.state_id,
    name: req.body.name,
    created_by: created_by.id
    });
    res.status(200).send({
    status:200,
    message:'Success',
    output:data
    });
}} catch (error) {
    res.status(500).send({
    message: error.message,
    });
}
};

exports.cityList = async (req, res) => {
try {
    const id = req.params.id;
    
    let thisQuery = ` SELECT ci.id as id, ci.name as name, cou.id as country_id, st.id as state_id, cou.name as country_name, st.name as state_name
    FROM lz_city as ci 
    left join lz_country as cou on (cou.id = ci.country_id)
    left join lz_state as st on (st.id = ci.state_id)
    where ci.status = 1 `
    const data = await db2.sequelize.query(thisQuery);

    res.status(200).send({
        status:200,
        message:'Success',
        output:data[0]
    });
} catch (error) {
    res.status(500).send({
    message: error.message,
    });
}
};

exports.cityEdit = async (req, res) => {
try {
    const id = req.params.id;
    
    let thisQuery = ` SELECT ci.id as id, ci.name as name, cou.id as country_id, st.id as state_id, cou.name as country_name, st.name as state_name
    FROM lz_city as ci 
    left join lz_country as cou on (cou.id = ci.country_id)
    left join lz_state as st on (st.id = ci.state_id)
    where ci.status = 1 and ci.id = ${id}`
    const data = await db2.sequelize.query(thisQuery);

    if (data) {
    res.status(200).send({
        status:200,
        message:'Success',
        output:data[0][0]
        });
    } else {
    res.status(200).send({
        status:404,
        message: `Cannot find with id : ${id}.`
    });
    }
} catch (error) {
    res.status(500).send({
    message: error.message,
    });
}
};

exports.cityUpdate = async (req, res) => {
try {
    const id = req.params.id;
    const countryID = await db2['city'].findOne({
    where: {status:1, id: id},
    });
    const countryData = countryID?.dataValues ? countryID?.dataValues.id : 0
    console.log("countryData", countryData);

    const countryCheck = await db2['city'].findOne({
    where: {
        id: {
        [Op.ne]: countryData
        },
        name:`${req.body.name}`,
        status:1,
    },
    attributes:['name']
    });
    const checkData = countryCheck?.dataValues ? countryCheck?.dataValues.id : 0

    if (checkData !== 0) {
    res.status(200).send({
        status:400,
        message: "City Already Exists.",
    });
    } else {
    const id = req.params.id;
    const num = await db2['city'].update(req.body, {
    where: { id: id ,status:1},
    });
    if (num == 1) {
    res.status(200).send({
        status:200,
        message: "Updated successfully."
    });
    } else {
    res.status(200).send({
        status:404,
        message: `Cannot update with id : ${id}.`
    });
    }
}} catch (error) {
    res.status(500).send({
    message: error.message,
    });
}
};

exports.cityDelete = async (req, res) => {  
const cityData = {
    status: 0,
}
try {
    const id = req.params.id;
    const num = await db2['city'].update(cityData, {
    where: { id: id },
    });
    if (num == 1) {
    res.status(200).send({
        status:200,
        message: "Deleted successfully!"
    });
    } else {
    res.status(200).send({
        status:404,
        message: `Cannot delete with id : ${id}.`
    });
    }
} catch (error) {
    res.status(500).send({
    message: error.message,
    });
}
};