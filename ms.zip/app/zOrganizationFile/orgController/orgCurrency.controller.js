const orgDbConfig = require("../orgConfig/orgDb.config.js");
const db2 = require("../orgModel/orgIndex.js");
const db = require("../../models");
const Op = db2.Sequelize.Op;

exports.currencySave = async (req, res) => {
try {
    const created_by = req.user.id
    console.log('created_by', created_by.id);

    const currencyData = await db2['currency'].findOne({
    where: {status:1, name:`${req.body.name}`},
    attributes:['name','symbol']
    });
    console.log("currencyData", currencyData);
    const executives = currencyData?.dataValues ? currencyData?.dataValues.name : 0

    if (executives !== 0) {
    res.status(200).send({
        status:400,
        message: "Currency Already Exists.",
    });
    } else {
    const data = await db2['currency'].create({
    name: req.body.name,
    symbol: req.body.symbol,
    created_by: created_by.id
    });
    res.status(200).send({
    status:200,
    message:'Success',
    output:data
    });
}} catch (error) {
    res.status(500).send({
    message: error.message,
    });
}
};
exports.currencyList = async (req, res) => {
try {
    const id = req.params.id;
    
    let thisQuery = ` SELECT id, name, symbol FROM lz_currency where status = 1 `
    const data = await db2.sequelize.query(thisQuery);
    res.status(200).send({
    status:200,
    message:'Success',
    output:data[0]
    });
} catch (error) {
    res.status(500).send({
    message: error.message,
    });
}
};
exports.currencyEdit = async (req, res) => {
try {
    const id = req.params.id;
    
    let thisQuery = ` SELECT id, name, symbol FROM lz_currency where status = 1 and id = ${id} `
    const data = await db2.sequelize.query(thisQuery);

    if (data) {
    res.status(200).send({
        status:200,
        message:'Success',
        output:data[0][0]
    });
    } else {
    res.status(200).send({
        status:404,
        message: `Cannot find with id : ${id}.`
    });
    }
} catch (error) {
    res.status(500).send({
    message: error.message,
    });
}
};
exports.currencyUpdate = async (req, res) => {
try {
    const id = req.params.id;
    const countryID = await db2['currency'].findOne({
    where: {id: id},
    });
    const countryData = countryID?.dataValues ? countryID?.dataValues.id : 0
    console.log("countryData", countryData);

    const countryCheck = await db2['currency'].findOne({
    where: {
        id: {
        [Op.ne]: countryData
        },
        name:`${req.body.name}`,
    },
    attributes:['name']
    });
    const checkData = countryCheck?.dataValues ? countryCheck?.dataValues.id : 0

    if (checkData !== 0) {
    res.status(400).send({
        status:400,
        message: "Currency Already Exists.",
    });
    } else {
    const id = req.params.id;
    const num = await db2['currency'].update(req.body, {
    where: { id: id,status:1 },
    });
    if (num == 1) {
    res.status(200).send({
        status:200,
        message: "Updated successfully."
    });
    } else {
    res.status(200).send({
        status:404,
        message: `Cannot update with id : ${id}.`
    });
    }
}} catch (error) {
    res.status(500).send({
    message: error.message,
    });
}
};
exports.currencyDelete = async (req, res) => {
const currencyData = {
    status: 0,
}
try {
    const id = req.params.id;
    const num = await db2['currency'].update(currencyData,{
    where: { id: id },
    });
    if (num == 1) {
    res.status(200).send({
        status:200,
        message: "Deleted successfully!"
    });
    } else {
    res.status(200).send({
        status:404,
        message: `Cannot delete with id : ${id}.`
    });
    }
} catch (error) {
    res.status(500).send({
    message: error.message,
    });
}
};