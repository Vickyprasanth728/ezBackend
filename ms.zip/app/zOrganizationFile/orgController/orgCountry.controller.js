const orgDbConfig = require("../orgConfig/orgDb.config.js");
const db2 = require("../orgModel/orgIndex.js");
const db = require("../../models");
const Op = db2.Sequelize.Op;

exports.countrySave = async (req, res) => {
try {
    const created_by = req.user.id
    console.log('created_by', created_by.id);

    const countryData = await db2['country'].findOne({
    where: {status:1, name:`${req.body.name}`},
    attributes:['name']
    });
    console.log("countryData", countryData);
    const executives = countryData?.dataValues ? countryData?.dataValues.name : 0

    if (executives !== 0) {
    res.status(200).send({
        status:400,
        message: "Country Already Exists.",
    });
    } else {
    const data = await db2['country'].create({
    name: req.body.name,
    created_by: created_by.id
    });
    res.status(200).send({
        status:200,
        message: 'Successfully',
        output:data
    });
} } catch (error) {
    res.status(500).send({
    message: error.message,
    });
}
};
exports.countryList = async (req, res) => {
try {
    var condition = {
    where:{
        status:1
    },
    order: [['name', 'ASC']], // ASC, DESC
    attributes:['id','name']
    };
    var offset = parseInt(req.query.offset);
    var limit = parseInt(req.query.limit);

    if (offset >= 0 && limit >= 0) {
    condition.offset = offset;
    condition.limit = limit;
    }

    const data = await db2['country'].findAll(condition);
    res.status(200).send({
        status:200,
        message: 'Success',
        output:data
    });
    
} catch (error) {
    res.status(500).send({
    message: error.message,
    });
}
};
exports.countryEdit = async (req, res) => {
try {
    const id = req.params.id;
    
    let thisQuery = ` SELECT id, name FROM lz_country where status = 1 and id = ${id}`
    const data = await db2.sequelize.query(thisQuery);

    if (data) {
    res.status(200).send({
        status:200,
        message: 'Success',
        output:data[0][0]
        });
    } else {
    res.status(200).send({
        status: 404,
        message: `Cannot find with id : ${id}.`
    });
    }
} catch (error) {
    res.status(500).send({
    message: error.message,
    });
}
};
exports.countryUpdate = async (req, res) => {
try {
    const id = req.params.id;
    const countryID = await db2['country'].findOne({
    where: {status:1, id: id},
    });
    const countryData = countryID?.dataValues ? countryID?.dataValues.id : 0
    console.log("countryData", countryData);

    const countryCheck = await db2['country'].findOne({
    where: {
        id: {
        [Op.ne]: countryData
        },
        status:1,
        name:`${req.body.name}`,
    },
    attributes:['name']
    });
    const checkData = countryCheck?.dataValues ? countryCheck?.dataValues.id : 0

    if (checkData !== 0) {
    res.status(200).send({
        status:400,
        message: "Country Already Exists.",
    });
    } else {
    const id = req.params.id;
    const num = await db2['country'].update(req.body, {
    where: { id: id, status:1},
    });
    if (num == 1) {
    res.status(200).send({
        status:200,
        message: "Updated successfully."
    });
    } else {
    res.status(200).send({
        status:404,
        message: `Cannot update with id : ${id}.`
    });
    }
}} catch (error) {
    res.status(500).send({
    message: error.message,
    });
}
};
exports.countryDelete = async (req, res) => {
    const CountryData = {
      status: 0,
    }
    try {
      const id = req.params.id;
  
      const thisQuery45 = ` SELECT country_id FROM lz_state where country_id = ${id} and status = 1 limit 1 `
      const data45 = await db2.sequelize.query(thisQuery45);
  
      const stateDelete = data45[0]
  
      console.log("StateDataaaaaa",stateDelete[0]);
  
      const executives = stateDelete[0] ? stateDelete[0].country_id : 0
      console.log("executivesssssss", executives);
      if (executives) { 
        res.status(200).send({
          status: 400,
          message: "Country In-active!"
        });
      } else {
      const num = await db2['country'].update(CountryData,{
        where: { id: id },
      });
  
      if (num == 1) {
        res.status(200).send({
          status: 200,
          message: "Deleted successfully!"
        });
      } else {
        res.status(200).send({
          status: 404,
          message: `Cannot delete with id : ${id}.`
        });
      }
    }} catch (error) {
      res.status(500).send({
        message: error.message,
      });
    }
  };