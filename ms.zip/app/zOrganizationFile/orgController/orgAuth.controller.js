const jwt = require("../../helpers/jwt");
const phone_gateway = require("../../helpers/phone-gateway");
const email_gateway = require("../../helpers/email-gateway");

const bcrypt = require("bcrypt");
const saltRounds = 10;

const db2 = require("../orgModel/orgIndex.js");
const db = require("../../models");
const Op = db2.Sequelize.Op;

const Moment = require('moment')

exports.loginOrgAuth = async (req, res) => {
  try {
    if (!req.body.email || !req.body.password) {
      res.status(200).send({
        status:401,
        message: "Email & Password required.",
      });
      return;
    }

    var condition = {
      where: {
        [Op.or]: [
          {
            email: req.body.email,
          },
        ], status:1
      },
      // attributes: {exclude: ['createdAt','updatedAt']}
    };

    const data = await db2['user'].findOne(condition);

    if (!data) {
      res.status(200).send({
        status:404,
        message: "Email not found.",
      });
    } else {
      const match = await bcrypt.compare(req.body.password, data.password);
      if (match) {

        let id = data.id;
        let email = data.email;
        let org_id = data.org_id;
        let designation = data.designation;
        const token = jwt.accessTokenEncode(
          {id: id, email, org_id:data.org_id, designation},
          'the-super-strong-secrect',
          {
            expiresIn: "24h",
          }
        );

        const data123 = await db2['logoutTimeline'].create({
          login_time:Moment.utc().format('YYYY-MM-DD'),
          user_id: id,
        });
        
        console.log("tokennnnnnnn", token);
        console.log("org_iddddddddddd", data.org_id);

        const LangFetch = await db['translations'].findAll({
          where:{lang:'En'},
          attributes:['id','lang_key','lang_value']
        });
        // console.log(LangFetch);

        const obj = LangFetch.reduce((acc, { lang_key, lang_value }) => {
          acc[lang_key] = lang_value;
          return acc;
        }, {});

        var condition3 = {
          where:{id:data.org_id},
          attributes:["approval"]
        }
        const approvalFetch = await db['organization'].findOne(condition3);
        // console.log('approvalFetchhhh', approvalFetch?.dataValues.approval);

        const created_by = data.org_id
        console.log('created_by111', created_by);
    
        const id1 = req.params.id;
        const getData = await db['client_subscription'].findAll({
            where:{status:1, org_id:data.org_id},
            attributes:["id",'start_date','no_of_days','org_id']
        });

        // const data1 = await db['user_timeline'].create({
        //   login_time: Moment.utc().format('YYYY-MM-DD'),
        //   user_id: data.org_id,
        // });

        console.log("clientSubs", getData[0]?.dataValues.org_id);
    
        const dateNum = getData[0]?.dataValues.start_date
        console.log('dateNum',dateNum);
    
        const NoOfDays = getData[0]?.dataValues.no_of_days
        console.log('NoOfDays',NoOfDays);
    
        const checkdate = (startingDate, number, add) => {
          if (add) {
            return new Date(new Date().setDate(startingDate?.getDate() + number));
          } else {
            return new Date(new Date().setDate(startingDate?.getDate() - number));
          }
        }
        // console.log('Today : ' + new Date());
        // console.log('Past : ' + checkdate(new Date(), 5, false));
        console.log('Future : ' + checkdate(dateNum, NoOfDays, true));
        let eeeeee = Moment.utc(dateNum).add(NoOfDays - 0, "days").format('YYYY-MM-DD')
        console.log('eeeeeeeeeeee', eeeeee);
    
        const expireDate = checkdate(dateNum, NoOfDays, true)
        const TodayDate = new Date()
        console.log("expireDate", expireDate);
        console.log('TodayDate', TodayDate);
    
        const FinalExpiredDate = {
          expireDate: Moment(expireDate).format('YYYY-MM-DD'),
          }
          // console.log("FinalExpiredDate",FinalExpiredDate.expireDate);
    
        const FinalTodayDate = {
          TodayDate: Moment.utc().format('YYYY-MM-DD'),
          }
          console.log("FinalTodayDate",FinalTodayDate.TodayDate);
    
          const logindata = await db['user_timeline'].findOne({
            where:{user_id :created_by},
            order:[["id", "desc"]]
          });
          console.log("logindata", logindata?.dataValues.user_id);
          console.log("logindataID", logindata?.dataValues.id);
    
          const loginCheckDate = logindata?.dataValues.login_time
    
          const loginDate = {
            LoginDate: Moment.utc(loginCheckDate).format('YYYY-MM-DD'),
            }
          console.log("FinalExpiredDate",FinalExpiredDate.expireDate);
          console.log("loginDate",loginDate.LoginDate);
          
          let ed = FinalExpiredDate.expireDate
          let ld = loginDate.LoginDate

          console.log("PlanExpireDate",ed);
          console.log("AdminLogindate",ld);
            
        if(eeeeee.toString() < ld.toString()) {
          const subsdata = {
            status: 0
          }
    
          const num = await db['client_subscription'].update(subsdata, {
            where: { status:1, org_id: data.org_id },
            order:[['id','DESC']]
          });
        } 

        var condition4 = {
          where:{status:1, org_id:data.org_id},
          attributes:["status"]
        }
        const statusFetch = await db['client_subscription'].findOne(condition4);
        console.log('statusFetch', statusFetch?.status ? statusFetch?.status : null);

        var condition2 = {
          where:{status:1, org_id:data.org_id}
        }
        const subscriptionFetch = await db['client_subscription'].findOne(condition2);

        const getThemeData = await db2['businessSettings'].findAll({
          where:{
            status:1
          },
          order: [['id', 'DESC']], // ASC, DESC
          attributes:['id','option_type','option_value']
        });

        const themeData = getThemeData.reduce((acc, { option_type, option_value }) => {
          acc[option_type] = option_value;
          return acc;
          }, {});

        // Attendance Check-IN
        const checkINFetch = await db2['attendance'].findOne({
          // where : {user_id: data.id},
          where: {
            [Op.and]: [
              { user_id: data.id },
              { status: 1 }
            ]
          },
          order: [
            ['id', 'DESC'],
        ],
        });
        console.log("checkINFetch" , checkINFetch?.user_id, Moment.utc(checkINFetch?.start).format('YYYY-MM-DD'));
        const attCheck = Moment.utc(checkINFetch ? checkINFetch?.start : 0).format('YYYY-MM-DD') == Moment.utc().format('YYYY-MM-DD')
        const finalAtt = `${attCheck == true ? 1 : 0}`
        console.log("attCheck : " , attCheck, "attCheck : ",finalAtt);
        console.log("startTimeCheck : " , Moment.utc(checkINFetch?.start).format('YYYY-MM-DD'));

        // if (getData) {

        res.status(200).send({
          status:200,
          message:"success",
          att: Moment.utc(checkINFetch?.start).format('YYYY-MM-DD'),
          attNow : Moment.utc().format('YYYY-MM-DD'),
          attStatus: attCheck,
          access_token:token,
          refresh_token: jwt.refreshTokenEncode(data.id),
          check_in:finalAtt,
          expire_date: eeeeee,
          subscription:subscriptionFetch,
          approval:approvalFetch ? approvalFetch.approval : 0,
          subscription_status:statusFetch?.status ? statusFetch?.status : null,
          output: data,
          language:obj,
          theme:themeData,
          // plan:getData,
        });

        // res.status(200).send({
        //   status:200,
        //   message:"success",
        //   access_token:token,
        //   refresh_token: jwt.refreshTokenEncode(data.id),
        //   output: data,
        //   language:obj
        // });
      // }
     }else {
        res.status(200).send({
          status:403,
          message: "Incorrect password",
        });
      }
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};

// Organization Change Password
exports.changeOrgPassword = async (req, res) => {
  try {
    bcrypt.hash(req.body.password, saltRounds, async function (error, hash) {
      req.body.password = hash;

      const id = req.params.id;

      const userIdFetch = await db2['user'].findOne({
        where: {
          [Op.or]: [
            { email: req.body.email },
            { password: req.body.oldpassword },
          ]
        },
      });

      const match = await bcrypt.compare(req.body.oldpassword, userIdFetch?.dataValues.password);
      console.log("matchhhhhhh", match);

      const user_verification = userIdFetch?.dataValues ? userIdFetch?.dataValues["id"] : 0
      const x = userIdFetch?.dataValues
      console.log('userIdFetchhhhhhhhhh', userIdFetch?.dataValues);
      console.log('user_verificationnnnnnnnnnnn', user_verification);

      console.log('x', x);
      console.log('oldpassword', req.body.oldpassword);
      console.log('password', req.body.password);

      if (match) {
        const data = {
          password: req.body.password
        }
        const num = await db2['user'].update(data, {
          where: { email: req.body.email },
        });
        if (num == 1) {
          res.status(200).send({
            status: 200,
            message: "Updated successfully."
          });
        } else {
          res.status(200).send({
            status: 404,
            message: `Cannot update with id : ${id}.`
          });
        }
      }
      else {
        res.status(200).send({
          status: 400,
          message: `Wrong old password.`
        });
      }
    })
  }
  catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
