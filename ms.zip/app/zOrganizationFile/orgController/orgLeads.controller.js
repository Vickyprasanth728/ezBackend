const orgDbConfig = require("../orgConfig/orgDb.config.js");
const db2 = require("../orgModel/orgIndex.js");
const db = require("../../models");
const Op = db2.Sequelize.Op;
const path = require("path");
const fs = require("fs");
var Sequelize = require('sequelize');
const util = require('util');
const sql = require("../orgConfig/orgDb.config.js");
const readXlsxFile = require('read-excel-file/node');
const mailer = require("../orgModel/mailer.model.js");
const dbConfig = require("../../config/db.config.js");
// const DbName = dbConfig.DB_DATABASE
const puppeteer = require('puppeteer');
// const pdfkit = require('pdfkit');


exports.saveLeads = async (req, res) => {

  await db2.sequelize.query('START TRANSACTION');

  try {
    const created_by = req.user.id
    console.log('created_by', created_by.id);

    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);
    
    const data = await db2['leads'].create({
      org_id: org_id,
      contact_id: req.body.contact_id,
      property_id: req.body.property_id,
      looking_for: req.body.looking_for,
      property_type: req.body.property_type,
      // city: req.body.city,
      lead_source: req.body.lead_source,
      lead_group: req.body.lead_group,
      segment: req.body.segment,
      lead_priority: req.body.lead_priority,
      fee_oppurtunity: req.body.fee_oppurtunity,
      lead_status: req.body.lead_status,
      assign_to: req.body.assign_to || 1,
      sales_manager: req.body.sales_manager,
      created_by: created_by.id
    });
    let leadID = data?.dataValues.id

    const data1 = await db2['leadRequirement'].create({
        lead_id: leadID,
        requirement_location: req.body.requirement_location,
        budget_min: req.body.budget_min,
        budget_max: req.body.budget_max,
        money_term_min: req.body.money_term_min,
        money_term_max: req.body.money_term_max,
        no_of_bedrooms_min: req.body.no_of_bedrooms_min,
        no_of_bedrooms_max: req.body.no_of_bedrooms_max,
        no_of_bathrooms_min: req.body.no_of_bathrooms_min,
        no_of_bathrooms_max: req.body.no_of_bathrooms_max,
        built_up_area_min: req.body.built_up_area_min,
        built_up_area_max: req.body.built_up_area_max,
        plot_area_min: req.body.plot_area_min,
        plot_area_max: req.body.plot_area_max,
        possession_status: req.body.possession_status,
        age_of_property: req.body.age_of_property,
        vasthu_compliant: req.body.vasthu_compliant,
        property_facing: req.body.property_facing,
        furnishing: req.body.furnishing,
        car_park_min: req.body.car_park_min,
        car_park_max: req.body.car_park_max,
        timeline_for_closure_min: req.body.timeline_for_closure_min,
        timeline_for_closure_max: req.body.timeline_for_closure_max,
        amenities: req.body.amenities,
        country: req.body.country,
        state: req.body.state,
        city: req.body.city,
        locality: req.body.locality,
        zipcode: req.body.zipcode,
    });

    console.log('leadIDDD',leadID);

    const LeadLogs = await db2['logs'].create({
      org_id: org_id,
      module_id: leadID,
      module_name: "2",
      note: "Lead created at",
      user_id: created_by.id
    })
    // console.log("LeadLogs", LeadLogs);

    res.status(200).send({
      status:200,
      message:'Success',
      output:data
    });
    await db2.sequelize.query('COMMIT');
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
    await db2.sequelize.query('ROLLBACK');
  }
};
exports.getLeadFinal = async (req, res) => {
    try {
      
    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    const id = req.body.id
    
      var condition = {
        where:{
          status:1, 
        },
        order: [['id', 'DESC']], // ASC, DESC
        attributes: {exclude :['createdAt','updatedAt']},
        include: [
          {
            model: db2['contacts'],
            // attributes:['id','first_name'],
            where: {status:1},
            as:'contact_name',
            required: false,
          },
          {
            model: db2['masters'],
            attributes: ['option_type','option_value'],
            where: {},
            as:'looking_for_name',
            required: false,
          },
          {
            model: db2['masters'],
            attributes: ['option_type','option_value'],
            where: {},
            as:'property_type_name',
            required: false,
          },
          {
            model: db2['masters'],
            attributes: ['option_type','option_value'],
            where: {},
            as:'lead_source_name',
            required: false,
          },
          {
            model: db2['masters'],
            attributes: ['option_type','option_value'],
            where: {},
            as:'lead_group_name',
            required: false,
          },
          {
            model: db2['masters'],
            attributes: ['option_type','option_value'],
            where: {},
            as:'segment_name',
            required: false,
          },
          {
            model: db2['masters'],
            attributes: ['option_type','option_value'],
            where: {},
            as:'lead_priority_name',
            required: false,
          },
          {
            model: db2['masters'],
            attributes: ['option_type','option_value'],
            where: {},
            as:'lead_status_name',
            required: false,
          },
          {
            model: db2['leadRequirement'],
            attributes:{exclude:['createdAt','updatedAt']},
            where: {},
            as:'lead_requirement_name',
            required: false,
            include: [
              {
              model: db2['masters'],
              attributes: ['option_type','option_value'],
              where: {},
              as:'age_of_property_name',
              required: false,
              },
              {
              model: db2['masters'],
              attributes: ['option_type','option_value'],
              where: {},
              as:'vasthu_compliant_name',
              required: false,
              },
              {
              model: db2['masters'],
              attributes: ['option_type','option_value'],
              where: {},
              as:'property_facing_name',
              required: false,
              },
              {
              model: db2['masters'],
              attributes: ['option_type','option_value'],
              where:{status:1},
              as:'amenities_name',
              required: false,
              },
              {
              model: db2['masters'],
              attributes: ['option_type','option_value'],
              where:{status:1},
              as:'furnishing_name',
              required: false,
              },
              {
              model: db2['masters'],
              attributes: ['option_type','option_value'],
              where:{status:1},
              as:'requirement_location_name',
              required: false,
              },
              {
              model: db2['masters'],
              attributes: ['option_type','option_value'],
              where:{status:1},
              as:'possession_status_name',
              required: false,
              },
          ],
          },
        ],
          offset :parseInt(req.query.offset) || 0,
        //   limit: parseInt(req.query.limit) || 12
          limit : (req.query.offset ? 12 : null)
      };
    //   var offset = parseInt(req.query.offset);
    //   var limit = parseInt(req.query.limit);
  
    //   if (offset >= 0 && limit >= 0) {
    //     condition.offset = offset;
    //     condition.limit = limit;
    //   }
  
      const data = await db2['leads'].findAll(condition);
      
      const filters = req.query;
      const filteredLeads = data.filter(user => {
        let isValid = true;
        for (key in filters) {
          if(key != "offset" ) {
          console.log('keyyyyyyy',key, user[key], filters[key]);
          isValid = isValid && user[key] == filters[key];
          }
        }
        return isValid;
      });
      const data2 = await db2['leads'].findAll({
        where:{status:1},
        attributes: [[Sequelize.fn('COUNT', Sequelize.col('id')), 'leads_count']],
      });
      const contact = data2[0]?.dataValues.contact_count
      
      const count_filter = (filteredLeads)
      console.log('count_filter', count_filter.length);

      const leadR = filteredLeads[1]?.dataValues?.lead_requirement_name[0]?.dataValues
      console.log("leadR", leadR);


      res.status(200).send({
        status:200,
        message:'Success',
        count:count_filter.length,
        output:filteredLeads,
      });
    } catch (error) {
      res.status(500).send({
        message: error.message,
      });
    }
};

exports.getLeads = async (req, res) => {
  try {
    const created_id = req.user.id
    const created_by = created_id.id
    console.log('created_by', created_by);
  
    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);
  
    const role = req.user.id
    const role_id = role.designation
    console.log('role_id', role_id);

  let thisQuery = `select l.*, GROUP_CONCAT(distinct CONCAT(us.first_name,' ', IFNULL(us.last_name, ''),'-',us.id)) as assign_to_name, CONVERT(l.assign_to USING utf8) as assign_to, CONVERT(l.sales_manager USING utf8) as sales_manager, c.company_name as company_name, CONCAT(c.first_name,' ', IFNULL(c.last_name, '')) as contact_name, c.email as contact_email, c.mobile as contact_mobile, c.mobile as contact_mobile, c.profile_image as contact_profile_image, c.profile_image_original_name as contact_profile_image_original_name, pa.name_of_building as property_name,  CONCAT(us2.first_name,' ', IFNULL(us2.last_name, '')) as created_by_name, lr.age_of_property as age_of_property, lr.vasthu_compliant as vasthu_compliant,  CONVERT(lr.furnishing USING utf8) as furnishing, CONVERT(lr.amenities USING utf8) as amenities, CONVERT(lr.possession_status USING utf8) as possession_status,
  lr.budget_min as budget_min, lr.budget_max as budget_max, lr.no_of_bedrooms_min as no_of_bedrooms_min, lr.no_of_bedrooms_max as no_of_bedrooms_max, lr.no_of_bathrooms_min as no_of_bathrooms_min, lr.no_of_bathrooms_max as no_of_bathrooms_max, lr.plot_area_min as plot_area_min, lr.plot_area_max as plot_area_max, lr.built_up_area_min as built_up_area_min, lr.built_up_area_max as built_up_area_max, lr.car_park_min as car_park_min, lr.car_park_max as car_park_max, lr.timeline_for_closure_min as timeline_for_closure_min, lr.timeline_for_closure_max as timeline_for_closure_max, lr.property_facing as property_facing, lr.country as country, lr.state as state, lr.city as city, lr.zipcode as zipcode,
  lr.locality as locality,
  lrn.option_value as looking_for_name, 
  pt.option_value as property_type_name, 
  ls.option_value as lead_source_name,
  lg.option_value as lead_group_name,
  seg.option_value as segment_name,
  lp.option_value as lead_priority_name,
  lss.option_value as lead_status_name,
  aop.option_value as age_of_property_name,
  vc.option_value as vasthu_compliant_name,
  pf.option_value as property_facing_name,
  GROUP_CONCAT(distinct CONCAT(amen.option_value),'-',amen.id) as amenities_name,
  GROUP_CONCAT(distinct CONCAT(ps.option_value),'-',ps.id) as possession_status_name,
  GROUP_CONCAT(distinct CONCAT(fur.option_value),'-',fur.id) as furnishing_name

  from lz_leads as l
  LEFT JOIN lz_contacts as c on (c.id = l.contact_id) 
  LEFT JOIN lz_lead_requirements as lr on (l.id = lr.lead_id) 
  LEFT JOIN lz_property_addresses as pa on (pa.property_id = l.property_id) 
  LEFT JOIN lz_user as us on FIND_IN_SET(us.id,l.assign_to) > 0 
  LEFT JOIN lz_user as us2 on (us2.id = l.created_by)
  LEFT JOIN lz_masters as lrn on (lrn.id = l.looking_for) 
  LEFT JOIN lz_masters as pt on (pt.id = l.property_type)
  LEFT JOIN lz_masters as ls on (ls.id = l.lead_source)
  LEFT JOIN lz_masters as lg on (lg.id = l.lead_group)
  LEFT JOIN lz_masters as seg on (seg.id = l.segment)
  LEFT JOIN lz_masters as lp on (lp.id = l.lead_priority)
  LEFT JOIN lz_masters as lss on (lss.id = l.lead_status)
  LEFT JOIN lz_masters as aop on (aop.id = lr.age_of_property)
  LEFT JOIN lz_masters as vc on (vc.id = lr.vasthu_compliant)
  LEFT JOIN lz_masters as pf on (pf.id = lr.property_facing) 
  
  LEFT JOIN lz_user as us5 on FIND_IN_SET(us5.id,c.assign_to) > 0 
  left join lz_user as us4 on (us5.team_leader = us4.id) 
  LEFT JOIN lz_user as us6 on FIND_IN_SET(us6.id,c.assign_to) > 0 
  left join lz_user as us7 on (us6.portfolio_head = us7.id) 
  `

  thisQuery += 'LEFT JOIN lz_masters as amen on FIND_IN_SET(amen.id,lr.amenities) > 0 '
  thisQuery += 'LEFT JOIN lz_masters as fur on FIND_IN_SET(fur.id,lr.furnishing) > 0 '
  thisQuery += 'LEFT JOIN lz_masters as ps on FIND_IN_SET(ps.id,lr.possession_status) > 0 '
  thisQuery += `where ${role_id == 1 ? `l.status IN (1,2) ` : `l.status = 1 `}`

  if (role_id == 1) {
    thisQuery += ` `
  }
  if (role_id == 2) {
    thisQuery += ` and (FIND_IN_SET(${created_by},l.assign_to)>0 or us.team_leader = ${created_by} or us.portfolio_head = ${created_by} or us2.team_leader = ${created_by} or us2.portfolio_head = ${created_by} or l.created_by = ${created_by}) `
    // thisQuery += ` and c.created_by = ${created_by} `
  }
  if (role_id == 3) {
    thisQuery += ` and (FIND_IN_SET(${created_by},l.assign_to)>0 OR us.team_leader = ${created_by} OR us.portfolio_head = ${created_by} or us2.team_leader = ${created_by} or us2.portfolio_head = ${created_by} OR l.created_by = ${created_by}) `
    // thisQuery += ` and c.created_by = ${created_by} `
  }
  if (role_id == 4) {
    thisQuery += ` and (FIND_IN_SET(${created_by},l.assign_to)>0 or l.created_by = ${created_by}) `
  }
  if (role_id == 5) {
    thisQuery += ` `
  }
  if (role_id == 6) {
    thisQuery += `and l.created_by = ${created_by} `
  }
  if (role_id >= 7) {
    thisQuery += `and l.created_by = ${created_by} `
  }

  const filters = req.query;
  // for (key in filters) {
    if (filters.looking_for) {
      thisQuery += " and l.looking_for = " + `${filters.looking_for} `
    }
    // if (filters.lead_source) {
    //   thisQuery += "and l.lead_source = " + `${filters.lead_source} `
    // }
    if (filters.lead_group) {
      thisQuery += "and l.lead_group = " + `${filters.lead_group} `
    }
    if (filters.fee_oppurtunity) {
      thisQuery += "and l.fee_oppurtunity = " + `${filters.fee_oppurtunity} `
    }
    // if (filters.lead_status) {
    //   thisQuery += "and l.lead_status = " + `${filters.lead_status} `
    // }
    if (filters.created_by) {
      thisQuery += " and l.created_by = " + `${filters.created_by} `
    }
    // if (filters.assign_to) {
    //   var a = filters.assign_to;
    //   var b = a.replace(/[,]/g, ",");
    //   thisQuery += `and CONCAT(',', l.assign_to, ',') REGEXP ',(${a}),' `
    // }
    if (filters.lead_status) {
      var a = filters.lead_status;
      let a1 = a.split(',').map(item => `'${item}'`).join(',');
      // thisQuery += `and CONCAT(',', c.lead_status, ',') REGEXP ',(${a1}),' `
      thisQuery += " and (l.lead_status IN (" + a1 + ")" + ` OR CONCAT(',', l.lead_status, ',') REGEXP ',(${a}),' )`
    }
    if (filters.lead_source) {
      var a = filters.lead_source;
      let a1 = a.split(',').map(item => `'${item}'`).join(',');
      // thisQuery += `and CONCAT(',', c.lead_source, ',') REGEXP ',(${a1}),' `
      thisQuery += " and (l.lead_source IN (" + a1 + ")" + ` OR CONCAT(',', l.lead_source, ',') REGEXP ',(${a}),' )`
    }
    if (filters.assign_to) {
      var a = filters.assign_to;
      let a1 = a.split(',').map(item => `'${item}'`).join(',');
      // thisQuery += `and CONCAT(',', c.assign_to, ',') REGEXP ',(${a1}),' `
      thisQuery += " and (l.assign_to IN (" + a1 + ")" + ` OR CONCAT(',', l.assign_to, ',') REGEXP ',(${a}),' )`
    }
    // WHERE Price BETWEEN 50 AND 60;
    // WHERE CategoryID and SupplierID BETWEEN 7 AND 28;
    // thisQuery += ` and no_of_bedrooms_min >= ${filters.no_of_bedrooms_min} and no_of_bedrooms_max <= ${filters.no_of_bedrooms_max} `

    // if (filters.no_of_bedrooms_min && filters.no_of_bedrooms_max) {
    //   thisQuery += ` and no_of_bedrooms_min and no_of_bedrooms_max BETWEEN ${filters.no_of_bedrooms_min} and ${filters.no_of_bedrooms_max} ` 
    // }
    if (filters.no_of_bedrooms_min) {
      thisQuery += " and lr.no_of_bedrooms_min >= " + `'${filters.no_of_bedrooms_min}' `
    }
    if (filters.no_of_bedrooms_max) {
      thisQuery += " and lr.no_of_bedrooms_max <= " + `'${filters.no_of_bedrooms_max}' `
    }
    if (filters.no_of_bathrooms_min) {
      thisQuery += " and lr.no_of_bathrooms_min >= " + `'${filters.no_of_bathrooms_min}' `
    }
    if (filters.no_of_bathrooms_max) {
      thisQuery += " and lr.no_of_bathrooms_max <= " + `'${filters.no_of_bathrooms_max}' `
    }

    // if (filters.no_of_bathrooms_min && filters.no_of_bathrooms_max) {
    //   thisQuery += ` and no_of_bathrooms_min and no_of_bathrooms_max BETWEEN ${filters.no_of_bathrooms_min} and ${filters.no_of_bathrooms_max} ` 
    // }
    if (filters.budget_min && filters.budget_max) {
      thisQuery += ` and budget_min and budget_max BETWEEN ${filters.budget_min} and ${filters.budget_max} ` 
    }
    if (filters.built_up_area_min && filters.built_up_area_max) {
      thisQuery += ` and built_up_area_min and built_up_area_max BETWEEN ${filters.built_up_area_min} and ${filters.built_up_area_max} ` 
    }
    if (filters.plot_area_min && filters.plot_area_max) {
      thisQuery += ` and plot_area_min and plot_area_max BETWEEN ${filters.plot_area_min} and ${filters.plot_area_max} ` 
    }
    // if (filters.possession_status) {
    //   var a = filters.possession_status;
    //   var b = a.replace(/[,]/g, ",");
    //   thisQuery += `and CONCAT(',', lr.possession_status, ',') REGEXP ',(${a}),' `
    // }
    if (filters.possession_status) {
      var a = filters.possession_status;
      let a1 = a.split(',').map(item => `'${item}'`).join(',');
      // thisQuery += `and CONCAT(',', c.possession_status, ',') REGEXP ',(${a1}),' `
      thisQuery += " and (lr.possession_status IN (" + a1 + ")" + ` OR CONCAT(',', lr.possession_status, ',') REGEXP ',(${a}),' )`
    }
    if (filters.age_of_property) {
      thisQuery += " and lr.age_of_property = " + `${filters.age_of_property} `
    }
    if (filters.vasthu_compliant) {
      thisQuery += " and lr.vasthu_compliant = " + `${filters.vasthu_compliant} `
    }
    if (filters.property) {
      thisQuery += " and l.property_id = " + `${filters.property} `
    }
    if (filters.priority) {
      thisQuery += " and l.lead_priority = " + `${filters.priority} `
    }
    if (filters.property_type) {
      thisQuery += " and l.property_type = " + `${filters.property_type} `
    }
    // if (filters.furnishing) {
    //   var a = filters.furnishing;
    //   var b = a.replace(/[,]/g, ",");
    //   thisQuery += `and CONCAT(',', lr.furnishing, ',') REGEXP ',(${a}),' `
    // }
    if (filters.furnishing) {
      var a = filters.furnishing;
      let a1 = a.split(',').map(item => `'${item}'`).join(',');
      // thisQuery += `and CONCAT(',', c.furnishing, ',') REGEXP ',(${a1}),' `
      thisQuery += " and (lr.furnishing IN (" + a1 + ")" + ` OR CONCAT(',', lr.furnishing, ',') REGEXP ',(${a}),' )`
    }
    if (filters.car_park_min) {
      thisQuery += " and lr.car_park_min = " + `${filters.car_park_min} `
    }
    if (filters.car_park_max) {
      thisQuery += " and lr.car_park_max = " + `${filters.car_park_max} `
    }
    if (filters.timeline_for_closure_min) {
      thisQuery += " and lr.timeline_for_closure_min = " + `${filters.timeline_for_closure_min} `
    }
    if (filters.timeline_for_closure_max) {
      thisQuery += " and lr.timeline_for_closure_max = " + `${filters.timeline_for_closure_max} `
    }
    // if (filters.amenities) {
    //   var a = filters.amenities;
    //   var b = a.replace(/[,]/g, ",");
    //   thisQuery += `and CONCAT(',', lr.amenities, ',') REGEXP ',(${a}),' `
    // }
    if (filters.amenities) {
      var a = filters.amenities;
      let a1 = a.split(',').map(item => `'${item}'`).join(',');
      // thisQuery += `and CONCAT(',', c.amenities, ',') REGEXP ',(${a1}),' `
      thisQuery += " and (lr.amenities IN (" + a1 + ")" + ` OR CONCAT(',', lr.amenities, ',') REGEXP ',(${a}),' )`
    }
    if (filters.created_at) {
      thisQuery += " and l.created_at = " + `${filters.created_at} `
    }
  // }
  thisQuery += ' group by l.id '

  if (filters.order_by) {
    let orderByString = filters.order_by.split('|')
    thisQuery += " order by " + `${orderByString[0]} ${orderByString[1]} `
  }
  const data1 = await db2.sequelize.query(thisQuery);

  if (filters.order_by =="" || filters.order_by == undefined) {
    thisQuery += '  order by l.id DESC '
  }

  if (filters.limit) {
    thisQuery += ` limit ${filters.limit},12 `
  }

  const data = await db2.sequelize.query(thisQuery);

  let array = [];
  if (filters.limit) {
  for(let a in data[0]) {
    let thisQueryNotes = ` 
    SELECT COUNT(id) as notes_count 
    FROM lz_notes 
    where status = 1 and (module_id = ${data[0][a]?.id} and module_name = 2 or module_id = ${data[0][a]?.contact_id}) `
    const cNotesData = await db2.sequelize.query(thisQueryNotes);

    let thisQueryFiles = ` 
    SELECT COUNT(id) as files_count 
    FROM lz_file_uploads 
    where status = 1 and (module_id = ${data[0][a]?.id} and module_name = 2) `
    const cFilesData = await db2.sequelize.query(thisQueryFiles);

    let thisQueryTask = ` 
    SELECT ifnull(COUNT(*),0) as task_count 
    FROM lz_tasks as t
    LEFT JOIN lz_leads on (${data[0][a]?.id} = ${data[0][a]?.contact_id})
    where t.status = 1 and (t.contact = ${data[0][a]?.contact_id}) `
    const cTaskData = await db2.sequelize.query(thisQueryTask);

    let thisQueryLastNotes = ` 
    SELECT reply as last_note
    FROM lz_notes
    where status = 1 and (module_name = 2 and module_id = ${data[0][a]?.id}) order by id desc limit 1 `
    const cLastNotesData = await db2.sequelize.query(thisQueryLastNotes);

    let thisQueryLastTask = ` 
    SELECT DATE_FORMAT(ta.task_time,'%Y-%m-%d') as last_task_date
    FROM lz_tasks as ta
    where ta.status = 1 and (ta.contact = ${data[0][a]?.contact_id} and ta.task_time <= curdate()) order by ta.task_time DESC limit 1 `
    const cLastTaskData = await db2.sequelize.query(thisQueryLastTask);

    let thisQueryNextTask = ` 
    SELECT DATE_FORMAT(ta.task_time,'%Y-%m-%d') as next_task_date
    FROM lz_tasks as ta
    where ta.status = 1 and (ta.contact = ${data[0][a]?.contact_id} and ta.task_time >= curdate()) order by ta.task_time limit 1 `
    const cNextTaskData = await db2.sequelize.query(thisQueryNextTask);

    let obj = {...data[0][a], ...cNotesData[0][0], ...cFilesData[0][0], ...cTaskData[0][0], ...cLastNotesData[0][0], ...cLastTaskData[0][0], ...cNextTaskData[0][0]}
    array.push(obj);
  }
  } else {
    array = data[0];
  }
  // (SELECT COUNT(id) FROM lz_notes where status = 1 and (module_id = l.id and module_name = 2 or module_id = l.contact_id)) as notes_count,
  // (SELECT COUNT(id) FROM lz_file_uploads where module_id = l.id and module_name = 2 ) as files_count,
  // (SELECT ifnull(COUNT(*),0) FROM lz_tasks as t LEFT JOIN lz_leads on (lz_leads.id = l.contact_id) where t.contact = l.contact_id) as task_count,
  // (SELECT reply FROM lz_notes where module_name = 2 and module_id = l.id order by id desc limit 1 ) as last_note,
  // (SELECT DATE_FORMAT(ta.task_time,'%Y-%m-%d') FROM lz_tasks as ta where ta.contact = l.contact_id and ta.task_time <= curdate() order by ta.task_time DESC limit 1) as last_task_date,
  // (SELECT DATE_FORMAT(ta.task_time,'%Y-%m-%d') FROM lz_tasks as ta where ta.contact = l.contact_id and ta.task_time >= curdate() order by ta.task_time limit 1) as next_task_date

  const count_filter = (data1[0])

    res.status(200).send({
      status:200,
      message:'Success',
      count: count_filter.length,
      // output: data[0],
      output: array,
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};

// Filter >> Bedroom Range
// exports.getLeads = async (req, res) => {
//   try {
//     const created_id = req.user.id
//     const created_by = created_id.id
//     console.log('created_by', created_by);
  
//     const organ_id = req.user.id
//     const org_id = organ_id.org_id
//     console.log('organ_id', org_id);
  
//     const role = req.user.id
//     const role_id = role.designation
//     console.log('role_id', role_id);

//   let thisQuery = `select l.*, GROUP_CONCAT(distinct CONCAT(us.first_name,' ', IFNULL(us.last_name, ''),'-',us.id)) as assign_to_name, CONVERT(l.assign_to USING utf8) as assign_to, CONVERT(l.sales_manager USING utf8) as sales_manager, c.company_name as company_name, CONCAT(c.first_name,' ', IFNULL(c.last_name, '')) as contact_name, c.email as contact_email, c.mobile as contact_mobile, c.mobile as contact_mobile, c.profile_image as contact_profile_image, c.profile_image_original_name as contact_profile_image_original_name, pa.name_of_building as property_name,  CONCAT(us2.first_name,' ', IFNULL(us2.last_name, '')) as created_by_name, lr.age_of_property as age_of_property, lr.vasthu_compliant as vasthu_compliant,  CONVERT(lr.furnishing USING utf8) as furnishing, CONVERT(lr.amenities USING utf8) as amenities, CONVERT(lr.possession_status USING utf8) as possession_status,
//   lr.budget_min as budget_min, lr.budget_max as budget_max, lr.no_of_bedrooms_min as no_of_bedrooms_min, lr.no_of_bedrooms_max as no_of_bedrooms_max, lr.no_of_bathrooms_min as no_of_bathrooms_min, lr.no_of_bathrooms_max as no_of_bathrooms_max, lr.plot_area_min as plot_area_min, lr.plot_area_max as plot_area_max, lr.built_up_area_min as built_up_area_min, lr.built_up_area_max as built_up_area_max, lr.car_park_min as car_park_min, lr.car_park_max as car_park_max, lr.timeline_for_closure_min as timeline_for_closure_min, lr.timeline_for_closure_max as timeline_for_closure_max, lr.property_facing as property_facing, lr.country as country, lr.state as state, lr.city as city, lr.zipcode as zipcode,
//   lr.locality as locality,
//   lrn.option_value as looking_for_name, 
//   pt.option_value as property_type_name, 
//   ls.option_value as lead_source_name,
//   lg.option_value as lead_group_name,
//   seg.option_value as segment_name,
//   lp.option_value as lead_priority_name,
//   lss.option_value as lead_status_name,
//   aop.option_value as age_of_property_name,
//   vc.option_value as vasthu_compliant_name,
//   pf.option_value as property_facing_name,
//   GROUP_CONCAT(distinct CONCAT(amen.option_value),'-',amen.id) as amenities_name,
//   GROUP_CONCAT(distinct CONCAT(ps.option_value),'-',ps.id) as possession_status_name,
//   GROUP_CONCAT(distinct CONCAT(fur.option_value),'-',fur.id) as furnishing_name

//   from lz_leads as l
//   LEFT JOIN lz_contacts as c on (c.id = l.contact_id) 
//   LEFT JOIN lz_lead_requirements as lr on (l.id = lr.lead_id) 
//   LEFT JOIN lz_property_addresses as pa on (pa.property_id = l.property_id) 
//   LEFT JOIN lz_user as us on FIND_IN_SET(us.id,l.assign_to) > 0 
//   LEFT JOIN lz_user as us2 on (us2.id = l.created_by)
//   LEFT JOIN lz_masters as lrn on (lrn.id = l.looking_for) 
//   LEFT JOIN lz_masters as pt on (pt.id = l.property_type)
//   LEFT JOIN lz_masters as ls on (ls.id = l.lead_source)
//   LEFT JOIN lz_masters as lg on (lg.id = l.lead_group)
//   LEFT JOIN lz_masters as seg on (seg.id = l.segment)
//   LEFT JOIN lz_masters as lp on (lp.id = l.lead_priority)
//   LEFT JOIN lz_masters as lss on (lss.id = l.lead_status)
//   LEFT JOIN lz_masters as aop on (aop.id = lr.age_of_property)
//   LEFT JOIN lz_masters as vc on (vc.id = lr.vasthu_compliant)
//   LEFT JOIN lz_masters as pf on (pf.id = lr.property_facing) 
  
//   LEFT JOIN lz_user as us5 on FIND_IN_SET(us5.id,c.assign_to) > 0 
//   left join lz_user as us4 on (us5.team_leader = us4.id) 
//   LEFT JOIN lz_user as us6 on FIND_IN_SET(us6.id,c.assign_to) > 0 
//   left join lz_user as us7 on (us6.portfolio_head = us7.id) 
//   `

//   thisQuery += 'LEFT JOIN lz_masters as amen on FIND_IN_SET(amen.id,lr.amenities) > 0 '
//   thisQuery += 'LEFT JOIN lz_masters as fur on FIND_IN_SET(fur.id,lr.furnishing) > 0 '
//   thisQuery += 'LEFT JOIN lz_masters as ps on FIND_IN_SET(ps.id,lr.possession_status) > 0 '
//   thisQuery += `where ${role_id == 1 ? `l.status IN (1,2) ` : `l.status = 1 `}`

//   if (role_id == 1) {
//     thisQuery += ` `
//   }
//   if (role_id == 2) {
//     thisQuery += ` and (FIND_IN_SET(${created_by},l.assign_to)>0 or us.team_leader = ${created_by} or us.portfolio_head = ${created_by} or us2.team_leader = ${created_by} or us2.portfolio_head = ${created_by} or l.created_by = ${created_by}) `
//     // thisQuery += ` and c.created_by = ${created_by} `
//   }
//   if (role_id == 3) {
//     thisQuery += ` and (FIND_IN_SET(${created_by},l.assign_to)>0 OR us.team_leader = ${created_by} OR us.portfolio_head = ${created_by} or us2.team_leader = ${created_by} or us2.portfolio_head = ${created_by} OR l.created_by = ${created_by}) `
//     // thisQuery += ` and c.created_by = ${created_by} `
//   }
//   if (role_id == 4) {
//     thisQuery += ` and (FIND_IN_SET(${created_by},l.assign_to)>0 or l.created_by = ${created_by}) `
//   }
//   if (role_id == 5) {
//     thisQuery += ` `
//   }
//   if (role_id == 6) {
//     thisQuery += `and l.created_by = ${created_by} `
//   }
//   if (role_id >= 7) {
//     thisQuery += `and l.created_by = ${created_by} `
//   }

//   const filters = req.query;
//   // for (key in filters) {
//     if (filters.looking_for) {
//       thisQuery += " and l.looking_for = " + `${filters.looking_for} `
//     }
//     // if (filters.lead_source) {
//     //   thisQuery += "and l.lead_source = " + `${filters.lead_source} `
//     // }
//     if (filters.lead_group) {
//       thisQuery += "and l.lead_group = " + `${filters.lead_group} `
//     }
//     if (filters.fee_oppurtunity) {
//       thisQuery += "and l.fee_oppurtunity = " + `${filters.fee_oppurtunity} `
//     }
//     // if (filters.lead_status) {
//     //   thisQuery += "and l.lead_status = " + `${filters.lead_status} `
//     // }
//     if (filters.created_by) {
//       thisQuery += " and l.created_by = " + `${filters.created_by} `
//     }
//     // if (filters.assign_to) {
//     //   var a = filters.assign_to;
//     //   var b = a.replace(/[,]/g, ",");
//     //   thisQuery += `and CONCAT(',', l.assign_to, ',') REGEXP ',(${a}),' `
//     // }
//     if (filters.lead_status) {
//       var a = filters.lead_status;
//       let a1 = a.split(',').map(item => `'${item}'`).join(',');
//       // thisQuery += `and CONCAT(',', c.lead_status, ',') REGEXP ',(${a1}),' `
//       thisQuery += " and (l.lead_status IN (" + a1 + ")" + ` OR CONCAT(',', l.lead_status, ',') REGEXP ',(${a}),' )`
//     }
//     if (filters.lead_source) {
//       var a = filters.lead_source;
//       let a1 = a.split(',').map(item => `'${item}'`).join(',');
//       // thisQuery += `and CONCAT(',', c.lead_source, ',') REGEXP ',(${a1}),' `
//       thisQuery += " and (l.lead_source IN (" + a1 + ")" + ` OR CONCAT(',', l.lead_source, ',') REGEXP ',(${a}),' )`
//     }
//     if (filters.assign_to) {
//       var a = filters.assign_to;
//       let a1 = a.split(',').map(item => `'${item}'`).join(',');
//       // thisQuery += `and CONCAT(',', c.assign_to, ',') REGEXP ',(${a1}),' `
//       thisQuery += " and (l.assign_to IN (" + a1 + ")" + ` OR CONCAT(',', l.assign_to, ',') REGEXP ',(${a}),' )`
//     }
//     // WHERE Price BETWEEN 50 AND 60;
//     // WHERE CategoryID and SupplierID BETWEEN 7 AND 28;
//     // thisQuery += ` and no_of_bedrooms_min >= ${filters.no_of_bedrooms_min} and no_of_bedrooms_max <= ${filters.no_of_bedrooms_max} `

//     // if (filters.no_of_bedrooms_min && filters.no_of_bedrooms_max) {
//     //   thisQuery += ` and no_of_bedrooms_min and no_of_bedrooms_max BETWEEN ${filters.no_of_bedrooms_min} and ${filters.no_of_bedrooms_max} ` 
//     // }
//     if (filters.no_of_bedrooms_min) {
//       thisQuery += " and lr.no_of_bedrooms_min <= " + `'${filters.no_of_bedrooms_min}' `
//     }
//     if (filters.no_of_bedrooms_max) {
//       thisQuery += " and lr.no_of_bedrooms_max >= " + `'${filters.no_of_bedrooms_max}' `
//     }

//     if (filters.no_of_bathrooms_min && filters.no_of_bathrooms_max) {
//       thisQuery += ` and no_of_bathrooms_min and no_of_bathrooms_max BETWEEN ${filters.no_of_bathrooms_min} and ${filters.no_of_bathrooms_max} ` 
//     }
//     if (filters.budget_min && filters.budget_max) {
//       thisQuery += ` and budget_min and budget_max BETWEEN ${filters.budget_min} and ${filters.budget_max} ` 
//     }
//     if (filters.built_up_area_min && filters.built_up_area_max) {
//       thisQuery += ` and built_up_area_min and built_up_area_max BETWEEN ${filters.built_up_area_min} and ${filters.built_up_area_max} ` 
//     }
//     if (filters.plot_area_min && filters.plot_area_max) {
//       thisQuery += ` and plot_area_min and plot_area_max BETWEEN ${filters.plot_area_min} and ${filters.plot_area_max} ` 
//     }
//     // if (filters.possession_status) {
//     //   var a = filters.possession_status;
//     //   var b = a.replace(/[,]/g, ",");
//     //   thisQuery += `and CONCAT(',', lr.possession_status, ',') REGEXP ',(${a}),' `
//     // }
//     if (filters.possession_status) {
//       var a = filters.possession_status;
//       let a1 = a.split(',').map(item => `'${item}'`).join(',');
//       // thisQuery += `and CONCAT(',', c.possession_status, ',') REGEXP ',(${a1}),' `
//       thisQuery += " and (lr.possession_status IN (" + a1 + ")" + ` OR CONCAT(',', lr.possession_status, ',') REGEXP ',(${a}),' )`
//     }
//     if (filters.age_of_property) {
//       thisQuery += " and lr.age_of_property = " + `${filters.age_of_property} `
//     }
//     if (filters.vasthu_compliant) {
//       thisQuery += " and lr.vasthu_compliant = " + `${filters.vasthu_compliant} `
//     }
//     if (filters.property) {
//       thisQuery += " and l.property_id = " + `${filters.property} `
//     }
//     if (filters.priority) {
//       thisQuery += " and l.lead_priority = " + `${filters.priority} `
//     }
//     if (filters.property_type) {
//       thisQuery += " and l.property_type = " + `${filters.property_type} `
//     }
//     // if (filters.furnishing) {
//     //   var a = filters.furnishing;
//     //   var b = a.replace(/[,]/g, ",");
//     //   thisQuery += `and CONCAT(',', lr.furnishing, ',') REGEXP ',(${a}),' `
//     // }
//     if (filters.furnishing) {
//       var a = filters.furnishing;
//       let a1 = a.split(',').map(item => `'${item}'`).join(',');
//       // thisQuery += `and CONCAT(',', c.furnishing, ',') REGEXP ',(${a1}),' `
//       thisQuery += " and (lr.furnishing IN (" + a1 + ")" + ` OR CONCAT(',', lr.furnishing, ',') REGEXP ',(${a}),' )`
//     }
//     if (filters.car_park_min) {
//       thisQuery += " and lr.car_park_min = " + `${filters.car_park_min} `
//     }
//     if (filters.car_park_max) {
//       thisQuery += " and lr.car_park_max = " + `${filters.car_park_max} `
//     }
//     if (filters.timeline_for_closure_min) {
//       thisQuery += " and lr.timeline_for_closure_min = " + `${filters.timeline_for_closure_min} `
//     }
//     if (filters.timeline_for_closure_max) {
//       thisQuery += " and lr.timeline_for_closure_max = " + `${filters.timeline_for_closure_max} `
//     }
//     // if (filters.amenities) {
//     //   var a = filters.amenities;
//     //   var b = a.replace(/[,]/g, ",");
//     //   thisQuery += `and CONCAT(',', lr.amenities, ',') REGEXP ',(${a}),' `
//     // }
//     if (filters.amenities) {
//       var a = filters.amenities;
//       let a1 = a.split(',').map(item => `'${item}'`).join(',');
//       // thisQuery += `and CONCAT(',', c.amenities, ',') REGEXP ',(${a1}),' `
//       thisQuery += " and (lr.amenities IN (" + a1 + ")" + ` OR CONCAT(',', lr.amenities, ',') REGEXP ',(${a}),' )`
//     }
//     if (filters.created_at) {
//       thisQuery += " and l.created_at = " + `${filters.created_at} `
//     }
//   // }
//   thisQuery += ' group by l.id '

//   if (filters.order_by) {
//     let orderByString = filters.order_by.split('|')
//     thisQuery += " order by " + `${orderByString[0]} ${orderByString[1]} `
//   }
//   const data1 = await db2.sequelize.query(thisQuery);

//   if (filters.order_by =="" || filters.order_by == undefined) {
//     thisQuery += '  order by l.id DESC '
//   }

//   if (filters.limit) {
//     thisQuery += ` limit ${filters.limit},12 `
//   }

//   const data = await db2.sequelize.query(thisQuery);

//   let array = [];
//   if (filters.limit) {
//   for(let a in data[0]) {
//     let thisQueryNotes = ` 
//     SELECT COUNT(id) as notes_count 
//     FROM lz_notes 
//     where status = 1 and (module_id = ${data[0][a]?.id} and module_name = 2 or module_id = ${data[0][a]?.contact_id}) `
//     const cNotesData = await db2.sequelize.query(thisQueryNotes);

//     let thisQueryFiles = ` 
//     SELECT COUNT(id) as files_count 
//     FROM lz_file_uploads 
//     where status = 1 and (module_id = ${data[0][a]?.id} and module_name = 2) `
//     const cFilesData = await db2.sequelize.query(thisQueryFiles);

//     let thisQueryTask = ` 
//     SELECT ifnull(COUNT(*),0) as task_count 
//     FROM lz_tasks as t
//     LEFT JOIN lz_leads on (${data[0][a]?.id} = ${data[0][a]?.contact_id})
//     where t.status = 1 and (t.contact = ${data[0][a]?.contact_id}) `
//     const cTaskData = await db2.sequelize.query(thisQueryTask);

//     let thisQueryLastNotes = ` 
//     SELECT reply as last_note
//     FROM lz_notes
//     where status = 1 and (module_name = 2 and module_id = ${data[0][a]?.id}) order by id desc limit 1 `
//     const cLastNotesData = await db2.sequelize.query(thisQueryLastNotes);

//     let thisQueryLastTask = ` 
//     SELECT DATE_FORMAT(ta.task_time,'%Y-%m-%d') as last_task_date
//     FROM lz_tasks as ta
//     where ta.status = 1 and (ta.contact = ${data[0][a]?.contact_id} and ta.task_time <= curdate()) order by ta.task_time DESC limit 1 `
//     const cLastTaskData = await db2.sequelize.query(thisQueryLastTask);

//     let thisQueryNextTask = ` 
//     SELECT DATE_FORMAT(ta.task_time,'%Y-%m-%d') as next_task_date
//     FROM lz_tasks as ta
//     where ta.status = 1 and (ta.contact = ${data[0][a]?.contact_id} and ta.task_time >= curdate()) order by ta.task_time limit 1 `
//     const cNextTaskData = await db2.sequelize.query(thisQueryNextTask);

//     let obj = {...data[0][a], ...cNotesData[0][0], ...cFilesData[0][0], ...cTaskData[0][0], ...cLastNotesData[0][0], ...cLastTaskData[0][0], ...cNextTaskData[0][0]}
//     array.push(obj);
//   }
//   } else {
//     array = data[0];
//   }
//   // (SELECT COUNT(id) FROM lz_notes where status = 1 and (module_id = l.id and module_name = 2 or module_id = l.contact_id)) as notes_count,
//   // (SELECT COUNT(id) FROM lz_file_uploads where module_id = l.id and module_name = 2 ) as files_count,
//   // (SELECT ifnull(COUNT(*),0) FROM lz_tasks as t LEFT JOIN lz_leads on (lz_leads.id = l.contact_id) where t.contact = l.contact_id) as task_count,
//   // (SELECT reply FROM lz_notes where module_name = 2 and module_id = l.id order by id desc limit 1 ) as last_note,
//   // (SELECT DATE_FORMAT(ta.task_time,'%Y-%m-%d') FROM lz_tasks as ta where ta.contact = l.contact_id and ta.task_time <= curdate() order by ta.task_time DESC limit 1) as last_task_date,
//   // (SELECT DATE_FORMAT(ta.task_time,'%Y-%m-%d') FROM lz_tasks as ta where ta.contact = l.contact_id and ta.task_time >= curdate() order by ta.task_time limit 1) as next_task_date

//   const count_filter = (data1[0])

//     res.status(200).send({
//       status:200,
//       message:'Success',
//       count: count_filter.length,
//       // output: data[0],
//       output: array,
//     });
//   } catch (error) {
//     res.status(500).send({
//       message: error.message,
//     });
//   }
// };

// exports.getLeads = async (req, res) => {
//   try {
//     const created_id = req.user.id
//     const created_by = created_id.id
//     console.log('created_by', created_by);
  
//     const organ_id = req.user.id
//     const org_id = organ_id.org_id
//     console.log('organ_id', org_id);
  
//     const role = req.user.id
//     const role_id = role.designation
//     console.log('role_id', role_id);

//   let thisQuery = `select l.*, GROUP_CONCAT(distinct CONCAT(us.first_name,' ', IFNULL(us.last_name, ''),'-',us.id)) as assign_to_name, CONVERT(l.assign_to USING utf8) as assign_to, CONVERT(l.sales_manager USING utf8) as sales_manager, c.company_name as company_name, CONCAT(c.first_name,' ', IFNULL(c.last_name, '')) as contact_name, c.email as contact_email, c.mobile as contact_mobile, c.mobile as contact_mobile, c.profile_image as contact_profile_image, c.profile_image_original_name as contact_profile_image_original_name, pa.name_of_building as property_name,  CONCAT(us2.first_name,' ', IFNULL(us2.last_name, '')) as created_by_name, lr.age_of_property as age_of_property, lr.vasthu_compliant as vasthu_compliant,  CONVERT(lr.furnishing USING utf8) as furnishing, CONVERT(lr.amenities USING utf8) as amenities, CONVERT(lr.possession_status USING utf8) as possession_status,
//   lr.budget_min as budget_min, lr.budget_max as budget_max, lr.no_of_bedrooms_min as no_of_bedrooms_min, lr.no_of_bedrooms_max as no_of_bedrooms_max, lr.no_of_bathrooms_min as no_of_bathrooms_min, lr.no_of_bathrooms_max as no_of_bathrooms_max, lr.plot_area_min as plot_area_min, lr.plot_area_max as plot_area_max, lr.built_up_area_min as built_up_area_min, lr.built_up_area_max as built_up_area_max, lr.car_park_min as car_park_min, lr.car_park_max as car_park_max, lr.timeline_for_closure_min as timeline_for_closure_min, lr.timeline_for_closure_max as timeline_for_closure_max, lr.property_facing as property_facing, lr.country as country, lr.state as state, lr.city as city, lr.zipcode as zipcode,
//   lr.locality as locality,
//   lrn.option_value as looking_for_name, 
//   pt.option_value as property_type_name, 
//   ls.option_value as lead_source_name,
//   lg.option_value as lead_group_name,
//   seg.option_value as segment_name,
//   lp.option_value as lead_priority_name,
//   lss.option_value as lead_status_name,
//   aop.option_value as age_of_property_name,
//   vc.option_value as vasthu_compliant_name,
//   pf.option_value as property_facing_name,
//   GROUP_CONCAT(distinct CONCAT(amen.option_value),'-',amen.id) as amenities_name,
//   GROUP_CONCAT(distinct CONCAT(ps.option_value),'-',ps.id) as possession_status_name,
//   GROUP_CONCAT(distinct CONCAT(fur.option_value),'-',fur.id) as furnishing_name,

//   (SELECT COUNT(id) FROM lz_notes where status = 1 and (module_id = l.id and module_name = 2 or module_id = l.contact_id)) as notes_count,
//   (SELECT COUNT(id) FROM lz_file_uploads where module_id = l.id and module_name = 2 ) as files_count,
//   (SELECT ifnull(COUNT(*),0) FROM lz_tasks as t LEFT JOIN lz_leads on (lz_leads.id = l.contact_id) where t.contact = l.contact_id) as task_count,
//   (SELECT reply FROM lz_notes where module_name = 2 and module_id = l.id order by id desc limit 1 ) as last_note,
//   (SELECT DATE_FORMAT(ta.task_time,'%Y-%m-%d') FROM lz_tasks as ta where ta.contact = l.contact_id and ta.task_time <= curdate() order by ta.task_time DESC limit 1) as last_task_date,
//   (SELECT DATE_FORMAT(ta.task_time,'%Y-%m-%d') FROM lz_tasks as ta where ta.contact = l.contact_id and ta.task_time >= curdate() order by ta.task_time limit 1) as next_task_date

//   from lz_leads as l
//   LEFT JOIN lz_contacts as c on (c.id = l.contact_id) 
//   LEFT JOIN lz_lead_requirements as lr on (l.id = lr.lead_id) 
//   LEFT JOIN lz_property_addresses as pa on (pa.property_id = l.property_id) 
//   LEFT JOIN lz_user as us on FIND_IN_SET(us.id,l.assign_to) > 0 
//   LEFT JOIN lz_user as us2 on (us2.id = l.created_by)
//   LEFT JOIN lz_masters as lrn on (lrn.id = l.looking_for) 
//   LEFT JOIN lz_masters as pt on (pt.id = l.property_type)
//   LEFT JOIN lz_masters as ls on (ls.id = l.lead_source)
//   LEFT JOIN lz_masters as lg on (lg.id = l.lead_group)
//   LEFT JOIN lz_masters as seg on (seg.id = l.segment)
//   LEFT JOIN lz_masters as lp on (lp.id = l.lead_priority)
//   LEFT JOIN lz_masters as lss on (lss.id = l.lead_status)
//   LEFT JOIN lz_masters as aop on (aop.id = lr.age_of_property)
//   LEFT JOIN lz_masters as vc on (vc.id = lr.vasthu_compliant)
//   LEFT JOIN lz_masters as pf on (pf.id = lr.property_facing) 
  
//   LEFT JOIN lz_user as us5 on FIND_IN_SET(us5.id,c.assign_to) > 0 
//   left join lz_user as us4 on (us5.team_leader = us4.id) 
//   LEFT JOIN lz_user as us6 on FIND_IN_SET(us6.id,c.assign_to) > 0 
//   left join lz_user as us7 on (us6.portfolio_head = us7.id) 
//   `

//   thisQuery += 'LEFT JOIN lz_masters as amen on FIND_IN_SET(amen.id,lr.amenities) > 0 '
//   thisQuery += 'LEFT JOIN lz_masters as fur on FIND_IN_SET(fur.id,lr.furnishing) > 0 '
//   thisQuery += 'LEFT JOIN lz_masters as ps on FIND_IN_SET(ps.id,lr.possession_status) > 0 '
//   thisQuery += `where ${role_id == 1 ? `l.status IN (1,2) ` : `l.status = 1 `}`

//   if (role_id == 1) {
//     thisQuery += ` `
//   }
//   if (role_id == 2) {
//     thisQuery += ` and (FIND_IN_SET(${created_by},l.assign_to)>0 or us.team_leader = ${created_by} or us.portfolio_head = ${created_by} or us2.team_leader = ${created_by} or us2.portfolio_head = ${created_by} or l.created_by = ${created_by}) `
//     // thisQuery += ` and c.created_by = ${created_by} `
//   }
//   if (role_id == 3) {
//     thisQuery += ` and (FIND_IN_SET(${created_by},l.assign_to)>0 OR us.team_leader = ${created_by} OR us.portfolio_head = ${created_by} or us2.team_leader = ${created_by} or us2.portfolio_head = ${created_by} OR l.created_by = ${created_by}) `
//     // thisQuery += ` and c.created_by = ${created_by} `
//   }
//   if (role_id == 4) {
//     thisQuery += ` and (FIND_IN_SET(${created_by},l.assign_to)>0 or l.created_by = ${created_by}) `
//   }
//   if (role_id == 5) {
//     thisQuery += ` `
//   }
//   if (role_id == 6) {
//     thisQuery += `and l.created_by = ${created_by} `
//   }
//   if (role_id >= 7) {
//     thisQuery += `and l.created_by = ${created_by} `
//   }

//   const filters = req.query;
//   // for (key in filters) {
//     if (filters.looking_for) {
//       thisQuery += " and l.looking_for = " + `${filters.looking_for} `
//     }
//     if (filters.lead_source) {
//       thisQuery += "and l.lead_source = " + `${filters.lead_source} `
//     }
//     if (filters.lead_group) {
//       thisQuery += "and l.lead_group = " + `${filters.lead_group} `
//     }
//     if (filters.fee_oppurtunity) {
//       thisQuery += "and l.fee_oppurtunity = " + `${filters.fee_oppurtunity} `
//     }
//     if (filters.lead_status) {
//       thisQuery += "and l.lead_status = " + `${filters.lead_status} `
//     }
//     if (filters.created_by) {
//       thisQuery += " and l.created_by = " + `${filters.created_by} `
//     }
//     // if (filters.assign_to) {
//     //   var a = filters.assign_to;
//     //   var b = a.replace(/[,]/g, ",");
//     //   thisQuery += `and CONCAT(',', l.assign_to, ',') REGEXP ',(${a}),' `
//     // }
//     if (filters.assign_to) {
//       var a = filters.assign_to;
//       let a1 = a.split(',').map(item => `'${item}'`).join(',');
//       // thisQuery += `and CONCAT(',', c.assign_to, ',') REGEXP ',(${a1}),' `
//       thisQuery += " and (l.assign_to IN (" + a1 + ")" + ` OR CONCAT(',', l.assign_to, ',') REGEXP ',(${a}),' )`
//     }
//     // WHERE Price BETWEEN 50 AND 60;
//     // WHERE CategoryID and SupplierID BETWEEN 7 AND 28;
//     // thisQuery += ` and no_of_bedrooms_min >= ${filters.no_of_bedrooms_min} and no_of_bedrooms_max <= ${filters.no_of_bedrooms_max} `

//     // if (filters.no_of_bedrooms_min && filters.no_of_bedrooms_max) {
//     //   thisQuery += ` and no_of_bedrooms_min and no_of_bedrooms_max BETWEEN ${filters.no_of_bedrooms_min} and ${filters.no_of_bedrooms_max} ` 
//     // }
//     if (filters.no_of_bedrooms_min) {
//       thisQuery += " and lr.no_of_bedrooms_min <= " + `'${filters.no_of_bedrooms_min}' `
//     }
//     if (filters.no_of_bedrooms_max) {
//       thisQuery += " and lr.no_of_bedrooms_max >= " + `'${filters.no_of_bedrooms_max}' `
//     }

//     if (filters.no_of_bathrooms_min && filters.no_of_bathrooms_max) {
//       thisQuery += ` and no_of_bathrooms_min and no_of_bathrooms_max BETWEEN ${filters.no_of_bathrooms_min} and ${filters.no_of_bathrooms_max} ` 
//     }
//     if (filters.budget_min && filters.budget_max) {
//       thisQuery += ` and budget_min and budget_max BETWEEN ${filters.budget_min} and ${filters.budget_max} ` 
//     }
//     if (filters.built_up_area_min && filters.built_up_area_max) {
//       thisQuery += ` and built_up_area_min and built_up_area_max BETWEEN ${filters.built_up_area_min} and ${filters.built_up_area_max} ` 
//     }
//     if (filters.plot_area_min && filters.plot_area_max) {
//       thisQuery += ` and plot_area_min and plot_area_max BETWEEN ${filters.plot_area_min} and ${filters.plot_area_max} ` 
//     }
//     // if (filters.possession_status) {
//     //   var a = filters.possession_status;
//     //   var b = a.replace(/[,]/g, ",");
//     //   thisQuery += `and CONCAT(',', lr.possession_status, ',') REGEXP ',(${a}),' `
//     // }
//     if (filters.possession_status) {
//       var a = filters.possession_status;
//       let a1 = a.split(',').map(item => `'${item}'`).join(',');
//       // thisQuery += `and CONCAT(',', c.possession_status, ',') REGEXP ',(${a1}),' `
//       thisQuery += " and (lr.possession_status IN (" + a1 + ")" + ` OR CONCAT(',', lr.possession_status, ',') REGEXP ',(${a}),' )`
//     }
//     if (filters.age_of_property) {
//       thisQuery += " and lr.age_of_property = " + `${filters.age_of_property} `
//     }
//     if (filters.vasthu_compliant) {
//       thisQuery += " and lr.vasthu_compliant = " + `${filters.vasthu_compliant} `
//     }
//     if (filters.property) {
//       thisQuery += " and l.property_id = " + `${filters.property} `
//     }
//     if (filters.priority) {
//       thisQuery += " and l.lead_priority = " + `${filters.priority} `
//     }
//     if (filters.property_type) {
//       thisQuery += " and l.property_type = " + `${filters.property_type} `
//     }
//     // if (filters.furnishing) {
//     //   var a = filters.furnishing;
//     //   var b = a.replace(/[,]/g, ",");
//     //   thisQuery += `and CONCAT(',', lr.furnishing, ',') REGEXP ',(${a}),' `
//     // }
//     if (filters.furnishing) {
//       var a = filters.furnishing;
//       let a1 = a.split(',').map(item => `'${item}'`).join(',');
//       // thisQuery += `and CONCAT(',', c.furnishing, ',') REGEXP ',(${a1}),' `
//       thisQuery += " and (lr.furnishing IN (" + a1 + ")" + ` OR CONCAT(',', lr.furnishing, ',') REGEXP ',(${a}),' )`
//     }
//     if (filters.car_park_min) {
//       thisQuery += " and lr.car_park_min = " + `${filters.car_park_min} `
//     }
//     if (filters.car_park_max) {
//       thisQuery += " and lr.car_park_max = " + `${filters.car_park_max} `
//     }
//     if (filters.timeline_for_closure_min) {
//       thisQuery += " and lr.timeline_for_closure_min = " + `${filters.timeline_for_closure_min} `
//     }
//     if (filters.timeline_for_closure_max) {
//       thisQuery += " and lr.timeline_for_closure_max = " + `${filters.timeline_for_closure_max} `
//     }
//     // if (filters.amenities) {
//     //   var a = filters.amenities;
//     //   var b = a.replace(/[,]/g, ",");
//     //   thisQuery += `and CONCAT(',', lr.amenities, ',') REGEXP ',(${a}),' `
//     // }
//     if (filters.amenities) {
//       var a = filters.amenities;
//       let a1 = a.split(',').map(item => `'${item}'`).join(',');
//       // thisQuery += `and CONCAT(',', c.amenities, ',') REGEXP ',(${a1}),' `
//       thisQuery += " and (lr.amenities IN (" + a1 + ")" + ` OR CONCAT(',', lr.amenities, ',') REGEXP ',(${a}),' )`
//     }
//     if (filters.created_at) {
//       thisQuery += " and l.created_at = " + `${filters.created_at} `
//     }
//   // }
//   thisQuery += ' group by l.id '

//   if (filters.order_by) {
//     let orderByString = filters.order_by.split('|')
//     thisQuery += " order by " + `${orderByString[0]} ${orderByString[1]} `
//   }
//   const data1 = await db2.sequelize.query(thisQuery);

//   if (filters.order_by =="" || filters.order_by == undefined) {
//     thisQuery += '  order by l.id DESC '
//   }

//   if (filters.limit) {
//     thisQuery += ` limit ${filters.limit},12 `
//   }

//   const data = await db2.sequelize.query(thisQuery);

//   const count_filter = (data1[0])

//     res.status(200).send({
//       status:200,
//       message:'Success',
//       count: count_filter.length,
//       output: data[0],
//     });
//   } catch (error) {
//     res.status(500).send({
//       message: error.message,
//     });
//   }
// };


exports.editLead = async (req, res) => {
  try {
    const created_id = req.user.id
    const created_by = created_id.id
    console.log('created_by', created_by);
  
    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);
  
    const role = req.user.id
    const role_id = role.designation
    console.log('role_id', role_id);

    const id = req.params.id;
    let thisQuery = `select l.*, GROUP_CONCAT(distinct CONCAT(us.first_name,' ', IFNULL(us.last_name, ''),'-',us.id)) as assign_to_name, CONVERT(l.assign_to USING utf8) as assign_to, CONVERT(l.sales_manager USING utf8) as sales_manager, c.company_name as company_name, CONCAT(c.first_name,' ', IFNULL(c.last_name, '')) as contact_name, c.email as contact_email, c.mobile as contact_mobile, c.mobile as contact_mobile, c.profile_image as contact_profile_image, c.profile_image_original_name as contact_profile_image_original_name,  pa.name_of_building as property_name,  CONCAT(us2.first_name,' ', IFNULL(us2.last_name, '')) as created_by_name,  lr.age_of_property as age_of_property, lr.vasthu_compliant as vasthu_compliant, CONVERT(lr.furnishing USING utf8) as furnishing, CONVERT(lr.amenities USING utf8) as amenities, CONVERT(lr.possession_status USING utf8) as possession_status, lr.property_facing as property_facing,
    lr.budget_min as budget_min, lr.budget_max as budget_max, lr.no_of_bedrooms_min as no_of_bedrooms_min, lr.no_of_bedrooms_max as no_of_bedrooms_max, lr.no_of_bathrooms_min as no_of_bathrooms_min, lr.no_of_bathrooms_max as no_of_bathrooms_max, lr.plot_area_min as plot_area_min, lr.plot_area_max as plot_area_max, lr.built_up_area_min as built_up_area_min, lr.built_up_area_max as built_up_area_max, lr.car_park_min as car_park_min, lr.car_park_max as car_park_max, lr.timeline_for_closure_min as timeline_for_closure_min, lr.timeline_for_closure_max as timeline_for_closure_max, lr.country as country, lr.state as state, lr.city as city, lr.zipcode as zipcode,
    lr.locality as locality,
    lrn.option_value as looking_for_name, 
    pt.option_value as property_type_name, 
    ls.option_value as lead_source_name,
    lg.option_value as lead_group_name,
    seg.option_value as segment_name,
    lp.option_value as lead_priority_name,
    lss.option_value as lead_status_name,
    aop.option_value as age_of_property_name,
    vc.option_value as vasthu_compliant_name,
    pf.option_value as property_facing_name,
    GROUP_CONCAT(distinct CONCAT(amen.option_value),'-',amen.id) as amenities_name,
    GROUP_CONCAT(distinct CONCAT(ps.option_value),'-',ps.id) as possession_status_name,
    GROUP_CONCAT(distinct CONCAT(fur.option_value),'-',fur.id) as furnishing_name,
    (SELECT COUNT(id) FROM lz_notes where module_id = l.id and module_name = 2 and status = 1) as notes_count,
    (SELECT COUNT(id) FROM lz_file_uploads where module_id = l.id and module_name = 2 ) as files_count,
    (SELECT ifnull(COUNT(*),0) FROM lz_tasks as t LEFT JOIN lz_leads on (lz_leads.id = l.contact_id) where t.contact = l.contact_id) as task_count
    from lz_leads as l
    LEFT JOIN lz_contacts as c on (c.id = l.contact_id) 
    LEFT JOIN lz_lead_requirements as lr on (l.id = lr.lead_id) 
    LEFT JOIN lz_property_addresses as pa on (pa.property_id = l.property_id) 
    LEFT JOIN lz_user as us on FIND_IN_SET(us.id,l.assign_to) > 0 
    LEFT JOIN lz_user as us2 on FIND_IN_SET(us2.id,l.created_by) > 0 
    LEFT JOIN lz_masters as lrn on (lrn.id = l.looking_for) 
    LEFT JOIN lz_masters as pt on (pt.id = l.property_type)
    LEFT JOIN lz_masters as ls on (ls.id = l.lead_source)
    LEFT JOIN lz_masters as lg on (lg.id = l.lead_group)
    LEFT JOIN lz_masters as seg on (seg.id = l.segment)
    LEFT JOIN lz_masters as lp on (lp.id = l.lead_priority)
    LEFT JOIN lz_masters as lss on (lss.id = l.lead_status)
    LEFT JOIN lz_masters as aop on (aop.id = lr.age_of_property)
    LEFT JOIN lz_masters as vc on (vc.id = lr.vasthu_compliant)
    LEFT JOIN lz_masters as pf on (pf.id = lr.property_facing) `;
  
    thisQuery += 'LEFT JOIN lz_masters as amen on FIND_IN_SET(amen.id,lr.amenities) > 0 '
    thisQuery += 'LEFT JOIN lz_masters as fur on FIND_IN_SET(fur.id,lr.furnishing) > 0 '
    thisQuery += 'LEFT JOIN lz_masters as ps on FIND_IN_SET(ps.id,lr.possession_status) > 0 '
    thisQuery += `where l.status IN (1,2) and l.id = ${id} group by l.id `


    const data1 = await db2.sequelize.query(thisQuery);

    const data = await db2.sequelize.query(thisQuery);
    console.log("dataaaaaaa", data);

    const localityCountryData = data[0][0]?.country
    const localityStateData = data[0][0]?.state
    const localityCityData = data[0][0]?.city
    const countryData = await db['country'].findOne({
      where: {
        status: 1, id:localityCountryData
      },
      attributes:['name'],
    });
    const stateData = await db['state'].findOne({
      where: {
        status: 1, id:localityStateData
      },
      attributes:['name'],
    });
    const cityData = await db['city'].findOne({
      where: {
        status: 1, id:localityCityData
      },
      attributes:['name'],
    });

    if (data1) {
      res.status(200).send({
        status:200,
        message:'Success',
        output: [{...data1[0][0], country_name: countryData?.dataValues.name ?? "",  state_name: stateData?.dataValues.name ?? "",  city_name: cityData?.dataValues.name ?? "" }],
      });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot find with id : ${id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.updateLead = async (req, res) => {
  try {
    const id = req.params.id;

    const created_by = req.user.id
    console.log('created_by', created_by.id);

    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    const role = req.user.id
    const role_id = role.designation
    console.log('role_id', role_id);
    
    let thisQuery = ` select l.contact_id as contact_id, c.first_name as contact_name, l.lead_source as source, so.option_value as source_name, l.lead_status as lead_status, cs.option_value as lead_status_name, l.property_id as property_id, pa.name_of_building as property_name, l.assign_to as assign_to, GROUP_CONCAT(distinct CONCAT(us.first_name,' ', IFNULL(us.last_name, ''))) as assign_to_name
    from lz_leads as l
    left join lz_contacts as c on (c.id = l.contact_id)
    left join lz_properties as p on (p.id = l.property_id)
    left join lz_property_addresses as pa on (p.id = pa.property_id)
    left join lz_masters as so on (so.id = l.lead_source)
    left join lz_masters as cs on (cs.id = l.lead_status)
    LEFT JOIN lz_user as us on FIND_IN_SET(us.id,l.assign_to) > 0 
    where ${role_id == 1 ? `l.status IN (1,2) ` : `l.status = 1`} and l.id = ${id} `
    const data123= await db2.sequelize.query(thisQuery);
    const dataContactID = data123[0][0]?.contact_id
    const dataContactName = data123[0][0]?.contact_name
    const dataSource = data123[0][0]?.source
    const dataSourceName = data123[0][0]?.source_name
    const dataStatus = data123[0][0]?.lead_status
    const dataStatusName = data123[0][0]?.lead_status_name
    const dataProperty = data123[0][0]?.property_id
    const dataPropertyName = data123[0][0]?.property_name
    const dataAssign = data123[0][0]?.assign_to
    const dataAssignName = data123[0]?.map(item => item.assign_to_name).join(', ')

    console.log("dataContactID", dataContactID);
    console.log("dataContactName", dataContactName);
    console.log("dataSourceName", dataSourceName);
    console.log("dataStatus", dataStatus);
    console.log("dataStatusName", dataStatusName);
    console.log("dataProperty", dataProperty);
    console.log("dataPropertyName", dataPropertyName);
    console.log("dataAssign", dataAssign);
    console.log("dataAssignName", dataAssignName);

    const data = {
      contact_id: req.body.contact_id,
      property_id: req.body.property_id,
      looking_for: req.body.looking_for,
      property_type: req.body.property_type,
      city: req.body.city,
      lead_source: req.body.lead_source,
      lead_group: req.body.lead_group,
      segment: req.body.segment,
      lead_priority: req.body.lead_priority,
      fee_oppurtunity: req.body.fee_oppurtunity,
      lead_status: req.body.lead_status,
      assign_to: req.body.assign_to,
      sales_manager: req.body.sales_manager,
      }
      let LeadId = req.params.id

    const num = await db2['leads'].update(data, {
      where: { id: id },
    });
    if (num == 1) {
          // Source
          if(req.body.lead_source) {
            let thisQuery456 = ` select l.lead_source as l_source, so.option_value as l_source_name
            from lz_leads as l
            left join lz_masters as so on (so.id = l.lead_source)
            where ${role_id == 1 ? `l.status IN (1,2) ` : `l.status = 1`} and l.lead_source = ${req.body.lead_source}
            `
            const dataSO = await db2.sequelize.query(thisQuery456);
            const dataSO1 = dataSO[0][0]?.l_source
            const dataSO2 = dataSO[0][0]?.l_source_name
            console.log("dataSO1", dataSO1);
            console.log("dataSO2", dataSO2);
  
          if(dataSource?.toString() !== req.body.lead_source?.toString()) {
            const LeadSourceLog = await db2['logs'].create({
              org_id: org_id,
              module_id: LeadId,
              module_name: "2",
              note: 'Lead source : ' + dataSourceName + ' to '+ dataSO2,
              user_id: created_by.id
            })
            console.log("Lead Source",LeadSourceLog.dataValues.note);
          }
        }
          // Lead Status
          if(req.body.lead_status) {
            let thisQuery456 = ` select l.lead_status as l_status, cs.option_value as l_status_name
            from lz_leads as l
            left join lz_masters as cs on (cs.id = l.lead_status)
            where ${role_id == 1 ? `l.status IN (1,2) ` : `l.status = 1`} and l.lead_status = ${req.body.lead_status}
            `
            const dataCS = await db2.sequelize.query(thisQuery456);
            const dataCS1 = dataCS[0][0]?.l_status
            const dataCS2 = dataCS[0][0]?.l_status_name
            console.log("dataCS1", dataCS1);
            console.log("dataCS2", dataCS2);
  
          if(dataStatus?.toString() !== req.body.lead_status?.toString()) {
            const LeadStatusLog = await db2['logs'].create({
              org_id: org_id,
              module_id: LeadId,
              module_name: "2",
              note: 'Lead status : ' + dataStatusName + ' to '+ dataCS2,
              user_id: created_by.id
            })
            console.log("Lead Status",LeadStatusLog.dataValues.note);
          }
        }
        // Contact Name
          if(req.body.contact_id) {
            let thisQuery456 = ` select l.contact_id as l_contact_id, c.first_name as l_contact_name
            from lz_leads as l
            left join lz_contacts as c on (c.id = l.contact_id)
            where ${role_id == 1 ? `l.status IN (1,2) ` : `l.status = 1`} and l.contact_id = ${req.body.contact_id}
            `
            const dataC = await db2.sequelize.query(thisQuery456);
            const dataC1 = dataC[0][0]?.l_contact_id
            const dataC2 = dataC[0][0]?.l_contact_name
            console.log("dataC1", dataC1);
            console.log("dataC2", dataC2);
  
          if(dataContactID?.toString() !== req.body.contact_id?.toString()) {
            const LeadContactLog = await db2['logs'].create({
              org_id: org_id,
              module_id: LeadId,
              module_name: "2",
              note: 'Lead contact name : ' + dataContactName + ' to '+ dataC2,
              user_id: created_by.id
            })
            console.log("Lead Contact name",LeadContactLog.dataValues.note);
          }
        }
        // Property Name
        if(req.body.property_id) {
          let thisQueryPro = ` select l.property_id as l_property_id, pa1.name_of_building as l_property_name
          from lz_leads as l
          left join lz_properties as p on (p.id = l.property_id)
          left join lz_property_addresses as pa1 on (p.id = pa1.property_id)
          where ${role_id == 1 ? `l.status IN (1,2) ` : `l.status = 1`} and l.property_id = ${req.body.property_id}
          `
          const dataPro = await db2.sequelize.query(thisQueryPro);
          const dataPro1 = dataPro[0][0]?.l_property_id
          const dataPro2 = dataPro[0][0]?.l_property_name
          console.log("dataPro1", dataPro1);
          console.log("dataPro2", dataPro2);

        if(dataProperty?.toString() !== req.body.property_id?.toString()) {
          const contactPropertyLog = await db2['logs'].create({
            org_id: org_id,
            module_id: LeadId,
            module_name: "2",
            note: 'Lead propery name : ' + dataPropertyName + ' to '+ dataPro2,
            user_id: created_by.id
          })
          console.log("Lead Property",contactPropertyLog.dataValues.note);
        }
      }
      // Assign To Name
      if(req.body.assign_to) {
        let thisQuery456 = ` select c.assign_to as assign_to, GROUP_CONCAT(distinct CONCAT(us.first_name,' ', IFNULL(us.last_name, ''))) as assign_to_name
        from lz_leads as c
        left join lz_user as us on FIND_IN_SET(us.id,c.assign_to)>0
        where ${role_id == 1 ? `c.status IN (1,2) ` : `c.status = 1`} and c.assign_to IN ('${req.body.assign_to}')
        `
        const dataSO = await db2.sequelize.query(thisQuery456);
        const dataSO1 = dataSO[0][0]?.assign_to
        const dataSO2 = dataSO[0][0]?.assign_to_name
        console.log("dataSO1", dataSO1);
        console.log("dataSO2", dataSO2);

      if(dataAssign !== req.body.assign_to) {
        const leadAssignLog = await db2['logs'].create({
          org_id: org_id,
          module_id: LeadId,
          module_name: "2",
          // note: 'Contact Source : ' + dataSourceName + ' TO '+ dataSO2,
          note: 'Assign To : ' + `${dataAssignName == null ? dataSO2 : dataAssignName + '  TO  '+ dataSO2}`,
          user_id: created_by.id
        })
        console.log("Assign To", leadAssignLog?.dataValues?.note);
      }
    }

      res.status(200).send({
        status:200,
        message: "Updated successfully."
      });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot update with id : ${id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.updateLeadRequirement = async (req, res) => {
  try {
    const id = req.params.lead_id;

    const created_by = req.user.id
    console.log('created_by', created_by.id);

    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    const data = {
      requirement_location: req.body.requirement_location,
      budget_min: req.body.budget_min,
      budget_max: req.body.budget_max,
      money_term_min: req.body.money_term_min,
      money_term_max: req.body.money_term_max,
      no_of_bedrooms_min: req.body.no_of_bedrooms_min,
      no_of_bedrooms_max: req.body.no_of_bedrooms_max,
      no_of_bathrooms_min: req.body.no_of_bathrooms_min,
      no_of_bathrooms_max: req.body.no_of_bathrooms_max,
      built_up_area_min: req.body.built_up_area_min,
      built_up_area_max: req.body.built_up_area_max,
      plot_area_min: req.body.plot_area_min,
      plot_area_max: req.body.plot_area_max,
      possession_status: req.body.possession_status,
      age_of_property: req.body.age_of_property,
      vasthu_compliant: req.body.vasthu_compliant,
      property_facing: req.body.property_facing,
      furnishing: req.body.furnishing,
      car_park_min: req.body.car_park_min,
      car_park_max: req.body.car_park_max,
      timeline_for_closure_min: req.body.timeline_for_closure_min,
      timeline_for_closure_max: req.body.timeline_for_closure_max,
      amenities: req.body.amenities,
      country: req.body.country,
      state: req.body.state,
      city: req.body.city,
      zipcode: req.body.zipcode,
      locality: req.body.locality,
      }

    const num = await db2['leadRequirement'].update(data, {
      where: { lead_id: id },
    });
    if (num == 1) {
        const leadLogs = await db2['logs'].create({
          org_id: org_id,
          module_id: id,
          module_name: "1",
          note: "Lead requirement updated at",
          user_id: created_by.id
        })
        // console.log("leadLogs", leadLogs);

      res.status(200).send({
        status:200,
        message: "Updated successfully."
      });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot update with id : ${id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.deleteLead = async (req, res) => {
  const organ_id = req.user.id
  const org_id = organ_id.org_id
  console.log('organ_id', org_id);

  const role = req.user.id
  const role_id = role.designation
  console.log('role_id', role_id);

  const created_by = req.user.id
  console.log('created_by', created_by.id);

    try {
      let x = req.params.id
      
      console.log("id111", x);

      let thisQuery  = ` UPDATE lz_leads SET status = 0 `;
          thisQuery += " WHERE id IN (" + x + ") "
          thisQuery += ` and ${role_id == 1 ? `status IN (1,2) ` : `status = 1`} `;

      const data = await db2.sequelize.query(thisQuery);

      res.status(200).send({
        status:200,
        message:'Success',
        output:data[0]
      });

    } catch (error) {
      res.status(500).send({
        message: error.message,
      });
    }
};
exports.updateLeadStatus = async (req, res) => {
  try {
    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    const created_by = req.user.id
    console.log('created_by', created_by.id);

    const id = req.params.id;

    let thisQuery = ` select l.lead_status as lead_status, cs.option_value as lead_status_name
    from lz_leads as l
    left join lz_masters as cs on (cs.id = l.lead_status)
    where l.status = 1 and l.id = ${id} `
    const data123= await db2.sequelize.query(thisQuery);
    const dataStatus = data123[0][0]?.lead_status
    const dataStatusName = data123[0][0]?.lead_status_name
    console.log("dataStatus", dataStatus);
    console.log("dataStatusName", dataStatusName);

    const data = {
      lead_status: req.body.lead_status,
    }

    const leadStatus = req.body.lead_status
    console.log("leadStatusssssss", leadStatus);

    const num = await db2['leads'].update(data, {
      where: { id: id },
    });
    if (num == 1) {

      let thisQuery = ` select option_value from lz_masters where option_type = "lead_status" and id = ${leadStatus} `
      const data = await db2.sequelize.query(thisQuery);
      const dataValue = data[0][0]?.option_value
      console.log("dataaaaa", dataValue);

      let thisQuery1 = `SELECT l.*, c.email as email
      FROM lz_leads as l 
      LEFT JOIN lz_contacts as c on (c.id = l.contact_id)
      WHERE l.status = 1 and l.id = ${id} `
      const data1 = await db2.sequelize.query(thisQuery1);
      const dataV = data1[0][0]
      console.log("LeadList", dataV);

      if(leadStatus == 62) {
        const LeadData = {
          status: 2,
        }
        const leadDrop = await db2['leads'].update(LeadData,{
          where: { id: id },
        });
      }

      if(leadStatus == 61) {
        const data = await db2['transaction'].create({
          org_id: org_id,
          lead_id: id,
          booking_date: req.body.booking_date,
          country: req.body.country,
          state: req.body.state,
          city: req.body.city,
          lead_source: req.body.lead_source,
          team_leader: req.body.team_leader,
          shared_with: req.body.shared_with,
          closed_by: req.body.closed_by,
          transaction_status: 338 ?? req.body.transaction_status,
          developer_name: req.body.developer_name,
          project_name: dataV?.property_id,
          client_name: dataV?.contact_id,
          contact_number: req.body.contact_number,
          email_id: dataV?.email,
          dob: req.body.dob,
          anniversary_date: req.body.anniversary_date,
          discount_amount: req.body.discount_amount,
          block_no: req.body.block_no,
          unit_no: req.body.unit_no,
          floor_no: req.body.floor_no,
          bhk_type: req.body.bhk_type,
          unit_size: req.body.unit_size,
          plot_size: req.body.plot_size,
          frc: req.body.frc,
          plc: req.body.plc,
          basic_price: req.body.basic_price ?? 0,
          car_parking_cost: req.body.basic_price,
          pan: req.body.pan,
          agreement_value: req.body.agreement_value  ?? 0,
          brokerage_percentage	: req.body.brokerage_percentage	,
          brokerage_value: req.body.brokerage_value,
          aop_percentage: req.body.aop_percentage,
          discount_value: req.body.discount_value,
          discount_paid_status: req.body.discount_paid_status,
          tds_value: req.body.tds_value,
          revenue: req.body.revenue,
          created_by: created_by.id
        });
        
        const TransactionID = data?.dataValues.id
        const data1 = await db2['transactionBrokerageDetails'].create({
            transaction_id: TransactionID,
        })
        const data2 = await db2['transactionInvoicingDetails'].create({
            transaction_id: TransactionID,
        })
        const TransactionLogs = await db2['logs'].create({
            org_id: org_id,
            module_id: TransactionID,
            module_name: "5",
            note: "Transaction created at",
            user_id: created_by.id
        })

        const LeadData = {
          status: 0,
        }
        const leadDelete = await db2['leads'].update(LeadData,{
          where: { id: id },
        });
      } 
      let LeadId = req.params.id

      // Lead Status
      if(req.body.lead_status) {
        let thisQuery456 = ` select l.lead_status as l_status, cs.option_value as l_status_name
        from lz_leads as l
        left join lz_masters as cs on (cs.id = l.lead_status)
        where l.status = 1 and l.lead_status = ${req.body.lead_status}
        `
        const dataCS = await db2.sequelize.query(thisQuery456);
        const dataCS1 = dataCS[0][0]?.l_status
        const dataCS2 = dataCS[0][0]?.l_status_name
        console.log("dataCS1", dataCS1);
        console.log("dataCS2", dataCS2);

      if(dataStatus?.toString() !== req.body.lead_status?.toString()) {
        const LeadStatusLog = await db2['logs'].create({
          org_id: org_id,
          module_id: LeadId,
          module_name: "2",
          note: 'Lead status : ' + dataStatusName + ' to '+ dataCS2,
          user_id: created_by.id
        })
        console.log("Lead Status",LeadStatusLog.dataValues.note);
      }
    }

      res.status(200).send({
        status:200,
        message: "Updated successfully."
      });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot update with id : ${id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.saveLeadFilter = async (req, res) => {
  try {
    const created_by = req.user.id
    console.log('created_by', created_by.id);

    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    let thisQuery1 = ` SELECT id FROM lz_lead_filter `
    const data1 = await db2.sequelize.query(thisQuery1);
    const totalLead = data1[0].length
    console.log("totalLead", totalLead);
    
    if (totalLead < 5) {

    const data = await db2['leadFilter'].create({
      property_id: req.body.property_id,
      looking_for: req.body.looking_for,
      property_type: req.body.property_type,
      requirement_location: req.body.requirement_location,
      lead_source: req.body.lead_source,
      lead_priority: req.body.lead_priority,
      lead_group: req.body.lead_group,
      fee_oppurtunity: req.body.fee_oppurtunity,
      lead_status: req.body.lead_status,
      assign_to: req.body.assign_to,
      no_of_bedrooms_min: req.body.no_of_bedrooms_min,
      no_of_bedrooms_max: req.body.no_of_bedrooms_max,
      no_of_bathrooms_min: req.body.no_of_bathrooms_min,
      no_of_bathrooms_max: req.body.no_of_bathrooms_max,
      budget_min: req.body.budget_min,
      budget_max: req.body.budget_max	,
      built_up_area_min: req.body.built_up_area_min,
      built_up_area_max: req.body.built_up_area_max,
      plot_area_min: req.body.plot_area_min,
      plot_area_max: req.body.plot_area_max,
      car_park_min: req.body.car_park_min,
      car_park_max: req.body.car_park_max,
      timeline_for_closure_min: req.body.timeline_for_closure_min,
      timeline_for_closure_max: req.body.timeline_for_closure_max,
      age_of_property: req.body.age_of_property,
      vasthu_compliant: req.body.vasthu_compliant,
      property_facing: req.body.property_facing,
      furnishing: req.body.furnishing,
      possession_status: req.body.possession_status,
      filter_name: req.body.filter_name,
      created_date: req.body.created_date,
      updated_date: req.body.updated_date,
      amenities: req.body.amenities,
      created_by: created_by.id
    });
    res.status(200).send({
      status: 200,
      message: 'Success',
      output: data
    });
  }
  else {
    res.status(200).send({
      status: 400,
      message: 'Only 5 filters can add',
      output: []
    });
  }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.getLeadFilter = async (req, res) => {
  try {
    
  const organ_id = req.user.id
  const org_id = organ_id.org_id
  console.log('organ_id', org_id);
  
  let thisQuery = `select l.*, GROUP_CONCAT(distinct CONCAT(us.first_name,' ', IFNULL(us.last_name, ''),'-',us.id)) as assign_to_name, CONVERT(l.assign_to USING utf8) as assign_to, pa.name_of_building as property_name,  CONCAT(us2.first_name,' ', IFNULL(us2.last_name, '')) as created_by_name,
  l.budget_min as budget_min, l.budget_max as budget_max, l.no_of_bedrooms_min as no_of_bedrooms_min, l.no_of_bedrooms_max as no_of_bedrooms_max, l.no_of_bathrooms_min as no_of_bathrooms_min, l.no_of_bathrooms_max as no_of_bathrooms_max, l.plot_area_min as plot_area_min, l.plot_area_max as plot_area_max, 
  lrn.option_value as looking_for_name, 
  pt.option_value as property_type_name, 
  ls.option_value as lead_source_name,
  lg.option_value as lead_group_name,
  lp.option_value as lead_priority_name,
  lss.option_value as lead_status_name,
  aop.option_value as age_of_property_name,
  vc.option_value as vasthu_compliant_name,
  GROUP_CONCAT(distinct CONCAT(amen.option_value)) as amenities_name,
  GROUP_CONCAT(distinct CONCAT(ps.option_value)) as possession_status_name,
  GROUP_CONCAT(distinct CONCAT(fur.option_value)) as furnishing_name
  from lz_lead_filter as l
  LEFT JOIN lz_property_addresses as pa on (pa.property_id = l.property_id) 
  LEFT JOIN lz_user as us on FIND_IN_SET(us.id,l.assign_to) > 0 
  LEFT JOIN lz_user as us2 on FIND_IN_SET(us2.id,l.created_by) > 0 
  LEFT JOIN lz_masters as lrn on (lrn.id = l.looking_for) 
  LEFT JOIN lz_masters as pt on (pt.id = l.property_type)
  LEFT JOIN lz_masters as ls on (ls.id = l.lead_source)
  LEFT JOIN lz_masters as lg on (lg.id = l.lead_group)
  LEFT JOIN lz_masters as lp on (lp.id = l.lead_priority)
  LEFT JOIN lz_masters as lss on (lss.id = l.lead_status)
  LEFT JOIN lz_masters as aop on (aop.id = l.age_of_property)
  LEFT JOIN lz_masters as vc on (vc.id = l.vasthu_compliant)
  LEFT JOIN lz_masters as amen on FIND_IN_SET(amen.id,l.amenities) > 0
  LEFT JOIN lz_masters as fur on FIND_IN_SET(amen.id,l.furnishing) > 0
  LEFT JOIN lz_masters as ps on FIND_IN_SET(amen.id,l.possession_status) > 0
  where l.status = 1 group by l.id
  `;

  const data = await db2.sequelize.query(thisQuery);

    res.status(200).send({
      status:200,
      message:'Success',
      output: data[0],
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.deleteLeadFilter = async (req, res) => {
  try {
    const id = req.params.id;
    const num = await db2['leadFilter'].destroy({
      where: { id: id },
    });
    if (num == 1) {
      res.status(200).send({
        status:200,
        message: "Deleted successfully."
      });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot delete with id : ${id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};

exports.getLeadAutoMatch = async (req, res) => {
  try {
    const created_id = req.user.id
    const created_by = created_id.id
    console.log('created_by', created_by);
  
    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);
  
    const role = req.user.id
    const role_id = role.designation
    console.log('role_id', role_id);

  const id = req.params.id

  let thisQuery = `select p.*, c.email as email, c.mobile as mobile, CONCAT(c.first_name,' ', IFNULL(c.last_name, '')) as contact_name, c.developer_name as developer_name,pa.name_of_building as property_name, pa.locality as locality, p.property_type as property_type, p.property_status as property_status, pr.uds_min as uds_min, pr.uds_max as uds_max, pr.tower as tower, pr.no_of_units_min as no_of_units_min, pr.no_of_floors as no_of_floors, pr.built_up_area_min as built_up_area_min, pr.built_up_area_max as built_up_area_max, pr.property_facing as property_facing, pr.vasthu_compliant as vasthu_compliant, pr.car_park_type as car_park_type, pr.rera_number as rera_number, p.description as description, pr.amenities as amenities, pa.city as city, pt.option_value as property_type_name, pss.option_value as property_status_name, vc.option_value as vasthu_compliant_name, cr.option_value as car_type_name, ame.option_value as amenities_name, ci.name as city_name,

  pr.id, pr.plot_area_min as plot_area_min, pr.plot_area_max as plot_area_max, pr.built_up_area_min as built_up_area_min, pr.built_up_area_max as built_up_area_max,
  pr.furnishing as furnishing, pr.project_stage as project_stage, pr.project_unit_type as project_unit_type, 
  REPLACE(JSON_EXTRACT(pr.project_unit_type,'$[0].unit_type'), '\"', '') AS unit_type, 
  ROUND(REPLACE(JSON_EXTRACT(pr.project_unit_type,'$[0].price_min'), '\"', '')) AS price_min, 
  ROUND(REPLACE(JSON_EXTRACT(pr.project_unit_type,'$[0].price_max'), '\"', '')) AS price_max,
  GROUP_CONCAT(distinct CONCAT(fur.option_value),'-',fur.id) as furnishing_name,
  GROUP_CONCAT(distinct CONCAT(ps.option_value)) as project_stage_name

  from lz_property_residentials as pr 
  LEFT JOIN lz_properties as p on (pr.property_id = p.id)
  LEFT JOIN lz_property_addresses as pa on (pa.property_id = pr.property_id)
  LEFT JOIN lz_contacts as c on (c.id = p.contact_id)
  LEFT JOIN lz_masters as fur on FIND_IN_SET(fur.id,pr.furnishing) > 0
  LEFT JOIN lz_masters as ps on FIND_IN_SET(ps.id,pr.project_stage) > 0
  LEFT JOIN lz_masters as ame on FIND_IN_SET(ame.id,pr.amenities) > 0
  LEFT JOIN lz_masters as pt on (pt.id = p.property_type)
  LEFT JOIN lz_masters as pss on (pss.id = p.property_status)
  LEFT JOIN lz_masters as vc on (vc.id = pr.vasthu_compliant)
  LEFT JOIN lz_masters as cr on (cr.id = pr.car_park_type)
  LEFT JOIN lz_city as ci on (ci.id = pa.city)
  where pr.created_at IS NOT NULL
  `
  let thisQuery1 = ` SELECT lr.plot_area_min as plot_area_min, lr.plot_area_max as plot_area_max, lr.built_up_area_min as built_up_area_min, lr.built_up_area_max as built_up_area_max, lr.furnishing as furnishing, lr.locality as locality, lr.possession_status as possession_status, lr.no_of_bedrooms_min as no_of_bedrooms_min, lr.no_of_bedrooms_max as no_of_bedrooms_max ,lr.budget_min as budget_min, lr.budget_max as budget_max
  FROM lz_lead_requirements as lr 
  where lead_id = ${id} `
  
  const data1 = await db2.sequelize.query(thisQuery1);

  const filters = req.query;

    if (data1[0][0].plot_area_min) {
      thisQuery += " and pr.plot_area_min <= " + `'${data1[0][0].plot_area_min}' `
    }
    if (data1[0][0].plot_area_max) {
      thisQuery += " and pr.plot_area_max >= " + `'${data1[0][0].plot_area_max}' `
    }
    if (data1[0][0].built_up_area_min) {
      thisQuery += " and pr.built_up_area_min <= " + `'${data1[0][0].built_up_area_min}' `
    }
    if (data1[0][0].built_up_area_max) {
      thisQuery += " and pr.built_up_area_max >= " + `'${data1[0][0].built_up_area_max}' `
    }
    if (data1[0][0].possession_status) {
      var a = data1[0][0].possession_status;
      thisQuery += ` and CONCAT(',', pr.project_stage, ',') REGEXP ',(${a}),' `
    }
    if (data1[0][0].furnishing) {
      var a = data1[0][0].furnishing;
      var b = a.replace(/[,]/g, ",");
      thisQuery += ` and CONCAT(',', pr.furnishing, ',') REGEXP ',(${a}),' `
    }
    if (data1[0][0].locality) {
      thisQuery += " and pa.locality = " + `'${data1[0][0].locality}' `
    }
    // if (data1[0][0].budget_min && data1[0][0].budget_max) {
    //   thisQuery += " and REPLACE(JSON_EXTRACT(pr.project_unit_type,'$[0].price_min'), '\"', '') <= " + `'${data1[0][0].budget_min}' ` + " and REPLACE(JSON_EXTRACT(pr.project_unit_type,'$[0].price_max'), '\"', '') >= " + `'${data1[0][0].budget_max}' `
    // }
    // if (data1[0][0].no_of_bedrooms_min) {
    //   var a = data1[0][0].no_of_bedrooms_min;
    //   thisQuery += ` and CONCAT(',', REPLACE(JSON_EXTRACT(pr.project_unit_type,'$[0].unit_type'), '\"', ''), ',') REGEXP ',(${a}),' `
    // }
    // if (data1[0][0].no_of_bedrooms_max == 0 || data1[0][0].no_of_bedrooms_max) {
    //   var a = data1[0][0].no_of_bedrooms_max;
    //   // var b = a.replace(/[,]/g, ",");
    //   thisQuery += ` and CONCAT(',', REPLACE(JSON_EXTRACT(pr.project_unit_type,'$[0].unit_type'), '\"', ''), ',') REGEXP ',(${a}),' `
    // }

    // if ((data1[0][0].budget_min == 0 && data1[0][0].budget_max == 0) || (data1[0][0].budget_min &&  data1[0][0].budget_max)) {
    //   thisQuery += " and REPLACE(JSON_EXTRACT(pr.project_unit_type,'$[0].price_min'), '\"', '') <= " + `'${data1[0][0].budget_min}' ` + " and REPLACE(JSON_EXTRACT(pr.project_unit_type,'$[0].price_max'), '\"', '') >= " + `'${data1[0][0].budget_max}' `
    // }

    thisQuery += ' group by pr.id '
    thisQuery += ' order by pr.id desc '

    // REPLACE(JSON_EXTRACT(pr.project_unit_type,'$[0].price_min'), '\"', '') AS price_min, REPLACE(JSON_EXTRACT(pr.project_unit_type,'$[0].price_max'), '\"', '') AS price_max,

    const data = await db2.sequelize.query(thisQuery);

    console.log("propertyResidentials", data[0]);
    console.log("leadRequirements", data1[0][0]);

      res.status(200).send({
        status:200,
        message:'Success',
        output: data[0],
      });

  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};

exports.optionPDF = async (req, res) => {

  const created_id = req.user.id
  const created_by = created_id.id
  console.log('created_by', created_by);

  const organ_id = req.user.id
  const org_id = organ_id.org_id
  console.log('organ_id', org_id);

  const id = req.params.id

  const desCreatedUser = await db2.sequelize.query(`select designation, CONCAT(first_name,' ', IFNULL(last_name, '')) as user_name, email from lz_user where status = 1 and id = ${created_by} `);
  const cDesignation = desCreatedUser[0][0]?.designation
  const CUserName = desCreatedUser[0][0]?.user_name
  console.log("cDesignation", cDesignation);
  console.log("CUserName", CUserName);

  const mailTriC = await db2.sequelize.query(`select designation from lz_email_trigger where options = 'options' and status = 1 `);
  const cTriDesC = mailTriC[0][0]?.designation ?? 0
  console.log("cTriDesC", cTriDesC);

    try {
      let thisQuery2 = `SELECT CONCAT(first_name,' ',IFNULL(last_name, '')) as contact_name FROM lz_contacts where status = 1 group by id order by id asc limit 5 `
      const data = await db2.sequelize.query(thisQuery2);
      // console.log(req.files)

      // let thisQueryTemp = `select mt.* from lz_mail_template mt where mt.status = 1 and title = 'Option Template' `;
      let thisQueryTemp = `select mt.* from lz_mail_template mt where mt.status = 1 and title = '${req.body.title}' `;

      const orgCheck = await db2.sequelize.query(`select id, organization_name, logo from lz_organization where company_ref_id = ${org_id} `);
      const OrgC = orgCheck[0][0]?.organization_name
      const OrgLogo = orgCheck[0][0]?.logo
      console.log("OrgC", OrgC);
      console.log("OrgLogo", OrgLogo);

      // const currencyData = await db.sequelize.query(`select name, symbol from lz_currency where company_ref_id = ${org_id} `);

      const emailTemp = await db2.sequelize.query(thisQueryTemp)
      let emailT = emailTemp[0][0]?.body

      let thisQuery = `select p.*, c.email as email, c.mobile as mobile, CONCAT(c.first_name,' ', IFNULL(c.last_name, '')) as contact_name, c.developer_name as developer_name,pa.name_of_building as property_name, pa.locality as locality, p.property_type as property_type, p.property_status as property_status, pr.uds_min as uds_min, pr.uds_max as uds_max, pr.tower as tower, pr.no_of_units_min as no_of_units_min, pr.no_of_units_max as no_of_units_max, pr.no_of_floors as no_of_floors, pr.built_up_area_min as built_up_area_min, pr.built_up_area_max as built_up_area_max, pr.property_facing as property_facing, pr.vasthu_compliant as vasthu_compliant, pr.car_park_type as car_park_type, pr.rera_number as rera_number, p.description as description, pr.amenities as amenities, pa.city as city, pt.option_value as property_type_name, pss.option_value as property_status_name, vc.option_value as vasthu_compliant_name, cr.option_value as car_type_name, ame.option_value as amenities_name, pf.option_value as property_facing_name, ci.name as city_name, cu.name as currency_name, cu.symbol as symbol_currency_name, pr.plot_area_min_ut as plot_area_min_ut, pr.plot_area_max_ut as plot_area_max_ut, pr.builtup_area_min_ut as builtup_area_min_ut, pr.builtup_area_max_ut as builtup_area_max_ut, pam.option_value as pam,  pax.option_value as pax,  bam.option_value as bam,  bax.option_value as bax,
      pr.uds_min_ut as uds_min_ut, pr.uds_max_ut as uds_max_ut, um.option_value as um, ux.option_value as ux,

      pr.id, pr.plot_area_min as plot_area_min, pr.plot_area_max as plot_area_max, pr.built_up_area_min as built_up_area_min, pr.built_up_area_max as built_up_area_max,
      pr.furnishing as furnishing, pr.project_stage as project_stage, pr.project_unit_type as project_unit_type, 
      REPLACE(JSON_EXTRACT(pr.project_unit_type,'$[0].unit_type'), '\"', '') AS unit_type, 
      ROUND(REPLACE(JSON_EXTRACT(pr.project_unit_type,'$[0].price_min'), '\"', '')) AS price_min, 
      ROUND(REPLACE(JSON_EXTRACT(pr.project_unit_type,'$[0].price_max'), '\"', '')) AS price_max,
      ROUND(REPLACE(JSON_EXTRACT(pr.project_unit_type,'$[0].local_currency'), '\"', '')) AS local_currency,
      GROUP_CONCAT(distinct CONCAT(fur.option_value),'-',fur.id) as furnishing_name,
      GROUP_CONCAT(distinct CONCAT(ps.option_value)) as project_stage_name
    
      from lz_property_residentials as pr 
      LEFT JOIN lz_properties as p on (pr.property_id = p.id)
      LEFT JOIN lz_property_addresses as pa on (pa.property_id = pr.property_id)
      LEFT JOIN lz_contacts as c on (c.id = p.contact_id)
      LEFT JOIN lz_masters as fur on FIND_IN_SET(fur.id,pr.furnishing) > 0
      LEFT JOIN lz_masters as ps on FIND_IN_SET(ps.id,pr.project_stage) > 0
      LEFT JOIN lz_masters as ame on FIND_IN_SET(ame.id,pr.amenities) > 0
      LEFT JOIN lz_masters as pt on (pt.id = p.property_type)
      LEFT JOIN lz_masters as pss on (pss.id = p.property_status)
      LEFT JOIN lz_masters as vc on (vc.id = pr.vasthu_compliant)
      LEFT JOIN lz_masters as cr on (cr.id = pr.car_park_type)
      LEFT JOIN lz_masters as pf on (pf.id = pr.property_facing)
      LEFT JOIN lz_masters as pam on (pam.id = pr.plot_area_min_ut)
      LEFT JOIN lz_masters as pax on (pax.id = pr.plot_area_max_ut)
      LEFT JOIN lz_masters as bam on (bam.id = pr.builtup_area_min_ut)
      LEFT JOIN lz_masters as bax on (bax.id = pr.builtup_area_max_ut)
      LEFT JOIN lz_masters as um on (um.id = pr.uds_min_ut)
      LEFT JOIN lz_masters as ux on (ux.id = pr.uds_max_ut)
      LEFT JOIN lz_city as ci on (ci.id = pa.city)
      LEFT JOIN lz_currency as cu on (cu.id = ROUND(REPLACE(JSON_EXTRACT(pr.project_unit_type,'$[0].local_currency'), '\"', '')))
      where pr.created_at IS NOT NULL `

      let thisQuery1 = ` SELECT lr.plot_area_min as plot_area_min, lr.plot_area_max as plot_area_max, lr.built_up_area_min as built_up_area_min, lr.built_up_area_max as built_up_area_max, lr.furnishing as furnishing, lr.locality as locality, lr.possession_status as possession_status, lr.no_of_bedrooms_min as no_of_bedrooms_min, lr.no_of_bedrooms_max as no_of_bedrooms_max ,lr.budget_min as budget_min, lr.budget_max as budget_max
      FROM lz_lead_requirements as lr 
      where lead_id = ${id} `
      
      const data1 = await db2.sequelize.query(thisQuery1);
    
      const filters = req.query;
    
        if (data1[0][0]?.plot_area_min) {
          thisQuery += " and pr.plot_area_min <= " + `'${data1[0][0]?.plot_area_min}' `
        }
        if (data1[0][0]?.plot_area_max) {
          thisQuery += " and pr.plot_area_max >= " + `'${data1[0][0]?.plot_area_max}' `
        }
        if (data1[0][0]?.built_up_area_min) {
          thisQuery += " and pr.built_up_area_min <= " + `'${data1[0][0]?.built_up_area_min}' `
        }
        if (data1[0][0]?.built_up_area_max) {
          thisQuery += " and pr.built_up_area_max >= " + `'${data1[0][0]?.built_up_area_max}' `
        }
        if (data1[0][0]?.possession_status) {
          var a = data1[0][0]?.possession_status;
          thisQuery += ` and CONCAT(',', pr.project_stage, ',') REGEXP ',(${a}),' `
        }
        if (data1[0][0].furnishing) {
          var a = data1[0][0]?.furnishing;
          var b = a.replace(/[,]/g, ",");
          thisQuery += ` and CONCAT(',', pr.furnishing, ',') REGEXP ',(${a}),' `
        }
        if (data1[0][0]?.locality) {
          thisQuery += " and pa.locality = " + `'${data1[0][0]?.locality}' `
        }

        thisQuery += ' group by p.id '
        thisQuery += ' order by p.id desc '

        // REPLACE(JSON_EXTRACT(pr.project_unit_type,'$[0].price_min'), '\"', '') AS price_min, REPLACE(JSON_EXTRACT(pr.project_unit_type,'$[0].price_max'), '\"', '') AS price_max,

        const data123 = await db2.sequelize.query(thisQuery);

        console.log("propertyResidentials", data123[0]);
        console.log("leadRequirements", data1[0][0]);

        const propertyData = await db2.sequelize.query(thisQuery)
        const pData = propertyData[0];

        let thisQueryF = ` SELECT * FROM lz_file_uploads where module_name = 3 order by id desc limit 3 `
        const filesData = await db2.sequelize.query(thisQueryF);
        const Fdata = filesData[0]
        console.log("files1", Fdata[0]);
        console.log("files2", Fdata[1]);
        console.log("files3", Fdata[2]);

        let dirPath1 = "uploads/leads/"
        if(!fs.existsSync(dirPath1)) {
          fs.mkdir(dirPath1, (err) => {
            if (err) throw err;
            console.log('Folder created successfully');
          });
        };
        let dirPath = "uploads/leads/"+`${id}`
        if(!fs.existsSync(dirPath)) {
          fs.mkdir(dirPath, (err) => {
            if (err) throw err;
            console.log('Id created successfully');
          });
        };
        let dfgkg = '';

      for (let i in pData) {
        let ekfeu = emailTemp[0][0]?.body;
        const placeholders = {
          '{{logo}}' : `${req.body.logo == 1 ? 'https://listeznew.vrikshatech.in/uploads/organization/logo/'+orgCheck[0][0]?.id+'/'+OrgLogo : ``}`,
          '{{img1}}' : `${req.body.img1 == 1 ? 'https://listeznew.vrikshatech.in/uploads/property/profile_image/'+pData[i]?.id+'/'+pData[i]?.profile_image : ``}`,
          '{{img2}}' : `${req.body.img2 == 1 ? 'https://listeznew.vrikshatech.in/uploads/contacts/files/'+Fdata[0]?.id+'/'+Fdata[0]?.file : ``}`,
          '{{img3}}' : `${req.body.img3 == 1 ? 'https://listeznew.vrikshatech.in/uploads/contacts/files/'+Fdata[1]?.id+'/'+Fdata[1]?.file : ``}`,
          '{{img4}}' : `${req.body.img4 == 1 ? 'https://listeznew.vrikshatech.in/uploads/contacts/files/'+Fdata[2]?.id+'/'+Fdata[2]?.file : ``}`,
          '{{mobile}}' : `${req.body.mobile == 1 ? pData[i]?.mobile : ``} `,
          '{{email}}' : `${req.body.email == 1 ? pData[i]?.email : ``} `,

          '{{property_type}}' : `${req.body.property_type == 1 ? pData[i]?.property_type_name : ``} `,
          '{{locality}}' : `${req.body.locality == 1 ? pData[i]?.locality : ``} `,
          '{{city}}' : `${req.body.city == 1 ? pData[i]?.city_name : ``} `,

          '{{developer_name}}' : `${req.body.developer_name == 1 ? `<p style="Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:'comic sans ms', 'marker felt-thin', arial, sans-serif;line-height:21px;color:#000000;font-size:14px;text-align:left"><strong><span style="font-size:15px"> Developer name :</span></strong>&nbsp; <span style="font-size:13px">${pData[i]?.developer_name} </span></p>` : ``}`,

          '{{property_name}}' : `${req.body.property_name == 1 ? `<p style="Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:'comic sans ms', 'marker felt-thin', arial, sans-serif;line-height:21px;color:#000000;font-size:14px;text-align:left"><strong><span style="font-size:15px"> Property name :</span></strong>&nbsp; <span style="font-size:13px">${pData[i]?.property_name} </span></p>` : ``}`,

          '{{property_status}}' : `${req.body.property_status == 1 ? `<p style="Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:'comic sans ms', 'marker felt-thin', arial, sans-serif;line-height:21px;color:#000000;font-size:14px;text-align:left"><strong><span style="font-size:15px"> Property status :</span></strong>&nbsp; <span style="font-size:13px">${pData[i]?.property_status_name} </span></p>` : ``}`,

          '{{uds}}' : `${req.body.uds == 1 ? `<p style="Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:'comic sans ms', 'marker felt-thin', arial, sans-serif;line-height:21px;color:#000000;font-size:14px;text-align:left"><strong><span style="font-size:15px"> Uds :</span></strong>&nbsp; <span style="font-size:13px">${pData[i]?.uds_min+' '+`${pData[i]?.um == null ? '' : pData[i]?.um}`+ ' - ' + pData[i]?.uds_max+' '+`${pData[i]?.ux == null ? '' : pData[i]?.ux}`} </span></p>` : ``}`,

          '{{no_of_units}}' : `${req.body.no_of_units == 1 ? `<p style="Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:'comic sans ms', 'marker felt-thin', arial, sans-serif;line-height:21px;color:#000000;font-size:14px;text-align:left"><strong><span style="font-size:15px"> No of units :</span></strong>&nbsp; <span style="font-size:13px">${pData[i]?.no_of_units_min +' - '+ pData[i]?.no_of_units_max} </span></p>` : ``}`,

          '{{rera_number}}' :  `${req.body.rera_number == 1 ? `<p style="Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:'comic sans ms', 'marker felt-thin', arial, sans-serif;line-height:21px;color:#000000;font-size:14px;text-align:left"><strong><span style="font-size:15px">Rera Number :</span></strong>&nbsp; <span style="font-size:13px">${pData[i]?.rera_number} </span></p>` : ``}`,

          '{{plot_area}}' : `${req.body.plot_area == 1 ? `<p style="Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:'comic sans ms', 'marker felt-thin', arial, sans-serif;line-height:21px;color:#000000;font-size:14px;text-align:left"><strong><span style="font-size:15px"> Plot area :</span></strong>&nbsp; <span style="font-size:13px">${pData[i]?.plot_area_min +' '+`${pData[i]?.pam == null ? '' : pData[i]?.pam}`+ ' - ' + pData[i]?.plot_area_max +' '+`${pData[i]?.pax == null ? '' : pData[i]?.pax}`} </span></p>` : ``}`,

          '{{builtup_area}}' :`${req.body.builtup_area == 1 ? `<p style="Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:'comic sans ms', 'marker felt-thin', arial, sans-serif;line-height:21px;color:#000000;font-size:14px;text-align:left"><strong><span style="font-size:15px"> Built up area :</span></strong>&nbsp; <span style="font-size:13px"> ${pData[i]?.built_up_area_min +' '+`${pData[i]?.bam == null ? '' : pData[i]?.bam}`+ ' - ' + pData[i]?.built_up_area_max +' '+`${pData[i]?.bax == null ? '' : pData[i]?.bax}` } </span></p> ` : ``}`,

          '{{price}}' : `${req.body.price == 1 ? `${data123[0][0]?.symbol_currency_name == null ? '' : data123[0][0]?.symbol_currency_name}` +' '+`${pData[i]?.price_min == null ? '' : pData[i]?.price_min}`+ ' - ' + `${pData[i]?.price_max == null ? '' : pData[i]?.price_max}` : `` }`,

          '{{no_of_floors}}' : `${req.body.no_of_floors == 1 ? `<p style="Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:'comic sans ms', 'marker felt-thin', arial, sans-serif;line-height:21px;color:#000000;font-size:14px;text-align:left"><strong><span style="font-size:15px"> No Of floors :</span></strong>&nbsp; <span style="font-size:13px">${pData[i]?.no_of_floors} </span></p>` : ``}`,

          '{{configuration}}' : `${req.body.configuration == 1 ? `<p style="Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:'comic sans ms', 'marker felt-thin', arial, sans-serif;line-height:21px;color:#000000;font-size:14px;text-align:left"><strong><span style="font-size:15px"> Configuration :</span></strong>&nbsp; <span style="font-size:13px">${pData[i]?.unit_type == null ? '' : pData[i]?.unit_type + '-'+'BHK'} </span></p>` : ``}`,

          '{{bathrooms}}' : `${req.body.bathrooms == 1 ? `<p style="Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:'comic sans ms', 'marker felt-thin', arial, sans-serif;line-height:21px;color:#000000;font-size:14px;text-align:left"><strong><span style="font-size:15px"> Bathrooms :</span></strong>&nbsp; <span style="font-size:13px">${pData[i]?.bathrooms ?? 0} </span></p>` : ``}`,
          
          '{{facing}}' : `${req.body.facing == 1 ? `<p style="Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:'comic sans ms', 'marker felt-thin', arial, sans-serif;line-height:21px;color:#000000;font-size:14px;text-align:left"><strong><span style="font-size:15px"> Property facing :</span></strong>&nbsp; <span style="font-size:13px">${pData[i]?.property_facing_name} </span></p>` : ``}`,

          '{{vasthu_complient}}' : `${req.body.vasthu_complient == 1 ? `<p style="Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:'comic sans ms', 'marker felt-thin', arial, sans-serif;line-height:21px;color:#000000;font-size:14px;text-align:left"><strong><span style="font-size:15px"> Vasthu complient :</span></strong>&nbsp; <span style="font-size:13px">${pData[i]?.vasthu_compliant_name} </span></p>` : ``}`,
          
          '{{car_parking}}' : `${req.body.car_parking == 1 ? `<p style="Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:'comic sans ms', 'marker felt-thin', arial, sans-serif;line-height:21px;color:#000000;font-size:14px;text-align:left"><strong><span style="font-size:15px"> Car parking :</span></strong>&nbsp; <span style="font-size:13px">${pData[i]?.car_type_name} </span></p>` : ``}`,

          '{{amenities}}' :  `${req.body.amenities == 1 ? `<p style="Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:'comic sans ms', 'marker felt-thin', arial, sans-serif;line-height:21px;color:#000000;font-size:14px;text-align:left"><strong><span style="font-size:15px"> Amenities :</span></strong>&nbsp; <span style="font-size:13px">${pData[i]?.amenities_name} </span></p>` : ``}`,

          '{{property_tower}}' :  `${req.body.property_tower == 1 ? `<p style="Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:'comic sans ms', 'marker felt-thin', arial, sans-serif;line-height:21px;color:#000000;font-size:14px;text-align:left"><strong><span style="font-size:15px">Property Tower :</span></strong>&nbsp; <span style="font-size:13px">${pData[i]?.tower} </span></p>` : ``}`,
        }

      console.log("placeholders", placeholders);
      for (const placeholder in placeholders) {
        ekfeu = ekfeu?.replace(placeholder, placeholders[placeholder]);
      }
      dfgkg = dfgkg + ekfeu;
      }
      console.log("html111");

      const browser = await puppeteer.launch();
      const page = await browser.newPage();
      await page.setContent(dfgkg);
      const pdfBuffer = await page.pdf();

      await page.screenshot({ path: "uploads/leads/"+`${id}`+"/leadfile.jpg", type: 'jpeg' });

      await browser.close();

      fs.writeFile("uploads/leads/"+`${id}`+"/leadfile.pdf", pdfBuffer, (err) => {
        if (err) throw err;
        console.log('PDF saved!');
      });

      const email_settings = await db2.sequelize.query(`select status from lz_email_trigger where FIND_IN_SET('${cDesignation}', '${cTriDesC}') > 0 and options = 'options' and status = 1 `);
      // const emailTri = email_settings[0][0] ? email_settings[0][0]["active_status"] : 0
      const emailTri = email_settings[0][0]?.status ?? 0
      console.log("emailTri", emailTri);  

      // Email-Trigger
      if (emailTri == 1) {
        if(req.body.share == 'email') {
      let dfgkg = '';

      for (let i in pData) {
        let ekfeu = emailTemp[0][0]?.body;
        const placeholders = {
          '{{logo}}' : `${req.body.logo == 1 ? 'https://listeznew.vrikshatech.in/uploads/organization/logo/'+orgCheck[0][0]?.id+'/'+OrgLogo : ``}`,
          '{{img1}}' : `${req.body.img1 == 1 ? 'https://listeznew.vrikshatech.in/uploads/property/profile_image/'+pData[i]?.id+'/'+pData[i]?.profile_image : ``}`,
          '{{img2}}' : `${req.body.img2 == 1 ? 'https://listeznew.vrikshatech.in/uploads/contacts/files/'+Fdata[0]?.id+'/'+Fdata[0]?.file : ``}`,
          '{{img3}}' : `${req.body.img3 == 1 ? 'https://listeznew.vrikshatech.in/uploads/contacts/files/'+Fdata[1]?.id+'/'+Fdata[1]?.file : ``}`,
          '{{img4}}' : `${req.body.img4 == 1 ? 'https://listeznew.vrikshatech.in/uploads/contacts/files/'+Fdata[2]?.id+'/'+Fdata[2]?.file : ``}`,
          '{{mobile}}' : `${req.body.mobile == 1 ? pData[i]?.mobile : ``} `,
          '{{email}}' : `${req.body.email == 1 ? pData[i]?.email : ``} `,
  
          '{{property_type}}' : `${req.body.property_type == 1 ? pData[i]?.property_type_name : ``} `,
          '{{locality}}' : `${req.body.locality == 1 ? pData[i]?.locality : ``} `,
          '{{city}}' : `${req.body.city == 1 ? pData[i]?.city_name : ``} `,
  
          '{{developer_name}}' : `${req.body.developer_name == 1 ? `<p style="Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:'comic sans ms', 'marker felt-thin', arial, sans-serif;line-height:21px;color:#000000;font-size:14px;text-align:left"><strong><span style="font-size:15px"> Developer name :</span></strong>&nbsp; <span style="font-size:13px">${pData[i]?.developer_name} </span></p>` : ``}`,
  
          '{{property_name}}' : `${req.body.property_name == 1 ? `<p style="Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:'comic sans ms', 'marker felt-thin', arial, sans-serif;line-height:21px;color:#000000;font-size:14px;text-align:left"><strong><span style="font-size:15px"> Property name :</span></strong>&nbsp; <span style="font-size:13px">${pData[i]?.property_name} </span></p>` : ``}`,
  
          '{{property_status}}' : `${req.body.property_status == 1 ? `<p style="Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:'comic sans ms', 'marker felt-thin', arial, sans-serif;line-height:21px;color:#000000;font-size:14px;text-align:left"><strong><span style="font-size:15px"> Property status :</span></strong>&nbsp; <span style="font-size:13px">${pData[i]?.property_status_name} </span></p>` : ``}`,
  
          '{{uds}}' : `${req.body.uds == 1 ? `<p style="Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:'comic sans ms', 'marker felt-thin', arial, sans-serif;line-height:21px;color:#000000;font-size:14px;text-align:left"><strong><span style="font-size:15px"> Uds :</span></strong>&nbsp; <span style="font-size:13px">${pData[i]?.uds_min+' '+`${pData[i]?.um == null ? '' : pData[i]?.um}`+ ' - ' + pData[i]?.uds_max+' '+`${pData[i]?.ux == null ? '' : pData[i]?.ux}`} </span></p>` : ``}`,
  
          '{{no_of_units}}' : `${req.body.no_of_units == 1 ? `<p style="Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:'comic sans ms', 'marker felt-thin', arial, sans-serif;line-height:21px;color:#000000;font-size:14px;text-align:left"><strong><span style="font-size:15px"> No of units :</span></strong>&nbsp; <span style="font-size:13px">${pData[i]?.no_of_units_min +' - '+ pData[i]?.no_of_units_max} </span></p>` : ``}`,
  
          '{{rera_number}}' :  `${req.body.rera_number == 1 ? `<p style="Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:'comic sans ms', 'marker felt-thin', arial, sans-serif;line-height:21px;color:#000000;font-size:14px;text-align:left"><strong><span style="font-size:15px">Rera Number :</span></strong>&nbsp; <span style="font-size:13px">${pData[i]?.rera_number} </span></p>` : ``}`,
  
          '{{plot_area}}' : `${req.body.plot_area == 1 ? `<p style="Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:'comic sans ms', 'marker felt-thin', arial, sans-serif;line-height:21px;color:#000000;font-size:14px;text-align:left"><strong><span style="font-size:15px"> Plot area :</span></strong>&nbsp; <span style="font-size:13px">${pData[i]?.plot_area_min +' '+`${pData[i]?.pam == null ? '' : pData[i]?.pam}`+ ' - ' + pData[i]?.plot_area_max +' '+`${pData[i]?.pax == null ? '' : pData[i]?.pax}`} </span></p>` : ``}`,
  
          '{{builtup_area}}' :`${req.body.builtup_area == 1 ? `<p style="Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:'comic sans ms', 'marker felt-thin', arial, sans-serif;line-height:21px;color:#000000;font-size:14px;text-align:left"><strong><span style="font-size:15px"> Built up area :</span></strong>&nbsp; <span style="font-size:13px"> ${pData[i]?.built_up_area_min +' '+`${pData[i]?.bam == null ? '' : pData[i]?.bam}`+ ' - ' + pData[i]?.built_up_area_max +' '+`${pData[i]?.bax == null ? '' : pData[i]?.bax}` } </span></p> ` : ``}`,
  
          '{{price}}' : `${req.body.price == 1 ? `${data123[0][0]?.symbol_currency_name == null ? '' : data123[0][0]?.symbol_currency_name}` +' '+`${pData[i]?.price_min == null ? '' : pData[i]?.price_min}`+ ' - ' + `${pData[i]?.price_max == null ? '' : pData[i]?.price_max}` : `` }`,
  
          '{{no_of_floors}}' : `${req.body.no_of_floors == 1 ? `<p style="Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:'comic sans ms', 'marker felt-thin', arial, sans-serif;line-height:21px;color:#000000;font-size:14px;text-align:left"><strong><span style="font-size:15px"> No Of floors :</span></strong>&nbsp; <span style="font-size:13px">${pData[i]?.no_of_floors} </span></p>` : ``}`,
  
          '{{configuration}}' : `${req.body.configuration == 1 ? `<p style="Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:'comic sans ms', 'marker felt-thin', arial, sans-serif;line-height:21px;color:#000000;font-size:14px;text-align:left"><strong><span style="font-size:15px"> Configuration :</span></strong>&nbsp; <span style="font-size:13px">${pData[i]?.unit_type == null ? '' : pData[i]?.unit_type + '-'+'BHK'} </span></p>` : ``}`,
  
          '{{bathrooms}}' : `${req.body.bathrooms == 1 ? `<p style="Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:'comic sans ms', 'marker felt-thin', arial, sans-serif;line-height:21px;color:#000000;font-size:14px;text-align:left"><strong><span style="font-size:15px"> Bathrooms :</span></strong>&nbsp; <span style="font-size:13px">${pData[i]?.bathrooms ?? 0} </span></p>` : ``}`,
          
          '{{facing}}' : `${req.body.facing == 1 ? `<p style="Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:'comic sans ms', 'marker felt-thin', arial, sans-serif;line-height:21px;color:#000000;font-size:14px;text-align:left"><strong><span style="font-size:15px"> Property facing :</span></strong>&nbsp; <span style="font-size:13px">${pData[i]?.property_facing_name} </span></p>` : ``}`,
  
          '{{vasthu_complient}}' : `${req.body.vasthu_complient == 1 ? `<p style="Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:'comic sans ms', 'marker felt-thin', arial, sans-serif;line-height:21px;color:#000000;font-size:14px;text-align:left"><strong><span style="font-size:15px"> Vasthu complient :</span></strong>&nbsp; <span style="font-size:13px">${pData[i]?.vasthu_compliant_name} </span></p>` : ``}`,
          
          '{{car_parking}}' : `${req.body.car_parking == 1 ? `<p style="Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:'comic sans ms', 'marker felt-thin', arial, sans-serif;line-height:21px;color:#000000;font-size:14px;text-align:left"><strong><span style="font-size:15px"> Car parking :</span></strong>&nbsp; <span style="font-size:13px">${pData[i]?.car_type_name} </span></p>` : ``}`,
  
          '{{amenities}}' :  `${req.body.amenities == 1 ? `<p style="Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:'comic sans ms', 'marker felt-thin', arial, sans-serif;line-height:21px;color:#000000;font-size:14px;text-align:left"><strong><span style="font-size:15px"> Amenities :</span></strong>&nbsp; <span style="font-size:13px">${pData[i]?.amenities_name} </span></p>` : ``}`,
  
          '{{property_tower}}' :  `${req.body.property_tower == 1 ? `<p style="Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:'comic sans ms', 'marker felt-thin', arial, sans-serif;line-height:21px;color:#000000;font-size:14px;text-align:left"><strong><span style="font-size:15px">Property Tower :</span></strong>&nbsp; <span style="font-size:13px">${pData[i]?.tower} </span></p>` : ``}`,
        }

      // console.log("fffffffffffffffffff");

      // console.log("placeholders", placeholders);
      for (const placeholder in placeholders) {
        ekfeu = ekfeu?.replace(placeholder, placeholders[placeholder]);
      }
      dfgkg = dfgkg + ekfeu;
      }

      console.log("html111");

      const browser = await puppeteer.launch();
      const page = await browser.newPage();
      await page.setContent(dfgkg);
      const pdfBuffer = await page.pdf();
      await browser.close();

      fs.writeFile('leadfile.pdf', pdfBuffer, (err) => {
        if (err) throw err;
        console.log('PDF saved!');
      });
      console.log("created_by", created_by);

      let thisQueryDes = ` select us.team_leader as tl, us.portfolio_head as sub_tl 
      from lz_user as us where id = ${created_by} `
      const desCheck = await db2.sequelize.query(thisQueryDes);
      const desCheckTL = desCheck[0][0]?.tl ?? 0
      const desCheckSubTL = desCheck[0][0]?.sub_tl ?? 0

      console.log("desCheckTL", desCheckTL);

      // Team Leader
      const checkTl = await db2.sequelize.query(`select email from lz_user where id = ${desCheckTL} `);
      const checkTl1 = checkTl[0][0]?.email
      // Sub TL
      const checksubTL = await db2.sequelize.query(`select email from lz_user where id = ${desCheckSubTL} `);
      const checksubTL1 = checksubTL[0][0]?.email
      // Admin
      const checkAdmin = await db2.sequelize.query(`select email from lz_user where designation = 1 group by id `);
      const checkAdmin1 = checkAdmin[0]?.map(item => item.email).join(', ');
      // Assign To
      const assignEmail = await db2.sequelize.query(`select us.id as id, us.email as email from lz_user as us where us.id IN ('${pData?.assign_to}') `);
      const assEmail = assignEmail[0]?.map(item => item.email).join(', ')
    
      console.log("checkTl", checkTl1);
      console.log("checksubTL1", checksubTL1);
      console.log("checkAdmin1", checkAdmin1);
      console.log("assign_to",assEmail);
    
      const createdEmail = await db2.sequelize.query(`select email from lz_user where id = ${created_by} `);
      const cEmail = createdEmail[0][0].email
      console.log("cEmail", cEmail);

   console.log("checkkkkkk");
      let message = {
        from: cEmail,
        to: [checkAdmin1,checkTl1,checksubTL1, assEmail].join(', '),
        // from: 'gowshickvts@gmail.com',
        // to: 'vignesh@vrikshatech.in',
        subject: "Lead option",
        // html: dfgkg
        attachments: [
          {
            filename: 'leadfile.pdf',
            content: pdfBuffer
          }
        ]
      };

        mailer.sendMail(message, function(error, info){
          if (error) {
            console.log('Error');
          } else {
            console.log('Email sent: ' + info.response);
          }
        });
      }
      }
      // PDF
      if(req.body.download == 'pdf') {
        const filePath = "uploads/leads/"+`${id}`+"/leadfile.pdf";
        fs.readFile(filePath, (err, data) => {
          if (err) {
            res.writeHead(404, {'Content-Type': 'text/plain'});
            res.end('File not found');
          } else {
            // Set the appropriate headers for PDF response
            // res.setHeader('Content-Type', 'application/pdf');
            // res.setHeader('Content-Disposition', 'attachment; filename=file.pdf');
            console.log('check');
            // Send the file content as the response
            res.end(data);
          }
        });
      }
      // JPG
      if(req.body.download == 'jpg') {
        const filePath = "uploads/leads/"+`${id}`+"/leadfile.jpg";
        fs.readFile(filePath, (err, data) => {
          if (err) {
            res.writeHead(404, {'Content-Type': 'text/plain'});
            res.end('File not found');
          } else {
            // Set the appropriate headers for PDF response
            // res.setHeader('Content-Type', 'application/pdf');
            // res.setHeader('Content-Disposition', 'attachment; filename=file.pdf');
            console.log('check');
            // Send the file content as the response
            res.end(data);
          }
        });
      }
 
      // console.log("pData", pData);
      if(req.body.download == '') {
        res.status(200).send({
          message: 'success',
          output: data123[0],
        });
      }
    }

    catch (error) {
        res.status(500).send({
            message: error.message,
        });
    }
};


// exports.getLeadAutoMatch = async (req, res) => {
//   try {
//   const organ_id = req.user.id
//   const org_id = organ_id.org_id
//   console.log('organ_id', org_id);

//   const id = req.params.id

//   let thisQuery = `select pr.id,
//   pr.plot_area_min as plot_area_min, pr.plot_area_max as plot_area_max, pr.built_up_area_min as built_up_area_min, pr.built_up_area_max as built_up_area_max,
//   pr.furnishing as furnishing, pr.project_stage as project_stage, pr.project_unit_type as project_unit_type, REPLACE(JSON_EXTRACT(pr.project_unit_type,'$[0].unit_type'), '\"', '') AS unit_type, 
//   REPLACE(JSON_EXTRACT(pr.project_unit_type,'$[0].price_min'), '\"', '') AS price_min, REPLACE(JSON_EXTRACT(pr.project_unit_type,'$[0].price_max'), '\"', '') AS price_max,
//   GROUP_CONCAT(distinct CONCAT(fur.option_value),'-',fur.id) as furnishing_name,GROUP_CONCAT(distinct CONCAT(ps.option_value),'-',ps.id) as project_stage_name, pa.locality as locality
//   from lz_property_residentials as pr 
//   LEFT JOIN lz_property_addresses as pa on (pa.property_id = pr.property_id)
//   LEFT JOIN lz_masters as fur on FIND_IN_SET(fur.id,pr.furnishing) > 0
//   LEFT JOIN lz_masters as ps on FIND_IN_SET(ps.id,pr.project_stage) > 0
//   where pr.created_at IS NOT NULL
//   `
//   let thisQuery1 = ` SELECT lr.plot_area_min as plot_area_min, lr.plot_area_max as plot_area_max, lr.built_up_area_min as built_up_area_min, lr.built_up_area_max as built_up_area_max, lr.furnishing as furnishing, lr.locality as locality, lr.possession_status as possession_status, lr.no_of_bedrooms_min as no_of_bedrooms_min, lr.no_of_bedrooms_max as no_of_bedrooms_max ,lr.budget_min as budget_min, lr.budget_max as budget_max
//   FROM lz_lead_requirements as lr 
//   where lead_id = ${id} `
  
//   const data1 = await db2.sequelize.query(thisQuery1);

//   const filters = req.query;

//     if (data1[0][0].locality == 0 || data1[0][0].locality) {
//       thisQuery += " and pa.locality = " + `'${data1[0][0].locality}' `
//     }
//     if (data1[0][0].furnishing == 0 || data1[0][0].furnishing) {
//       var a = data1[0][0].furnishing;
//       var b = a.replace(/[,]/g, ",");
//       thisQuery += ` and CONCAT(',', pr.furnishing, ',') REGEXP ',(${a}),' `
//     }
//     if (data1[0][0].possession_status == 0 || data1[0][0].possession_status) {
//       var a = data1[0][0].possession_status;
//       var b = a.replace(/[,]/g, ",");
//       thisQuery += ` and CONCAT(',', pr.project_stage, ',') REGEXP ',(${a}),' `
//     }
//     if ((data1[0][0].plot_area_min == 0 && data1[0][0].plot_area_max == 0) || (data1[0][0].plot_area_min &&  data1[0][0].plot_area_max)) {
//       thisQuery += " and pr.plot_area_min <= " + `'${data1[0][0].plot_area_min}' ` + " and pr.plot_area_max >= " + `'${data1[0][0].plot_area_max}' `
//     }
//     if ((data1[0][0].built_up_area_min == 0 && data1[0][0].built_up_area_max == 0) || (data1[0][0].built_up_area_min &&  data1[0][0].built_up_area_max)) {
//       thisQuery += " and pr.built_up_area_min <= " + `'${data1[0][0].built_up_area_min}' ` + " and pr.built_up_area_max >= " + `'${data1[0][0].built_up_area_max}' `
//     }

//     if (data1[0][0].no_of_bedrooms_min == 0 || data1[0][0].no_of_bedrooms_min) {
//       var a = data1[0][0].no_of_bedrooms_min;
//       // var b = a.replace(/[,]/g, ",");
//       thisQuery += ` and CONCAT(',', REPLACE(JSON_EXTRACT(pr.project_unit_type,'$[0].unit_type'), '\"', ''), ',') REGEXP ',(${a}),' `
//     }
//     if (data1[0][0].no_of_bedrooms_max == 0 || data1[0][0].no_of_bedrooms_max) {
//       var a = data1[0][0].no_of_bedrooms_max;
//       // var b = a.replace(/[,]/g, ",");
//       thisQuery += ` and CONCAT(',', REPLACE(JSON_EXTRACT(pr.project_unit_type,'$[0].unit_type'), '\"', ''), ',') REGEXP ',(${a}),' `
//     }

//     if ((data1[0][0].budget_min == 0 && data1[0][0].budget_max == 0) || (data1[0][0].budget_min &&  data1[0][0].budget_max)) {
//       thisQuery += " and REPLACE(JSON_EXTRACT(pr.project_unit_type,'$[0].price_min'), '\"', '') <= " + `'${data1[0][0].budget_min}' ` + " and REPLACE(JSON_EXTRACT(pr.project_unit_type,'$[0].price_max'), '\"', '') >= " + `'${data1[0][0].budget_max}' `
//     }

//     thisQuery += ' group by pr.id '
//     thisQuery += ' order by pr.id desc '

//     // REPLACE(JSON_EXTRACT(pr.project_unit_type,'$[0].price_min'), '\"', '') AS price_min, REPLACE(JSON_EXTRACT(pr.project_unit_type,'$[0].price_max'), '\"', '') AS price_max,

//     const data = await db2.sequelize.query(thisQuery);

//     console.log("propertyResidentials", data[0]);
//     console.log("leadRequirements", data1[0][0]);

//       res.status(200).send({
//         status:200,
//         message:'Success',
//         output: data[0],
//       });

//   } catch (error) {
//     res.status(500).send({
//       message: error.message,
//     });
//   }
// };

exports.getLeadDuplicate = async (req, res) => {
  try {
  const organ_id = req.user.id
  const org_id = organ_id.org_id
  console.log('organ_id', org_id);

  const id = req.params.id
  const propertyID = req.params.property_id

  let x = `(select l.contact_id from lz_leads as l left join lz_properties as p on (p.id = l.property_id) where l.id = ${id} and c.property_id = ${propertyID}) `
  let thisQuery = `SELECT * FROM lz_contacts as c 
  where c.status = 1 and c.mobile in (SELECT mobile FROM lz_contacts where id = ${x}) and c.id != ${x} `

  const data = await db2.sequelize.query(thisQuery);

      res.status(200).send({
        status:200,
        message:'Success',
        output: data[0],
      });

  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};

exports.getLeadTask = async (req, res) => {
  try {
    const created_id = req.user.id
    const created_by = created_id.id
    console.log('created_by', created_by);
  
    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);
  
    const role = req.user.id
    const role_id = role.designation
    console.log('role_id', role_id);

  const id = req.params.id

  // let x = `(select contact_id from lz_leads where id = ${id})`
  let thisQuery = `select t.*, CONVERT(t.assign_to USING utf8) as assign_to, GROUP_CONCAT(distinct CONCAT(us.first_name,' ', IFNULL(us.last_name, ''))) as assign_to_name,CONCAT(us1.first_name,' ', IFNULL(us1.last_name, '')) as created_by_name, CONCAT(c.first_name,' ', IFNULL(c.last_name, '')) as contact_name, c.email as email, c.mobile as mobile, c.mobile as mobile, c.profile_image as contact_profile_image, c.profile_image_original_name as contact_profile_image_original_name, pa.name_of_building as property_name, tt.option_value as task_type_name, pri.option_value as priority_name, ts.option_value as task_status_name
  FROM lz_tasks as t `
  thisQuery += "LEFT JOIN lz_contacts as c on (c.id = t.contact) "
  thisQuery += "LEFT JOIN lz_leads as le on (le.contact_id = t.contact) "
  thisQuery += "LEFT JOIN lz_property_addresses as pa on (pa.property_id = t.project) "
  thisQuery += "LEFT JOIN lz_masters as tt on (t.task_type = tt.id) "
  thisQuery += "LEFT JOIN lz_masters as pri on (t.priority = pri.id) "
  thisQuery += "LEFT JOIN lz_masters as ts on (t.task_status = ts.id) "
  thisQuery += "LEFT JOIN lz_user as us on FIND_IN_SET(us.id,t.assign_to)>0 "
  thisQuery += "LEFT JOIN lz_user as us1 on (us1.id = t.created_by) "
  thisQuery += ` where ${role_id == 1 ? `t.status IN (1,2) ` : ` t.status = 1 `} `
  thisQuery += ` and t.contact = ${id} group by t.id `

  const data = await db2.sequelize.query(thisQuery);

      res.status(200).send({
        status:200,
        message:'Success',
        output: data[0],
      });

  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};

// Bulk Lead Re-Assign
exports.bulkLeadReAssign = async (req, res) => {
  const organ_id = req.user.id
  const org_id = organ_id.org_id
  console.log('organ_id', org_id);

  const created_by = req.user.id
  console.log('created_by', created_by.id);

    try {
      let x = req.params.id
      console.log("id111", x);

      let thisQuery  = ` UPDATE lz_leads SET assign_to = '${req.body.assign_to}' `;
          thisQuery += " WHERE id IN (" + x + ") "
          thisQuery += ` and status = 1 `;

      const data = await db2.sequelize.query(thisQuery);

      res.status(200).send({
        status:200,
        message:'Success',
        output:data[0]
      });

    } catch (error) {
      res.status(500).send({
        message: error.message,
      });
    }
};

exports.importLead = (async (req, res) => {
  // const query = util.promisify;
  readXlsxFile('./uploads/' + req.file.filename).then(async (rows) => {

    const created_id = req.user.id
    const created_by = created_id.id
    console.log('created_by', created_by);
  
    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);
    
    const role = req.user.id
    const role_id = role.designation
    console.log('role_id', role_id);

    rows.shift();
    rows.map(async (row, i) => {
        // const company_nameIdFetch = await db2.sequelize.query(`select id from lz_contacts where company_name ='${row[3]}' limit 1`);
        // const company_nameId = company_nameIdFetch[0][0] ? company_nameIdFetch[0][0]["id"] : 0

        // Contacts ID
        const contact_IdFetch = await db2.sequelize.query(`select id from lz_contacts where first_name ='${row[0]}' limit 1`);
        const contact_Id = contact_IdFetch[0][0] ? contact_IdFetch[0][0]["id"] : 0
        console.log("contact_IdFetch", contact_IdFetch[0][0]);
        console.log("contact_Id", contact_Id);
        // Property ID
        const property_IdFetch = await db2.sequelize.query(`select property_id from lz_property_addresses where name_of_building ='${row[1]}' limit 1`);
        const property_Id = property_IdFetch[0][0] ? property_IdFetch[0][0]["property_id"] : 0
        console.log("property_IdFetch", property_IdFetch[0][0]);
        console.log("property_Id", property_Id);
        // Looking For
        // var a = `${row[2]}`;
        // console.log("aaaaaaaaaaaa", a);
        // var b = a.replace(/[,]/g, ",");
        // console.log("bbbbbbbbbbbbbb", b);

        // var c = 'Buy, Sell'
        // var d = c.split(",");
        // console.log("dddddddddddddd", d);

        // Looking For
        const looking_for_IdFetch = await db2.sequelize.query(`select id from lz_masters where option_type ="looking_for" and option_value ='${row[2]}' limit 1`);
        const looking_forId = looking_for_IdFetch[0][0] ? looking_for_IdFetch[0][0]["id"] : 0
        console.log("looking_for_IdFetch", looking_for_IdFetch[0]);
        console.log("looking_forId", looking_forId);
        // Property Type
        const property_type_IdFetch = await db2.sequelize.query(`select id from lz_masters where option_type ="property_type" and option_value ='${row[3]}' limit 1`);
        const property_typeId = property_type_IdFetch[0][0] ? property_type_IdFetch[0][0]["id"] : 0
        // Lead Source
        const lead_source_IdFetch = await db2.sequelize.query(`select id from lz_masters where option_type ="source" and option_value ='${row[4]}' limit 1`);
        const lead_sourceId = lead_source_IdFetch[0][0] ? lead_source_IdFetch[0][0]["id"] : 0
        // Lead Group
        const lead_group_IdFetch = await db2.sequelize.query(`select id from lz_masters where option_type ="lead_group" and option_value ='${row[5]}' limit 1`);
        const lead_groupId = lead_group_IdFetch[0][0] ? lead_group_IdFetch[0][0]["id"] : 0
        // Segment
        const segment_IdFetch = await db2.sequelize.query(`select id from lz_masters where option_type ="segment" and option_value ='${row[6]}' limit 1`);
        const segmentId = segment_IdFetch[0][0] ? segment_IdFetch[0][0]["id"] : 0
        // Priority
        const priority_IdFetch = await db2.sequelize.query(`select id from lz_masters where option_type ="lead_priority" and option_value ='${row[7]}' limit 1`);
        const priorityId = priority_IdFetch[0][0] ? priority_IdFetch[0][0]["id"] : 0
        // Fee Oppurtunity
        // const fee_oppurtunity_IdFetch = await db2.sequelize.query(`select id from lz_masters where option_type ="fee_oppurtunity" and option_value ='${row[8]}' limit 1`);
        // const fee_oppurtunityId = fee_oppurtunity_IdFetch[0][0] ? fee_oppurtunity_IdFetch[0][0]["id"] : 0
        // Lead Status
        const lead_status_IdFetch = await db2.sequelize.query(`select id from lz_masters where option_type ="lead_status" and option_value ='${row[9]}' limit 1`);
        const lead_statusId = lead_status_IdFetch[0][0] ? lead_status_IdFetch[0][0]["id"] : 52
        console.log("lead_status_IdFetch", lead_status_IdFetch[0][0]);
        console.log("lead_statusId", lead_statusId);

        // Project facing
        const project_facing_IdFetch = await db2.sequelize.query(`select id from lz_masters where option_type ="property_facing" and option_value ='${row[27]}' limit 1`);
        const project_facingId = project_facing_IdFetch[0][0] ? project_facing_IdFetch[0][0]["id"] : 0
        console.log("project_facing_IdFetch", project_facing_IdFetch[0][0]);
        console.log("project_facingId", project_facingId);

        // Age Of Property
        const age_of_property_IdFetch = await db2.sequelize.query(`select id from lz_masters where option_type ="age_of_property" and option_value ='${row[25]}' limit 1`);
        const age_of_propertyId = age_of_property_IdFetch[0][0] ? age_of_property_IdFetch[0][0]["id"] : 0
        console.log("age_of_property_IdFetch", age_of_property_IdFetch[0][0]);
        console.log("age_of_propertyId", age_of_propertyId);

        // country
        const countryIdFetch = await db.sequelize.query(`select id from lz_country where name ='${row[34]}' limit 1`);
        const countryId = countryIdFetch[0][0] ? countryIdFetch[0][0]["id"] : 0
        // city
        const cityIdFetch = await db.sequelize.query(`select id from lz_city where name ='${row[36]}' limit 1`);
        const cityId = cityIdFetch[0][0] ? cityIdFetch[0][0]["id"] : 0
        // state
        const stateIdFetch = await db.sequelize.query(`select id from lz_state where name ='${row[35]}' limit 1`);
        const stateId = stateIdFetch[0][0] ? stateIdFetch[0][0]["id"] : 0

        // Multiple Select
        // Assign To
        let userValue = `${row[10]}`;
        let userValue1 = userValue.split(',').map(item => `'${item}'`).join(',');

        const assignIdFetch = await db2.sequelize.query("select id from lz_user where first_name IN (" + userValue1 + ") group by id " );
        const assignId = assignIdFetch[0][0] ? assignIdFetch[0].map(params => params.id).join(',') : 0
        console.log("assignIdFetch", assignIdFetch[0]);
        console.log("assignId", assignId);

        // Amenities
        let amenitiesValue = `${row[33]}`;
        let amenitiesValue1 = amenitiesValue.split(',').map(item => `'${item}'`).join(',');

        const amenities_IdFetch = await db2.sequelize.query("select id from lz_masters where option_type = 'amenities' and option_value IN (" + amenitiesValue1 + ") group by id " );
        const amenitiesId = amenities_IdFetch[0][0] ? amenities_IdFetch[0].map(params => params.id).join(',') : 0
        console.log("amenities_IdFetch", amenities_IdFetch[0]);
        console.log("amenitiesId", amenitiesId);

        // Furnishing        
        let furnishing_Value = `${row[28]}`;
        let furnishing_Value1 = furnishing_Value.split(',').map(item => `'${item}'`).join(',');

        const furnishing_IdFetch = await db2.sequelize.query("select id from lz_masters where option_type = 'furnishing_status' and option_value IN (" + furnishing_Value1 + ") group by id " );
        const furnishingId = furnishing_IdFetch[0][0] ? furnishing_IdFetch[0].map(params => params.id).join(',') : 0
        console.log("furnishing_IdFetch", furnishing_IdFetch[0]);
        console.log("furnishingId", furnishingId);

        // possession_status
        let possession_status_value = `${row[24]}`;
        let possession_status_value1 = possession_status_value.split(',').map(item => `'${item}'`).join(',');

        const possession_status_IdFetch = await db2.sequelize.query("select id from lz_masters where option_type = 'possession_status' and option_value IN (" + possession_status_value1 + ") group by id " );
        const possession_statusId = possession_status_IdFetch[0][0] ? possession_status_IdFetch[0].map(params => params.id).join(',') : 0
        console.log("possession_status_IdFetch", possession_status_IdFetch[0]);
        console.log("possession_statusId", possession_statusId);

        // Sales Manager
        let sales_manager_value = `${row[11]}`;
        let sales_manager_value1 = sales_manager_value.split(',').map(item => `'${item}'`).join(',');

        const sales_managerFetch = await db2.sequelize.query("select id from lz_user where first_name IN (" + sales_manager_value1 + ") group by id " );
        const sales_managerId = sales_managerFetch[0][0] ? sales_managerFetch[0].map(params => params.id).join(',') : 0
        console.log("sales_managerFetch", sales_managerFetch[0]);
        console.log("sales_managerId", sales_managerId);
        
        const data = await db2['leads'].create({
          contact_id: contact_Id,
          property_id: property_Id,
          looking_for: looking_forId,
          property_type: property_typeId,
          lead_source: lead_sourceId,
          lead_group: lead_groupId,
          segment: segmentId,
          lead_priority: priorityId,
          fee_oppurtunity: row[8],
          lead_status:  lead_statusId,
          assign_to: assignId,
          sales_manager: sales_managerId,
          created_by: created_by,
        })

        let leadId = data?.dataValues.id
        console.log('leadID', leadId);

        const data3 = await db2['leadRequirement'].create({
          lead_id: leadId,
          // requirement_location: row[20],
          budget_min: row[12] ?? 0,
          budget_max: row[13] ?? 0,
          money_term_min: row[14] ?? 0,
          money_term_max: row[15] ?? 0,
          no_of_bedrooms_min: row[16] ?? 0,
          no_of_bedrooms_max: row[17] ?? 0,
          no_of_bathrooms_min: row[18] ?? 0,
          no_of_bathrooms_max: row[19] ?? 0,
          built_up_area_min: row[20] ?? 0,
          built_up_area_max: row[21] ?? 0,
          plot_area_min: row[22] ?? 0,
          plot_area_max: row[23] ?? 0,
          possession_status: possession_statusId,
          age_of_property: age_of_propertyId,
          vasthu_compliant: row[26] ?? 0,
          property_facing: project_facingId ?? 0,
          furnishing: furnishingId ?? 0,
          car_park_min: row[29] ?? 0,
          car_park_max: row[30] ?? 0,
          timeline_for_closure_min: row[31] ?? 0,
          timeline_for_closure_max: row[32] ?? 0,
          amenities: amenitiesId,
          country: countryId,
          state: stateId,
          city: cityId,
          zipcode: row[37] ?? 0,
          locality: row[38] ?? 0,
        })

        // const data4 = await db2['logs'].create({
        //   org_id: org_id,
        //   user_id: created_by,
        //   module_id: contactId,
        //   module_name: "1",
        //   note: " contact created at"
        // })
    });

    // res.send("Leads Saved Succesfully");
      res.status(200).send({
        status: 200,
        message: 'Bulk Leads Successfully',
      });
  });
});

exports.sendMailLead = (async (req, res) => {
  try {
    if (!req.body) {
      res.status(400).send({
        message: "Lead Cannot be Empty"
      });
    }
    const leadData = ({
      lead_id: req.body.lead_id || null,
      from: 'listez@admin.com' || null,
      to: req.body.to || null,
      subject: req.body.subject || null,
      message: req.body.message || null,
    });
    let message = {
      from: leadData.from,
      to: leadData.to,
      subject: leadData.subject,
      html:
        "<h3> message: </h3>" +
        leadData.message + "",
    };
    // mailer.sendMail(message);
    console.log('message',message);

    res.status(200).send({
      status: 200,
      message:'mail send sucessfully',
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
});

// exports.getLeadAutoMatch = async (req, res) => {
//   try {
//   const organ_id = req.user.id
//   const org_id = organ_id.org_id
//   console.log('organ_id', org_id);

//   const id = req.params.id

//   let thisQuery = `select pr.id,
//   pr.plot_area_min as plot_area_min, pr.plot_area_max as plot_area_max, pr.built_up_area_min as built_up_area_min, pr.built_up_area_max as built_up_area_max,
//   pr.furnishing as furnishing,
//   GROUP_CONCAT(distinct CONCAT(fur.option_value),'-',fur.id) as furnishing_name, pa.locality as locality
//   from lz_property_residentials as pr 
//   LEFT JOIN lz_property_addresses as pa on (pa.property_id = pr.property_id)
//   LEFT JOIN lz_masters as fur on FIND_IN_SET(fur.id,pr.furnishing) > 0
//   where pr.created_at IS NOT NULL
//   `

//   let thisQuery1 = ` SELECT lr.plot_area_min as plot_area_min, lr.plot_area_max as plot_area_max, lr.built_up_area_min as built_up_area_min, lr.built_up_area_max as built_up_area_max, lr.furnishing as furnishing, lr.locality as locality
//   FROM lz_lead_requirements as lr 
//   where id = ${id} `
  
//   const data1 = await db2.sequelize.query(thisQuery1);

//   const filters = req.query;

//     // if (filters.furnishing) {
//     //   var a = filters.furnishing;
//     //   var b = a.replace(/[,]/g, ",");
//     //   thisQuery += ` and CONCAT(',', pr.furnishing, ',') REGEXP ',(${a}),' `
//     // }
//     // if (filters.project_stage) {
//     //   var a = filters.project_stage;
//     //   var b = a.replace(/[,]/g, ",");
//     //   thisQuery += ` and CONCAT(',', pr.project_stage, ',') REGEXP ',(${a}),' `
//     // }

//     // if (data1[0][0].locality =="" || data1[0][0].locality) {
//     //   thisQuery += " and pa.locality = " + `'${data1[0][0].locality}' `
//     // }

//     if (data1[0][0].furnishing =="" || data1[0][0].furnishing) {
//       var a = data1[0][0].furnishing;
//       var b = a.replace(/[,]/g, ",");
//       thisQuery += ` and CONCAT(',', pr.furnishing, ',') REGEXP ',(${a}),' `
//     }
   
//     // if (data1[0][0].plot_area_min =="" || data1[0][0].plot_area_min) {
//     //   thisQuery += " and pr.plot_area_min >= " + `'${data1[0][0].plot_area_min}' `
//     // }
//     // if (data1[0][0].plot_area_max =="" || data1[0][0].plot_area_max) {
//     //   thisQuery += " and pr.plot_area_max <= " + `'${data1[0][0].plot_area_max}' `
//     // }

//     if ((data1[0][0].plot_area_min =="" && data1[0][0].plot_area_max =="") || (data1[0][0].plot_area_min &&  data1[0][0].plot_area_max)) {
//       thisQuery += " and pr.plot_area_min < " + `'${data1[0][0].plot_area_min}' ` + " and pr.plot_area_max >= " + `'${data1[0][0].plot_area_max}' `
//     }
//     // if ((data1[0][0].built_up_area_min =="" && data1[0][0].built_up_area_max =="") || (data1[0][0].built_up_area_min && data1[0][0].built_up_area_max)) {
//     //   thisQuery += " and pr.built_up_area_min < " + `'${data1[0][0].built_up_area_min}' ` + " and pr.built_up_area_max >= " + `'${data1[0][0].built_up_area_max}' `
//     // }

//     // if (data1[0][0].built_up_area_min =="" || data1[0][0].built_up_area_min) {
//     //   thisQuery += " and pr.built_up_area_min between " + `'${data1[0][0].built_up_area_min}' `
//     // }
//     // if (data1[0][0].built_up_area_max =="" || data1[0][0].built_up_area_max) {
//     //   thisQuery += " and pr.built_up_area_max >= " + `'${data1[0][0].built_up_area_max}' `
//     // }

//     // if ((data1[0][0].plot_area_min =="" || data1[0][0].plot_area_min) || (data1[0][0].plot_area_min && data1[0][0].plot_area_max)) {
//     //   thisQuery += " and pr.plot_area_min and pr.plot_area_max between " + `${data1[0][0].plot_area_min} ` + `and ${data1[0][0].plot_area_max} `
//     // }
//     // if (data1[0][0].built_up_area_max =="" || data1[0][0].built_up_area_max) {
//     //   thisQuery += " and pr.built_up_area_max = " + `${data1[0][0].built_up_area_max} `
//     // }

//     // if (filters.built_up_area_min && filters.built_up_area_max) {
//     //   thisQuery += " and pr.built_up_area_min between " + `${filters.built_up_area_min}` + ` and ${filters.built_up_area_max} `
//     // }

//     // if (data1[0][0].plot_area_max =="" || data1[0][0].plot_area_max) {
//     //   thisQuery += " and pr.plot_area_max = " + `${data1[0][0].plot_area_max} `
//     // }
//     thisQuery += ' group by pr.id '
//     thisQuery += ' order by pr.id desc '

//     const data = await db2.sequelize.query(thisQuery);

//     console.log("propertyResidentials", data[0]);
//     console.log("leadRequirements", data1[0][0]);


//     if(data[0].length == 0) {
//       res.status(200).send({
//         status:200,
//         message:'Empty',
//         output:[],
//       });
//     } else {
//       res.status(200).send({
//         status:200,
//         message:'Success',
//         output: data[0],
//       });
//     }

//   } catch (error) {
//     res.status(500).send({
//       message: error.message,
//     });
//   }
// };