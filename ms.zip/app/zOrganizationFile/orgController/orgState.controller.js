const orgDbConfig = require("../orgConfig/orgDb.config.js");
const db2 = require("../orgModel/orgIndex.js");
const db = require("../../models");
const Op = db2.Sequelize.Op;

exports.stateSave = async (req, res) => {
try {
    const created_by = req.user.id
    console.log('created_by', created_by.id);

    const stateData = await db2['state'].findOne({
    where: {status:1,name:`${req.body.name}`},
    attributes:['name']
    });
    console.log("stateData", stateData);
    const executives = stateData?.dataValues ? stateData?.dataValues.name : 0

    if (executives !== 0) {
    res.status(200).send({
        status:400,
        message: "State Already Exists.",
    });
    } else {
    const data = await db2['state'].create({
    country_id: req.body.country_id,
    name: req.body.name,
    created_by: created_by.id
    });
    res.status(200).send({
        status:200,
        message:'Success',
        output:data
    });
}} catch (error) {
    res.status(500).send({
    message: error.message,
    });
}
};
exports.stateList = async (req, res) => {
try {
    const id = req.params.id;
    
    let thisQuery = ` SELECT st.id as id, st.name as name, cou.id as country_id, cou.name as country_name FROM lz_state as st
    LEFT JOIN lz_country as cou on (cou.id = st.country_id)
    WHERE st.status = 1 `
    const data = await db2.sequelize.query(thisQuery);

    res.status(200).send({
    status:200,
    message:'Success',
    output:data[0]
    });
} catch (error) {
    res.status(500).send({
    message: error.message,
    });
}
};
exports.stateEdit = async (req, res) => {
try {
    const id = req.params.id;
    
    let thisQuery = ` SELECT st.id as id, st.name as name, cou.id as country_id, cou.name as country_name FROM lz_state as st
    LEFT JOIN lz_country as cou on (cou.id = st.country_id)
    WHERE status = 1 and id = ${id}`
    const data = await db2.sequelize.query(thisQuery);

    if (data) {
    res.status(200).send({
        status:200,
        message:'Success',
        output:data[0][0]
        });
    } else {
    res.status(200).send({
        status:404,
        message: `Cannot find with id : ${id}.`
    });
    }
} catch (error) {
    res.status(500).send({
    message: error.message,
    });
}
};
exports.stateUpdate = async (req, res) => {
try {
    const id = req.params.id;
    const countryID = await db2['state'].findOne({
    where: {status:1, id: id},
    });
    const countryData = countryID?.dataValues ? countryID?.dataValues.id : 0
    console.log("countryData", countryData);

    const countryCheck = await db2['state'].findOne({
    where: {
        id: {
        [Op.ne]: countryData
        },
        name:`${req.body.name}`,
        status:1,
    },
    attributes:['name']
    });
    const checkData = countryCheck?.dataValues ? countryCheck?.dataValues.id : 0

    if (checkData !== 0) {
    res.status(200).send({
        status:400,
        message: "State Already Exists.",
    });
    } else {
    const id = req.params.id;
    const num = await db2['state'].update(req.body, {
    where: { id: id, status:1 },
    });
    if (num == 1) {
    res.status(200).send({
        status:200,
        message: "Updated successfully."
    });
    } else {
    res.status(200).send({
        status:404,
        message: `Cannot update with id : ${id}.`
    });
    }
}} catch (error) {
    res.status(500).send({
    message: error.message,
    });
}
};
exports.stateDelete = async (req, res) => {
    const stateData = {
      status: 0,
    }
    try {
      const id = req.params.id;
  
      const thisQuery45 = ` SELECT state_id FROM lz_city where state_id = ${id} and status = 1 limit 1 `
      const data45 = await db2.sequelize.query(thisQuery45);
  
      const stateDelete = data45[0]
  
      console.log("StateDataaaaaa",stateDelete[0] ?? 0);
  
      const executives = stateDelete[0] ? stateDelete[0].state_id : 0
      console.log("executivesssssss", executives);
      if (executives) { 
        res.status(200).send({
          status: 400,
          message: "State In-active!"
        });
      } else {
      const num = await db2['state'].update(stateData,{
        where: { id: id },
      });
      const thisQuery = ` Update lz_city SET status = 0 where state_id = ${id} `
      const data1 = await db2.sequelize.query(thisQuery);
  
      if (num == 1) {
        res.status(200).send({
          status:200,
          message: "Deleted successfully!"
        });
      } else {
        res.status(200).send({
          status:404,
          message: `Cannot delete with id : ${id}.`
        });
      }
    } } catch (error) {
      res.status(500).send({
        message: error.message,
      });
    }
};