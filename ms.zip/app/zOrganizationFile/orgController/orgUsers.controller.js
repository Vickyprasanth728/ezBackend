const jwt = require("../../helpers/jwt");

const db = require("../../models");
const db2 = require("../orgModel/orgIndex.js");
const Op = db2.Sequelize.Op;

const bcrypt = require("bcrypt");
const saltRounds = 10;

exports.findAll = async (req, res) => {
  try {
    var condition = {
      where:{
        status:1
      },
      order: [['id', 'DESC']], // ASC, DESC
      attributes:{exclude:['createdAt','updatedAt']},
    };
    var offset = parseInt(req.query.offset);
    var limit = parseInt(req.query.limit);

    if (offset >= 0 && limit >= 0) {
      condition.offset = offset;
      condition.limit = limit;
    }

    const data = await db2['users'].findAll(condition);
    res.status(200).send({
        status:200,
        message: 'Success',
        output:data
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.findOne = async (req, res) => {
  try {
    var condition = {
      where:{
        status:1
      },
      attributes:['id','email']
    };
    const id = req.params.id;
    const data = await db2[req.params.document].findByPk(id,condition);
    if (data) {
      res.status(200).send({
          status:200,
          message: 'Success',
          output:data
        });
    } else {
      res.status(200).send({
        status: 404,
        message: `Cannot find with id : ${id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.createUser = async (req, res) => {
  try {
    const created_by = req.user.id
    const org_id = req.user.org_id
    console.log('created_by', created_by.id);
    console.log('org_id', org_id);

    if (!req.body.email || !req.body.password) {
      res.status(200).send({
        status:400,
        message: "Email & Password required.",
      });
      return;
    }

    var condition = {
      where: {
        [Op.and]: [
          {
            email: req.body.email,
          },
        ],
      },
    };

    const user = await db2[req.params.document].findOne(condition);

    if (user) {
      res.status(200).send({
        status:400,
        message: "Email already in use.",
      });
    } else {
      bcrypt.hash(req.body.password, saltRounds, async function (error, hash) {
        req.body.password = hash;
        const users = new db2[req.params.document]({
          email: req.body.email,
          password: req.body.password,
          org_id: org_id,
          status: req.body.status,
          created_by: created_by.id
        });
        const data = await users.save(users);

        res.status(200).send({
          status:200,
          message: "Sucess.",
          access_token: jwt.accessTokenEncode(data.id),
          refresh_token: jwt.refreshTokenEncode(data.id),
          user: data,
        });
      });
    }
  } catch (error) {
    console.log(error);
    res.status(500).send({
      status:500,
      message: error.message,
    });
  }
};
exports.updateUser = async (req, res) => {
  try {
    const id = req.params.id;
    const user = await db2['users'].findOne({
      where: {id: id},
      // attributes:['id']
    });
    console.log("userrrrr",user);
    const adminId = user?.dataValues ? user?.dataValues.id : 0
    console.log("adminId", adminId);

    const users = await db2['users'].findOne({
      // where: { email:`${req.body.email}`,id : `${adminId}`},
      where: {
        id: {
          [Op.ne]: adminId
        },
        email:`${req.body.email}`,
      },

      attributes:['id', "email"]
    });
    console.log("userssss", users);

    const executives = users?.dataValues ? users?.dataValues.id : 0
    console.log("executivesssss", executives);

    if (executives !== 0) {
      res.status(200).send({
        status:400,
        message: "Email already in use.",
      });
    } else {
    bcrypt.hash(req.body.password, saltRounds, async function (error, hash) {
      req.body.password = hash;
      const num = await db2[req.params.document].update(req.body, {
        where: { id: id },
      });
    if (num == 1) {
      res.status(200).send({
        status:200,
        message: "Updated successfully."
      });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot update with id : ${id}.`
      });
    }
  })} } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.deleteUser = async (req, res) => {
  const UserData = {
      status: 0,
  }
  try {
      const id = req.params.id;
      const num = await db2[req.params.document].update(UserData, {
          where: { id: id },
      });
      if (num == 1) {
          res.status(200).send({
              status:200,
              message: "Deleted successfully!"
          });
      } else {
          res.status(200).send({
              status:404,
              message: `Cannot delete with id : ${id}.`
          });
      }
  } catch (error) {
      res.status(500).send({
          message: error.message,
      });
  }
};