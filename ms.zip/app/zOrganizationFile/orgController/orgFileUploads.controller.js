const db2 = require("../orgModel/orgIndex.js");
const db = require("../../models");
const Op = db2.Sequelize.Op;
const path = require("path");
const fs = require("fs");

exports.saveFileUploads = async (req, res) => {
    try {
        const id = req.params.id
        const created_by = req.user.id
        console.log('created_by', created_by.id);

        const organ_id = req.user.id
        const org_id = organ_id.org_id
        console.log('organ_id', org_id);

        if (req.files.length > 0) {
            for (i = 0; i < req.files.length; i++) {
                //extension
                let additionalFiles = "";
                let additionalFiles_original_name = "";
                if (req.files[i]) {
                    const extension = req.files[i]["mimetype"].split('/')[1]
                    additionalFiles = req.files[i]["filename"] + '.' + extension
                    additionalFiles_original_name = req.files[i]["originalname"]
                }

                const fileData = {
                    module_id: req.params.id,
                    module_name: req.body.module_name,
                    file: additionalFiles,
                    fileoriginalname: additionalFiles_original_name,
                    user_id: created_by.id,
                    created_by: created_by.id,
                };

                x = fileData.module_id
                console.log('xxxxxxxxxxxxx', x);
                const data = await db2['files'].create(fileData);
                //move the file to directory
                const currentPath = path.join(process.cwd(), "uploads", req.files[i]["filename"]);
                const destinationPath = path.join(process.cwd(), "uploads/contacts/files/" + `${x}`, additionalFiles);

                const baseUrl = process.cwd() + '/uploads/contacts/files/' + `${x}`
                fs.mkdirSync(baseUrl, { recursive: true })
                fs.rename(currentPath, destinationPath, function (err) {
                    if (err) {
                        throw err
                    } else {
                        console.log("Successfully moved the file!")
                    }
                })
            }
        }

        const ModuleID = req.params.id
        const ModuleName = req.body.module_name

        let thisQuery = `select * from lz_file_uploads where module_id = ${ModuleID} and module_name = ${ModuleName} order by id desc  `
        const fileData = await db2.sequelize.query(thisQuery);
        console.log("thisQueryyyyyyyyyy", thisQuery);

        res.status(200).send({
            status: 200,
            message: 'Success',
            output: fileData[0]
        });

    } catch (error) {
        res.status(500).send({
            message: error.message,
        });
    }
};
exports.getFileUploads = async (req, res) => {
    try {
        const id = req.params.id
        const module_id = req.params.module_id
        const module_name = req.params.module_name

        const created_by = req.user.id
        console.log('created_by', created_by.id);

        const organ_id = req.user.id
        const org_id = organ_id.org_id
        console.log('organ_id', org_id);

        var condition = {
            where: {
                status: 1, module_id: module_id, module_name: module_name
            },
            order: [['id', 'DESC']], // ASC, DESC
            attributes: { exclude: ['createdAt', 'updatedAt'] },
        };

        const data = await db2['files'].findAll(condition);

        res.status(200).send({
            status: 200,
            message: 'Success',
            output: data
        });
    } catch (error) {
        res.status(500).send({
            message: error.message,
        });
    }
};
exports.deleteFileUpload = async (req, res) => {
    try {
      const id = req.params.id;
      const module_id = req.body.module_id;
      const module_name = req.body.module_name;

      const num = await db2['files'].destroy({
        where: { id: id},
      });
      if (num == 1) {
        
        var condition = {
            where: {
                status: 1, module_id: module_id, module_name: module_name
            },
            order: [['id', 'DESC']], // ASC, DESC
            attributes: { exclude: ['createdAt', 'updatedAt'] },
        };

        const data = await db2['files'].findAll(condition);

        res.status(200).send({
            status: 200,
            message: 'Success',
            output: data
        });
      } else {

        var condition = {
            where: {
                status: 1, module_id: module_id, module_name: module_name
            },
            order: [['id', 'DESC']], // ASC, DESC
            attributes: { exclude: ['createdAt', 'updatedAt'] },
        };

        const data1 = await db2['files'].findAll(condition);

        res.status(200).send({
            status: 404,
            message: `Cannot delete with id : ${id}.`,
            output: data1
        });
      }
    } catch (error) {
      res.status(500).send({
        message: error.message,
      });
    }
};
