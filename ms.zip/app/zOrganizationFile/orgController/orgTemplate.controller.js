const db2 = require("../orgModel/orgIndex.js");
const Op = db2.Sequelize.Op;

exports.create = async (req, res) => {
    try {
      const created_by = req.user.id
      console.log('created_by', created_by.id);
      
      let x = req.body.template_name.toLowerCase().replace(/ /g, '-').replace(/[^\w-]+/g, '');
  
      const data = await db2['template'].create({
        template_name: req.body.template_name,
        slug: x,
        template_content: req.body.template_content,
        status: req.body.status,
        created_by: created_by.id
      });
      res.status(200).send({
        status:200,
        message:'Success',
        output:data
      });
    } catch (error) {
      res.status(500).send({
        message: error.message,
      });
    }
  };
exports.findAll = async (req, res) => {
    try {
      var condition = {
        where:{
          status:1
        },
        order: [['id', 'DESC']], // ASC, DESC
        attributes:['id','template_name','slug','template_content']
      };
      var offset = parseInt(req.query.offset);
      var limit = parseInt(req.query.limit);
  
      if (offset >= 0 && limit >= 0) {
        condition.offset = offset;
        condition.limit = limit;
      }
  
      const data = await db2['template'].findAll(condition);
      res.status(200).send({
        status:200,
        message:'Success',
        output:data
      });
    } catch (error) {
      res.status(500).send({
        message: error.message,
      });
    }
  };
exports.findOne = async (req, res) => {

  try {
    const id = req.params.id;
    const data = await db2['template'].findByPk(id, {
      where: {
        [Op.and]: [
          { id: id },
          { status: 1 }
        ]
      },
      attributes:['id','template_name','slug','template_content']
    }
      );
    if (data) {
      res.status(200).send({
        status:200,
        message:'Success',
        output:data
        });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot find with id : ${id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.update = async (req, res) => {
  try {
    const id = req.params.id;
    let x = req.body.template_name.toLowerCase().replace(/ /g, '-').replace(/[^\w-]+/g, '');

    const templatedata = {
        template_name: req.body.template_name,
        slug: x,
        template_content: req.body.template_content,
        status: req.body.status,
    }

    const num = await db2['template'].update(templatedata, {
      where: { id: id },
    });
    if (num == 1) {
      res.status(200).send({
        status:200,
        message: "Updated successfully."
      });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot update with id : ${id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};