const db2 = require("../orgModel/orgIndex.js");
const Op = db2.Sequelize.Op;

exports.findAll = async (req, res) => {
    try {
        const organ_id = req.user.id
        const org_id = organ_id.org_id
        console.log('organ_id', org_id);

        var module_id = req.params.module_id
        var module_name = req.params.module_name

      var condition = {
        where:{
            module_id:`${module_id}`, module_name:`${module_name}`
        },
        order: [['id', 'DESC']], // ASC, DESC
        attributes:{exclude:['updatedAt']},
        include: [
          {
            model: db2['user'],
            attributes: ['id', 'first_name', 'last_name'],
            where: {},
            as: 'user_name',
            required: false,
          },
        ]
      };
      var offset = parseInt(req.query.offset);
      var limit = parseInt(req.query.limit);
  
      if (offset >= 0 && limit >= 0) {
        condition.offset = offset;
        condition.limit = limit;
      }
  
      const data = await db2['logs'].findAll(condition);

      res.status(200).send({
        status:200,
        message:'Success',
        output:data
      });
    } catch (error) {
      res.status(500).send({
        message: error.message,
      });
    }
};