const db2 = require("../orgModel/orgIndex.js");
const db = require("../../models");
const Op = db2.Sequelize.Op;

exports.saveNotes = async (req, res) => {
    try {
      const id = req.params.id
      const created_by = req.user.id
      console.log('created_by', created_by.id);
  
      const organ_id = req.user.id
      const org_id = organ_id.org_id
      console.log('organ_id', org_id);

    if (req.body.parent_id == 0) {

      const data = await db2['notes'].create({
        org_id: org_id,
        reply: req.body.reply,
        parent_id: "0",
        module_id: req.body.module_id,
        module_name: req.body.module_name,
        user_id: created_by.id,
        created_by: created_by.id
      });
      const ModuleID = data?.dataValues.module_id
      const ModuleName = data?.dataValues.module_name

      const NotesID = data?.dataValues.id;

      const data1 = {
        parent_id: NotesID
      }
      const num = await db2['notes'].update(data1, {
        where: { id: NotesID },
      });

      let thisQuery = `SELECT nc.id as id, nc.org_id as org_id, nc.reply as reply, nc.parent_id as parent_id, nc.module_id as module_id, nc.module_name as module_name, nc.user_id as user_id,  nc.created_at as created_at, nc.updated_at as updated_at, IF(nc.parent_id != nc.id , "YES", "NO") as reply1, CONCAT(us.first_name,' ',us.last_name) as user_name, us.profile_image as user_profile_image FROM lz_notes as nc LEFT JOIN lz_user as us on (us.id = nc.user_id) where nc.status = 1 and nc.module_id = ${ModuleID} and nc.module_name = ${ModuleName} order by nc.parent_id DESC, nc.id `
      const notesData = await db2.sequelize.query(thisQuery);

      res.status(200).send({
        status:200,
        message:'Success',
        output:notesData[0]
      });

    } else {
        const data = await db2['notes'].create({
            org_id: org_id,
            reply: req.body.reply,
            parent_id: req.body.parent_id,
            module_id: req.body.module_id,
            module_name: req.body.module_name,
            user_id: created_by.id,
            created_by: created_by.id
          });
          let ModuleID =  data?.dataValues.module_id
          let ModuleName = data?.dataValues.module_name

          let thisQuery = `SELECT nc.id as id, nc.org_id as org_id, nc.reply as reply, nc.parent_id as parent_id, nc.module_id as module_id, nc.module_name as module_name, nc.user_id as user_id, nc.created_at as created_at, nc.updated_at as updated_at, IF(nc.parent_id != nc.id , "YES", "NO") as reply1, CONCAT(us.first_name,' ',us.last_name) as user_name, us.profile_image as user_profile_image FROM lz_notes as nc LEFT JOIN lz_user as us on (us.id = nc.user_id) where nc.status = 1 and nc.module_id = ${ModuleID} and nc.module_name = ${ModuleName} order by nc.parent_id DESC, nc.id `
          const notesData = await db2.sequelize.query(thisQuery);

          res.status(200).send({
            status:200,
            message:'Success',
            output:notesData[0]
          });
    }

    } catch (error) {
      res.status(500).send({
        message: error.message,
      });
    }
};
exports.getNotes = async (req, res) => {
  try {
  const organ_id = req.user.id
  const org_id = organ_id.org_id
  console.log('organ_id', org_id);
  const role = req.user.id
  const role_id = role.designation
  console.log('role_id', role_id);

  const ModuleID = req.params.module_id;
  const ModuleName = req.params.module_name;
  
  let thisQuery1 = `
  ${ModuleName == 1 ? `SELECT c.id as contact_id FROM lz_contacts as c where ${role_id == 1 ? `c.status IN (1,2) ` : `c.status = 1`} and c.id = ${ModuleID}` : 
    ModuleName == 2 ? `SELECT l.id as lead_id,l.contact_id as contact_id FROM lz_leads as l where ${role_id == 1 ? `l.status IN (1,2) ` : `l.status = 1`} and l.id = ${ModuleID}` : 
    ModuleName == 3 ? `SELECT p.contact_id as contact_id FROM lz_properties as p where p.status = 1 and p.id = ${ModuleID} ` : 
    ModuleName == 4 ? `SELECT t.contact as contact_id, t.project as property_id, le.id as lead_id FROM lz_tasks as t left join lz_contacts as c on (c.id = t.contact) left join lz_leads as le on (c.id = le.contact_id) where ${role_id == 1 ? `t.status IN (1,2) ` : `t.status = 1`} and t.id = ${ModuleID} ` : 
    ModuleName == 5 ? `SELECT tra.client_name as contact_id, tra.project_name as property_id, tra.lead_id as lead_id FROM lz_transactions as tra left join lz_leads as le on (le.id = tra.lead_id) where tra.status = 1 and tra.id = ${ModuleID} ` : ``} `
  const conData = await db2.sequelize.query(thisQuery1);

  const cData = `
  ${ModuleName == 2 || 3 ? conData[0][0].contact_id : 
    ModuleName == 4 ? conData[0][0].contact_id : 
    ModuleName == 5 ? conData[0][0].client_name : ``} `
  console.log("cData", cData);
  const lData = `
  ${ModuleName == 2 || 3 ? conData[0][0].lead_id : 
    ModuleName == 4 ? conData[0][0].lead_id : 
    ModuleName == 5 ? conData[0][0].lead_id : ``} `
  console.log("lData", lData);
  const pData = `
  ${ModuleName == 2 || 3 ? conData[0][0].property_id : 
    ModuleName == 4 ? conData[0][0].property_id : 
    ModuleName == 5 ? conData[0][0].property_id : ``} `
  console.log("pData", pData);

  let thisQuery = `SELECT nc.id as id, nc.org_id as org_id, nc.reply as reply, nc.parent_id as parent_id, nc.module_id as module_id, nc.module_name as module_name, nc.user_id as user_id,  nc.created_at as created_at, nc.updated_at as updated_at, IF(nc.parent_id != nc.id , "YES", "NO") as reply1, CONCAT(us.first_name,' ',us.last_name) as user_name, us.profile_image as user_profile_image 
  FROM lz_notes as nc 
  LEFT JOIN lz_user as us on (us.id = nc.user_id)  
  where nc.status = 1 and (nc.module_id = ${ModuleID} and nc.module_name = ${ModuleName} 
  ${ModuleName == 1 ? `` : `or (nc.module_id = ${cData} and nc.module_name = 1) `} 
  ${ModuleName == 4 ? `or (nc.module_id = ${lData} and nc.module_name = 2) or (nc.module_id = ${pData} and nc.module_name = 3) ` : ``} 
  ${ModuleName == 5 ? `or (nc.module_id = ${lData} and nc.module_name = 2) or (nc.module_id = ${pData} and nc.module_name = 3) ` : ``} 
  )
  order by nc.parent_id DESC, nc.id `
  const notesData = await db2.sequelize.query(thisQuery);

    res.status(200).send({
      status:200,
      message:'Success',
      count:notesData[0].length,
      output:notesData[0]
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.updateNotes = async (req, res) => {
  try {
    const id = req.params.id;

    const created_by = req.user.id
    console.log('created_by', created_by.id);

    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    const contactNotesData = {
        reply: req.body.reply,
    };

    const ModuleID = req.body.module_id
    const ModuleName = req.body.module_name

    const num = await db2['notes'].update(contactNotesData, {
      where: { id: id },
    });
    if (num == 1) {

        let thisQuery1 = `SELECT nc.id as id, nc.org_id as org_id, nc.reply as reply, nc.parent_id as parent_id, nc.module_id as module_id, nc.module_name as module_name, nc.user_id as user_id, nc.updated_at as updated_at, IF(nc.parent_id != nc.id , "YES", "NO") as reply1, CONCAT(us.first_name,' ',us.last_name) as user_name, us.profile_image as user_profile_image FROM lz_notes as nc LEFT JOIN lz_user as us on (us.id = nc.user_id) where nc.status = 1 and nc.module_id = ${ModuleID} and nc.module_name = ${ModuleName} order by nc.parent_id DESC, nc.id `
        const notesData = await db2.sequelize.query(thisQuery1);

      res.status(200).send({
        status:200,
        message: "Updated successfully.",
        output:notesData[0]
      });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot update with id : ${id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.deleteNotes = async (req, res) => {

  const id = req.params.id;
  const parent_id = req.params.parent_id;

  const created_by = req.user.id
  console.log('created_by', created_by.id);

  const organ_id = req.user.id
  const org_id = organ_id.org_id
  console.log('organ_id', org_id);

  const ModuleID = req.body.module_id
  const ModuleName = req.body.module_name

  try {
    let thisQuery = ` UPDATE lz_notes SET status = 0 `
    if (id == parent_id) {
        thisQuery += "where parent_id IN (" + parent_id + ")"
    } else {
        thisQuery += `where id = ${id} `
    }
    const data = await db2.sequelize.query(thisQuery);

    let thisQuery1 = `SELECT nc.id as id, nc.org_id as org_id, nc.reply as reply, nc.parent_id as parent_id, nc.module_id as module_id, nc.module_name as module_name, nc.user_id as user_id, nc.updated_at as updated_at, IF(nc.parent_id != nc.id , "YES", "NO") as reply1, CONCAT(us.first_name,' ',us.last_name) as user_name, us.profile_image as user_profile_image FROM lz_notes as nc LEFT JOIN lz_user as us on (us.id = nc.user_id) where nc.status = 1 and nc.module_id = ${ModuleID} and nc.module_name = ${ModuleName} order by nc.parent_id DESC, nc.id `
    const notesData = await db2.sequelize.query(thisQuery1);

    res.status(200).send({
        status:200,
        message:'Success',
        output:notesData[0]
      });

  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
