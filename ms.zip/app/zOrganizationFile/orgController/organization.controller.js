const jwt = require("../../helpers/jwt");

const db = require("../../models");
const db2 = require("../orgModel/orgIndex.js");
const Op = db.Sequelize.Op;

const bcrypt = require("bcrypt");
const saltRounds = 10;

const path = require("path");
const fs = require("fs");

exports.findOne = async (req, res) => {
  try {

    const id = req.params.company_ref_id;
    const data = await db2['organization'].findOne({
      where: {
        status: 1, company_ref_id: id
      },
      attributes: { exclude: ['createdAt', 'updatedAt', 'created_by', 'deleted_by'] },
    });
    const localityCountryData = data?.dataValues.country
    const localityStateData = data?.dataValues.state
    const localityCityData = data?.dataValues.city
    const countryData = await db['country'].findOne({
      where: {
        status: 1, id:localityCountryData
      },
      attributes: { exclude: ['createdAt', 'updatedAt', 'created_by'] },
    });
    const stateData = await db['state'].findOne({
      where: {
        status: 1, id:localityStateData
      },
      attributes: { exclude: ['createdAt', 'updatedAt', 'created_by'] },
    });
    const cityData = await db['city'].findOne({
      where: {
        status: 1, id:localityCityData
      },
      attributes: { exclude: ['createdAt', 'updatedAt', 'created_by'] },
    });

    if (data) {
      res.status(200).send({
        status: 200,
        message: 'Success',
        output: {...data?.dataValues, country_data: countryData?.dataValues,  state_data: stateData?.dataValues,  city_data: cityData?.dataValues}
      });
    } else {
      res.status(200).send({
        status: 404,
        message: `Cannot find with id : ${id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.updateOrg = async (req, res) => {
  try {
    const id = req.params.id;
    const companyId = req.params.company_ref_id;
    // const email = `${req.body.email}`;
    const user = await db['users'].findOne({
      where: { id: id },
      // attributes:['id']
    });
    console.log("userrrrr", user);
    const adminId = user?.dataValues ? user?.dataValues.id : 0
    console.log("adminId", adminId);

    const users = await db['users'].findOne({
      // where: { email:`${req.body.email}`,id : `${adminId}`},
      where: {
        id: {
          [Op.ne]: adminId
        },
        email: `${req.body.email}`,
      },

      attributes: ['id', "email"]
    });
    console.log("userssss", users);

    const executives = users?.dataValues ? users?.dataValues.id : 0
    console.log("executivesssss", executives);

    if (executives !== 0) {
      res.status(200).send({
        status: 400,
        message: "Email already in use.",
      });
    } else {

      let water_mark = undefined;
      let logo = undefined;
      console.log("req.files.logo" , req.files.logo);
      console.log("req.files.water_mark" , req.files.water_mark);

      if (req.files.logo) {
        const extension = req.files.logo[0]["mimetype"].split('/')[1]
        logo = req.files.logo[0]["filename"] + '.' + extension
      }
      else {
        logo = null
      }
      if (req.files.water_mark) {
        const extension = req.files.water_mark[0]["mimetype"].split('/')[1]
        water_mark = req.files.water_mark[0]["filename"] + '.' + extension
      }
      else {
        water_mark = null
      }
      console.log("water_markkkkkk" , water_mark);

      bcrypt.hash(req.body.password, saltRounds, async function (error, hash) {
        req.body.password = hash;
        console.log("logoooo" , logo);
        console.log("water_markkkkkk" , water_mark);
        let data = {};
        if (logo != undefined && water_mark != undefined) {
          data = {
            organization_name: req.body.organization_name,
            company_ref_id: req.body.company_ref_id,
            user_name: req.body.user_name,
            password: req.body.password,
            sub_domain: req.body.sub_domain,
            sub_domain_database_name: req.body.sub_domain_database_name,
            phone_number: req.body.phone_number,
            gst_number: req.body.gst_number,
            cin_number: req.body.cin_number,
            tan_number: req.body.tan_number,
            pan_number: req.body.pan_number,
            address: req.body.address,
            city: req.body.city,
            state: req.body.state,
            country: req.body.country,
            currency: req.body.currency,
            website: req.body.website,
            facebook_url: req.body.facebook_url,
            linkindin_url: req.body.linkindin_url,
            twitter_url: req.body.twitter_url,
            instagram_url: req.body.instagram_url,
            youtube_url: req.body.youtube_url,
            approval: req.body.approval,
            logo: logo,
            water_mark: water_mark,
          };
        } 
        else if (water_mark != undefined) {
          data = {
            organization_name: req.body.organization_name,
            company_ref_id: req.body.company_ref_id,
            user_name: req.body.user_name,
            password: req.body.password,
            sub_domain: req.body.sub_domain,
            sub_domain_database_name: req.body.sub_domain_database_name,
            phone_number: req.body.phone_number,
            gst_number: req.body.gst_number,
            cin_number: req.body.cin_number,
            tan_number: req.body.tan_number,
            pan_number: req.body.pan_number,
            address: req.body.address,
            city: req.body.city,
            state: req.body.state,
            country: req.body.country,
            currency: req.body.currency,
            website: req.body.website,
            facebook_url: req.body.facebook_url,
            linkindin_url: req.body.linkindin_url,
            twitter_url: req.body.twitter_url,
            instagram_url: req.body.instagram_url,
            youtube_url: req.body.youtube_url,
            approval: req.body.approval,
            // logo: logo,
            water_mark: water_mark,
          };
        }    
        else if (logo != undefined) {
          data = {
            organization_name: req.body.organization_name,
            company_ref_id: req.body.company_ref_id,
            user_name: req.body.user_name,
            password: req.body.password,
            sub_domain: req.body.sub_domain,
            sub_domain_database_name: req.body.sub_domain_database_name,
            phone_number: req.body.phone_number,
            gst_number: req.body.gst_number,
            cin_number: req.body.cin_number,
            tan_number: req.body.tan_number,
            pan_number: req.body.pan_number,
            address: req.body.address,
            city: req.body.city,
            state: req.body.state,
            country: req.body.country,
            currency: req.body.currency,
            website: req.body.website,
            facebook_url: req.body.facebook_url,
            linkindin_url: req.body.linkindin_url,
            twitter_url: req.body.twitter_url,
            instagram_url: req.body.instagram_url,
            youtube_url: req.body.youtube_url,
            approval: req.body.approval,
            logo: logo,
            // water_mark: water_mark,
          };
        } else {
          data = {
            organization_name: req.body.organization_name,
            company_ref_id: req.body.company_ref_id,
            user_name: req.body.user_name,
            password: req.body.password,
            sub_domain: req.body.sub_domain,
            sub_domain_database_name: req.body.sub_domain_database_name,
            phone_number: req.body.phone_number,
            gst_number: req.body.gst_number,
            cin_number: req.body.cin_number,
            tan_number: req.body.tan_number,
            pan_number: req.body.pan_number,
            address: req.body.address,
            city: req.body.city,
            state: req.body.state,
            country: req.body.country,
            currency: req.body.currency,
            website: req.body.website,
            facebook_url: req.body.facebook_url,
            linkindin_url: req.body.linkindin_url,
            twitter_url: req.body.twitter_url,
            instagram_url: req.body.instagram_url,
            youtube_url: req.body.youtube_url,
            approval: req.body.approval,
          };
        }
        let orgId = req.params.id
        console.log('orgIdddd', orgId);

        console.log('companyRefId', companyId);
        const num = await db2['organization'].update(data, {
          where: { company_ref_id: id },
        });
        const num1 = await db['organization'].update(data, {
          where: { id: id },
        });
        if (num == 1 && num1 == 1) {

          // let orgID = data.dataValues.id;

          if (req.files.water_mark) {
            const currentPath = path.join(process.cwd(), "uploads", req.files.water_mark[0]["filename"]);
            const destinationPath = path.join(process.cwd(), "uploads/organization/water_mark/" + `${orgId}`, water_mark);
            const baseUrl = process.cwd() + '/uploads/organization/water_mark/' + `${orgId}`
            fs.mkdirSync(baseUrl, { recursive: true })
            fs.rename(currentPath, destinationPath, function (err) {
              if (err) {
                throw err
              } else {
                console.log("Successfully moved the water_mark image!")
              }
            });
          }

          if (req.files.logo) {
            const currentPath = path.join(process.cwd(), "uploads", req.files.logo[0]["filename"]);
            const destinationPath = path.join(process.cwd(), "uploads/organization/logo/" + `${orgId}`, logo);

            const baseUrl = process.cwd() + '/uploads/organization/logo/' + `${orgId}`
            fs.mkdirSync(baseUrl, { recursive: true })
            fs.rename(currentPath, destinationPath, function (err) {
              if (err) {
                throw err
              } else {
                console.log("Successfully Logo Uploaded !")
              }
            });
          }
          const data1 = {
            email: req.body.email,
            password: req.body.password,
            // org_id: orgId,
          };

          const num = await db2['user'].update(data1, {
            where: { id: orgId },
          });

          // var condition12 = {
          //   where:{
          //     status:1
          //   },
          //   order: [['id', 'DESC']],
          //   attributes: {exclude: ['createdAt','updatedAt','created_by','deleted_by']},
          //   include: [
          //     {
          //       model: db2["user"],
          //       attributes: ["email"],
          //       where: {},
          //       as:"user",
          //       required: false,
          //     },
          //     {
          //       model: db["city"],
          //       attributes: ['id',"name"],
          //       where: {},
          //       as:"city_name",
          //       required: false,
          //     },
          //     {
          //       model: db["state"],
          //       attributes: ['id',"name"],
          //       where: {},
          //       as:"state_name",
          //       required: false,
          //     },
          //     {
          //       model: db["country"],
          //       attributes: ['id',"name"],
          //       where: {},
          //       as:"country_name",
          //       required: false,
          //     },
          //     {
          //       model: db["currency"],
          //       attributes: ['id',"name"],
          //       where: {},
          //       as:"currency_name",
          //       required: false,
          //     },
          //   ]
          //   };

          // const orgData = await db[req.params.document].findAll(condition12)


          res.status(200).send({
            status: 200,
            message: "Updated successfully.",
            output: data,
          });
        } else {
          res.status(200).send({
            status: 404,
            message: `Cannot update with id : ${id}.`
          });
        }
      })
    }
  }
  catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};