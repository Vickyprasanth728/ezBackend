const db = require("../../models");
const db2 = require("../orgModel/orgIndex.js");
const Op = db.Sequelize.Op;
var Sequelize = require('sequelize');

exports.create = async (req, res) => {
    try {
        const created_by = req.user.id
        console.log('created_by', created_by.id);

        const organ_id = req.user.id
        const org_id = organ_id.org_id
        console.log('organ_id', org_id);

        const translationData = await db2['translations'].findOne({
            // where: {
            //     lang: `${req.body.lang}`,
            //     lang_key: `${req.body.lang_key}`,
            //     lang_value: `${req.body.lang_value}`
            // },
            where: {
                status:1,
                [Op.and]: [
                  { lang:req.body.lang },
                  { lang_key:req.body.lang_key },
                //   { lang_value:req.body.lang_value }
                ]
              },
            attributes: ['lang','lang_key','lang_value']
        });
        console.log("translationData", translationData);
        const executives = translationData?.dataValues ? translationData?.dataValues.id : 0

        if (executives !== 0) {
            res.status(200).send({
                status:400,
                message: "Language key & Language value already exists.",
            });
        } else {
            const data = await db2['translations'].create({
                lang: req.body.lang,
                lang_key: req.body.lang_key,
                lang_value: req.body.lang_value,
                status: req.body.status,
                created_by: created_by.id
            });
            res.status(200).send({
                status: 200,
                output: data
            });
        }
    } catch (error) {
        res.status(500).send({
            message: error.message,
        });
    }
};
exports.findAll = async (req, res) => {
    try {
        var condition = {
            where: {
                status: {
                    [Op.ne]: 0
                  },
            },
            order: [['id', 'DESC']], // ASC, DESC
            attributes:['id','lang','lang_key','lang_value'],
        };
        var offset = parseInt(req.query.offset);
        var limit = parseInt(req.query.limit);

        if (offset >= 0 && limit >= 0) {
            condition.offset = offset;
            condition.limit = limit;
        }

        const data = await db2['translations'].findAll(condition);
        res.status(200).send({
            status: 200,
            message:'success',
            output: data
        });
    } catch (error) {
        res.status(500).send({
            message: error.message,
        });
    }
};
exports.findOne = async (req, res) => {
    try {
        var condition = {
            where: {
            },
        };
        const id = req.params.id;
        const data = await db2['translations'].findByPk(id, condition);
        if (data) {
            res.status(200).send({
                status: 200,
                output: data
            });
        } else {
            res.status(404).send({
                status:404,
                message: `Cannot find with id : ${id}.`
            });
        }
    } catch (error) {
        res.status(500).send({
            message: error.message,
        });
    }
};
exports.update = async (req, res) => {
    try {
        const id = req.params.id;
        const TransID = await db2['translations'].findOne({
            where: { id: id },
            attributes: ['id','lang','lang_value', 'lang_key']
            // attributes:['id']
        });
        const LangID = TransID?.dataValues ? TransID?.dataValues.id : 0
        console.log("LangID", LangID);

        const LangCheck = await db2['translations'].findOne({
            // where: {
            //     id: {
            //         [Op.ne]: LangID
            //     },
            //     lang_key: `${req.body.lang_key}`,
            //     lang_value: `${req.body.lang_value}`,
            // },
            where: {
                status:1,
                id: {
                    [Op.ne]: LangID
                },
                [Op.and]: [
                  { lang:req.body.lang },
                  { lang_key:req.body.lang_key },
                //   { lang_value:req.body.lang_value }
                ]
              },
            attributes: ['lang','lang_value', 'lang_key']
        });

        const FinalData = LangCheck?.dataValues ? LangCheck?.dataValues.id : 0

        if (FinalData !== 0) {
            res.status(200).send({
                status:400,
                message: "Language & Translation Already Exists.",
            });
        } else {
            const num = await db2['translations'].update(req.body, {
                where: { id: id },
            });
            if (num == 1) {
                res.status(200).send({
                    status:200,
                    message: "Updated successfully.",
                    output: TransID
                });
            } else {
                res.status(200).send({
                    status:404,
                    message: `Cannot update with id : ${id}.`,
                });
            }
        }
    }
    catch (error) {
        res.status(500).send({
            message: error.message,
        });
    }
};
exports.delete = async (req, res) => {
    const CountryData = {
        status: 0,
    }
    try {
        const id = req.params.id;
        const num = await db2['translations'].update(CountryData, {
            where: { id: id },
        });
        if (num == 1) {
            res.status(200).send({
                status:200,
                message: "Deleted successfully!"
            });
        } else {
            res.status(200).send({
                status:404,
                message: `Cannot delete with id=${id}.`
            });
        }
    } catch (error) {
        res.status(500).send({
            message: error.message,
        });
    }
};
exports.deleteAll = async (req, res) => {
    try {
        const num = await db2['translations'].destroy({
            where: {},
            truncate: false,
        });
        res.status(200).send({
            message: `${num} has been deleted.`,
        });
    } catch (error) {
        res.status(500).send({
            message: error.message,
        });
    }
};

exports.translationSession = async (req, res) => {
    try {
        const lang = req.params.lang;
        console.log("lang", lang);
        const data = await db2['translations'].findAll({
            where: {
                status:1,
                lang: lang,
              },
              attributes:['id','lang','lang_key','lang_value','status']
        });
        console.log("data", data);

        if (data) {
            res.status(200).send({
                status: 200,
                output: data
            });
        } else {
            res.status(404).send({
                status:404,
                message: `Cannot find with id : ${lang}.`
            });
        }
    } catch (error) {
        res.status(500).send({
            message: error.message,
        });
    }
};

exports.findAllCheck = async (req, res) => {
    try {
        let thisQuery = `SELECT * FROM lz_translations `
        const data = await db.sequelize.query(thisQuery);

        res.status(200).send({
            status: 200,
            output: data[0]
        });
    } catch (error) {
        res.status(500).send({
            message: error.message,
        });
    }
};