const db2 = require("../orgModel/orgIndex.js");
const Op = db2.Sequelize.Op;

// exports.saveContactSettings = async (req, res) => {
//   try {
//     const created_by = req.user.id
//     console.log('created_by', created_by.id);

//     const organ_id = req.user.id
//     const org_id = organ_id.org_id
//     console.log('organ_id', org_id);

//     const id = req.params.id;

//     const CSCheck = await db2['contactSettings'].findOne({
//         where: {
//             status:1,
//             [Op.and]: [
//               {project_id:req.body.project_id},
//               {source_id:req.body.source_id},
//             ]
//           },
//         attributes: ['id','project_id','source_id']
//     });

//     const FinalData = CSCheck?.dataValues ? CSCheck?.dataValues.id : 0

//     if (FinalData !== 0) {
//         res.status(200).send({
//             status:400,
//             message: "Same Project & Source already exists.",
//         });
//     } else {
        
//     const data = await db2['contactSettings'].create({
//       org_id: org_id,
//       project_id: req.body.project_id,
//       source_id: req.body.source_id,
//       created_by: created_by.id
//     });

//     let contactSettingId = data?.dataValues.id

//     const orderSort = req.body.user_id
//     console.log("orderSort", orderSort);

//     const mergeOrder = Object.keys(orderSort).length === 0 ? '' : orderSort.join(',')
//     function getWordCount(str) {
//       return str.trim().split(',').length;
//     }
//     count = getWordCount(mergeOrder);
//     var newArray = mergeOrder.split(",");
//     for (i = 0; i < count; i++) {
//         const data1 = await db2['contactSettingMembers'].create({
//             contact_setting_id: contactSettingId,
//             user_id:  newArray[i],
//             sorting_order: i + 1,
//         });
//     }

//     const dataID = data?.dataValues.id
//     console.log('dataID', dataID);

//     res.status(200).send({
//       status:200,
//       message:'Success',
//       output:data
//     });

//   }} catch (error) {
//     res.status(500).send({
//       message: error.message,
//     });
//   }
// };

exports.saveContactSettings = async (req, res) => {
  try {
    const created_by = req.user.id
    console.log('created_by', created_by.id);

    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    const id = req.params.id;

    const CSCheck = await db2['contactSettings'].findOne({
        where: {
            status:1,
            [Op.and]: [
              {project_id:req.body.project_id},
              {source_id:req.body.source_id},
            ]
          },
        attributes: ['id','project_id','source_id']
    });

    const FinalData = CSCheck?.dataValues ? CSCheck?.dataValues.id : 0

    let thisQueryPC = ` SELECT cs.* FROM lz_contact_settings as cs WHERE cs.source_id =  ${req.body.source_id} `
    const rData = await db2.sequelize.query(thisQueryPC)
    const reqData = rData[0].map(item => item.project_id)

    const setData = [`${req.body.project_id}`]

    console.log('ReqData', reqData);
    console.log('SetData', setData);

    const valuesA = reqData.map(item => item.split(',')).flat();
    const valuesB = setData.map(item => item.split(',')).flat();
    
    // Find common values
    const commonValues = valuesA.filter(value => valuesB.includes(value));
    
    console.log('commonValues',commonValues);

    const Check = commonValues.length
    console.log('commonValues', Check);

    if (Check !== 0) {
        res.status(200).send({
            status:400,
            message: "Same Project & Source already exists.",
        });
    } else {
        
    const data = await db2['contactSettings'].create({
      org_id: org_id,
      project_id: req.body.project_id,
      source_id: req.body.source_id,
      created_by: created_by.id
    });

    let contactSettingId = data?.dataValues.id

    const orderSort = req.body.user_id
    console.log("orderSort", orderSort);

    const mergeOrder = Object.keys(orderSort).length === 0 ? '' : orderSort.join(',')
    function getWordCount(str) {
      return str.trim().split(',').length;
    }
    count = getWordCount(mergeOrder);
    var newArray = mergeOrder.split(",");
    for (i = 0; i < count; i++) {
        const data1 = await db2['contactSettingMembers'].create({
            contact_setting_id: contactSettingId,
            user_id:  newArray[i],
            sorting_order: i + 1,
        });
    }

    const dataID = data?.dataValues.id
    console.log('dataID', dataID);

    res.status(200).send({
      status:200,
      message:'Success',
      output:data
    });

  }} catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.getContactSettings = async (req, res) => {
  try {
    
  const organ_id = req.user.id
  const org_id = organ_id.org_id
  console.log('organ_id', org_id);
  
  let thisQuery = ` SELECT cs.*, GROUP_CONCAT(DISTINCT CONCAT(pa.name_of_building)) as property_name, so.option_value as source_name, 
  (SELECT group_concat(lz_contact_setting_members.user_id order by sorting_order asc) FROM lz_contact_setting_members where contact_setting_id = cs.id order by sorting_order asc) as user_id, 
  (SELECT group_concat(concat(us.first_name,' ',IFNULL(us.last_name, '') ,'-',us.id) order by sorting_order asc) FROM lz_contact_setting_members as csm LEFT JOIN lz_user as us on (us.id = csm.user_id) where us.status = 1 and contact_setting_id = cs.id order by sorting_order asc) as user_name 
  FROM lz_contact_settings as cs

  LEFT JOIN lz_property_addresses as pa on FIND_IN_SET(pa.property_id,cs.project_id)>0
  LEFT JOIN lz_masters as so on (so.id = cs.source_id)
  WHERE cs.status = 1
  GROUP BY cs.id
  ORDER by cs.id desc
  `
  const data = await db2.sequelize.query(thisQuery);
   
    res.status(200).send({
      status:200,
      message:'Success',
      output:data[0]
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.editContactSettings = async (req, res) => {
try {
  const organ_id = req.user.id
  const org_id = organ_id.org_id
  console.log('organ_id', org_id);

  const id = req.params.id;
  let thisQuery = ` SELECT cs.*, GROUP_CONCAT(DISTINCT CONCAT(pa.name_of_building)) as property_name, so.option_value as source_name, 
  (SELECT group_concat(lz_contact_setting_members.user_id order by sorting_order asc) FROM lz_contact_setting_members where contact_setting_id = cs.id order by sorting_order asc) as user_id, 
  (SELECT group_concat(concat(us.first_name,' ',IFNULL(us.last_name, '') ,'-',us.id) order by sorting_order asc) FROM lz_contact_setting_members as csm LEFT JOIN lz_user as us on (us.id = csm.user_id) where us.status = 1 and contact_setting_id = cs.id order by sorting_order asc) as user_name 
  FROM lz_contact_settings as cs

  LEFT JOIN lz_property_addresses as pa on FIND_IN_SET(pa.property_id,cs.project_id)>0
  LEFT JOIN lz_masters as so on (so.id = cs.source_id)
  WHERE cs.status = 1 and cs.id = ${id}
  `
  const data = await db2.sequelize.query(thisQuery);
  if (data) {
    res.status(200).send({
      status:200,
      message:'Success',
      output:data[0][0]
      });
  } else {
    res.status(200).send({
      status:404,
      message: `Cannot find with id : ${id}.`
    });
  }
} catch (error) {
  res.status(500).send({
    message: error.message,
  });
}
};
exports.updateContactSettings = async (req, res) => {
  try {
    const id = req.params.id;

    const created_by = req.user.id
    console.log('created_by', created_by.id);

    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    const conID = await db2['contactSettings'].findOne({
        where: { id: id },
        attributes:['id','project_id','source_id']
        // attributes:['id']
    });
    const conSet = conID?.dataValues ? conID?.dataValues.id : 0
    console.log("conSet", conSet);

    const CSCheck = await db2['contactSettings'].findOne({
        where: {
            status:1,
            id: {
                [Op.ne]: conSet
            },
            [Op.and]: [
              {project_id:req.body.project_id},
              {source_id:req.body.source_id},
            ]
          },
        attributes: ['id','project_id','source_id']
    });

    const FinalData = CSCheck?.dataValues ? CSCheck?.dataValues.id : 0

    let thisQueryPC = ` SELECT cs.* FROM lz_contact_settings as cs WHERE cs.status = 1 and id !=${conSet} and cs.source_id =  ${req.body.source_id} `
    const rData = await db2.sequelize.query(thisQueryPC)
    const reqData = rData[0].map(item => item.project_id)

    const setData = [`${req.body.project_id}`]

    console.log('ReqData', reqData);
    console.log('SetData', setData);

    const valuesA = reqData.map(item => item.split(',')).flat();
    const valuesB = setData.map(item => item.split(',')).flat();
    
    // Find common values
    const commonValues = valuesA.filter(value => valuesB.includes(value));
    
    console.log('commonValues',commonValues);

    const Check = commonValues.length
    console.log('commonValues', Check);

    if (Check !== 0) {
        res.status(200).send({
            status:400,
            message: "Same Project & Source already exists.",
        });
    } else {
        
    let contactSettingId = req.params.id

    const num1 = await db2['contactSettingMembers'].destroy({
      where: {contact_setting_id: id },
    });

    const orderSort = req.body.user_id
    console.log("orderSort", orderSort);

    const mergeOrder = Object.keys(orderSort).length === 0 ? '' : orderSort.join(',')
    function getWordCount(str) {
      return str.trim().split(',').length;
    }
    count = getWordCount(mergeOrder);
    var newArray = mergeOrder.split(",");
    for (i = 0; i < count; i++) {
        const data1 = await db2['contactSettingMembers'].create({
            contact_setting_id: contactSettingId,
            user_id:  newArray[i],
            sorting_order: i + 1,
        });
    }

    const num = await db2['contactSettings'].update(req.body, {
      where: {
        id: {
          [Op.ne]: 1
        }, id:id
    },
    });
    if (num == 1) {
      res.status(200).send({
        status:200,
        message: "Updated successfully."
      });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot update with id : ${id}.`
      });
    }
  } } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.deleteContactSettings = async (req, res) => {
  const contactSettingsData = {
    status: 0,
  }
  try {
    const id = req.params.id;

    console.log("id111", id);
    const num = await db2['contactSettings'].update(contactSettingsData, {
      where: {
        id: {
          [Op.ne]:1
        }, id:id
    },
    });

    const num1 = await db2['contactSettingMembers'].destroy({
        where: {contact_setting_id: id },
    });

    if (num == 1) {
      res.status(200).send({
        status:200,
        message: "Deleted successfully!"
      });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot delete with id : ${id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};