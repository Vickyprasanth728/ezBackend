const jwt = require("../../helpers/jwt");

const db = require("../../models");
const db2 = require("../../zOrganizationFile/orgModel/orgIndex.js");
const Op = db.Sequelize.Op;
var Sequelize = require('sequelize');
let fetch = require('node-fetch');

const bcrypt = require("bcrypt");
const saltRounds = 10;

const path = require("path");
const fs = require("fs");


// Netty Fish Api
exports.saveNettyfish = async (req, res) => {
  const pattern = req.body.mobile.replace(/[^a-zA-Z0-9]/g, "");

  try {

    const property_IdFetch = await db2.sequelize.query(`select pa.property_id as property_id from lz_properties as p left join lz_property_addresses as pa on (p.id = pa.property_id) where p.status = 1 and pa.name_of_building ='${req.body.property_id}' limit 1`);
    const propertyId = property_IdFetch[0][0] ? property_IdFetch[0][0]["property_id"] : 0
    console.log("property_IdFetch", property_IdFetch[0][0]);
    console.log("propertyId", propertyId);

    const DuplicateFetch = await db2.sequelize.query(`select id from lz_contacts where mobile ='${req.body.mobile}' or property_id ='${propertyId}' and date(created_at) = curdate() limit 1`);
    const duplicateId = DuplicateFetch[0][0] ? DuplicateFetch[0][0]?.id : 0
    console.log("duplicateId", duplicateId);

    const CSCheck123 = await db2.sequelize.query(`select csm.sorting_order as sorting_order, csm.user_id as user_id, csm.contact_setting_id, cs.project_id as project_id, cs.source_id as source_id 
      from lz_contact_setting_members as csm 
      left join lz_contact_settings as cs on (cs.id = csm.contact_setting_id) 
      where (cs.project_id = ${propertyId} and cs.source_id = 362)
      group by csm.id
       `);

    const checkOut = CSCheck123[0].length
    console.log("checkOut", checkOut);


    const autoAssignFetch = await db2.sequelize.query(`select last_assign_to,position from lz_auto_assign where project_id ='${propertyId}' and source_id ='362' order by id desc limit 1`);
    const assignToId = autoAssignFetch[0][0] ? autoAssignFetch[0][0]["last_assign_to"] : 0
    let positionId = ((autoAssignFetch[0][0]?.position ?? 0) + 1) <= checkOut ? (autoAssignFetch[0][0]?.position ?? 0) + 1 : autoAssignFetch[0][0]?.position - checkOut + 1

    console.log("assignToId", assignToId);
    console.log("positionId", positionId);

    if (autoAssignFetch) {

      const CSCheck = await db2.sequelize.query(`select csm.sorting_order as sorting_order, csm.user_id as user_id, csm.contact_setting_id, cs.project_id as project_id, cs.source_id as source_id 
      from lz_contact_setting_members as csm 
      left join lz_contact_settings as cs on (cs.id = csm.contact_setting_id) 
      where cs.project_id = ${propertyId} and cs.source_id = 362 ${!positionId ? `` : `and csm.sorting_order = ${positionId}`}
      limit 1 `);

      // const conSetCheck = CSCheck[0][0] ? CSCheck[0][0]["user_id"] : 0
      // console.log("CSCheckkkkk", CSCheck[0]);

      var assign_to = CSCheck[0][0] ? CSCheck[0][0]["user_id"] : 0
      var position_id = CSCheck[0][0] ? CSCheck[0][0]["sorting_order"] : 0

      console.log("aaaaaaaaa", assign_to);
      console.log("ppppppppp", position_id);
    }

    const limit24Check = await db2.sequelize.query(`select id as id, property_id as property_id, mobile as mobile from lz_contacts where property_id ='${propertyId}' and source ='362' and mobile ='${pattern}' and (DATE(created_at) = DATE(NOW())) order by id desc limit 1`);

    console.log("limit24Checkkkkkk", limit24Check);
    const check24Limit = limit24Check[0][0]
    console.log("check24Limit", check24Limit);

    if (check24Limit) {
      res.status(200).send({
        status: 400,
        message: 'Cannot add twice a day',
        output: []
      });
    } else {

    const data = await db2['contacts'].create({
      org_id: req.body.org_id ?? null,
      property_id: req.body.property_id,
      first_name: req.body.first_name,
      email: req.body.email,
      mobile: pattern ?? req.body.mobile,
      source: 362,
      contact_status: 2,
      assign_to: assign_to,
      created_by: req.body.created_by ?? null
    });

    let contactId = data?.dataValues.id
    let projectId = data?.dataValues.property_id

    const data1 = await db2['contactAddress'].create({
      contact_id: contactId,
      country: req.body.country,
      state: req.body.state,
      city: req.body.city,
      locality: req.body.locality,
    });
    const data12 = await db2['contactDetails'].create({
      contact_id: contactId,
    });

    const data5 = await db2['tasks'].create({
      contact: contactId,
      project: projectId,
      task_time: req.body.task_time,
      finish_time: req.body.finish_time,
      assign_to: assign_to,
      task_status : 156
    });

    console.log("data", data);

    let contactSettingId = data?.dataValues.id
    let contactCreatedBy = data?.dataValues.created_by
    let contactOrgId = data?.dataValues.org_id
    let sourceData = data?.dataValues.source
    let taskID = data5?.dataValues.id

    const TasksNotes = await db2['notes'].create({
      org_id: contactOrgId ?? '',
      reply: "budget" +'-'+req.body.budget ?? '',
      parent_id: "0",
      module_id: contactSettingId,
      module_name: "1",
      user_id: contactCreatedBy ?? '',
      created_by: contactCreatedBy ?? ''
    })

    if (propertyId > 0) {
      const updateAutoAssignTable = await db2.sequelize.query(`INSERT INTO lz_auto_assign (project_id, source_id, last_assign_to, position) VALUES (${propertyId},${sourceData},${assign_to},${position_id})`)
    }

    const contactLogs = await db2['logs'].create({
      org_id: req.body.org_id ?? 0,
      module_id: contactSettingId,
      module_name: "1",
      note: "Contact created at",
      user_id: req.body.created_by ?? 0
    })
    const taskLogs = await db2['logs'].create({
      org_id: req.body.org_id ?? 0,
      module_id: taskID,
      module_name: "4",
      note: "Task created at",
      user_id: req.body.created_by ?? 0
    })

    console.log("contactLogss", contactLogs);

    const getUserPhoneNumber = await db2.sequelize.query(`SELECT p_phone_number FROM lz_user where id IN (${assign_to}) `);
    const getUserMobile = getUserPhoneNumber[0]?.map(item => item.p_phone_number).join(', ') ?? 0 ;
    if(getUserMobile) {
      var contactName = req.body.first_name || 'Customer'
      var contactNumber = req.body.mobile
      var projectName = req.body.property_id
      var email = req.body.email
      var toNumber = getUserMobile
      whatsAppMessageNettyFish(contactName,contactNumber,projectName,email,toNumber)
    console.log('toNumber',toNumber);
    }
    console.log('getUserMobile', getUserMobile);

    res.status(200).send({
      status: 200,
      message: 'Success',
      output: data
    });

  }} catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
async function whatsAppMessageNettyFish(contactName, contactNumber, projectName, email, toNumber) {
  var phoneNumber = toNumber ?? 0;
  var templateValue = {
    name: "listez",
    language: { code: "en" },
    components: [{ 
      type: "body", parameters: 
      [
        {type: "text", text: contactName},
        {type: "text", text: contactNumber}, 
        {type: "text", text: projectName}, 
        {type: "text", text: email}, 
        {type: "text", text: "Netty Fish"}
      ] 
    }]
  }
  var params = {
    messaging_product: 'whatsapp',
    to: phoneNumber,
    type: 'template',
    template: templateValue
  };
  // console.log(params);
  try {
    console.log("formmmmmmm");
    const response = await fetch('https://graph.facebook.com/v15.0/102284452719874/messages', {
      method: 'post',
      body: JSON.stringify(params),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer EAAGZCewXTNRQBOZCZCZBO9CAL9T4GS8H43pkZAyABZAmnqJ7f3iZCY5xL3fdXco7xfLyffIs7gfowZCIaH6RSyYGbBhFQx2yfqCg2KZBcWd23tswK5lZAGRjtFq7Na9XAZBvmF3h3WOO6HB0WtfyC22U3cYMOOi20nzchoJrZCZBjgeWBVMDroSxYJbTcNIFsT98cbSbB2iabOFy8PnuGN5Bz'}
        // EAAGZCewXTNRQBALKUKrKx81d1T4qFxZAqRqZAt4tHFq6EHOZBZCzMw0MzFT3ZBjY1w3R0vmNUicTIbsYC7sQuSUcKtWeBskGk5BbazOKUn6vU1YESJ0trGPBge2UyQCprUkjVHMxkaKUUp2FNuctK8aRNJ0b1gYo8bt9YTAK14bW7wNvXUPMFckW6k91CEA8JzCanZCS1RsRAZDZD
    });
    const data = await response.json();
    console.log('data',data);
    // res.send(data)
  } catch (error) {
    console.log('error', error)
    // res.send(e)
  }
};


// Google PPC Api
exports.saveGooglePpc = async (req, res) => {
  const pattern = req.body.mobile.replace(/[^a-zA-Z0-9]/g, "");
  try {

    const property_IdFetch = await db2.sequelize.query(`select pa.property_id as property_id from lz_properties as p left join lz_property_addresses as pa on (p.id = pa.property_id) where p.status = 1 and pa.name_of_building ='${req.body.property_id}' limit 1`);
    const propertyId = property_IdFetch[0][0] ? property_IdFetch[0][0]["property_id"] : 0
    console.log("property_IdFetch", property_IdFetch[0][0]);
    console.log("propertyId", propertyId);

    const DuplicateFetch = await db2.sequelize.query(`select id from lz_contacts where mobile ='${req.body.mobile}' or property_id ='${propertyId}' and date(created_at) = curdate() limit 1`);
    const duplicateId = DuplicateFetch[0][0] ? DuplicateFetch[0][0]['id'] : 0
    console.log("duplicateId", duplicateId);

    const CSCheck123 = await db2.sequelize.query(`select csm.sorting_order as sorting_order, csm.user_id as user_id, csm.contact_setting_id, cs.project_id as project_id, cs.source_id as source_id 
      from lz_contact_setting_members as csm 
      left join lz_contact_settings as cs on (cs.id = csm.contact_setting_id) 
      where (cs.project_id = ${propertyId} and cs.source_id = 76)
      group by csm.id
       `);

    const checkOut = CSCheck123[0].length
    console.log("checkOut", checkOut);


    const autoAssignFetch = await db2.sequelize.query(`select last_assign_to,position from lz_auto_assign where project_id ='${propertyId}' and source_id ='76' order by id desc limit 1`);
    const assignToId = autoAssignFetch[0][0] ? autoAssignFetch[0][0]["last_assign_to"] : 0
    let positionId = ((autoAssignFetch[0][0]?.position ?? 0) + 1) <= checkOut ? (autoAssignFetch[0][0]?.position ?? 0) + 1 : autoAssignFetch[0][0]?.position - checkOut + 1

    console.log("assignToId", assignToId);
    console.log("positionId", positionId);

    if (autoAssignFetch) {

      const CSCheck = await db2.sequelize.query(`select csm.sorting_order as sorting_order, csm.user_id as user_id, csm.contact_setting_id, cs.project_id as project_id, cs.source_id as source_id 
      from lz_contact_setting_members as csm 
      left join lz_contact_settings as cs on (cs.id = csm.contact_setting_id) 
      where cs.project_id = ${propertyId} and cs.source_id = 76 ${!positionId ? `` : `and csm.sorting_order = ${positionId}`}
      limit 1 `);

      const conSetCheck = CSCheck[0][0] ? CSCheck[0][0]["user_id"] : 0
      console.log("CSCheckkkkk", CSCheck[0]);

      var assign_to = CSCheck[0][0] ? CSCheck[0][0]["user_id"] : 0
      var position_id = CSCheck[0][0] ? CSCheck[0][0]["sorting_order"] : 0

      console.log("aaaaaaaaa", assign_to);
      console.log("ppppppppp", position_id);
    }

    const limit24Check = await db2.sequelize.query(`select id as id, property_id as property_id, mobile as mobile from lz_contacts where property_id ='${propertyId}' and source ='76' and mobile ='${pattern}' and (DATE(created_at) = DATE(NOW())) order by id desc limit 1`);

    console.log("limit24Checkkkkkk", limit24Check);
    const check24Limit = limit24Check[0][0]
    console.log("check24Limit", check24Limit);

    if (check24Limit) {
      res.status(200).send({
        status: 400,
        message: 'Cannot add twice a day',
        output: []
      });
    } else {

    const data = await db2['contacts'].create({
      org_id: req.body.org_id ?? null,
      property_id: req.body.property_id,
      first_name: req.body.first_name,
      email: req.body.email,
      mobile: pattern ?? req.body.mobile,
      source: 76,
      contact_status: 2,
      assign_to: assign_to,
      created_by: req.body.created_by ?? null
    });

    let contactId = data?.dataValues.id
    let projectId = data?.dataValues.property_id

    const data1 = await db2['contactAddress'].create({
      contact_id: contactId,
      country: req.body.country,
      state: req.body.state,
      city: req.body.city,
      locality: req.body.locality,
    });
    const data12 = await db2['contactDetails'].create({
      contact_id: contactId,
    });

    // const data3 = await db2['leads'].create({
    //   org_id: req.body.org_id ?? null ,
    //   contact_id: contactId,
    //   property_id: projectId,
    //   assign_to: assign_to,
    //   lead_status : 52
    // });
    // let leadId = data3?.dataValues.id

    // const data4 = await db2['leadRequirement'].create({
    //   lead_id: leadId,
    //   budget_min: req.body.budget_min,
    //   budget_max: req.body.budget_max
    // });

    const data5 = await db2['tasks'].create({
      contact: contactId,
      project: projectId,
      task_time: req.body.task_time,
      finish_time: req.body.finish_time,
      assign_to: assign_to,
      task_status : 156
    });

    console.log("data", data);

    let contactSettingId = data?.dataValues.id
    let contactCreatedBy = data?.dataValues.created_by
    let contactOrgId = data?.dataValues.org_id
    let sourceData = data?.dataValues.source
    let taskID = data5?.dataValues.id

    const TasksNotes = await db2['notes'].create({
      org_id: contactOrgId ?? '',
      reply: "budget" +'-'+req.body.budget ?? '',
      parent_id: "0",
      module_id: contactSettingId,
      module_name: "1",
      user_id: contactCreatedBy ?? '',
      created_by: contactCreatedBy ?? ''
    })

    if (propertyId > 0) {
      const updateAutoAssignTable = await db2.sequelize.query(`INSERT INTO lz_auto_assign (project_id, source_id, last_assign_to, position) VALUES (${propertyId},${sourceData},${assign_to},${position_id})`)
    }

    const contactLogs = await db2['logs'].create({
      org_id: req.body.org_id ?? 0,
      module_id: contactSettingId,
      module_name: "1",
      note: "Contact created at",
      user_id: req.body.created_by ?? 0
    })
    const taskLogs = await db2['logs'].create({
      org_id: req.body.org_id ?? 0,
      module_id: taskID,
      module_name: "4",
      note: "Task created at",
      user_id: req.body.created_by ?? 0
    })

    console.log("contactLogss", contactLogs);

    const getUserPhoneNumber = await db2.sequelize.query(`SELECT p_phone_number FROM lz_user where id IN (${assign_to}) `);
    const getUserMobile = getUserPhoneNumber[0]?.map(item => item.p_phone_number).join(', ') ?? 0 ;
    if(getUserMobile) {
      var contactName = req.body.first_name || 'Customer'
      var contactNumber = req.body.mobile
      var projectName = req.body.property_id
      var email = req.body.email
      var toNumber = getUserMobile
      whatsAppMessageGooglePPC(contactName,contactNumber,projectName,email,toNumber)
    console.log('toNumber',toNumber);
    }
    console.log('getUserMobile', getUserMobile);

    res.status(200).send({
      status: 200,
      message: 'Success',
      output: data
    });

  }} catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
async function whatsAppMessageGooglePPC(contactName, contactNumber, projectName, email, toNumber) {
  var phoneNumber = toNumber ?? 0;
  var templateValue = {
    name: "listez",
    language: { code: "en" },
    components: [{ 
      type: "body", parameters: 
      [
        {type: "text", text: contactName},
        {type: "text", text: contactNumber}, 
        {type: "text", text: projectName}, 
        {type: "text", text: email}, 
        {type: "text", text: "Google ppc"}
      ] 
    }]
  }
  var params = {
    messaging_product: 'whatsapp',
    to: phoneNumber,
    type: 'template',
    template: templateValue
  };
  // console.log(params);
  try {
    console.log("formmmmmmm");
    const response = await fetch('https://graph.facebook.com/v15.0/102284452719874/messages', {
      method: 'post',
      body: JSON.stringify(params),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer EAAGZCewXTNRQBOZCZCZBO9CAL9T4GS8H43pkZAyABZAmnqJ7f3iZCY5xL3fdXco7xfLyffIs7gfowZCIaH6RSyYGbBhFQx2yfqCg2KZBcWd23tswK5lZAGRjtFq7Na9XAZBvmF3h3WOO6HB0WtfyC22U3cYMOOi20nzchoJrZCZBjgeWBVMDroSxYJbTcNIFsT98cbSbB2iabOFy8PnuGN5Bz'}
        // EAAGZCewXTNRQBALKUKrKx81d1T4qFxZAqRqZAt4tHFq6EHOZBZCzMw0MzFT3ZBjY1w3R0vmNUicTIbsYC7sQuSUcKtWeBskGk5BbazOKUn6vU1YESJ0trGPBge2UyQCprUkjVHMxkaKUUp2FNuctK8aRNJ0b1gYo8bt9YTAK14bW7wNvXUPMFckW6k91CEA8JzCanZCS1RsRAZDZD
    });
    const data = await response.json();
    console.log('data',data);
    // res.send(data)
  } catch (error) {
    console.log('error', error)
    // res.send(e)
  }
};


// Roof & Floor
exports.saveRoofFloor = async (req, res) => {
  const pattern = req.body.mobile.replace(/[^a-zA-Z0-9]/g, "");
  try {
    // const created_id = req.user.id
    // const created_by = created_id.id
    // console.log('created_by', created_by);

    // const organ_id = req.user.id
    // const org_id = organ_id.org_id
    // console.log('organ_id', org_id);

    // const role = req.user.id
    // const role_id = role.designation
    // console.log('role_id', role_id);

    // const id = req.params.id;


    const property_IdFetch = await db2.sequelize.query(`select pa.property_id as property_id from lz_properties as p left join lz_property_addresses as pa on (p.id = pa.property_id) where p.status = 1 and pa.name_of_building ='${req.body.property_id}' limit 1`);
    const propertyId = property_IdFetch[0][0] ? property_IdFetch[0][0]["property_id"] : 0
    console.log("property_IdFetch", property_IdFetch[0][0]);
    console.log("propertyId", propertyId);

    const DuplicateFetch = await db2.sequelize.query(`select id from lz_contacts where mobile ='${req.body.mobile}' or property_id ='${propertyId}' and date(created_at) = curdate() limit 1`);
    const duplicateId = DuplicateFetch[0][0] ? DuplicateFetch[0][0]['id'] : 0
    console.log("duplicateId", duplicateId);

    const CSCheck123 = await db2.sequelize.query(`select csm.sorting_order as sorting_order, csm.user_id as user_id, csm.contact_setting_id, cs.project_id as project_id, cs.source_id as source_id 
      from lz_contact_setting_members as csm 
      left join lz_contact_settings as cs on (cs.id = csm.contact_setting_id) 
      where (cs.project_id = ${propertyId} and cs.source_id = 353)
      group by csm.id
       `);

    const checkOut = CSCheck123[0].length
    console.log("checkOut", checkOut);


    const autoAssignFetch = await db2.sequelize.query(`select last_assign_to,position from lz_auto_assign where project_id ='${propertyId}' and source_id ='353' order by id desc limit 1`);
    const assignToId = autoAssignFetch[0][0] ? autoAssignFetch[0][0]["last_assign_to"] : 0
    let positionId = ((autoAssignFetch[0][0]?.position ?? 0) + 1) <= checkOut ? (autoAssignFetch[0][0]?.position ?? 0) + 1 : autoAssignFetch[0][0]?.position - checkOut + 1

    console.log("assignToId", assignToId);
    console.log("positionId", positionId);

    if (autoAssignFetch) {

      const CSCheck = await db2.sequelize.query(`select csm.sorting_order as sorting_order, csm.user_id as user_id, csm.contact_setting_id, cs.project_id as project_id, cs.source_id as source_id 
      from lz_contact_setting_members as csm 
      left join lz_contact_settings as cs on (cs.id = csm.contact_setting_id) 
      where cs.project_id = ${propertyId} and cs.source_id = 353 ${!positionId ? `` : `and csm.sorting_order = ${positionId}`}
      limit 1
       `);

      const conSetCheck = CSCheck[0][0] ? CSCheck[0][0]["user_id"] : 0
      console.log("CSCheckkkkk", CSCheck[0]);

      var assign_to = CSCheck[0][0] ? CSCheck[0][0]["user_id"] : 0
      var position_id = CSCheck[0][0] ? CSCheck[0][0]["sorting_order"] : 0

    }

    const limit24Check = await db2.sequelize.query(`select id as id, property_id as property_id, mobile as mobile from lz_contacts where property_id ='${propertyId}' and source ='353' and mobile ='${pattern}' and (DATE(created_at) = DATE(NOW())) order by id desc limit 1`);

    console.log("limit24Checkkkkkk", limit24Check);
    const check24Limit = limit24Check[0][0]
    console.log("check24Limit", check24Limit);

    if (check24Limit) {
      res.status(200).send({
        status: 400,
        message: 'Cannot add twice a day with same mobile no & property',
        output: []
      });
    }
    else {
    const data = await db2['contacts'].create({
      org_id: req.body.org_id ?? null,
      property_id: propertyId,
      first_name: req.body.first_name,
      email: req.body.email,
      mobile: pattern ?? req.body.mobile,
      source: 353,
      contact_status: 2,
      assign_to: assign_to,
      created_by: req.body.created_by ?? null
    });

    let contactId = data?.dataValues.id
    let projectId = data?.dataValues.property_id

    const data1 = await db2['contactAddress'].create({
      contact_id: contactId,
      country: req.body.country,
      state: req.body.state,
      city: req.body.city,
      locality: req.body.locality,
    });

    const data12 = await db2['contactDetails'].create({
      contact_id: contactId,
    });

    // const data3 = await db2['leads'].create({
    //   org_id: req.body.org_id ?? null ,
    //   contact_id: contactId,
    //   property_id: projectId,
    //   assign_to: assign_to,
    //   lead_status : 52
    // });
    // let leadId = data3?.dataValues.id

    // const data4 = await db2['leadRequirement'].create({
    //   lead_id: leadId,
    //   budget_min: req.body.budget_min,
    //   budget_max: req.body.budget_max
    // });

    const data5 = await db2['tasks'].create({
      contact: contactId,
      project: projectId,
      task_time: req.body.task_time,
      finish_time: req.body.finish_time,
      assign_to: assign_to,
      task_status : 156
    });

    console.log("data", data);

    let contactSettingId = data?.dataValues.id
    let contactCreatedBy = data?.dataValues.created_by
    let contactOrgId = data?.dataValues.org_id
    let sourceData = data?.dataValues.source
    let taskID = data5?.dataValues.id

    const TasksNotes = await db2['notes'].create({
      org_id: contactOrgId ?? '',
      reply: "budget" +'-'+req.body.budget ?? '',
      parent_id: "0",
      module_id: contactSettingId,
      module_name: "1",
      user_id: contactCreatedBy ?? '',
      created_by: contactCreatedBy ?? ''
    })


    if (propertyId > 0) {
      const updateAutoAssignTable = await db2.sequelize.query(`INSERT INTO lz_auto_assign (project_id, source_id, last_assign_to, position) VALUES (${propertyId},${sourceData},${assign_to},${position_id})`)
    }

    const contactLogs = await db2['logs'].create({
      org_id: req.body.org_id ?? 0,
      module_id: contactSettingId,
      module_name: "1",
      note: "Contact created at",
      user_id: req.body.created_by ?? 0
    })
    console.log("contactLogs", contactLogs);

    const taskLogs = await db2['logs'].create({
      org_id: req.body.org_id ?? 0,
      module_id: taskID,
      module_name: "4",
      note: "Task created at",
      user_id: req.body.created_by ?? 0
    })
    console.log("taskLogs", taskLogs);

    const getUserPhoneNumber = await db2.sequelize.query(`SELECT p_phone_number FROM lz_user where id IN (${assign_to}) `);
    const getUserMobile = getUserPhoneNumber[0]?.map(item => item.p_phone_number).join(', ') ?? 0 ;
    if(getUserMobile) {
      var contactName = req.body.first_name || 'Customer'
      var contactNumber = req.body.mobile
      var projectName = req.body.property_id
      var email = req.body.email
      var toNumber = getUserMobile
      whatsAppMessageFloor(contactName,contactNumber,projectName,email,toNumber)
    console.log('toNumber',toNumber);
    }
    console.log('getUserMobile', getUserMobile);

    res.status(200).send({
      status: 200,
      message: 'Success',
      output: data
    });

  }} catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
async function whatsAppMessageFloor(contactName, contactNumber, projectName, email, toNumber) {
  var phoneNumber = toNumber ?? 0;
  var templateValue = {
    name: "listez",
    language: { code: "en" },
    components: [{ 
      type: "body", parameters: 
      [
        {type: "text", text: contactName},
        {type: "text", text: contactNumber}, 
        {type: "text", text: projectName}, 
        {type: "text", text: email}, 
        {type: "text", text: "Roof & Floor"}
      ] 
    }]
  }
  var params = {
    messaging_product: 'whatsapp',
    to: phoneNumber,
    type: 'template',
    template: templateValue
  };
  // console.log(params);
  try {
    console.log("formmmmmmm");
    const response = await fetch('https://graph.facebook.com/v15.0/102284452719874/messages', {
      method: 'post',
      body: JSON.stringify(params),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer EAAGZCewXTNRQBOZCZCZBO9CAL9T4GS8H43pkZAyABZAmnqJ7f3iZCY5xL3fdXco7xfLyffIs7gfowZCIaH6RSyYGbBhFQx2yfqCg2KZBcWd23tswK5lZAGRjtFq7Na9XAZBvmF3h3WOO6HB0WtfyC22U3cYMOOi20nzchoJrZCZBjgeWBVMDroSxYJbTcNIFsT98cbSbB2iabOFy8PnuGN5Bz'}
        // EAAGZCewXTNRQBALKUKrKx81d1T4qFxZAqRqZAt4tHFq6EHOZBZCzMw0MzFT3ZBjY1w3R0vmNUicTIbsYC7sQuSUcKtWeBskGk5BbazOKUn6vU1YESJ0trGPBge2UyQCprUkjVHMxkaKUUp2FNuctK8aRNJ0b1gYo8bt9YTAK14bW7wNvXUPMFckW6k91CEA8JzCanZCS1RsRAZDZD
    });
    const data = await response.json();
    console.log('data',data);
    // res.send(data)
  } catch (error) {
    console.log('error', error)
    // res.send(e)
  }
};


// save Housing Api
exports.saveHousingApi = async (req, res) => {
  const pattern = req.body.mobile.replace(/[^a-zA-Z0-9]/g, "");
  try {
    // const created_id = req.user.id
    // const created_by = created_id.id
    // console.log('created_by', created_by);

    // const organ_id = req.user.id
    // const org_id = organ_id.org_id
    // console.log('organ_id', org_id);

    // const role = req.user.id
    // const role_id = role.designation
    // console.log('role_id', role_id);

    // const id = req.params.id;

    const property_IdFetch = await db2.sequelize.query(`select pa.property_id as property_id from lz_properties as p left join lz_property_addresses as pa on (p.id = pa.property_id) where p.status = 1 and pa.name_of_building ='${req.body.property_id}' limit 1`);
    const propertyId = property_IdFetch[0][0] ? property_IdFetch[0][0]["property_id"] : 0
    console.log("property_IdFetch", property_IdFetch[0][0]);
    console.log("propertyId", propertyId);

    const DuplicateFetch = await db2.sequelize.query(`select id from lz_contacts where mobile ='${req.body.mobile}' or property_id ='${propertyId}' and date(created_at) = curdate() limit 1`);
    const duplicateId = DuplicateFetch[0][0] ? DuplicateFetch[0][0]['id'] : 0
    console.log("duplicateId", duplicateId);

    const CSCheck123 = await db2.sequelize.query(`select csm.sorting_order as sorting_order, csm.user_id as user_id, csm.contact_setting_id, cs.project_id as project_id, cs.source_id as source_id 
      from lz_contact_setting_members as csm 
      left join lz_contact_settings as cs on (cs.id = csm.contact_setting_id) 
      where (cs.project_id = ${propertyId} and cs.source_id = 74)
      group by csm.id
       `);

    const checkOut = CSCheck123[0].length
    console.log("checkOut", checkOut);


    const autoAssignFetch = await db2.sequelize.query(`select last_assign_to,position from lz_auto_assign where project_id ='${propertyId}' and source_id ='74' order by id desc limit 1`);
    const assignToId = autoAssignFetch[0][0] ? autoAssignFetch[0][0]["last_assign_to"] : 0
    let positionId = ((autoAssignFetch[0][0]?.position ?? 0) + 1) <= checkOut ? (autoAssignFetch[0][0]?.position ?? 0) + 1 : autoAssignFetch[0][0]?.position - checkOut + 1

    console.log("assignToId", assignToId);
    console.log("positionId", positionId);

    if (autoAssignFetch) {

      const CSCheck = await db2.sequelize.query(`select csm.sorting_order as sorting_order, csm.user_id as user_id, csm.contact_setting_id, cs.project_id as project_id, cs.source_id as source_id 
      from lz_contact_setting_members as csm 
      left join lz_contact_settings as cs on (cs.id = csm.contact_setting_id) 
      where cs.project_id = ${propertyId} and cs.source_id = 74 ${!positionId ? `` : `and csm.sorting_order = ${positionId}`}
      limit 1
       `);

      const conSetCheck = CSCheck[0][0] ? CSCheck[0][0]["user_id"] : 0
      console.log("CSCheckkkkk", CSCheck[0]);

      var assign_to = CSCheck[0][0] ? CSCheck[0][0]["user_id"] : 0
      var position_id = CSCheck[0][0] ? CSCheck[0][0]["sorting_order"] : 0

      console.log("aaaaaaaaa", assign_to);
      console.log("ppppppppp", position_id);
    }

    const limit24Check = await db2.sequelize.query(`select id as id, property_id as property_id, mobile as mobile from lz_contacts where property_id ='${propertyId}' and source ='74' and mobile ='${pattern}' and (DATE(created_at) = DATE(NOW())) order by id desc limit 1`);

    console.log("limit24Checkkkkkk", limit24Check);
    const check24Limit = limit24Check[0][0]
    console.log("check24Limit", check24Limit);

    if (check24Limit) {
      res.status(200).send({
        status: 400,
        message: 'Cannot add twice a day',
        output: []
      });
    } else {

    const data = await db2['contacts'].create({
      org_id: req.body.org_id ?? null,
      property_id: propertyId,
      first_name: req.body.first_name,
      email: req.body.email,
      mobile: pattern ?? req.body.mobile,
      source: 74,
      contact_status: 2,
      assign_to: assign_to,
      created_by: req.bodycreated_by ?? null
    });

    let contactId = data?.dataValues.id
    let projectId = data?.dataValues.property_id

    const data1 = await db2['contactAddress'].create({
      contact_id: contactId,
      country: req.body.country,
      state: req.body.state,
      city: req.body.city,
      locality: req.body.locality,
    });
    const data12 = await db2['contactDetails'].create({
      contact_id: contactId,
    });

    // const data3 = await db2['leads'].create({
    //   org_id: req.body.org_id ?? null ,
    //   contact_id: contactId,
    //   property_id: projectId,
    //   assign_to: assign_to,
    //   lead_status : 52
    // });
    // let leadId = data3?.dataValues.id

    // const data4 = await db2['leadRequirement'].create({
    //   lead_id: leadId,
    //   budget_min: req.body.budget_min,
    //   budget_max: req.body.budget_max
    // });

    const data5 = await db2['tasks'].create({
      contact: contactId,
      project: projectId,
      task_time: req.body.task_time,
      finish_time: req.body.finish_time,
      assign_to: assign_to,
      task_status : 156
    });

    console.log("data", data);

    let contactSettingId = data?.dataValues.id
    let contactCreatedBy = data?.dataValues.created_by
    let contactOrgId = data?.dataValues.org_id
    let sourceData = data?.dataValues.source
    let taskID = data5?.dataValues.id

    const TasksNotes = await db2['notes'].create({
      org_id: contactOrgId ?? '',
      reply: "budget" +'-'+req.body.budget ?? '',
      parent_id: "0",
      module_id: contactSettingId,
      module_name: "1",
      user_id: contactCreatedBy ?? '',
      created_by: contactCreatedBy ?? ''
    })

    if (propertyId > 0) {
      const updateAutoAssignTable = await db2.sequelize.query(`INSERT INTO lz_auto_assign (project_id, source_id, last_assign_to, position) VALUES (${propertyId},${sourceData},${assign_to},${position_id})`)
    }

    const contactLogs = await db2['logs'].create({
      org_id: req.body.org_id ?? 0,
      module_id: contactSettingId,
      module_name: "1",
      note: "Contact created at",
      user_id: req.body.created_by ?? 0
    })
    const taskLogs = await db2['logs'].create({
      org_id: req.body.org_id ?? 0,
      module_id: taskID,
      module_name: "4",
      note: "Task created at",
      user_id: req.body.created_by ?? 0
    })

    console.log("contactLogss", contactLogs);
    
    const getUserPhoneNumber = await db2.sequelize.query(`SELECT p_phone_number FROM lz_user where id IN (${assign_to}) `);
    const getUserMobile = getUserPhoneNumber[0]?.map(item => item.p_phone_number).join(', ') ?? 0 ;
    if(getUserMobile) {
      var contactName = req.body.first_name || 'Customer'
      var contactNumber = req.body.mobile
      var projectName = req.body.property_id
      var email = req.body.email
      var toNumber = getUserMobile
      whatsAppMessageHousing(contactName,contactNumber,projectName,email,toNumber)
    console.log('toNumber',toNumber);
    }
    console.log('getUserMobile', getUserMobile);

    res.status(200).send({
      status: 200,
      message: 'Success',
      output: data
    });

  }} catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
async function whatsAppMessageHousing(contactName, contactNumber, projectName, email, toNumber) {
  var phoneNumber = toNumber ?? 0;
  var templateValue = {
    name: "listez",
    language: { code: "en" },
    components: [{ 
      type: "body", parameters: 
      [
        {type: "text", text: contactName},
        {type: "text", text: contactNumber}, 
        {type: "text", text: projectName}, 
        {type: "text", text: email}, 
        {type: "text", text: "Housing.com"}
      ] 
    }]
  }
  var params = {
    messaging_product: 'whatsapp',
    to: phoneNumber,
    type: 'template',
    template: templateValue
  };
  // console.log(params);
  try {
    console.log("formmmmmmm");
    const response = await fetch('https://graph.facebook.com/v15.0/102284452719874/messages', {
      method: 'post',
      body: JSON.stringify(params),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer EAAGZCewXTNRQBOZCZCZBO9CAL9T4GS8H43pkZAyABZAmnqJ7f3iZCY5xL3fdXco7xfLyffIs7gfowZCIaH6RSyYGbBhFQx2yfqCg2KZBcWd23tswK5lZAGRjtFq7Na9XAZBvmF3h3WOO6HB0WtfyC22U3cYMOOi20nzchoJrZCZBjgeWBVMDroSxYJbTcNIFsT98cbSbB2iabOFy8PnuGN5Bz'}
        // EAAGZCewXTNRQBALKUKrKx81d1T4qFxZAqRqZAt4tHFq6EHOZBZCzMw0MzFT3ZBjY1w3R0vmNUicTIbsYC7sQuSUcKtWeBskGk5BbazOKUn6vU1YESJ0trGPBge2UyQCprUkjVHMxkaKUUp2FNuctK8aRNJ0b1gYo8bt9YTAK14bW7wNvXUPMFckW6k91CEA8JzCanZCS1RsRAZDZD
    });
    const data = await response.json();
    console.log('data',data);
    // res.send(data)
  } catch (error) {
    console.log('error', error)
    // res.send(e)
  }
};


// Magic Bricks Api
exports.saveMagicBricks = async (req, res) => {
  const pattern = req.body.mobile.replace(/[^a-zA-Z0-9]/g, "");
  try {

    const property_IdFetch = await db2.sequelize.query(`select pa.property_id as property_id from lz_properties as p left join lz_property_addresses as pa on (p.id = pa.property_id) where p.status = 1 and pa.name_of_building ='${req.body.property_id}' limit 1`);
    const propertyId = property_IdFetch[0][0] ? property_IdFetch[0][0]["property_id"] : 0
    console.log("property_IdFetch", property_IdFetch[0][0]);
    console.log("property_Id", propertyId);

    const DuplicateFetch = await db2.sequelize.query(`select id from lz_contacts where mobile ='${req.body.mobile}' or property_id ='${propertyId}' and date(created_at) = curdate() limit 1`);
    const duplicateId = DuplicateFetch[0][0] ? DuplicateFetch[0][0]['id'] : 0
    console.log("duplicateId", duplicateId);

    const CSCheck123 = await db2.sequelize.query(`select csm.sorting_order as sorting_order, csm.user_id as user_id, csm.contact_setting_id, cs.project_id as project_id, cs.source_id as source_id 
      from lz_contact_setting_members as csm 
      left join lz_contact_settings as cs on (cs.id = csm.contact_setting_id) 
      where (cs.project_id = ${propertyId} and cs.source_id = 73)
      group by csm.id
       `);

    const checkOut = CSCheck123[0].length
    console.log("checkOut", checkOut);


    const autoAssignFetch = await db2.sequelize.query(`select last_assign_to,position from lz_auto_assign where project_id ='${propertyId}' and source_id ='73' order by id desc limit 1`);
    const assignToId = autoAssignFetch[0][0] ? autoAssignFetch[0][0]["last_assign_to"] : 0
    let positionId = ((autoAssignFetch[0][0]?.position ?? 0) + 1) <= checkOut ? (autoAssignFetch[0][0]?.position ?? 0) + 1 : autoAssignFetch[0][0]?.position - checkOut + 1

    console.log("assignToId", assignToId);
    console.log("positionId", positionId);

    if (autoAssignFetch) {

      const CSCheck = await db2.sequelize.query(`select csm.sorting_order as sorting_order, csm.user_id as user_id, csm.contact_setting_id, cs.project_id as project_id, cs.source_id as source_id 
      from lz_contact_setting_members as csm 
      left join lz_contact_settings as cs on (cs.id = csm.contact_setting_id) 
      where cs.project_id = ${propertyId} and cs.source_id = 73 ${!positionId ? `` : `and csm.sorting_order = ${positionId}`}
      limit 1 `);

      const conSetCheck = CSCheck[0][0] ? CSCheck[0][0]["user_id"] : 0
      console.log("CSCheckkkkk", CSCheck[0]);

      var assign_to = CSCheck[0][0] ? CSCheck[0][0]["user_id"] : 0
      var position_id = CSCheck[0][0] ? CSCheck[0][0]["sorting_order"] : 0

      console.log("aaaaaaaaa", assign_to);
      console.log("ppppppppp", position_id);
    }

    const limit24Check = await db2.sequelize.query(`select id as id, property_id as property_id, mobile as mobile from lz_contacts where property_id ='${propertyId}' and source ='73' and mobile ='${pattern}' and (DATE(created_at) = DATE(NOW())) order by id desc limit 1`);
    

    console.log("limit24Checkkkkkk", limit24Check);
    const check24Limit = limit24Check[0][0]
    console.log("check24Limit", check24Limit);

    if (check24Limit) {
      res.status(200).send({
        status: 400,
        message: 'Cannot add twice a day',
        output: []
      });
    } else {

    const data = await db2['contacts'].create({
      org_id: req.body.org_id ?? null,
      property_id: propertyId,
      first_name: req.body.first_name,
      email: req.body.email,
      mobile: pattern ?? req.body.mobile,
      source: 73,
      contact_status: 2,
      assign_to: assign_to,
      created_by: req.bodycreated_by ?? null
    });

    let contactId = data?.dataValues.id
    let projectId = data?.dataValues.property_id

    const data1 = await db2['contactAddress'].create({
      contact_id: contactId,
      country: req.body.country,
      state: req.body.state,
      city: req.body.city,
      locality: req.body.locality,
    });
    const data12 = await db2['contactDetails'].create({
      contact_id: contactId,
    });

    // const data3 = await db2['leads'].create({
    //   org_id: req.body.org_id ?? null ,
    //   contact_id: contactId,
    //   property_id: projectId,
    //   assign_to: assign_to,
    //   lead_status : 52
    // });
    // let leadId = data3?.dataValues.id

    // const data4 = await db2['leadRequirement'].create({
    //   lead_id: leadId,
    //   budget_min: req.body.budget_min,
    //   budget_max: req.body.budget_max
    // });

    const data5 = await db2['tasks'].create({
      contact: contactId,
      project: projectId,
      task_time: req.body.task_time,
      finish_time: req.body.finish_time,
      assign_to: assign_to,
      task_status : 156
    });

    console.log("data", data);

    let contactSettingId = data?.dataValues.id
    let contactCreatedBy = data?.dataValues.created_by
    let contactOrgId = data?.dataValues.org_id
    let sourceData = data?.dataValues.source
    let taskID = data5?.dataValues.id

    const TasksNotes = await db2['notes'].create({
      org_id: contactOrgId ?? '',
      reply: "budget" +'-'+req.body.budget ?? '',
      parent_id: "0",
      module_id: contactSettingId,
      module_name: "1",
      user_id: contactCreatedBy ?? '',
      created_by: contactCreatedBy ?? ''
    })

    if (propertyId > 0) {
      const updateAutoAssignTable = await db2.sequelize.query(`INSERT INTO lz_auto_assign (project_id, source_id, last_assign_to, position) VALUES (${propertyId},${sourceData},${assign_to},${position_id})`)
    }

    const contactLogs = await db2['logs'].create({
      org_id: req.body.org_id ?? 0,
      module_id: contactSettingId,
      module_name: "1",
      note: "Contact created at",
      user_id: req.body.created_by ?? 0
    })
    const taskLogs = await db2['logs'].create({
      org_id: req.body.org_id ?? 0,
      module_id: taskID,
      module_name: "4",
      note: "Task created at",
      user_id: req.body.created_by ?? 1
    })

    console.log("contactLogss", contactLogs);

    const getUserPhoneNumber = await db2.sequelize.query(`SELECT p_phone_number FROM lz_user where id IN (${assign_to}) `);
    const getUserMobile = getUserPhoneNumber[0]?.map(item => item.p_phone_number).join(', ') ?? 0 ;
    if(getUserMobile) {
      var contactName = req.body.first_name || 'Customer'
      var contactNumber = req.body.mobile
      var projectName = req.body.property_id
      var email = req.body.email
      var toNumber = getUserMobile
      whatsAppMessageMagicbricks(contactName,contactNumber,projectName,email,toNumber)
    console.log('toNumber',toNumber);
    }

    res.status(200).send({
      status: 200,
      message: 'Success',
      output: data
    });

  }} catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
async function whatsAppMessageMagicbricks(contactName, contactNumber, projectName, email, toNumber) {
  var phoneNumber = toNumber ?? 0;
  var templateValue = {
    name: "listez",
    language: { code: "en" },
    components: [{ 
      type: "body", parameters: 
      [
        {type: "text", text: contactName},
        {type: "text", text:contactNumber}, 
        {type: "text", text: projectName}, 
        {type: "text", text: email}, 
        {type: "text", text: "MagicBricks"}
      ] 
    }]
  }
  var params = {
    messaging_product: 'whatsapp',
    to: phoneNumber,
    type: 'template',
    template: templateValue
  };
  // console.log(params);
  try {
    console.log("formmmmmmm");
    const response = await fetch('https://graph.facebook.com/v15.0/102284452719874/messages', {
      method: 'post',
      body: JSON.stringify(params),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer EAAGZCewXTNRQBOZCZCZBO9CAL9T4GS8H43pkZAyABZAmnqJ7f3iZCY5xL3fdXco7xfLyffIs7gfowZCIaH6RSyYGbBhFQx2yfqCg2KZBcWd23tswK5lZAGRjtFq7Na9XAZBvmF3h3WOO6HB0WtfyC22U3cYMOOi20nzchoJrZCZBjgeWBVMDroSxYJbTcNIFsT98cbSbB2iabOFy8PnuGN5Bz'}
        // EAAGZCewXTNRQBALKUKrKx81d1T4qFxZAqRqZAt4tHFq6EHOZBZCzMw0MzFT3ZBjY1w3R0vmNUicTIbsYC7sQuSUcKtWeBskGk5BbazOKUn6vU1YESJ0trGPBge2UyQCprUkjVHMxkaKUUp2FNuctK8aRNJ0b1gYo8bt9YTAK14bW7wNvXUPMFckW6k91CEA8JzCanZCS1RsRAZDZD
    });
    const data = await response.json();
    console.log('data',data);
    // res.send(data)
  } catch (error) {
    console.log('error', error)
    // res.send(e)
  }
}


// FaceBook
exports.saveFaceBook = async (req, res) => {
  const pattern = req.body.phone.replace(/[^0-9]/g, "");

  const backUpSave = await db2.sequelize.query(`INSERT INTO lz_backup (data) VALUES ('${JSON.stringify(req.body)}') `);
  console.log("backUpSave", backUpSave);
  var condition = {
    where:{status:1},
    order: [['id', 'DESC']],
    attributes:['id','option_type','option_value']
  };

  const data34 = await db2['businessSettings'].findAll(condition);
  // console.log('Business Settings', data34);

  const obj = data34.reduce((acc, { option_type, option_value }) => {
    acc[option_type] = option_value;
    return acc;
    }, {});

    console.log('objjjjjjjjjjjj', obj);
  
  if(req.body.phone) {
    try {
  
      const propertyIdFetch = await db2.sequelize.query(`select property_id from lz_property_addresses where property_id = '${req.body.project}' limit 1`);
      const propertyId = propertyIdFetch[0][0] ? propertyIdFetch[0][0]?.property_id : 0
      console.log("propertyyyy", propertyId);
  
      const property_IdFetch = await db2.sequelize.query(`select pa.property_id as property_id from lz_properties as p left join lz_property_addresses as pa on (p.id = pa.property_id) where p.status = 1 and pa.name_of_building ='${req.body.project}' limit 1`);
      const property_Id = property_IdFetch[0][0] ? property_IdFetch[0][0]["property_id"] : 0
      console.log("property_IdFetch", property_IdFetch[0][0]);
      console.log("property_Id", property_Id);
  
      const DuplicateFetch = await db2.sequelize.query(`select id from lz_contacts where mobile ='${req.body.phone}' or property_id ='${property_Id}' and date(created_at) = curdate() limit 1`);
      const duplicateId = DuplicateFetch[0][0] ? DuplicateFetch[0][0]['id'] : 0
      console.log("duplicateId", duplicateId);
  
      const CSCheck123 = await db2.sequelize.query(`select csm.sorting_order as sorting_order, csm.user_id as user_id, csm.contact_setting_id, cs.project_id as project_id, cs.source_id as source_id 
        from lz_contact_setting_members as csm 
        left join lz_contact_settings as cs on (cs.id = csm.contact_setting_id) 
        where cs.status = 1 and (CONCAT(',', cs.project_id, ',') REGEXP ',(${property_Id}),' and cs.source_id = 68)
        group by csm.id
         `);
  
      const checkOut = CSCheck123[0].length
      console.log("checkOut", checkOut);
  
  
      const autoAssignFetch = await db2.sequelize.query(`select last_assign_to,position from lz_auto_assign where project_id ='${property_Id}' and source_id ='68' order by id desc limit 1`);
      const assignToId = autoAssignFetch[0][0] ? autoAssignFetch[0][0]["last_assign_to"] : 0
      let positionId = ((autoAssignFetch[0][0]?.position ?? 0) + 1) <= checkOut ? (autoAssignFetch[0][0]?.position ?? 0) + 1 : autoAssignFetch[0][0]?.position - checkOut + 1
  
      console.log("assignToId", assignToId);
      console.log("positionId", positionId);
  
      if (autoAssignFetch) {
  
        const CSCheck = await db2.sequelize.query(`select csm.sorting_order as sorting_order, csm.user_id as user_id, csm.contact_setting_id, cs.project_id as project_id, cs.source_id as source_id 
        from lz_contact_setting_members as csm 
        left join lz_contact_settings as cs on (cs.id = csm.contact_setting_id) 
        where cs.status = 1 and CONCAT(',', cs.project_id, ',') REGEXP ',(${property_Id}),' and cs.source_id = 68 ${!positionId ? `` : `and csm.sorting_order = ${positionId}`}
        limit 1 `);
  
        const conSetCheck = CSCheck[0][0] ? CSCheck[0][0]["user_id"] : 0
        console.log("CSCheckkkkk", CSCheck[0]);
  
        var assign_to = CSCheck[0][0] ? CSCheck[0][0]["user_id"] : 1
        var position_id = CSCheck[0][0] ? CSCheck[0][0]["sorting_order"] : 0
  
        console.log("aaaaaaaaa", assign_to);
        console.log("ppppppppp", position_id);
      }
  
      const limit24Check = await db2.sequelize.query(`select id as id, property_id as property_id, mobile as mobile from lz_contacts where status = 1 and property_id ='${property_Id}' and source ='68' and mobile ='${pattern}' and (DATE(created_at) = DATE(NOW())) order by id desc limit 1`);
  
      console.log("limit24Checkkkkkk", limit24Check);
      const check24Limit = limit24Check[0][0] ?? 0
      console.log("check24Limit", check24Limit);
      
  
      if (check24Limit) {
        res.status(200).send({
          status: 400,
          message: 'Cannot add twice a day',
          output: []
        });
      } else {
  
      const data = await db2['contacts'].create({
        org_id: req.body.org_id ?? null,
        property_id: property_Id,
        first_name: req.body.first_name,
        email: req.body.email,
        mobile: pattern ?? req.body.phone,
        source: 68,
        contact_status: 2,
        assign_to: assign_to,
        created_by: req.body.created_by ?? 1
      });
  
      let contactId = data?.dataValues.id
      let projectId = data?.dataValues.property_id
  
      const data1 = await db2['contactAddress'].create({
        contact_id: contactId,
        country: req.body.country,
        state: req.body.state,
        city: req.body.city,
        locality: req.body.locality,
      });
      const data12 = await db2['contactDetails'].create({
        contact_id: contactId,
      });
  
      // const data5 = await db2['tasks'].create({
      //   contact: contactId,
      //   project: projectId,
      //   task_time: req.body.task_time,
      //   finish_time: req.body.finish_time,
      //   assign_to: assign_to,
      //   task_status : 156
      // });
  
      console.log("data", data);
  
      let contactSettingId = data?.dataValues.id
      let contactCreatedBy = data?.dataValues.created_by
      let contactOrgId = data?.dataValues.org_id
      let sourceData = data?.dataValues.source
      // let taskID = data5?.dataValues.id
  
      const TasksNotes = await db2['notes'].create({
        org_id: contactOrgId ?? '',
        reply: req.body.notes ?? '',
        parent_id: "0",
        module_id: contactSettingId,
        module_name: "1",
        user_id: 1 ?? '',
        created_by: 1 ?? ''
      })
  
      if (property_Id > 0) {
        const updateAutoAssignTable = await db2.sequelize.query(`INSERT INTO lz_auto_assign (project_id, source_id, last_assign_to, position) VALUES (${property_Id},${sourceData},${assign_to},${position_id})`)
      }
  
      const contactLogs = await db2['logs'].create({
        org_id: req.body.org_id ?? 0,
        module_id: contactSettingId,
        module_name: "1",
        note: "Contact created at",
        user_id: req.body.created_by ?? 1
      })
      // const taskLogs = await db2['logs'].create({
      //   org_id: req.body.org_id ?? 0,
      //   module_id: taskID,
      //   module_name: "4",
      //   note: "Task created at",
      //   user_id: req.body.created_by ?? 0
      // })
  
      console.log("contactLogss", contactLogs);
  
      // const backUpSave = await db2.sequelize.query(`INSERT INTO lz_backup (data) VALUES ('${JSON.stringify(req.body)}') `);
      // console.log("backUpSave", backUpSave);
  
      // let thisQueryC = ` select `
      // const conSetCheck =  await db2.sequelize.query(thisQueryC)
  
      console.log("assign_tooooooo", assign_to);
  
        const getUserPhoneNumber = await db2.sequelize.query(`SELECT p_phone_number FROM lz_user where id IN (${assign_to}) `);
        const getUserMobile = getUserPhoneNumber[0]?.map(item => item.p_phone_number).join(', ') ?? 0 ;
        if(getUserMobile) {
          var contactName = req.body.first_name || 'Customer'
          var contactNumber = req.body.phone
          var projectName = req.body.project
          var email = req.body.email
          var toNumber = getUserMobile
          whatsAppMessageFacebook(contactName,contactNumber,projectName,email,toNumber, obj)
        console.log('toNumber',toNumber);
        }
        console.log('getUserMobile', getUserMobile);
  
      res.status(200).send({
        status: 200,
        message: 'Success',
        output: data
      });
  
    }} catch (error) {
      res.status(500).send({
        message: error.message,
      });
    }
  }
  else {
    res.status(400).send({
      message: 'Mobile number is required'
    });
  }
}; 
async function whatsAppMessageFacebook(contactName, contactNumber, projectName, email, toNumber, obj) {
  var phoneNumber = toNumber ?? 0;
  if (obj?.whatsapp_status == 1) {

  var templateValue = {
    name: "lead_notification_template",
    language: { code: "en" },
    components: [{ 
      type: "body", parameters: 
      [
        {type: "text", text: contactName},
        // {type: "text", text: contactNumber}, 
        {type: "text", text: projectName}, 
        // {type: "text", text: email}, 
        {type: "text", text: 'Facebook'}
      ] 
    }]
  }
  var params = {
    messaging_product: 'whatsapp',
    to: phoneNumber,
    type: 'template',
    template: templateValue
  };
  // console.log(params);
    // 'https://graph.facebook.com/v15.0/102284452719874/messages'
  // EAAGZCewXTNRQBOZCZCZBO9CAL9T4GS8H43pkZAyABZAmnqJ7f3iZCY5xL3fdXco7xfLyffIs7gfowZCIaH6RSyYGbBhFQx2yfqCg2KZBcWd23tswK5lZAGRjtFq7Na9XAZBvmF3h3WOO6HB0WtfyC22U3cYMOOi20nzchoJrZCZBjgeWBVMDroSxYJbTcNIFsT98cbSbB2iabOFy8PnuGN5Bz
  try {
    console.log("formmmmmmm");
    const response = await fetch(obj?.whatsapp_api, {
      method: 'post',
      body: JSON.stringify(params),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${obj?.whatsapp_token} ` }
        // EAAGZCewXTNRQBALKUKrKx81d1T4qFxZAqRqZAt4tHFq6EHOZBZCzMw0MzFT3ZBjY1w3R0vmNUicTIbsYC7sQuSUcKtWeBskGk5BbazOKUn6vU1YESJ0trGPBge2UyQCprUkjVHMxkaKUUp2FNuctK8aRNJ0b1gYo8bt9YTAK14bW7wNvXUPMFckW6k91CEA8JzCanZCS1RsRAZDZD
    });
    const data = await response.json();
    console.log('data',data);
    // res.send(data)
  } catch (error) {
    console.log('error', error)
    // res.send(e)
  }
}
else {
  console.log('WhatsApp Status - OFF Condition',)
}
}


// Live Chat
exports.saveLiveChat = async (req, res) => {
  const pattern = req.body.mobile.replace(/[^0-9]/g, "");
  const mob = parseInt(pattern.slice(-10))

  var condition = {
    where:{status:1},
    order: [['id', 'DESC']],
    attributes:['id','option_type','option_value']
  };

  const data34 = await db2['businessSettings'].findAll(condition);
  // console.log('Business Settings', data34);

  const obj = data34.reduce((acc, { option_type, option_value }) => {
    acc[option_type] = option_value;
    return acc;
    }, {});

    console.log('objjjjjjjjjjjj', obj);
  try {

    const property_IdFetch = await db2.sequelize.query(`select pa.property_id as property_id from lz_properties as p left join lz_property_addresses as pa on (p.id = pa.property_id) where p.status = 1 and pa.name_of_building ='${req.body.property_id}' limit 1`);
    const property_Id = property_IdFetch[0][0] ? property_IdFetch[0][0]["property_id"] : 0
    console.log("property_IdFetch", property_IdFetch[0][0]);
    console.log("property_Id", property_Id);
    
    const source_IdFetch = await db2.sequelize.query(`select so.id as id FROM lz_masters as so where so.option_value ='${req.body.source}' limit 1`);
    const source_Id = source_IdFetch[0][0] ? source_IdFetch[0][0]["id"] : 0
    console.log("source_IdFetch", source_IdFetch[0][0]);
    console.log("source_Id", source_Id);

    const country_IdFetch = await db2.sequelize.query(`select cou.id as id from lz_country as cou where cou.status = 1 and cou.name ='${req.body.country}' limit 1`);
    const state_IdFetch = await db2.sequelize.query(`select st.id as id from lz_state as st where st.status = 1 and st.name ='${req.body.state}' limit 1`);
    const city_IdFetch = await db2.sequelize.query(`select ci.id from lz_city as ci where ci.status = 1 and ci.name ='${req.body.city}' limit 1`);
    const country_Id = country_IdFetch[0][0] ? country_IdFetch[0][0]["id"] : 0
    const state_Id = state_IdFetch[0][0] ? state_IdFetch[0][0]["id"] : 0
    const city_Id = city_IdFetch[0][0] ? city_IdFetch[0][0]["id"] : 0
    console.log("locality", country_Id,state_Id,city_Id);

    const propertyIdFetch = await db2.sequelize.query(`select property_id from lz_property_addresses where property_id='${property_Id}' limit 1`);
    const propertyId = propertyIdFetch[0][0] ? propertyIdFetch[0][0].property_id : 0
    console.log("propertyyyy", propertyId);

    const num = `${req.body.mobile}`
    // const mob = parseInt(num.slice(-10))

    const DuplicateFetch = await db2.sequelize.query(`select id from lz_contacts where mobile ='${req.body.mobile}' or property_id ='${property_Id}' and date(created_at) = curdate() limit 1`);
    const duplicateId = DuplicateFetch[0][0] ? DuplicateFetch[0][0]['id'] : 0
    console.log("duplicateId", duplicateId);

    const CSCheck123 = await db2.sequelize.query(`select csm.sorting_order as sorting_order, csm.user_id as user_id, csm.contact_setting_id, cs.project_id as project_id, cs.source_id as source_id 
      from lz_contact_setting_members as csm 
      left join lz_contact_settings as cs on (cs.id = csm.contact_setting_id) 
      where (CONCAT(',', cs.project_id, ',') REGEXP ',(${property_Id}),' and cs.source_id = ${source_Id})
      group by csm.id
       `);

    const checkOut = CSCheck123[0].length
    console.log("checkOut", checkOut);


    const autoAssignFetch = await db2.sequelize.query(`select last_assign_to,position from lz_auto_assign where project_id ='${property_Id}' and source_id = ${source_Id} order by id desc limit 1`);
    const assignToId = autoAssignFetch[0][0] ? autoAssignFetch[0][0]["last_assign_to"] : 0
    let positionId = ((autoAssignFetch[0][0]?.position ?? 0) + 1) <= checkOut ? (autoAssignFetch[0][0]?.position ?? 0) + 1 : autoAssignFetch[0][0]?.position - checkOut + 1

    console.log("assignToId", assignToId);
    console.log("positionId", positionId);

    if (autoAssignFetch) {

      const CSCheck = await db2.sequelize.query(`select csm.sorting_order as sorting_order, csm.user_id as user_id, csm.contact_setting_id, cs.project_id as project_id, cs.source_id as source_id 
      from lz_contact_setting_members as csm 
      left join lz_contact_settings as cs on (cs.id = csm.contact_setting_id) 
      where CONCAT(',', cs.project_id, ',') REGEXP ',(${property_Id}),' and cs.source_id = ${source_Id} ${!positionId ? `` : `and csm.sorting_order = ${positionId}`}
      limit 1 `);

      const conSetCheck = CSCheck[0][0] ? CSCheck[0][0]["user_id"] : 0
      console.log("CSCheckkkkk", CSCheck[0]);

      var assign_to = CSCheck[0][0] ? CSCheck[0][0]["user_id"] : 1
      var position_id = CSCheck[0][0] ? CSCheck[0][0]["sorting_order"] : 0

      console.log("aaaaaaaaa", assign_to);
      console.log("ppppppppp", position_id);
    }

    const limit24Check = await db2.sequelize.query(`select id as id, property_id as property_id, mobile as mobile from lz_contacts where status !=0 and property_id = ${property_Id} and source = ${source_Id} and ${ `${mob.toString().length}` >= 10 ? `SUBSTR(mobile, -10) = '${mob}' ` : `mobile = '${req.body.mobile}' `} and (DATE(created_at) = DATE(NOW())) order by id desc limit 1`);

    console.log("limit24Checkkkkkk", limit24Check);
    const check24Limit = limit24Check[0][0]
    console.log("check24Limit", check24Limit);

    if (check24Limit) {
      res.status(200).send({
        status: 400,
        message: 'Cannot add twice a day',
        output: []
      });
    } else {

    const data = await db2['contacts'].create({
      org_id: req.body.org_id ?? null,
      property_id: property_Id,
      first_name: req.body.first_name,
      email: req.body.email,
      mobile: pattern ?? req.body.mobile,
      source: source_Id,
      contact_status: 2,
      assign_to: assign_to,
      created_by: req.bodycreated_by ?? null
    });

    let contactId = data?.dataValues.id
    let projectId = data?.dataValues.property_id

    const data1 = await db2['contactAddress'].create({
      contact_id: contactId,
      country: country_Id,
      state: state_Id,
      city: city_Id,
      locality: req.body.locality,
    });
    const data12 = await db2['contactDetails'].create({
      contact_id: contactId,
    });

    console.log("data", data);

    let contactSettingId = data?.dataValues.id
    let contactCreatedBy = data?.dataValues.created_by
    let contactOrgId = data?.dataValues.org_id
    let sourceData = data?.dataValues.source

    const TasksNotes = await db2['notes'].create({
      org_id: contactOrgId ?? '',
      reply: "budget" +'-'+req.body.budget ?? '',
      parent_id: "0",
      module_id: contactSettingId,
      module_name: "1",
      user_id: contactCreatedBy ?? '',
      created_by: contactCreatedBy ?? ''
    })

    if (property_Id > 0) {
      const updateAutoAssignTable = await db2.sequelize.query(`INSERT INTO lz_auto_assign (project_id, source_id, last_assign_to, position) VALUES (${property_Id},${sourceData},${assign_to},${position_id})`)
    }

    const contactLogs = await db2['logs'].create({
      org_id: req.body.org_id ?? 0,
      module_id: contactSettingId,
      module_name: "1",
      note: "Contact created at",
      user_id: req.body.created_by ?? 0
    })

    console.log("contactLogss", contactLogs);

    console.log("assign_tooooooo", assign_to);
  
    const getUserPhoneNumber = await db2.sequelize.query(`SELECT p_phone_number FROM lz_user where id IN (${assign_to}) `);
    const getUserMobile = getUserPhoneNumber[0]?.map(item => item.p_phone_number).join(', ') ?? 0 ;
    if(getUserMobile) {
      var contactName = req.body.first_name || 'Customer'
      var contactNumber = req.body.mobile
      var projectName = req.body.property_id
      var email = req.body.email
      var toNumber = getUserMobile
      var sourceName = req.body.source
      whatsAppMessageLiveChat(contactName,contactNumber,projectName,email,toNumber, sourceName, obj)
    console.log('toNumber',toNumber);
    }
    console.log('getUserMobile', getUserMobile);

    res.status(200).send({
      status: 200,
      message: 'Success',
      output: data
    });

  }} catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
async function whatsAppMessageLiveChat(contactName, contactNumber, projectName, email, toNumber, sourceName, obj) {
  var phoneNumber = toNumber ?? 0;
  if (obj?.whatsapp_status == 1) {

  var templateValue = {
    name: "lead_notification_template",
    language: { code: "en" },
    components: [{ 
      type: "body", parameters: 
      [
        {type: "text", text: contactName},
        // {type: "text", text: contactNumber}, 
        {type: "text", text: projectName}, 
        // {type: "text", text: email}, 
        {type: "text", text: sourceName}
      ] 
    }]
  }
  var params = {
    messaging_product: 'whatsapp',
    to: phoneNumber,
    type: 'template',
    template: templateValue
  };
  // console.log(params);
  // 'https://graph.facebook.com/v15.0/102284452719874/messages'
  // EAAGZCewXTNRQBOZCZCZBO9CAL9T4GS8H43pkZAyABZAmnqJ7f3iZCY5xL3fdXco7xfLyffIs7gfowZCIaH6RSyYGbBhFQx2yfqCg2KZBcWd23tswK5lZAGRjtFq7Na9XAZBvmF3h3WOO6HB0WtfyC22U3cYMOOi20nzchoJrZCZBjgeWBVMDroSxYJbTcNIFsT98cbSbB2iabOFy8PnuGN5Bz
  try {
    console.log("formmmmmmm");
    const response = await fetch(obj?.whatsapp_api, {
      method: 'post',
      body: JSON.stringify(params),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${obj?.whatsapp_token} `}
        // EAAGZCewXTNRQBALKUKrKx81d1T4qFxZAqRqZAt4tHFq6EHOZBZCzMw0MzFT3ZBjY1w3R0vmNUicTIbsYC7sQuSUcKtWeBskGk5BbazOKUn6vU1YESJ0trGPBge2UyQCprUkjVHMxkaKUUp2FNuctK8aRNJ0b1gYo8bt9YTAK14bW7wNvXUPMFckW6k91CEA8JzCanZCS1RsRAZDZD
    });
    const data = await response.json();
    console.log('data',data);
    // res.send(data)
  } catch (error) {
    console.log('error', error)
    // res.send(e)
  }
}
else {
  console.log('WhatsApp Status - OFF Condition',)
}
};



// TRAIL ++++++++++++++++++++++ >>>>>>>>>>>>>>>>>>
// Save Responder
exports.saveResponder = async (req, res) => {
  try {
    const created_id = req.user.id
    const created_by = created_id.id
    console.log('created_by', created_by);
  
    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);
    
    const role = req.user.id
    const role_id = role.designation
    console.log('role_id', role_id);

    const id = req.params.id;

    const data = await db2['contacts'].create({
      org_id: org_id,
      property_id: req.body.property_id,
      first_name: req.body.first_name,
      email: req.body.email,
      mobile: req.body.mobile,
      contact_status:2
    });

    let contactId = data?.dataValues.id
    let propertyId = data?.dataValues.property_id

    const data1 = await db2['contactAddress'].create({
      contact_id: contactId,
      country: req.body.country,
      state: req.body.state,
      city: req.body.city,
      locality: req.body.locality,
    });

    const data12 = await db2['contactDetails'].create({
      contact_id: contactId,
    });
    
    const data3 = await db2['leads'].create({
      org_id: org_id,
      contact_id: contactId,
      property_id: propertyId,
    });
    let leadId = data3?.dataValues.id

    const data4 = await db2['leadRequirement'].create({
      lead_id: leadId,
      budget_min: req.body.budget_min,
      budget_max: req.body.budget_max
    });
    const data5 = await db2['tasks'].create({
      contact: contactId,
      project: propertyId,
      task_time: req.body.task_time,
      finish_time: req.body.finish_time
    });

    console.log("data", data);

    res.status(200).send({
      status:200,
      message:'Success',
      output:data
    });

  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
// Housing.Com
exports.saveHousing = async (req, res) => {
  try {
    const created_id = req.user.id
    const created_by = created_id.id
    console.log('created_by', created_by);
  
    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);
  
    const role = req.user.id
    const role_id = role.designation
    console.log('role_id', role_id);

    const id = req.params.id;

    const propertyIdFetch = await db2.sequelize.query(`select property_id from lz_property_addresses where property_id='${req.body.property_id}' limit 1`);
    const propertyId = propertyIdFetch[0][0] ? propertyIdFetch[0][0].property_id : 0
    console.log("propertyyyy", propertyId);

    const DuplicateFetch = await db2.sequelize.query(`select id from lz_contacts where mobile ='${req.body.mobile}' or property_id ='${propertyId}' and date(created_at) = curdate() limit 1`);
    const duplicateId = DuplicateFetch[0][0] ? DuplicateFetch[0][0]['id'] : 0
    console.log("duplicateId", duplicateId);

    // if (!duplicateId) {
    //     res.status(200).send({
    //         status:400,
    //         message: "your contact has been already exists.",
    //     }); 
    // } else {

      const CSCheck123 = await db2.sequelize.query(`select csm.sorting_order as sorting_order, csm.user_id as user_id, csm.contact_setting_id, cs.project_id as project_id, cs.source_id as source_id 
      from lz_contact_setting_members as csm 
      left join lz_contact_settings as cs on (cs.id = csm.contact_setting_id) 
      where (cs.project_id = ${propertyId} and cs.source_id = 74)
      group by csm.id
       `);

      const checkOut = CSCheck123[0].length
      console.log("checkOut", checkOut);


      const autoAssignFetch = await db2.sequelize.query(`select last_assign_to,position from lz_auto_assign where project_id ='${propertyId}' and source_id ='74' order by id desc limit 1`);
      const assignToId = autoAssignFetch[0][0] ? autoAssignFetch[0][0]["last_assign_to"] : 0
      let positionId = ((autoAssignFetch[0][0]?.position ?? 0) +1) <= checkOut ? (autoAssignFetch[0][0]?.position ?? 0) +1 : autoAssignFetch[0][0]?.position - checkOut+1

      console.log("assignToId", assignToId);
      console.log("positionId", positionId);

if (autoAssignFetch) {

      const CSCheck = await db2.sequelize.query(`select csm.sorting_order as sorting_order, csm.user_id as user_id, csm.contact_setting_id, cs.project_id as project_id, cs.source_id as source_id 
      from lz_contact_setting_members as csm 
      left join lz_contact_settings as cs on (cs.id = csm.contact_setting_id) 
      where cs.project_id = ${propertyId} and cs.source_id = 74 ${!positionId ? ``:`and csm.sorting_order = ${positionId}`}
      limit 1
       `);

      const conSetCheck = CSCheck[0][0] ? CSCheck[0][0]["user_id"] : 0
      console.log("CSCheckkkkk", CSCheck[0]);
        
      var assign_to = CSCheck[0][0] ? CSCheck[0][0]["user_id"] : 0
      var position_id = CSCheck[0][0] ? CSCheck[0][0]["sorting_order"] : 0

      console.log("aaaaaaaaa", assign_to);
      console.log("ppppppppp", position_id);
}
        const data = await db2['contacts'].create({
          first_name: req.body.first_name || 'Customer',
          last_name: req.body.last_name || null,
          email: req.body.email || null,
          mobile: req.body.mobile || null,
          property_id: propertyId || null,
          source: 74,
          contact_status: 2,
          contact_type: 8,
          assign_to: assign_to,
          created_by: created_by
        });

        let contactSettingId = data?.dataValues.id
        let sourceData = data?.dataValues.source

        const data1 = await db2['contactAddress'].create({
          contact_id: contactSettingId,
        });    
        const data12 = await db2['contactDetails'].create({
          contact_id: contactSettingId,
        });


      if (propertyId > 0) {
        const updateAutoAssignTable = await db2.sequelize.query(`INSERT INTO lz_auto_assign (project_id, source_id, last_assign_to, position) VALUES (${propertyId},${sourceData},${assign_to},${position_id})`)
      }

      const contactLogs = await db2['logs'].create({
        org_id: org_id,
        module_id: contactSettingId,
        module_name: "1",
        note: "Contact created at",
        user_id: created_by
      })
      console.log("contactLogss", contactLogs);

    res.status(200).send({
      status:200,
      message:'Success',
      output:data
    });

  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
// FaceBook
exports.saveFaceBookAPI = async (req, res) => {
  try {
    const created_id = req.user.id
    const created_by = created_id.id
    console.log('created_by', created_by);

    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    const role = req.user.id
    const role_id = role.designation
    console.log('role_id', role_id);

    const id = req.params.id;

    const propertyIdFetch = await db2.sequelize.query(`select property_id from lz_property_addresses where property_id='${req.body.property_id}' limit 1`);
    const propertyId = propertyIdFetch[0][0] ? propertyIdFetch[0][0].property_id : 0
    console.log("propertyyyy", propertyId);

    const DuplicateFetch = await db2.sequelize.query(`select id from lz_contacts where mobile ='${req.body.mobile}' or property_id ='${propertyId}' and date(created_at) = curdate() limit 1`);
    const duplicateId = DuplicateFetch[0][0] ? DuplicateFetch[0][0]['id'] : 0
    console.log("duplicateId", duplicateId);

    // if (!duplicateId) {
    //     res.status(200).send({
    //         status:400,
    //         message: "your contact has been already exists.",
    //     }); 
    // } else {

    const CSCheck123 = await db2.sequelize.query(`select csm.sorting_order as sorting_order, csm.user_id as user_id, csm.contact_setting_id, cs.project_id as project_id, cs.source_id as source_id 
      from lz_contact_setting_members as csm 
      left join lz_contact_settings as cs on (cs.id = csm.contact_setting_id) 
      where (cs.project_id = ${propertyId} and cs.source_id = 68)
      group by csm.id
       `);

    const checkOut = CSCheck123[0].length
    console.log("checkOut", checkOut);


    const autoAssignFetch = await db2.sequelize.query(`select last_assign_to,position from lz_auto_assign where project_id ='${propertyId}' and source_id ='68' order by id desc limit 1`);
    const assignToId = autoAssignFetch[0][0] ? autoAssignFetch[0][0]["last_assign_to"] : 0
    let positionId = ((autoAssignFetch[0][0]?.position ?? 0) + 1) <= checkOut ? (autoAssignFetch[0][0]?.position ?? 0) + 1 : autoAssignFetch[0][0]?.position - checkOut + 1

    console.log("assignToId", assignToId);
    console.log("positionId", positionId);

    if (autoAssignFetch) {

      const CSCheck = await db2.sequelize.query(`select csm.sorting_order as sorting_order, csm.user_id as user_id, csm.contact_setting_id, cs.project_id as project_id, cs.source_id as source_id 
      from lz_contact_setting_members as csm 
      left join lz_contact_settings as cs on (cs.id = csm.contact_setting_id) 
      where cs.project_id = ${propertyId} and cs.source_id = 68 ${!positionId ? `` : `and csm.sorting_order = ${positionId}`}
      limit 1
       `);

      const conSetCheck = CSCheck[0][0] ? CSCheck[0][0]["user_id"] : 0
      console.log("CSCheckkkkk", CSCheck[0]);

      var assign_to = CSCheck[0][0] ? CSCheck[0][0]["user_id"] : 0
      var position_id = CSCheck[0][0] ? CSCheck[0][0]["sorting_order"] : 0

      console.log("aaaaaaaaa", assign_to);
      console.log("ppppppppp", position_id);
    }

      const data = await db2['contacts'].create({
        first_name: req.body.first_name || 'Customer',
        last_name: req.body.last_name || null,
        email: req.body.email || null,
        mobile: req.body.mobile || null,
        property_id: propertyId || null,
        source: 68,
        contact_status: 2,
        contact_type: 8,
        assign_to: assign_to,
        created_by: created_by
      });

      let contactSettingId = data?.dataValues.id
      let sourceData = data?.dataValues.source;

      const data1 = await db2['contactAddress'].create({
        contact_id: contactSettingId,
      });
      const data12 = await db2['contactDetails'].create({
        contact_id: contactSettingId,
      });

      if (propertyId > 0) {
        const updateAutoAssignTable = await db2.sequelize.query(`INSERT INTO lz_auto_assign (project_id, source_id, last_assign_to, position) VALUES (${propertyId},${sourceData},${assign_to},${position_id})`)
      }

      const contactLogs = await db2['logs'].create({
        org_id: org_id,
        module_id: contactSettingId,
        module_name: "1",
        note: "Contact created at",
        user_id: created_by
      })
      console.log("contactLogss", contactLogs);

      res.status(200).send({
        status: 200,
        message: 'Success',
        output: data
      });

    } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};

// Google PPC
// exports.saveGooglePpc = async (req, res) => {
//     try {
//       const created_id = req.user.id
//       const created_by = created_id.id
//       console.log('created_by', created_by);
    
//       const organ_id = req.user.id
//       const org_id = organ_id.org_id
//       console.log('organ_id', org_id);
    
//       const role = req.user.id
//       const role_id = role.designation
//       console.log('role_id', role_id);
  
//       const id = req.params.id;
  
//       const propertyIdFetch = await db2.sequelize.query(`select property_id from lz_property_addresses where property_id='${req.body.property_id}' limit 1`);
//       const propertyId = propertyIdFetch[0][0] ? propertyIdFetch[0][0].property_id : 0
//       console.log("propertyyyy", propertyId);
  
//       const DuplicateFetch = await db2.sequelize.query(`select id from lz_contacts where mobile ='${req.body.mobile}' or property_id ='${propertyId}' and date(created_at) = curdate() limit 1`);
//       const duplicateId = DuplicateFetch[0][0] ? DuplicateFetch[0][0]['id'] : 0
//       console.log("duplicateId", duplicateId);
  
//       // if (!duplicateId) {
//       //     res.status(200).send({
//       //         status:400,
//       //         message: "your contact has been already exists.",
//       //     }); 
//       // } else {
  
//         const CSCheck123 = await db2.sequelize.query(`select csm.sorting_order as sorting_order, csm.user_id as user_id, csm.contact_setting_id, cs.project_id as project_id, cs.source_id as source_id 
//         from lz_contact_setting_members as csm 
//         left join lz_contact_settings as cs on (cs.id = csm.contact_setting_id) 
//         where (cs.project_id = ${propertyId} and cs.source_id = 76)
//         group by csm.id
//          `);
  
//         const checkOut = CSCheck123[0].length
//         console.log("checkOut", checkOut);
  
  
//         const autoAssignFetch = await db2.sequelize.query(`select last_assign_to,position from lz_auto_assign where project_id ='${propertyId}' and source_id ='76' order by id desc limit 1`);
//         const assignToId = autoAssignFetch[0][0] ? autoAssignFetch[0][0]["last_assign_to"] : 0
//         let positionId = ((autoAssignFetch[0][0]?.position ?? 0) +1) <= checkOut ? (autoAssignFetch[0][0]?.position ?? 0) +1 : autoAssignFetch[0][0]?.position - checkOut+1
  
//         console.log("assignToId", assignToId);
//         console.log("positionId", positionId);
  
//   if (autoAssignFetch) {
  
//         const CSCheck = await db2.sequelize.query(`select csm.sorting_order as sorting_order, csm.user_id as user_id, csm.contact_setting_id, cs.project_id as project_id, cs.source_id as source_id 
//         from lz_contact_setting_members as csm 
//         left join lz_contact_settings as cs on (cs.id = csm.contact_setting_id) 
//         where cs.project_id = ${propertyId} and cs.source_id = 76 ${!positionId ? ``:`and csm.sorting_order = ${positionId}`}
//         limit 1
//          `);
  
//         const conSetCheck = CSCheck[0][0] ? CSCheck[0][0]["user_id"] : 0
//         console.log("CSCheckkkkk", CSCheck[0]);
          
//         var assign_to = CSCheck[0][0] ? CSCheck[0][0]["user_id"] : 0
//         var position_id = CSCheck[0][0] ? CSCheck[0][0]["sorting_order"] : 0
  
//         console.log("aaaaaaaaa", assign_to);
//         console.log("ppppppppp", position_id);
//   }
//           const data = await db2['contacts'].create({
//             first_name: req.body.first_name || 'Customer',
//             last_name: req.body.last_name || null,
//             email: req.body.email || null,
//             mobile: req.body.mobile || null,
//             property_id: propertyId || null,
//             source: 76,
//             contact_status: 2,
//             contact_type: 8,
//             assign_to: assign_to,
//             created_by: created_by
//           });
  
//         let contactSettingId = data?.dataValues.id
//         let sourceData = data?.dataValues.source

//         const data1 = await db2['contactAddress'].create({
//           contact_id: contactSettingId,
//         });    
//         const data12 = await db2['contactDetails'].create({
//           contact_id: contactSettingId,
//         });
  
//         if (propertyId > 0) {
//           const updateAutoAssignTable = await db2.sequelize.query(`INSERT INTO lz_auto_assign (project_id, source_id, last_assign_to, position) VALUES (${propertyId},${sourceData},${assign_to},${position_id})`)
//         }
  
//         const contactLogs = await db2['logs'].create({
//           org_id: org_id,
//           module_id: contactSettingId,
//           module_name: "1",
//           note: "Contact created at - Google PPC",
//           user_id: created_by
//         })
//         console.log("contactLogss", contactLogs);
  
//       res.status(200).send({
//         status:200,
//         message:'Success',
//         output:data
//       });
  
//     } catch (error) {
//       res.status(500).send({
//         message: error.message,
//       });
//     }
// };