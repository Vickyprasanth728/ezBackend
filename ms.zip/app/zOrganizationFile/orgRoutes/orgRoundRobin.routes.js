const multer = require('multer')
const upload = multer({
  dest: 'uploads/',
  limits: {
    fileSize: 5242880
  },
  fileFilter(req, file, cb) {
    if (!file.originalname.match(/\.(jpg|jpeg|pdf|xlsx|png)$/)) {
      return cb(new Error('Please upload a Image'))
    }
    cb(undefined, true)
  }
})


const apikey = (req, res, next) => {
  if (req.header('apikey') == `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9`) {
    return next()
  }
  else {
    res.status(500).send({
      message: 'Invalid Api-Key',
    });
  }
};

const apikey1 = (req, res, next) => {
  if (req.header('apikey') == `goJhbGciOiJIUzI1NiIsInR5fh43YU64oi89`) {
    return next()
  }
  else {
    res.status(500).send({
      message: 'Invalid Api-Key',
    });
  }
};

const apikey2 = (req, res, next) => {
  if (req.header('apikey') == `JIUzI1NiIsInR5cCI6IkpXVCJ9IUzIciOiJ7`) {
    return next()
  }
  else {
    res.status(500).send({
      message: 'Invalid Api-Key',
    });
  }
};

// NettyFish
const nettyFish = (req, res, next) => {
  if (req.header('apikey') == `ZW1haWwiOiJvcmcyQGxpc3Rlei5pbiIsIm9y`) {
    return next()
  }
  else {
    res.status(500).send({
      message: 'Invalid Api-Key',
    });
  }
};
// liveChat
const liveChat = (req, res, next) => {
  if (req.header('apikey') == `F9LCJpYXQiOjE2OTQ1OTk0MDEsImV4cCI6MT`) {
    return next()
  }
  else {
    res.status(500).send({
      message: 'Invalid Api-Key',
    });
  }
};

module.exports = app => {
    const orgCon = require("../../zOrganizationFile/orgController/orgRoundRobin.controller.js");
  
    var router = require("express").Router();

    // Netty Fish
    router.post("/save_nettyfish", nettyFish, upload.fields([
      { name: "profile_image", maxCount: 1 },
    ]), function (req, res, next) {
      orgCon.saveNettyfish(req, res, next)
    });

    // GOOGLE-PPC
    router.post("/save_googleppc", apikey2, upload.fields([
      { name: "profile_image", maxCount: 1 },
    ]), function (req, res, next) {
      orgCon.saveGooglePpc(req, res, next)
    });

    // FACEBOOK
    router.post("/save_facebook", upload.fields([
      { name: "profile_image", maxCount: 1 },
    ]), function (req, res, next) {
      orgCon.saveFaceBook(req, res, next)
    });

    // Live Chat
    router.post("/save_live_chat", liveChat, upload.fields([
      { name: "profile_image", maxCount: 1 },
    ]), function (req, res, next) {
      orgCon.saveLiveChat(req, res, next)
    });

    // HOUSING.COM
    router.post("/save_housing", upload.fields([
      { name: "profile_image", maxCount: 1 },
    ]), function (req, res, next) {
      orgCon.saveHousing(req, res, next)
    });
    // ROOF & FLOOR
    router.post("/save_roof_floor", apikey, upload.fields([
      { name: "profile_image", maxCount: 1 },
    ]), function (req, res, next) {
      orgCon.saveRoofFloor(req, res, next)
    });
    // save Housing Api
    router.post("/save_housing_api", upload.fields([
      { name: "profile_image", maxCount: 1 },
    ]), function (req, res, next) {
      orgCon.saveHousingApi(req, res, next)
    });
    // Save Magic Bricks Api
    router.post("/save_magicbricks", apikey1, upload.fields([
      { name: "profile_image", maxCount: 1 },
    ]), function (req, res, next) {
      orgCon.saveMagicBricks(req, res, next)
    });

    // Save Responder
    router.post("/save_responders", orgCon.saveResponder);

    app.use('/', router);
  };