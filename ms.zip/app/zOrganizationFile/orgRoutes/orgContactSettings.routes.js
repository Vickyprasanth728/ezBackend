const authentication = require("../../middlewares/auth.js");

module.exports = app => {
    const auth = require("../../middlewares/auth");
    const contactSettings = require("../../zOrganizationFile/orgController/orgContactSettings.controller.js");
  
    var router = require("express").Router();

    router.get("/get_contact_settings", authentication, contactSettings.getContactSettings);
    // Property Dropdown
    router.post("/save_contact_settings", authentication, contactSettings.saveContactSettings);
    // Transaction Dropdown
    router.get("/edit_contact_settings/:id", authentication, contactSettings.editContactSettings);
    // Task Dropdown
    router.put("/update_contact_settings/:id", authentication, contactSettings.updateContactSettings);
    // Team Dropdown
    router.put("/delete_contact_settings/:id", authentication, contactSettings.deleteContactSettings);
  
    app.use('/orgContactSettings/',auth, router);
  };