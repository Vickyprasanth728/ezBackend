const authentication = require("../../middlewares/auth.js");

module.exports = app => {
    const auth = require("../../middlewares/auth");
    const orgTransaction = require("../../zOrganizationFile/orgController/orgTransaction.controller.js");
  
    var router = require("express").Router();
  
    router.post("/save/:document",authentication, orgTransaction.saveTransaction);
    router.get("/get/:document",authentication, orgTransaction.getTransactions);
    router.get("/edit/:document/:id",authentication, orgTransaction.editTransaction);
    // update Transaction
    router.put("/update/:document/:id",authentication, orgTransaction.updateTransaction);
    // update Transaction Brokerage Details
    router.put("/update_brokerage_details/:document/:transaction_id",authentication, orgTransaction.updateBrokerageDetails);
    // update Transaction Invoicing Details
    router.put("/update_invoicing_details/:document/:transaction_id",authentication, orgTransaction.updateInvoicingDetails);
    // Delete Transaction
    router.put("/delete/:document/:id",authentication, orgTransaction.deleteTransaction);
    router.put("/update_transaction_status/:document/:id",authentication, orgTransaction.updateTransactionStatus);

    // Transaction Filter
    router.get("/get_filter/:document",authentication, orgTransaction.getTransactionFilter);
    router.post("/save_filter/:document",authentication, orgTransaction.saveTransactionFilter);
    router.put("/delete_filter/:document/:id",authentication, orgTransaction.deleteTransactionFilter);
  

    app.use('/orgTransaction/',auth, router);
  };