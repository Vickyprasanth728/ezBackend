const authentication = require("../../middlewares/auth.js");

module.exports = app => {
    const auth = require("../../middlewares/auth");
    const city = require("../orgController/orgCity.controller.js");
    
    var router = require("express").Router();
  
    router.post("/save", authentication, city.citySave);
  
    router.get("/get", authentication, city.cityList);
  
    router.get("/edit/:id", authentication, city.cityEdit);
  
    router.put("/update/:id", authentication, city.cityUpdate);
  
    router.put("/delete/:id", authentication, city.cityDelete);
  
    app.use('/orgCity/',auth, router);
  };