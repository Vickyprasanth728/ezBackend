const authentication = require("../../middlewares/auth.js");

module.exports = app => {
    const auth = require("../../middlewares/auth");
    const emailTrigger = require("../../zOrganizationFile/orgController/emailTrigger.controller.js");
  
    var router = require("express").Router();
  
    // Roles
    router.get("/list",authentication, emailTrigger.getEmailTrigger);
  
    router.put("/update/:options",authentication, emailTrigger.updateEmailTrigger);
  
    app.use('/emailTrigger/',auth, router);
  };
  