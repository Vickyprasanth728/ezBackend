const authentication = require("../../middlewares/auth.js");

module.exports = app => {
    const auth = require("../../middlewares/auth");
    const translations = require("../orgController/orgTranslations.controller.js");
  
    var router = require("express").Router();
  
    router.post("/save/:document", authentication, translations.create);
  
    router.get("/get/:document", authentication, translations.findAll);
  
    router.get("/edit/:document/:id", authentication, translations.findOne);

    router.get("/translation_session/:document/:lang", authentication, translations.translationSession);
  
    router.put("/update/:document/:id", authentication, translations.update);
  
    router.put("/delete/:document/:id", authentication, translations.delete);
  
    router.delete("/:document", authentication, translations.deleteAll);
  
    app.use('/orgTranslations/',auth, router);
  };
  