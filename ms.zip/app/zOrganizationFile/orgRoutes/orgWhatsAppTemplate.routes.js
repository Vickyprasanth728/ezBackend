const authentication = require("../../middlewares/auth.js");

module.exports = app => {
    const auth = require("../../middlewares/auth");
    const orgWhatsappTemplate = require("../../zOrganizationFile/orgController/orgwhatsAppTemplate.controller.js");
  
    var router = require("express").Router();
  
    router.post("/save", authentication, orgWhatsappTemplate.create);
  
    router.get("/get", authentication, orgWhatsappTemplate.findAll);
  
    router.get("/edit/:id", authentication, orgWhatsappTemplate.findOne);
  
    router.put("/update/:id", authentication, orgWhatsappTemplate.update);
  
    router.put("/delete/:id", authentication, orgWhatsappTemplate.delete);
  
    app.use('/orgWhatsappTemplate/',auth, router);
  };
  