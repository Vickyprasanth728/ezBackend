const authentication = require("../../middlewares/auth.js");
const multer = require('multer')
const upload = multer({
  dest: 'uploads/',
  limits: {
    fileSize: 5242880
  },
  fileFilter(req, file, cb) {
    if (!file.originalname.match(/\.(jpg|jpeg|pdf|xlsx|png|ico)$/)) {
      return cb(new Error('Please upload a Image'))
    }
    cb(undefined, true)
  }
})

module.exports = app => {
    const auth = require("../../middlewares/auth");
    const business_settings = require("../../zOrganizationFile/orgController/orgBusinessSettings.controller.js");
  
    var router = require("express").Router();
  
    router.post("/save", authentication, business_settings.saveBusinessSettings);
  
    router.get("/get", authentication, business_settings.getBusinessSettings);
  
    router.get("/edit/:id", authentication, business_settings.editBusinessSettings);
  
    // router.put("/update/:id", authentication, business_settings.update);
    router.put('/update', authentication, upload.fields([
      { name: "site_favicon"},
      { name: "site_logo" },
    ]), function (req, res, next) {
      business_settings.updateBusinessSetting(req, res, next)
    });
  
    router.put("/delete/:id", authentication, business_settings.deleteBusinessSettings);
  
    app.use(require('express').static('public'));
    app.use('/uploads', require('express').static('uploads'));
    app.use('/orgBs/',auth, router);
  };