const authentication = require("../../middlewares/auth.js");
const multer = require('multer')
const upload = multer({
  dest: 'uploads/',
  limits: {
    fileSize: 5242880
  },
  fileFilter(req, file, cb) {
    if (!file.originalname.match(/\.(jpg|jpeg|pdf|xlsx|png)$/)) {
      return cb(new Error('Please upload a Image'))
    }
    cb(undefined, true)
  }
})

module.exports = app => {
    const auth = require("../../middlewares/auth");
    const orgProperty = require("../../zOrganizationFile/orgController/orgProperty.controller.js");
  
    var router = require("express").Router();
  
    // router.post("/save/:document", authentication, orgProperty.saveProperty);
    // router.post('/save/:document', authentication, upload.fields([
    //   { name: "images", maxCount: 1 },
    // ]), function (req, res, next) {
    //   orgProperty.saveProperty(req, res, next)
    // });
    // router.post("/save/:document", authentication, upload.array('images'), orgProperty.saveProperty);
    

    router.post('/save/:document', authentication,
    upload.fields([
      {name: 'images'},
      {name: 'profile_image', maxCount: 1},
    ]), function (req, res, next) {
      orgProperty.saveProperty(req, res, next)
    });

    // router.post('/save/:document', authentication,
    // upload.array('images'), function (req, res, next) {
    //   orgProperty.saveProperty(req, res, next)
    // });
  
    router.get("/get/:document", authentication, orgProperty.getProperty);
    router.get("/get_property_task/:document/:id", authentication, orgProperty.getPropertyTask);
    router.get("/get_property_lead/:document/:id", authentication, orgProperty.getPropertyLead);
  
    router.get("/edit/:document/:id", authentication, orgProperty.editProperty);
  
    // router.put("/update_property/:document/:id", authentication, orgProperty.updateProperty);

    router.put('/update_property/:document/:id', authentication, upload.fields([
      { name: "profile_image", maxCount: 1 },
    ]), function (req, res, next) {
      orgProperty.updateProperty(req, res, next)
    });

    router.put("/update_property_address/:document/:property_id", authentication, orgProperty.updatePropertyAddress);

    // Property Update
    router.put("/update_property_residential/:document/:property_id", authentication, orgProperty.updatePropertyResidential);
    router.put("/update_property_conventional/:document/:property_id", authentication, orgProperty.updatePropertyCoventional);
    router.put("/update_property_co_working/:document/:property_id", authentication, orgProperty.updatePropertyCoWorking);
    router.put("/update_property_industrial/:document/:property_id", authentication, orgProperty.updatePropertyIndustrial);
    router.put("/update_property_retail/:document/:property_id", authentication, orgProperty.updatePropertyRetail);
    router.put("/update_property_plot/:document/:property_id", authentication, orgProperty.updatePropertyPlot);

    router.put("/update_property_unit_type/:document/:property_id", authentication, orgProperty.updatePropertyUnitType);
  
    router.put("/delete/:document/:id", authentication, orgProperty.delete);
    router.put("/update_property_status/:document/:id", authentication, orgProperty.updatePropertyStatus);

    // Property Filter
    router.get("/get_property_filter/:document", authentication, orgProperty.getPropertyFilter);
    router.post("/save_property_filter/:document", authentication, orgProperty.SavePropertyFilter);
    router.put("/delete_property_filter/:document/:id", authentication, orgProperty.deletePropertyFilter);
  
    app.use('/orgProperty/',auth, router);
  }; 