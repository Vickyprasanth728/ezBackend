const authentication = require("../../middlewares/auth.js");

module.exports = app => {
    const auth = require("../../middlewares/auth");
    const country = require("../orgController/orgCountry.controller.js");
    
    var router = require("express").Router();
  
    router.post("/save", authentication, country.countrySave);
  
    router.get("/get", authentication, country.countryList);
  
    router.get("/edit/:id", authentication, country.countryEdit);
  
    router.put("/update/:id", authentication, country.countryUpdate);
  
    router.put("/delete/:id", authentication, country.countryDelete);
  
    app.use('/orgCountry/',auth, router);
  };