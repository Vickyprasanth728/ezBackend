const authentication = require("../../middlewares/auth.js");

module.exports = app => {
    const auth = require("../../middlewares/auth");
    const logoutTimeline = require("../../zOrganizationFile/orgController/orgUserTimeline.controller.js");
  
    var router = require("express").Router();
  
    router.put("/org_logout",authentication, logoutTimeline.updateOrgLogout);
  
    app.use('/logoutTimeline/',auth, router);
  };