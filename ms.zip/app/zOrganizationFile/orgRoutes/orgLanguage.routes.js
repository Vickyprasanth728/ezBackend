const authentication = require("../../middlewares/auth.js");

module.exports = app => {
    const auth = require("../../middlewares/auth");
    const language = require("../orgController/orgLanguage.controller.js");
  
    var router = require("express").Router();
  
    router.post("/save/:document", authentication, language.create);
  
    router.get("/get/:document", authentication, language.findAll);
  
    router.get("/edit/:document/:id", authentication, language.findOne);
  
    router.put("/update/:document/:id", authentication, language.update);
  
    router.put("/delete/:document/:id", authentication, language.delete);
  
    app.use('/orgLanguage/',auth, router);
  };