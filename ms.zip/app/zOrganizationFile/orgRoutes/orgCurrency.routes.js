const authentication = require("../../middlewares/auth.js");

module.exports = app => {
    const auth = require("../../middlewares/auth");
    const currency = require("../orgController/orgCurrency.controller.js");
    
    var router = require("express").Router();
  
    router.post("/save", authentication, currency.currencySave);
  
    router.get("/get", authentication, currency.currencyList);
  
    router.get("/edit/:id", authentication, currency.currencyEdit);
  
    router.put("/update/:id", authentication, currency.currencyUpdate);
  
    router.put("/delete/:id", authentication, currency.currencyDelete);
  
    app.use('/orgCurrency/',auth, router);
  };