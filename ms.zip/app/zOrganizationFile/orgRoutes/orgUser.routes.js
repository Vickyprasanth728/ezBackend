const authentication = require("../../middlewares/auth.js");
const multer = require('multer')
const upload = multer({
  dest: 'uploads/',
  limits: {
    fileSize: 5242880
  },
  fileFilter(req, file, cb) {
    if (!file.originalname.match(/\.(jpg|jpeg|pdf|xlsx|png)$/)) {
      return cb(new Error('Please upload a Image'))
    }
    cb(undefined, true)
  }
})

module.exports = app => {
    const auth = require("../../middlewares/auth");
    const users = require("../../zOrganizationFile/orgController/orgUser.controller.js");
  
    var router = require("express").Router();
  
    router.get("/get/:document", authentication, users.getUsers);
    router.get("/get_check/:document", authentication, users.getUsersCheck);
    router.get("/edit_user/:document/:id", authentication, users.editUser);

    // Save Basic Details
    router.post('/save_user/:document', authentication, upload.fields([
        { name: "profile_image", maxCount: 1 },
      ]), function (req, res, next) {
        users.saveUser(req, res, next)
      });
    // Update Basic Details
    router.put('/update_user/:document/:id', authentication, upload.fields([
        { name: "profile_image", maxCount: 1 },
      ]), function (req, res, next) {
        users.updateUser(req, res, next)
      });
    // Update Profile
    router.put('/update_profile/:document/:id', authentication, upload.fields([
      { name: "profile_image", maxCount: 1 },
    ]), function (req, res, next) {
      users.updateProfile(req, res, next)
    });
    // Save Personal Details
    router.post("/save_user_personal_details/:document", authentication, users.saveUserPersonalDetails);
    router.put("/update_user_personal_details/:document/:user_id", authentication, users.updateUserPersonalDetails);
    
    // Save Personal Details
    router.post("/save_user_professional_details/:document", authentication, users.saveUserProfessionalDetails);
    router.put("/update_user_professional_details/:document/:user_id", authentication, users.updateUserProfessionalDetails);

    // Save Finance Details
    router.post("/save_user_finance/:document", authentication, users.saveUserFinance);
    router.put("/update_user_finance/:document/:user_id", authentication, users.updateUserFinance);
    // Save Goals
    router.post("/save_user_goals/:document", authentication, users.saveUserGoals);
    router.put("/update_user_goals/:document/:user_id", authentication, users.updateUserGoals);

    router.put("/delete_user/:document/:id", authentication, users.deleteUser);

    router.get("/users_dropdown/:document/:designation", authentication, users.getUsersDropdown);

    app.use('/OrgUser/',auth, router);
  };
  