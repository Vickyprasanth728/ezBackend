const authentication = require("../../middlewares/auth.js");
const multer = require('multer')
const upload = multer({
  dest: 'uploads/',
  limits: {
    fileSize: 5242880
  },
  fileFilter(req, file, cb) {
    if (!file.originalname.match(/\.(jpg|jpeg|pdf|xlsx|png)$/)) {
      return cb(new Error('Please upload a Image'))
    }
    cb(undefined, true)
  }
})

module.exports = app => {
    const auth = require("../../middlewares/auth");
    const orgLeads = require("../../zOrganizationFile/orgController/orgLeads.controller.js");
  
    var router = require("express").Router();
  
    router.post("/save/:document",authentication, orgLeads.saveLeads);
    router.post("/send_mail_lead/:document",authentication, orgLeads.sendMailLead);
  
    router.get("/get/:document",authentication, orgLeads.getLeads);
    router.get("/get_lead_automatch/:document/:id",authentication, orgLeads.getLeadAutoMatch);
    router.get("/get_lead_duplicate/:document/:id/:property_id",authentication, orgLeads.getLeadDuplicate);
    router.get("/get_lead_task/:document/:id",authentication, orgLeads.getLeadTask);
  
    router.get("/edit/:document/:id",authentication, orgLeads.editLead);
  
    router.put("/update_lead/:document/:id",authentication, orgLeads.updateLead);
    router.put("/update_lead_requirement/:document/:lead_id",authentication, orgLeads.updateLeadRequirement);
  
    router.put("/delete/:document/:id",authentication, orgLeads.deleteLead);
    // Update lead status
    router.put("/update_lead_status/:document/:id",authentication, orgLeads.updateLeadStatus);

    // BUlk Lead Re-Assign
    router.put("/update_lead_bulk_reassign/:document/:id",authentication, orgLeads.bulkLeadReAssign);

    // Import Lead
    router.post('/import_lead', upload.single("uploadfile"), orgLeads.importLead);

    router.post("/save_lead_filter/:document",authentication, orgLeads.saveLeadFilter);
    router.get("/get_lead_filter/:document",authentication, orgLeads.getLeadFilter);
    router.put("/delete_lead_filter/:document/:id",authentication, orgLeads.deleteLeadFilter);

    router.get("/get_final/:document",authentication, orgLeads.getLeadFinal);

    // Options 
    router.post("/option_pdf/:id",authentication, orgLeads.optionPDF);
  
    app.use('/orgLeads/',auth, router);
  };