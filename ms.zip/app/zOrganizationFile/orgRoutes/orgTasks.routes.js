const authentication = require("../../middlewares/auth.js");

module.exports = app => {
    const auth = require("../../middlewares/auth");
    const orgTasks = require("../../zOrganizationFile/orgController/orgTasks.controller.js");
  
    var router = require("express").Router();
  
    router.post("/save/:document", authentication, orgTasks.saveTasks);
  
    router.get("/get/:document", authentication, orgTasks.getTasks);
  
    router.get("/edit/:document/:id", authentication, orgTasks.editTask);
  
    router.put("/update/:document/:id", authentication, orgTasks.updateTask);
    router.put("/update_priority_status/:document/:id", authentication, orgTasks.updateTaskPriorityStatus);
    router.put("/update_task_status/:document/:id", authentication, orgTasks.updateTaskStatus);
  
    router.put("/delete/:document/:id", authentication, orgTasks.deleteTask);
    router.put("/delete_task_filter/:document/:id", authentication, orgTasks.deleteTaskFilter);

    // Save Task Filter
    router.post("/save_task_filter/:document", authentication, orgTasks.saveTaskFilter);
    router.get("/get_task_filter/:document", authentication, orgTasks.getTaskFilter);

    // BUlk Task Re-Assign
    router.put("/update_task_bulk_reassign/:document/:id",authentication, orgTasks.bulkTaskReAssign);
  
    app.use('/orgTasks/',auth, router);
  };