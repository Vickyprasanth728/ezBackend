const authentication = require("../../middlewares/auth.js");

module.exports = app => {
    const auth = require("../../middlewares/auth");
    const state = require("../orgController/orgState.controller.js");
    
    var router = require("express").Router();
  
    router.post("/save", authentication, state.stateSave);
  
    router.get("/get", authentication, state.stateList);
  
    router.get("/edit/:id", authentication, state.stateEdit);
  
    router.put("/update/:id", authentication, state.stateUpdate);
  
    router.put("/delete/:id", authentication, state.stateDelete);
  
    app.use('/orgState/',auth, router);
  };