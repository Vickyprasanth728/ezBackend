const authentication = require("../../middlewares/auth.js");

module.exports = app => {
    const auth = require("../../middlewares/auth");
    const orgLogs = require("../../zOrganizationFile/orgController/orgLogs.controller.js");
  
    var router = require("express").Router();
  
    router.get("/get/:document/:module_id/:module_name", authentication, orgLogs.findAll);
  
    app.use('/orgLogs/',auth, router);
  };
  