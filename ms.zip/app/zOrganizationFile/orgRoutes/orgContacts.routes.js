const authentication = require("../../middlewares/auth.js");
const multer = require('multer')
const upload = multer({
  dest: 'uploads/',
  limits: {
    fileSize: 5242880
  },
  fileFilter(req, file, cb) {
    if (!file.originalname.match(/\.(jpg|jpeg|pdf|xlsx|png|csv)$/)) {
      return cb(new Error('Please upload a Image'))
    }
    cb(undefined, true)
  }
})

module.exports = app => {
    const auth = require("../../middlewares/auth");
    const orgContacts = require("../../zOrganizationFile/orgController/orgContacts.controller.js");
    const orgCon = require("../../zOrganizationFile/orgController/orgRoundRobin.controller.js");
  
    var router = require("express").Router();
  
      router.post('/save/:document', authentication,
      upload.fields([
        {name: 'document1', maxCount: 1}, 
        {name: 'document2', maxCount: 1}, 
        {name: 'document3', maxCount: 1}, 
        {name: 'document4', maxCount: 1}, 
        {name: 'document5', maxCount: 1}, 
        {name: 'profile_image', maxCount: 1},
        {name: 'documents', maxCount: 1}
      ]), function (req, res, next) {
        orgContacts.saveContacts(req, res, next)
      });
    router.get("/get/:document",authentication, orgContacts.getContacts);
    router.get("/get_contact_check/:document",authentication, orgContacts.getContactCheck);
    router.get("/get_final/:document",authentication, orgContacts.getContactFinal);
  
    router.get("/edit/:document/:id",authentication, orgContacts.editContact);
  
    router.put('/update/:document/:id', authentication, upload.fields([
        { name: "profile_image", maxCount: 1 },
      ]), function (req, res, next) {
        orgContacts.updateContact(req, res, next)
      });
  
    router.put("/update_contact_details/:document/:contact_id",authentication, orgContacts.updateContactDetails);
    router.put("/update_contact_address/:document/:contact_id",authentication, orgContacts.updateContactAddress);
    router.put("/update_contact_status/:document/:id",authentication, orgContacts.updateContactStatus);
    router.put("/delete/:document/:id",authentication, orgContacts.deleteContact);

    router.get("/contact_dropdown", authentication, orgContacts.getContactDropdown);

    router.get("/get_all_location/:pincode",authentication, orgContacts.getAllLocation);

    router.post("/save_contact_filter/:document",authentication, orgContacts.saveContactFilter);
    router.get("/get_contact_filter/:document",authentication, orgContacts.getContactFilter);
    router.put("/delete_contact_filter/:document/:id",authentication, orgContacts.deleteContactFilter);
  
    router.get("/get_contact_leads/:document/:contact_id",authentication, orgContacts.getContactLeads);
    router.get("/get_contact_tasks/:document/:contact_id",authentication, orgContacts.getContactTasks);
    router.get("/get_duplicate_contact/:document/:contact_id",authentication, orgContacts.getDuplicateContact);
    router.get("/get_secondary_contact/:document/:id",authentication, orgContacts.getSecondaryContacts);

    router.put("/update_reassign/:document/:id",authentication, orgContacts.updateReAssign);
    // Bulk-ReAssign
    router.put("/update_bulk_reassign/:document/:id",authentication, orgContacts.bulkReAssign);
    router.get("/reassign_dropdown/:document",authentication, orgContacts.ReAssignDropdown);

    // router.post("/save_contact_auto_assign/:document",authentication, orgContacts.saveContactAutoAssign);

    // Bulk Contact Re-Assign 
    router.post('/uploadfileContact', upload.single("uploadfile"), orgContacts.uploadFile);

    router.post("/save_contact_auto_assign/:document", authentication, upload.fields([
      { name: "profile_image", maxCount: 1 },
    ]), function (req, res, next) {
      orgContacts.saveContactAutoAssign(req, res, next)
    });
    
    // GOOGLE-PPC
    router.post("/save_googleppc_auto_assign/:document", authentication, upload.fields([
      { name: "profile_image", maxCount: 1 },
    ]), function (req, res, next) {
      orgCon.saveGooglePpc(req, res, next)
    });

    // FACEBOOK
    router.post("/save_facebook/:document", authentication, upload.fields([
      { name: "profile_image", maxCount: 1 },
    ]), function (req, res, next) {
      orgCon.saveFaceBook(req, res, next)
    });

    // HOUSING.COM
    router.post("/save_housing/:document", authentication, upload.fields([
      { name: "profile_image", maxCount: 1 },
    ]), function (req, res, next) {
      orgCon.saveHousing(req, res, next)
    });

    // Save Responder
    router.post("/save_responder",authentication, orgCon.saveResponder);

    app.use('/orgContacts/',auth, router);
  };


      // let thisQuery23 = ` select email from lz_user where id = 1 `
    // const emailCheck = await db2.sequelize.query(thisQuery23);
    // const emailId = emailCheck[0][0] ? emailCheck[0][0]["email"] : 0
    // console.log("emailCheck", emailCheck[0]);
    // console.log("emailId", emailId);

    // // let thisQuery1 = `select name_of_building from property_addresses where property_id = '${req.body.property_id}' `
    // // const projectCheck = await db2.sequelize.query(thisQuery1);
    // // const project_name = projectCheck[0] ? projectCheck[0]["name_of_building"] : 0

    // // console.log("projectCheck", projectCheck[0]);

    // let message = {
    //   from: "mobile.vriksha@gmail.com",
    //   to: 'gowshickvts@gmail.com',
    //   subject: "New contact assigned",
    //   html:
    //     "<h3>New contact has been assigned with </h3>" +
    //     "<h3>Project Id: </h3>" +
    //     // req.body.property_id +
    //     "<h3>Project Name:</h3>" 
    //     // +
    //     // project_name + ""
    //     // ,
    // };
    // mailer.sendMail(message);
    // console.log(message)
