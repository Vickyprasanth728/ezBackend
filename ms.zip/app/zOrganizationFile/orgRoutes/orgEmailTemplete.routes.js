const authentication = require("../../middlewares/auth.js");

module.exports = app => {
    const auth = require("../../middlewares/auth");
    const orgEmailTemplate = require("../../zOrganizationFile/orgController/orgEmailTemplate.controller.js");
  
    var router = require("express").Router();
  
    router.post("/save/:document", authentication, orgEmailTemplate.create);
  
    router.get("/get/:document", authentication, orgEmailTemplate.findAll);
  
    router.get("/edit/:document/:id", authentication, orgEmailTemplate.findOne);
  
    router.put("/update/:document/:id", authentication, orgEmailTemplate.update);
  
    router.put("/delete/:document/:id", authentication, orgEmailTemplate.delete);
  
    app.use('/orgEmailTemplate/',auth, router);
  };
  