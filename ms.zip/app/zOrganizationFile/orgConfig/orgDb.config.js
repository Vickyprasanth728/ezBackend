// module.exports = {
//     DB_HOST: "localhost",
//     DB_USER: "root",
//     DB_PASS: "",
//     DB_DATABASE: "listez_db2",
// };
const db = require("../../models");
// const authentication = require("../../middlewares/dummy.js").at;

exports.databaseAuth = (req, res, next) => {
    console.log("Config DB");
    // console.log("authentication", authentication);
  
    const org_id = 2  
    if(org_id == 2) {

      return(
        module.exports = {
          DB_HOST: "localhost",
          DB_USER: "root",
          DB_PASS: "",
          DB_DATABASE: `listez_db2`,
          
          smtpUserName: "gowshickvts@gmail.com",
          smtpPassword: "vpnhkrfagdmihnka",
          smtpHost: "smtp.gmail.com",
          smtpPort: "587",
          // smtpUserName: "d5818f0174d329",
          // smtpPassword: "38bb72c212fb86",
          // smtpHost: "sandbox.smtp.mailtrap.io",
          // smtpPort: "587",
          whatsAppKey: "EAAGZCewXTNRQBOZCZCZBO9CAL9T4GS8H43pkZAyABZAmnqJ7f3iZCY5xL3fdXco7xfLyffIs7gfowZCIaH6RSyYGbBhFQx2yfqCg2KZBcWd23tswK5lZAGRjtFq7Na9XAZBvmF3h3WOO6HB0WtfyC22U3cYMOOi20nzchoJrZCZBjgeWBVMDroSxYJbTcNIFsT98cbSbB2iabOFy8PnuGN5Bz"
        }
      )
    }
    // else if(org_id == 3) {
    //   return(
    //     module.exports = {
    //       DB_HOST: "localhost",
    //       DB_USER: "root",
    //       DB_PASS: "",
    //       DB_DATABASE: `listez_db3`,
    //       smtpUserName: "134a7d7fee3891",
    //       smtpPassword: "f549d5fc6cae82",
    //       smtpHost: "smtp.mailtrap.io",
    //       smtpPort: "587"
    //     }
    //   )
    // }
};