module.exports = (sequelize, Sequelize) => {
    return sequelize.define("lz_role_permissions", {
      designation: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      contact: {
        type: Sequelize.INTEGER,
        allowNull: true,
        defaultValue:0,
      },
      lead: {
        type: Sequelize.INTEGER,
        allowNull: true,
        defaultValue:0,
      },
      project: {
        type: Sequelize.INTEGER,
        allowNull: true,
        defaultValue:0,
      },
      task: {
        type: Sequelize.INTEGER,
        allowNull: true,
        defaultValue:0,
      },
      transaction: {
        type: Sequelize.INTEGER,
        allowNull: true,
        defaultValue:0,
      },
      file: {
        type: Sequelize.INTEGER,
        allowNull: true,
        defaultValue:0,
      },
      finance: {
        type: Sequelize.INTEGER,
        allowNull: true,
        defaultValue:0,
      },
      message: {
        type: Sequelize.INTEGER,
        allowNull: true,
        defaultValue:0,
      },
      report: {
        type: Sequelize.INTEGER,
        allowNull: true,
        defaultValue:0,
      },
      support: {
        type: Sequelize.INTEGER,
        allowNull: true,
        defaultValue:0,
      },
      settings: {
        type: Sequelize.INTEGER,
        allowNull: true,
        defaultValue:0,
      },
      export: {
        type: Sequelize.INTEGER,
        allowNull: true,
        defaultValue:0,
      },
      assign_list: {
        type: Sequelize.INTEGER,
        allowNull: true,
        defaultValue:0,
      },
      status: {
        type: Sequelize.INTEGER,
        allowNull: true,
        defaultValue:1,
      },
      createdAt: {
        type: 'TIMESTAMP',
        allowNull: true,
        defaultValue:sequelize.literal('CURRENT_TIMESTAMP'),
        field:'created_at'
      },
      updatedAt: {
        type: 'TIMESTAMP',
        allowNull: true,
        defaultValue:sequelize.literal('CURRENT_TIMESTAMP'),
        field:'updated_at'
      },
    },{
      tableName:'lz_role_permissions'
    });
  };
  