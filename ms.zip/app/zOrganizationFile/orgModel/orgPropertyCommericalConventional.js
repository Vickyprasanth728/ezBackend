module.exports = (sequelize, Sequelize) => {
    return sequelize.define("lz_property_commerical_conventional", {
        property_id: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        type_of_building: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        grade_of_building: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        total_project_built_up_area: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        total_project_built_up_area_ut: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        floor_plate_area: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        floor_plate_area_ut: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        building_structure: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        offered_floor: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        offered_area: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        offered_area_ut: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        furnishing: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        no_of_workstations: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        workstations_size: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        no_of_cabins: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        no_of_conference_rooms: { 
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        conference_room_size: { 
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        pantry: { 
            type: Sequelize.STRING,
            allowNull: true,
        },
        no_of_people: { 
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        washrooms: { 
            type: Sequelize.STRING,
            allowNull: true,
        },
        no_of_washrooms: { 
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        bike_parking: { 
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        car_parking: { 
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        amenities: { 
            type: Sequelize.STRING,
            allowNull: true,
        },
        certifications: { 
            type: Sequelize.STRING,
            allowNull: true,
        },
        If_specify: { 
            type: Sequelize.STRING,
            allowNull: true,
        },
        completion_certificate: { 
            type: Sequelize.STRING,
            allowNull: true,
        },
        conventional_unit_type: { 
            type: Sequelize.TEXT,
            allowNull: true,
        },
        createdAt: {
            type: 'TIMESTAMP',
            allowNull: true,
            defaultValue: sequelize.literal('CURRENT_TIMESTAMP'),
            field: 'created_at'
        },
        updatedAt: {
            type: 'TIMESTAMP',
            allowNull: true,
            defaultValue: sequelize.literal('CURRENT_TIMESTAMP'),
            field: 'updated_at'
        },
    }, {
        tableName: 'lz_property_commerical_conventional'
    });
};