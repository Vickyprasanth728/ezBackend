module.exports = (sequelize, Sequelize) => {
    return sequelize.define("lz_property_filter", {
        org_id: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        property_id: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        available_for: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        commission_min: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        commission_max: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        property_type: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        property_source: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        property_status: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        country: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        age_of_property_min: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        age_of_property_max: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        property_facing: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        project_stage: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        gated_community: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        vasthu_compliant: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        buildup_area_min: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        buildup_area_max: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        uds_min: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        uds_max: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        no_of_units_min	: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        no_of_units_max: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        no_of_floors_min: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        no_of_floors_max: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        rera_registered: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        filter_name: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        created_date: {
            type: Sequelize.DATEONLY,
            allowNull: true,
        },
        updated_date: {
            type: Sequelize.DATEONLY,
            allowNull: true,
        },
        created_by: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        createdAt: {
            type: 'TIMESTAMP',
            allowNull: true,
            defaultValue: sequelize.literal('CURRENT_TIMESTAMP'),
            field: 'created_at'
        },
        updatedAt: {
            type: 'TIMESTAMP',
            allowNull: true,
            defaultValue: sequelize.literal('CURRENT_TIMESTAMP'),
            field: 'updated_at'
        },
    }, {
        tableName: 'lz_property_filter'
    });
};