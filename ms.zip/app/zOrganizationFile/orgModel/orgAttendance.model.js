module.exports = (sequelize, Sequelize) => {
    return sequelize.define("lz_attendance", {
      user_id: {
        type: Sequelize.INTEGER(11),
        allowNull: false,
      },
      start: {
        type: Sequelize.DATE,
        allowNull: true,
      },
      end: {
        type: Sequelize.DATE,
        allowNull: true,
      },
      attendance_status: {
        type: Sequelize.INTEGER(11),
        allowNull: true,
      },
      leave_type: {
        type: Sequelize.INTEGER(11),
        allowNull: true,
      },
      user_ip: {
        type: Sequelize.STRING(255),
        allowNull: true,
      },
      user_latitude: {
        type: Sequelize.STRING(255),
        allowNull: true,
      },
      user_longitude: {
        type: Sequelize.STRING(255),
        allowNull: true,
      },
      user_address: {
        type: Sequelize.TEXT,
        allowNull: true,
      },
      created_by: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      status: {
        type: Sequelize.INTEGER,
        allowNull: true,
        defaultValue:1,
      },
      createdAt: {
        type: 'TIMESTAMP',
        allowNull: true,
        defaultValue:sequelize.literal('CURRENT_TIMESTAMP'),
        field:'created_at'
      },
      updatedAt: {
        type: 'TIMESTAMP',
        allowNull: true,
        defaultValue: sequelize.literal('CURRENT_TIMESTAMP'),
        field:'updated_at'
      },
    },{
      tableName:'lz_attendance'
    });
  };