module.exports = (sequelize, Sequelize) => {
    return sequelize.define("lz_property_plot", {
        property_id: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        plot_type: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        plot_area: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        plot_area_ut: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        fsi: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        frontage: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        frontage_ut: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        dimensions: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        dimensions_ut: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        road_width_min: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        road_width_min_ut: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        road_width_max: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        road_width_max_ut: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        corner_property: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        authority_approved: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        boundary_wall: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        current_status: {
            type: Sequelize.TEXT,
            allowNull: true,
        },
        amenities: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        plot_unit_type: {
            type: Sequelize.TEXT,
            allowNull: true,
        },
        createdAt: {
            type: 'TIMESTAMP',
            allowNull: true,
            defaultValue: sequelize.literal('CURRENT_TIMESTAMP'),
            field: 'created_at'
        },
        updatedAt: {
            type: 'TIMESTAMP',
            allowNull: true,
            defaultValue: sequelize.literal('CURRENT_TIMESTAMP'),
            field: 'updated_at'
        },
    }, {
        tableName: 'lz_property_plot'
    });
};