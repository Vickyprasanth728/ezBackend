module.exports = (sequelize, Sequelize) => {
    return sequelize.define("lz_organization", {
      organization_name: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      company_ref_id: {
        type: Sequelize.INTEGER,
        allowNull: true,
        // validate : {isInt: true}
      },
      user_name: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      password: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      sub_domain: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      sub_domain_database_name: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      phone_number: {
        type: Sequelize.BIGINT,
        allowNull: true,
        validate : {isInt: true}
      },
      gst_number: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      cin_number: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      tan_number: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      pan_number: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      address: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      city: {
        type: Sequelize.INTEGER,
        allowNull: true,
        // validate : {isInt: true}
      },
      state: {
        type: Sequelize.INTEGER,
        allowNull: true,
        // validate : {isInt: true}
      },
      country: {
        type: Sequelize.INTEGER,
        allowNull: true,
        // validate : {isInt: true}
      },
      currency: {
        type: Sequelize.INTEGER,
        allowNull: true,
        // validate : {isInt: true}
      },
      website: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      facebook_url: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      linkindin_url: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      twitter_url: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      instagram_url: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      youtube_url: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      approval: {
        type: Sequelize.INTEGER,
        allowNull: true,
        validate : {isInt: true}
      },
      logo: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      water_mark: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      created_by: {
        type: Sequelize.INTEGER,
        allowNull: true,
        validate : {isInt: true}
      },
      status: {
        type: Sequelize.INTEGER,
        allowNull: true,
        defaultValue:1,
        validate : {isInt: true}
      },
      deleted_by: {
        type: Sequelize.INTEGER,
        allowNull: true,
        defaultValue:0,
        validate : {isInt: true}
      },
      createdAt: {
        type: 'TIMESTAMP',
        allowNull: true,
        defaultValue:sequelize.literal('CURRENT_TIMESTAMP'),
        field:'created_at'
      },
      updatedAt: {
        type: 'TIMESTAMP',
        allowNull: true,
        defaultValue:sequelize.literal('CURRENT_TIMESTAMP'),
        field:'updated_at'
      },
    },{
      tableName:'lz_organization'
    });
  };