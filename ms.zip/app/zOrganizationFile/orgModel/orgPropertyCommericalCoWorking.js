module.exports = (sequelize, Sequelize) => {
    return sequelize.define("lz_property_commerical_co_working", {
        property_id: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        co_working_type: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        total_project_built_up_area: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        total_project_built_up_area_ut: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        no_of_workstations: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        no_of_workstations_ut: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        offered_floor_min: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        offered_floor_min_ut: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        offered_floor_max: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        offered_floor_max_ut: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        offered_workstations_max: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        offered_workstations_min: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        workstations_size: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        no_of_cabins: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        no_of_conference_rooms: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        conference_room_size: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        pantry: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        no_of_people: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        washrooms: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        no_of_washrooms: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        server_rooms: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        bike_parking: { 
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        car_parking: { 
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        office_work_hours: { 
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        office_work_hours_ut: { 
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        amenities: { 
            type: Sequelize.STRING,
            allowNull: true,
        },
        certifications: { 
            type: Sequelize.STRING,
            allowNull: true,
        },
        co_working_unit_type: { 
            type: Sequelize.TEXT,
            allowNull: true,
        },
        createdAt: {
            type: 'TIMESTAMP',
            allowNull: true,
            defaultValue: sequelize.literal('CURRENT_TIMESTAMP'),
            field: 'created_at'
        },
        updatedAt: {
            type: 'TIMESTAMP',
            allowNull: true,
            defaultValue: sequelize.literal('CURRENT_TIMESTAMP'),
            field: 'updated_at'
        },
    }, {
        tableName: 'lz_property_commerical_co_working'
    });
};