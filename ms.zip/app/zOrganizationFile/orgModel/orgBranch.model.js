module.exports = (sequelize, Sequelize) => {
    return sequelize.define("lz_branch", {
      branch_name: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      city: {
        type: Sequelize.INTEGER,
        allowNull: false,
        validate : {isInt: true}
      },
      state: {
        type: Sequelize.INTEGER,
        allowNull: false,
        validate : {isInt: true}
      },
      country: {
        type: Sequelize.INTEGER,
        allowNull: false,
        validate : {isInt: true}
      },
      pincode: {
        type: Sequelize.INTEGER,
        allowNull: false,
        validate : {isInt: true}
      },
      created_by: {
        type: Sequelize.INTEGER,
        allowNull: false,
        validate : {isInt: true}
      },
      status: {
        type: Sequelize.INTEGER,
        allowNull: true,
        defaultValue:1,
        validate : {isInt: true}
      },
      createdAt: {
        type: 'TIMESTAMP',
        allowNull: true,
        defaultValue:sequelize.literal('CURRENT_TIMESTAMP'),
        field:'created_at'
      },
      updatedAt: {
        type: 'TIMESTAMP',
        allowNull: true,
        defaultValue: sequelize.literal('CURRENT_TIMESTAMP'),
        field:'updated_at'
      },
    },{
      tableName:'lz_branch'
    });
  };