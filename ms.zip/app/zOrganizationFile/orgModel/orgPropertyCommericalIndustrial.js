module.exports = (sequelize, Sequelize) => {
    return sequelize.define("lz_property_commerical_industrial", {
        property_id: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        type: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        sub_type: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        specify: {
            type: Sequelize.TEXT,
            allowNull: true,
        },
        total_project_area: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        total_project_area_ut: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        total_build_up_area: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        total_build_up_area_ut: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        total_plot_area: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        total_plot_area_ut: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        offered_build_up_area: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        offered_build_up_area_ut: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        offered_plot_area: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        offered_plot_area_ut: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        office_area: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        office_area_ut: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        industrial_area: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        building_structure: {
            type: Sequelize.TEXT,
            allowNull: true,
        },
        building_material: {
            type: Sequelize.TEXT,
            allowNull: true,
        },
        typical_floor_plate_size: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        typical_floor_plate_size_ut: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        floor_ceiling_height: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        floor_ceiling_height_ut: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        flooring: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        fire_safety: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        possession_status: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        age_of_structure: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        pantry: { 
            type: Sequelize.STRING,
            allowNull: true,
        },
        no_of_people: { 
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        washrooms: { 
            type: Sequelize.STRING,
            allowNull: true,
        },
        server_rooms: { 
            type: Sequelize.STRING,
            allowNull: true,
        },
        bike_parking: { 
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        car_parking: { 
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        amenities: { 
            type: Sequelize.STRING,
            allowNull: true,
        },
        industrial_unit_type: { 
            type: Sequelize.TEXT,
            allowNull: true,
        },
        createdAt: {
            type: 'TIMESTAMP',
            allowNull: true,
            defaultValue: sequelize.literal('CURRENT_TIMESTAMP'),
            field: 'created_at'
        },
        updatedAt: {
            type: 'TIMESTAMP',
            allowNull: true,
            defaultValue: sequelize.literal('CURRENT_TIMESTAMP'),
            field: 'updated_at'
        },
    }, {
        tableName: 'lz_property_commerical_industrial'
    });
};