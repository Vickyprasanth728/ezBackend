module.exports = (sequelize, Sequelize) => {
    return sequelize.define("lz_property_residentials", {
        property_id: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        project_stage: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        age_of_property: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        furnishing: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        built_up_area_min: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        built_up_area_max: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        builtup_area_min_ut: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        builtup_area_max_ut: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        plot_area_min: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        plot_area_max: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        plot_area_min_ut: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        plot_area_max_ut: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        tower: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        uds_min: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        uds_max: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        uds_min_ut: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        uds_max_ut: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        no_of_floors: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        no_of_units_min: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        no_of_units_max: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        unit_type_min: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        unit_type_max: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        ownership_type: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        balcony: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        property_facing: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        kitchen_type: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        flooring: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        vasthu_compliant: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        currently_under_loan: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        available_from: {
            type: Sequelize.DATEONLY,
            allowNull: true,
        },
        site_visit_preference: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        key_custody: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        no_of_car: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        car_park_type: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        water_supply: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        gated_community: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        amenities: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        property_highlight: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        rera_registered: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        rera_number: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        completion_certificate: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        project_unit_type: {
            type: Sequelize.STRING(1000),
            allowNull: true,
        },
        specification: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        createdAt: {
            type: 'TIMESTAMP',
            allowNull: true,
            defaultValue: sequelize.literal('CURRENT_TIMESTAMP'),
            field: 'created_at'
        },
        updatedAt: {
            type: 'TIMESTAMP',
            allowNull: true,
            defaultValue: sequelize.literal('CURRENT_TIMESTAMP'),
            field: 'updated_at'
        },
    }, {
        tableName: 'lz_property_residentials'
    });
};