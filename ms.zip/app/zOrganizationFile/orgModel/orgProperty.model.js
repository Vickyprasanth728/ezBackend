module.exports = (sequelize, Sequelize) => {
    return sequelize.define("lz_properties", {
        org_id: {
            type: Sequelize.INTEGER,
            allowNull: true,
            validate: { isInt: true }
        },
        contact_id: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        available_for: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        assign_to: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        commission: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        property_indepth: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        segment: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        property_type: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        property_source: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        property_status: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        gst: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        invoice_name: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        legal_approval: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        description: {
            type: Sequelize.TEXT,
            allowNull: true,
        },
        profile_image: {
            type: Sequelize.STRING(1000),
            allowNull: true,
        },
        profile_image_original_name: {
            type: Sequelize.STRING(1000),
            allowNull: true,
        },
        created_by: {
            type: Sequelize.INTEGER,
            allowNull: true,
            validate: { isInt: true }
        },
        status: {
            type: Sequelize.INTEGER,
            allowNull: true,
            defaultValue: 1,
            validate: { isInt: true }
        },
        createdAt: {
            type: 'TIMESTAMP',
            allowNull: true,
            defaultValue: sequelize.literal('CURRENT_TIMESTAMP'),
            field: 'created_at'
        },
        updatedAt: {
            type: 'TIMESTAMP',
            allowNull: true,
            defaultValue: sequelize.literal('CURRENT_TIMESTAMP'),
            field: 'updated_at'
        },
    }, {
        tableName: 'lz_properties'
    });
};