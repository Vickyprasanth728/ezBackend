module.exports = (sequelize, Sequelize) => {
    return sequelize.define("lz_leads", {
      org_id: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      contact_id: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      property_id: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      looking_for: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      property_type: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      city: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      lead_source: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      lead_group: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      segment: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      lead_priority: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      fee_oppurtunity: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      lead_status: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      assign_to: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      zipcode: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      locality: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      sales_manager: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      created_by: {
        type: Sequelize.INTEGER,
        allowNull: true,
        validate : {isInt: true}
      },
      status: {
        type: Sequelize.INTEGER,
        allowNull: true,
        defaultValue:1,
        validate : {isInt: true}
      },
      createdAt: {
        type: 'TIMESTAMP',
        allowNull: true,
        defaultValue:sequelize.literal('CURRENT_TIMESTAMP'),
        field:'created_at'
      },
      updatedAt: {
        type: 'TIMESTAMP',
        allowNull: true,
        defaultValue:sequelize.literal('CURRENT_TIMESTAMP'),
        field:'updated_at'
      },
    },{
      tableName:'lz_leads'
    });
  };
  