module.exports = (sequelize, Sequelize) => {
    return sequelize.define("lz_property_commerical_retail", {
        property_id: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        situated_at: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        propery_suited_for: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        specify: {
            type: Sequelize.TEXT,
            allowNull: true,
        },
        total_project_build_up_area: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        total_project_build_up_area_ut: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        floor_plot_area: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        floor_plot_area_ut: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        building_structure: {
            type: Sequelize.TEXT,
            allowNull: true,
        },
        offered_floor: {
            type: Sequelize.TEXT,
            allowNull: true,
        },
        offered_area: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        offered_area_ut: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        furnishing: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        visibility: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        possession_status: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        age_of_property: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        no_of_cabins_min: { 
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        no_of_cabins_max: { 
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        washrooms: { 
            type: Sequelize.STRING,
            allowNull: true,
        },
        no_of_washrooms: { 
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        bike_parking: { 
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        car_parking: { 
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        work_hours: { 
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        work_hours_ut: { 
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        amenities: { 
            type: Sequelize.STRING,
            allowNull: true,
        },
        retail_unit_type: { 
            type: Sequelize.TEXT,
            allowNull: true,
        },
        createdAt: {
            type: 'TIMESTAMP',
            allowNull: true,
            defaultValue: sequelize.literal('CURRENT_TIMESTAMP'),
            field: 'created_at'
        },
        updatedAt: {
            type: 'TIMESTAMP',
            allowNull: true,
            defaultValue: sequelize.literal('CURRENT_TIMESTAMP'),
            field: 'updated_at'
        },
    }, {
        tableName: 'lz_property_commerical_retail'
    });
};