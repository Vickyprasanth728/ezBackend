const cors_ = {
    allowed_origins: '*'
};

module.exports = cors_;