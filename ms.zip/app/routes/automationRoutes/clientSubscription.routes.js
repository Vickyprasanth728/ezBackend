const authentication = require("../../middlewares/auth.js");

module.exports = app => {

    const auth = require("../../middlewares/auth");
    const client_subscription = require("../../controllers/automationControllers/clientSubscription.controller.js");
  
    var router = require("express").Router();
  
    router.post("/save/:document", authentication, client_subscription.create);
  
    router.get("/get/:document", authentication, client_subscription.findAll);

    // router.get("/get_razor_payment/:document/:transaction_id", authentication, client_subscription.getRazorPayment);

    router.get("/edit/:document/:id", authentication, client_subscription.findOne);

    router.get("/get_by_org/:document/:org_id", authentication, client_subscription.findOrgID);
  
    router.put("/update/:document/:id", authentication, client_subscription.update);

    router.put("/update_client_subscription_Status/:document/:id", authentication, client_subscription.updateClientSubscriptionStatus);
  
    router.put("/delete/:document/:id", authentication, client_subscription.delete);

    router.get("/plan_expire/:document/:id", authentication, client_subscription.planExpire);

    router.post("/save_org_susb/:document", authentication, client_subscription.createOrgSusb);

    app.use('/client_subscription/',auth, router);
  };
  