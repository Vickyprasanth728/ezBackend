const authentication = require("../../middlewares/auth.js");

module.exports = app => {
    const auth = require("../../middlewares/auth");
    const subscription = require("../../controllers/automationControllers/subscription.controller.js");
  
    var router = require("express").Router();
  
    router.post("/save/:document", authentication, subscription.create);
  
    router.get("/get/:document", authentication, subscription.findAll);
    
    router.get("/subscription_dropdown/:document", authentication, subscription.getSubscriptionDropdown);
  
    router.get("/edit/:document/:id", authentication, subscription.findOne);
  
    router.put("/update/:document/:id", authentication, subscription.update);
  
    router.put("/delete/:document/:id", authentication, subscription.delete);

    router.put("/update_subscription_status/:document/:id", authentication, subscription.updateSubscriptionStatus);
  
    app.use('/subscription/',auth, router);
  };
  