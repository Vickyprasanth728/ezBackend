-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 26, 2023 at 09:06 AM
-- Server version: 8.0.31
-- PHP Version: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `listeznewvriksha_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `postId` int NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lz_business_settings`
--

CREATE TABLE `lz_business_settings` (
  `id` int NOT NULL,
  `option_type` varchar(255) DEFAULT NULL,
  `option_value` varchar(255) DEFAULT NULL,
  `created_by` int NOT NULL,
  `status` int DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `lz_business_settings`
--

INSERT INTO `lz_business_settings` (`id`, `option_type`, `option_value`, `created_by`, `status`, `created_at`, `updated_at`) VALUES
(1, 'site_logo', '0f54b401cb10d1f7b7583a82d0aa430c.png', 1, 1, '2023-05-03 07:56:25', '2023-05-06 08:53:47'),
(2, 'site_favicon', 'fcfe604a07219b241d3f58897b2d1112.x-icon', 1, 1, '2023-05-03 07:56:29', '2023-05-11 05:39:02'),
(3, 'site_title', 'ListEz', 1, 1, '2023-05-03 07:56:34', '2023-05-11 05:39:02'),
(4, 'mail_driver', 'fnb', 1, 1, '2023-05-03 09:30:21', '2023-05-09 05:00:26'),
(5, 'mail_host', '345345wer', 1, 1, '2023-05-03 09:30:41', '2023-05-09 05:00:26'),
(6, 'mail_port', '4653454rewr', 1, 1, '2023-05-03 09:31:16', '2023-05-09 05:00:26'),
(7, 'mail_username', 'werwerwer', 1, 1, '2023-05-03 09:32:07', '2023-05-09 05:00:26'),
(8, 'mail_password', 'werwer', 1, 1, '2023-05-03 09:32:22', '2023-05-09 05:00:26'),
(9, 'mail_encryption', 'sslwerwer', 1, 1, '2023-05-03 09:32:46', '2023-05-09 05:00:26'),
(10, 'mail_from_address', 'werwerwe', 1, 1, '2023-05-03 09:33:00', '2023-05-09 05:00:26'),
(11, 'mail_from_name', 'werwerwer', 1, 1, '2023-05-03 09:33:09', '2023-05-09 05:00:26'),
(12, 'razor_key', 'rzp_test_nG8Ghnf8PfpxB6', 1, 1, '2023-05-03 09:33:26', '2023-05-08 10:05:39'),
(13, 'razor_secret', 'eaHKpjCa1pW2fZx5TZleJv4U', 1, 1, '2023-05-03 09:33:34', '2023-05-08 10:05:39'),
(14, 'stripe_key', 'stripe ke34534y', 1, 1, '2023-05-03 09:34:11', '2023-05-08 10:05:39'),
(15, 'stripe_secret', 'stripe Secre3453t', 1, 1, '2023-05-03 09:34:16', '2023-05-08 10:05:39'),
(16, 'payment_gateway', '1', 1, 1, '2023-05-03 09:34:16', '2023-05-08 10:05:39');

-- --------------------------------------------------------

--
-- Table structure for table `lz_city`
--

CREATE TABLE `lz_city` (
  `id` int NOT NULL,
  `country_id` int DEFAULT NULL,
  `state_id` int DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `status` int DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `lz_city`
--

INSERT INTO `lz_city` (`id`, `country_id`, `state_id`, `name`, `created_by`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 2, 'japkyo', 1, 1, '2023-04-29 12:21:05', '2023-04-29 12:21:05'),
(2, 1, 3, 'Chille', 2, 1, '2023-05-02 08:50:34', '2023-05-02 08:50:34'),
(3, 1, 2, 'ertertert', 1, 1, '2023-05-02 09:34:35', '2023-05-02 09:56:57'),
(4, 5, 5, 'rtertyrtyt', 1, 1, '2023-05-02 09:41:03', '2023-05-02 09:41:03'),
(5, NULL, 5, '4etertertet', 1, 1, '2023-05-02 09:42:47', '2023-05-02 09:42:47'),
(6, 4, 3, 'Ladakh', 1, 1, '2023-05-02 09:44:44', '2023-05-02 09:50:27'),
(7, 1, 1, 'Dunzo', 1, 1, '2023-05-05 07:00:54', '2023-05-05 07:00:54');

-- --------------------------------------------------------

--
-- Table structure for table `lz_client_subscription`
--

CREATE TABLE `lz_client_subscription` (
  `id` int NOT NULL,
  `org_id` int NOT NULL,
  `subscription_id` int NOT NULL,
  `paid_amount` decimal(20,4) NOT NULL,
  `start_date` datetime NOT NULL,
  `mode_of_payment` int DEFAULT NULL,
  `transaction_id` int DEFAULT NULL,
  `transaction_status` int DEFAULT '1',
  `transaction_time` timestamp NULL DEFAULT NULL,
  `no_of_days` int NOT NULL,
  `created_by` int NOT NULL,
  `status` int NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `lz_client_subscription`
--

INSERT INTO `lz_client_subscription` (`id`, `org_id`, `subscription_id`, `paid_amount`, `start_date`, `mode_of_payment`, `transaction_id`, `transaction_status`, `transaction_time`, `no_of_days`, `created_by`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 1, '599.0000', '2023-02-03 05:11:27', 1, 1, 1, '2023-05-10 11:44:01', 399, 1, 0, '2023-04-29 13:48:40', '2023-05-08 12:07:17'),
(2, 1, 1, '599.0000', '1900-01-08 17:58:32', 1, 1, 1, '0000-00-00 00:00:00', 0, 1, 1, '2023-04-29 13:49:27', '2023-05-08 12:18:30'),
(3, 2, 2, '599.0000', '2023-05-08 00:00:00', 2, 2, 1, '0000-00-00 00:00:00', 0, 2, 0, '2023-04-29 13:49:47', '2023-05-08 13:41:21'),
(4, 1, 1, '599.0000', '2023-05-09 00:00:00', 1, 1, 1, '0000-00-00 00:00:00', 0, 1, 1, '2023-04-29 13:50:26', '2023-05-08 13:19:25'),
(5, 1, 1, '599.0000', '2023-02-03 00:00:00', 1, 1, 1, '0000-00-00 00:00:00', 399, 1, 1, '2023-04-29 13:50:49', '2023-05-08 13:28:52'),
(6, 1, 1, '599.0000', '2023-02-01 00:00:00', 1, 1, 1, '0000-00-00 00:00:00', 399, 1, 1, '2023-04-29 13:52:19', '2023-04-29 13:52:19'),
(7, 1, 1, '599.0000', '2023-01-01 00:00:00', 1, 1, 1, '0000-00-00 00:00:00', 399, 1, 1, '2023-04-29 13:52:36', '2023-04-29 13:52:36'),
(8, 1, 1, '599.0000', '2023-01-01 00:00:00', 1, 1, 1, '0000-00-00 00:00:00', 399, 1, 1, '2023-04-29 13:52:51', '2023-04-29 13:52:51'),
(9, 1, 1, '599.0000', '2023-01-01 00:00:00', 1, 1, 1, '0000-00-00 00:00:00', 399, 2, 1, '2023-05-02 09:00:05', '2023-05-08 13:55:50'),
(10, 1, 1, '599.0000', '2023-01-01 00:00:00', 1, 1, 1, '0000-00-00 00:00:00', 399, 1, 0, '2023-05-02 09:00:37', '2023-05-02 10:23:53');

-- --------------------------------------------------------

--
-- Table structure for table `lz_country`
--

CREATE TABLE `lz_country` (
  `id` int NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `status` int DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `lz_country`
--

INSERT INTO `lz_country` (`id`, `name`, `created_by`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Japan', 1, 1, '2023-04-29 12:18:52', '2023-04-29 12:21:42'),
(2, 'china', 1, 0, '2023-04-29 12:18:59', '2023-04-29 12:18:59'),
(3, 'Usa', 1, 0, '2023-04-29 12:49:42', '2023-04-29 12:49:42'),
(4, 'china', 1, 1, '2023-04-29 12:50:00', '2023-04-29 12:50:00'),
(5, 'Moscow', 2, 1, '2023-05-02 08:45:01', '2023-05-02 08:45:01'),
(6, 'Russiaaaaaaaaaaa', 1, 1, '2023-05-02 09:18:18', '2023-05-02 09:18:36'),
(7, 'Domnica Republic', 1, 1, '2023-05-05 07:04:39', '2023-05-05 07:04:39');

-- --------------------------------------------------------

--
-- Table structure for table `lz_currency`
--

CREATE TABLE `lz_currency` (
  `id` int NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `symbol` varchar(255) NOT NULL,
  `created_by` int DEFAULT NULL,
  `status` int DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `lz_currency`
--

INSERT INTO `lz_currency` (`id`, `name`, `symbol`, `created_by`, `status`, `created_at`, `updated_at`) VALUES
(1, 'rupees', '', 2, 1, '2023-05-02 08:50:54', '2023-05-02 10:04:45'),
(3, 'Dollor', '$', 2, 1, '2023-05-02 10:00:07', '2023-05-02 10:10:09');

-- --------------------------------------------------------

--
-- Table structure for table `lz_language`
--

CREATE TABLE `lz_language` (
  `id` int NOT NULL,
  `lang` varchar(255) DEFAULT NULL,
  `lang_name` varchar(255) DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `status` int DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `lz_language`
--

INSERT INTO `lz_language` (`id`, `lang`, `lang_name`, `created_by`, `status`, `created_at`, `updated_at`) VALUES
(1, 'En', 'English', 1, 1, '2023-05-02 09:10:35', '2023-05-04 08:59:19'),
(2, 'Ni', 'Nimtha Fgc', 1, 1, '2023-05-02 13:04:09', '2023-05-08 10:27:19'),
(3, 'Ng', 'Nimmddaa Gojrass', 1, 0, '2023-05-02 13:08:35', '2023-05-02 13:16:05'),
(4, 'Ng', 'Kalakeya Language', 1, 0, '2023-05-02 13:08:52', '2023-05-02 13:16:03'),
(5, 'Hi', 'हिंदी', 1, 1, '2023-05-02 13:17:05', '2023-05-06 10:31:07'),
(6, 'He', 'Hindi 2', 1, 0, '2023-05-02 13:20:55', '2023-05-06 09:21:28'),
(7, 'Fr', 'French', 1, 0, '2023-05-05 06:21:42', '2023-05-06 10:32:12');

-- --------------------------------------------------------

--
-- Table structure for table `lz_masters`
--

CREATE TABLE `lz_masters` (
  `id` int NOT NULL,
  `option_type` varchar(255) NOT NULL,
  `option_value` varchar(255) NOT NULL,
  `created_by` int NOT NULL,
  `status` int DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `lz_masters`
--

INSERT INTO `lz_masters` (`id`, `option_type`, `option_value`, `created_by`, `status`, `created_at`, `updated_at`) VALUES
(1, 'age_of_property', 'wrewer', 1, 1, '2023-05-08 14:25:33', '2023-05-08 14:25:33'),
(2, 'age_of_property', '150', 1, 1, '2023-05-08 15:22:24', '2023-05-08 15:22:24'),
(3, 'age_of_property', 'rffsf', 1, 1, '2023-05-12 05:52:01', '2023-05-12 05:52:01'),
(4, 'age_of_property', '4545', 1, 1, '2023-05-12 05:52:06', '2023-05-12 05:52:06'),
(5, 'age_of_property', 'ffgfgfg', 1, 1, '2023-05-12 05:52:09', '2023-05-12 05:52:09'),
(6, 'age_of_property', 'gfgf', 1, 1, '2023-05-12 05:52:11', '2023-05-12 05:52:11');

-- --------------------------------------------------------

--
-- Table structure for table `lz_modules`
--

CREATE TABLE `lz_modules` (
  `id` int NOT NULL,
  `module_name` varchar(255) DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `status` int DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `lz_modules`
--

INSERT INTO `lz_modules` (`id`, `module_name`, `created_by`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Contact', 1, 1, '2023-04-29 13:14:52', '2023-04-29 13:22:51'),
(2, 'Dashboard', 1, 1, '2023-04-29 13:22:47', '2023-04-29 13:24:42');

-- --------------------------------------------------------

--
-- Table structure for table `lz_organization`
--

CREATE TABLE `lz_organization` (
  `id` int NOT NULL,
  `organization_name` varchar(255) DEFAULT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `sub_domain` varchar(255) DEFAULT NULL,
  `sub_domain_database_name` varchar(255) DEFAULT NULL,
  `phone_number` bigint DEFAULT NULL,
  `gst_number` varchar(255) DEFAULT NULL,
  `cin_number` varchar(255) DEFAULT NULL,
  `tan_number` varchar(255) DEFAULT NULL,
  `pan_number` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `city` int DEFAULT NULL,
  `state` int DEFAULT NULL,
  `country` int DEFAULT NULL,
  `currency` int DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `facebook_url` varchar(255) DEFAULT NULL,
  `linkindin_url` varchar(255) DEFAULT NULL,
  `twitter_url` varchar(255) DEFAULT NULL,
  `instagram_url` varchar(255) DEFAULT NULL,
  `youtube_url` varchar(255) DEFAULT NULL,
  `approval` int DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `water_mark` varchar(255) DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `status` int DEFAULT '1',
  `deleted_by` int DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `lz_organization`
--

INSERT INTO `lz_organization` (`id`, `organization_name`, `user_name`, `password`, `sub_domain`, `sub_domain_database_name`, `phone_number`, `gst_number`, `cin_number`, `tan_number`, `pan_number`, `address`, `city`, `state`, `country`, `currency`, `website`, `facebook_url`, `linkindin_url`, `twitter_url`, `instagram_url`, `youtube_url`, `approval`, `logo`, `water_mark`, `created_by`, `status`, `deleted_by`, `created_at`, `updated_at`) VALUES
(1, 'Listez', 'Listez Name', '$2b$10$7e/XWq.gzJdfkuSSNESzfuvEpu3ZGGXlyjTP.lbhragorsVldDtmC', '2', 'org1', 7894561230, '555555555555555', '987456321003214569870', '7410147741', '67Yu77yuhu', 'No:37 vba st', 1, 1, 2, 1, 'www.vtsone.com', 'www.facebook.com', 'www.linkin.com', 'www.twitter.com', 'www.instagram.com', 'www.youtube.com', 1, 'f1f7bda3f138bc7a37a83fa3f6624979.jpeg', '5ba94d49a51b44e2116243152ef6d943.png', 1, 1, 0, '2023-05-06 13:46:11', '2023-05-06 13:46:11'),
(2, 'Listez1111', 'Listez Name1111', '$2b$10$BslaTSH40N3Crovum9fbbuorYd/Tm4K6W637XwlvTjf3Iz4PEVFR6', '2', 'org1', 7894561230, '555555555555555', '987456321003214569870', '7410147741', '67Yu77yuhu', 'No:37 vba st', 1, 1, 2, 1, 'www.vtsone.com', 'www.facebook.com', 'www.linkin.com', 'www.twitter.com', 'www.instagram.com', 'www.youtube.com', 1, '7a0bae5f695c643ad2fb41262a93cba1.jpeg', 'e865c133c668bade0c357f01c7e2dcda.jpeg', 1, 0, 0, '2023-05-06 13:52:16', '2023-05-08 09:30:05'),
(3, 'erererwer', 'rtertertertert', '$2b$10$1zMuSTxFH82/i85aM9lLM.2LLH5eCMO9/xOznWJqE/xuHuk2zuiLa', NULL, NULL, 4545345345, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 1, 0, 0, '2023-05-08 09:02:42', '2023-05-09 08:56:46'),
(4, 'sgdhfjyurty', 'rrterterte', '$2b$10$NBQFI5db41UmvTOfp1/LS.8UNIFWmtPVjdGxGYQxlKO7CXu8WN7We', NULL, NULL, 54345345345, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 1, 0, 0, '2023-05-08 09:03:45', '2023-05-09 08:56:43'),
(5, '34534545', 'ertertertert', '$2b$10$NLDfPqYJqzECFrzrkJMn5ed4SQD6GP5E4rfQZk.TbTM5kKOk8fy8O', NULL, NULL, 34535345345, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 1, 0, 0, '2023-05-08 09:07:00', '2023-05-09 08:56:40'),
(6, 'ertertertert', 'ertertert', '$2b$10$iy7AVbRb5xxAwxznSou6Ju2353u32Qu/gzz9hpxf8kz6vRgkghp.a', NULL, NULL, 34534545353, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, 1, 0, 0, '2023-05-08 09:09:08', '2023-05-09 08:56:38'),
(7, 'werwerwerwer', 'erewrwewe', '$2b$10$XC2tZ7azvFY89YDjfQGHJejU8KVVIpSGwa6Nloh/h9nBrjgTrFIJ6', NULL, NULL, 45345345345, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 1, 0, 0, '2023-05-08 09:10:57', '2023-05-09 08:56:36'),
(8, 'ertrtertertertewerter45rterter', 'ertertertert', '$2b$10$sKcaW8.tKAYlxk/QczwOh.xG9FVKL4rCFQCY3NBNNvI31SPw3oNAe', NULL, NULL, 34545345345, '', '', '', '', NULL, 0, 0, 2, 0, '', '', '', '', '', '', 1, '83a801a15de3fe0396ce127ac1be6353.jpeg', '', 1, 0, 0, '2023-05-08 09:12:47', '2023-05-09 08:56:33'),
(9, 'tertertertetr', 'sgdfgerertert', '$2b$10$z7EpwVZYuFtkCh2bAMNmy.9rNCbFHio6cyG1s3R9qStHGjKGXNNmW', NULL, NULL, 45453454534545, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 1, 0, 0, '2023-05-08 09:14:58', '2023-05-08 09:55:13'),
(10, 'ertyerrtert', 'gfghgfhfgh', '$2b$10$kcTpYkNgB68vWhNL20rQ3.vkcN9DbuXLfIqAHDfvbzTJYD78pTUl2', NULL, NULL, 345345345, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 1, 0, 0, '2023-05-08 15:21:03', '2023-05-09 08:56:30'),
(11, 'eertertert', 'rrtertert', '$2b$10$nPtyrxLxjFDZYH0X3e2PoeoTw5j1ZjtyCS..9n5Rq6uoONwGrIwwW', NULL, NULL, 5345345534534, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, 1, 0, 0, '2023-05-09 05:57:37', '2023-05-09 08:56:26'),
(12, '6rtyrtyrty', 'tryytyre', '$2b$10$h6W17s9U8gxu9sOe1aZRN.m1P4dWL4bpBctOmiEPHw7uxOkQtxlx6', NULL, NULL, 6456456456, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 1, 0, 0, '2023-05-09 06:09:18', '2023-05-09 08:56:23'),
(13, '4535ertertertrter', 'rtretertertert', '$2b$10$wurwGdHUcKZAcFpUiTtKReEh9ntsUKq3z7lncM5rmCYEbknl.5Me6', NULL, NULL, 345345453454, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, 1, 0, 0, '2023-05-09 06:11:08', '2023-05-09 08:56:20'),
(14, 'ertyuerwerwer', 'retereyertert', '$2b$10$whd09Qb3D2XGSa2RGjRU2.7ulZpLEPSebqVY/H5zrQv2wnZDB14mK', NULL, NULL, 345345354345, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, '23babb0ef7b307dbeb66641a57529233.jpeg', 'f683183d54254fc266092a1c2eb50b41.jpeg', 1, 0, 0, '2023-05-09 06:14:12', '2023-05-09 08:56:13'),
(15, 'wterterter', 'erertertert', '$2b$10$uF95WiPL2oxVFqHATqKgauA/9LfjMG5mh.a3.1iJa7RGMsidc1e4y', NULL, NULL, 43534535345, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, 1, 0, 0, '2023-05-09 06:16:08', '2023-05-09 08:56:03'),
(16, 'fdrtergdfgdfg', 'etrgertertert', '$2b$10$MLTQYPFY3hKrXNsY4DSctu1svjkgf8UAM.chKd9/IfcdTYi18Ss5i', NULL, NULL, 56456456456, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 1, 0, 0, '2023-05-09 06:17:46', '2023-05-09 08:55:59'),
(17, 'fdhgfgjtyuty', 'rtrtyrtyrty', '$2b$10$24Gdu6YL91qLIerrOUb03.Q1h/EnpCDPWiJS.fLYcqmIIxa9aOFlq', NULL, NULL, 456456456456, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 1, 0, 0, '2023-05-09 06:24:21', '2023-05-09 08:55:56'),
(18, 'dhherrtytyr', 'ghhtyyery', '$2b$10$1bmpUPpTs3YbU5CT72qLNeFsvQoHGE6NPisoH86I1mX3HikZqeFzy', NULL, NULL, 4363456456, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, '4657b90cbc84550ec733dcf4e1fbd93e.jpeg', NULL, 1, 0, 0, '2023-05-09 06:25:03', '2023-05-09 08:55:52'),
(19, 'tyrrtyrtyrt', 'tyrtyrtytyry', '$2b$10$jgf4RMipk4mmUwqgYZAm8uzzAAvRvG3Wr7IVBJcycgLNpQCNcDCze', NULL, NULL, 4566456456, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 'a26ae57032a68f736239e84be283da51.jpeg', NULL, 1, 0, 0, '2023-05-09 06:28:18', '2023-05-09 08:55:45'),
(20, 'tertrterjtkrutgjrt', 'egrjhgerthgrytge', '$2b$10$uLr.ODOWhmxkZod3mKddCuWhm9NeCEzcuu2Ksj607DqVtkRgi6kZG', NULL, NULL, 57654536576, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, '9442e19d14fa7e6fe820572a615821a2.jpeg', NULL, 1, 0, 0, '2023-05-09 06:29:07', '2023-05-09 08:55:42'),
(21, 'rtrtertuytuetr', 'fgjiduyyretre', '$2b$10$pSQwdNq0jJo8urCGjj4mluAvueopi..JF/wjvhqHv9OgrBRal0Q1y', NULL, NULL, 75273453445, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, '3af71487e87133696d0ed82f58193f8e.jpeg', NULL, 1, 0, 0, '2023-05-09 06:30:20', '2023-05-09 08:55:37');

-- --------------------------------------------------------

--
-- Table structure for table `lz_roles`
--

CREATE TABLE `lz_roles` (
  `id` int NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `status` int DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `lz_roles`
--

INSERT INTO `lz_roles` (`id`, `name`, `created_by`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Cheif', 1, 0, '2023-04-29 13:59:02', '2023-04-29 13:59:45'),
(2, 'Manager', 1, 0, '2023-04-29 14:05:57', '2023-04-29 14:09:59'),
(3, 'TL', 1, 1, '2023-04-29 14:06:05', '2023-04-29 14:06:05'),
(4, 'Executive', 1, 1, '2023-04-29 14:06:14', '2023-04-29 14:06:14'),
(5, 'HR', 1, 1, '2023-04-29 14:06:22', '2023-04-29 14:06:22'),
(6, 'HR', 2, 0, '2023-04-29 14:19:45', '2023-04-29 14:20:15'),
(7, 'sales manager', 1, 1, '2023-05-02 05:33:15', '2023-05-02 05:33:15'),
(8, 'sales manager', 1, 1, '2023-05-02 09:04:06', '2023-05-02 09:04:06');

-- --------------------------------------------------------

--
-- Table structure for table `lz_settings`
--

CREATE TABLE `lz_settings` (
  `id` int NOT NULL,
  `option_type` varchar(255) NOT NULL,
  `option_value` varchar(255) NOT NULL,
  `created_by` int NOT NULL,
  `status` int DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lz_state`
--

CREATE TABLE `lz_state` (
  `id` int NOT NULL,
  `country_id` int DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `status` int DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `lz_state`
--

INSERT INTO `lz_state` (`id`, `country_id`, `name`, `created_by`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 'Tokyo', 1, 1, '2023-04-29 12:19:19', '2023-04-29 12:19:19'),
(2, 3, 'punjab', 2, 1, '2023-05-02 08:49:52', '2023-05-02 08:49:52'),
(3, 5, 'ertert435453', 1, 1, '2023-05-02 09:19:31', '2023-05-02 09:31:50'),
(4, 5, '4454resffeqer', 1, 1, '2023-05-02 09:40:33', '2023-05-02 09:40:39'),
(5, 4, 'rtertertert', 1, 1, '2023-05-02 09:40:55', '2023-05-02 09:41:59');

-- --------------------------------------------------------

--
-- Table structure for table `lz_subscription`
--

CREATE TABLE `lz_subscription` (
  `id` int NOT NULL,
  `subscription_name` varchar(255) NOT NULL,
  `amount` decimal(20,4) NOT NULL,
  `no_of_days` int NOT NULL,
  `created_by` int NOT NULL,
  `status` int NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `lz_subscription`
--

INSERT INTO `lz_subscription` (`id`, `subscription_name`, `amount`, `no_of_days`, `created_by`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Startup Plan ', '399.0000', 30, 1, 0, '2023-05-05 12:53:23', '2023-05-26 05:47:36'),
(2, 'May Plan1', '1998.0000', 159, 1, 1, '2023-05-05 12:53:43', '2023-05-08 14:25:47'),
(3, 'Pro plan', '5999.0000', 112, 1, 0, '2023-05-08 14:23:52', '2023-05-08 14:24:44'),
(4, 'May Plan1', '5999.0000', 365, 1, 1, '2023-05-26 05:46:37', '2023-05-26 05:46:37');

-- --------------------------------------------------------

--
-- Table structure for table `lz_support_ticket`
--

CREATE TABLE `lz_support_ticket` (
  `id` int NOT NULL,
  `org_id` int DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `priority` int DEFAULT NULL,
  `description` text,
  `created_by` int DEFAULT NULL,
  `ticket_status` int DEFAULT NULL,
  `status` int DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `lz_support_ticket`
--

INSERT INTO `lz_support_ticket` (`id`, `org_id`, `title`, `priority`, `description`, `created_by`, `ticket_status`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 'title22', 6, 'longgggggggggggggggggggggggggggggggggggggggggggg', 1, 4, 1, '2023-04-29 14:33:24', '2023-05-04 09:50:18'),
(2, 1, 'titleerqerqe', 5, 'longrgrrgrrgregergergrergr', 1, 4, 1, '2023-04-29 14:42:48', '2023-05-04 09:50:51'),
(3, 1, 'titleerqerqe', 6, 'longrgrrgrrgregergergrergr', 1, 3, 1, '2023-04-29 14:43:04', '2023-04-29 14:43:04'),
(4, 1, 'HR', 5, 'yuffvg', 1, 4, 1, '2023-04-29 14:51:25', '2023-05-04 09:50:59'),
(5, 1, 'check title', 6, 'check des', 1, 2, 1, '2023-05-02 09:06:05', '2023-05-02 09:06:05');

-- --------------------------------------------------------

--
-- Table structure for table `lz_templates`
--

CREATE TABLE `lz_templates` (
  `id` int NOT NULL,
  `template_name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `template_content` varchar(255) NOT NULL,
  `created_by` int NOT NULL,
  `status` int DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `lz_templates`
--

INSERT INTO `lz_templates` (`id`, `template_name`, `slug`, `template_content`, `created_by`, `status`, `created_at`, `updated_at`) VALUES
(1, 'ONce UpON A TiME', 'once-upon-a-time', 'template_content', 1, 1, '2023-05-03 11:16:15', '2023-05-03 11:16:15');

-- --------------------------------------------------------

--
-- Table structure for table `lz_translations`
--

CREATE TABLE `lz_translations` (
  `id` int NOT NULL,
  `lang` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lang_key` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `lang_value` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_by` int NOT NULL,
  `status` int NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lz_translations`
--

INSERT INTO `lz_translations` (`id`, `lang`, `lang_key`, `lang_value`, `created_by`, `status`, `created_at`, `updated_at`) VALUES
(1, 'en', 'lead', 'lead', 0, 1, '2023-05-08 14:32:45', '2023-05-05 06:35:03'),
(2, 'en', 'dashboard', 'Dashboard', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(3, 'en', 'organization', 'Organization', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(5, 'en', 'users_management', 'Users Management', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(6, 'en', 'settings', 'Settings', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(7, 'en', 'admin_name', 'Admin Name', 0, 1, '2023-05-06 10:36:49', '2023-05-05 06:35:03'),
(8, 'en', 'branch_details', 'Branch Details', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(9, 'en', 'meeting', 'Meeting', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(10, 'en', 'facebook', 'Facebook', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(11, 'en', 'linkedin', 'Linkedin', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(12, 'en', 'twitter', 'Twitter', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(13, 'en', 'youtube', 'Youtube', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(14, 'en', 'created_date', 'Created Date', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(15, 'en', 'manage_user', 'Manage User', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(16, 'en', 'instagram', 'Instagram', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(17, 'en', 'user_charts', 'User Charts', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(18, 'en', 'performance', 'Performance', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(19, 'en', 'attendance', 'Attendance', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(20, 'en', 'manage_teams', 'Manage Teams', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(21, 'en', 'time_sheets', 'Time Sheets', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(22, 'en', 'designation', 'Designation', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(23, 'en', 'site_visit', 'Site Visit', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(24, 'en', 'under_construction', 'Under Construction', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(25, 'en', 'profile_setting', 'Profile Setting', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(26, 'en', 'role_setting', 'Role Setting', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(27, 'en', 'id', 'Id', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(28, 'en', 'department', 'Department', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(29, 'en', 'actions', 'Actions', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(30, 'en', 'follow_up_call', 'Follow Up Calls', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(31, 'en', 'report_to', 'Report To', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(32, 'en', 'name', 'Name', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(33, 'en', 'view', 'View', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(34, 'en', 'edit', 'Edit', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(35, 'en', 'delete', 'Delete', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(36, 'en', 'archive', 'Archive', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(37, 'en', 'master_field', 'Master Field', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(38, 'en', 'master_field_mapping', 'Master Field Mapping', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(39, 'en', 'search_masters', 'Search Masters', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(40, 'en', 'age_of_property', 'Age of Property', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(41, 'en', 'masters', 'Masters', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(42, 'en', 'create', 'Create', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(43, 'en', 'localizations', 'Localizations', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(44, 'en', 'country', 'Country', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(45, 'en', 'translations', 'Translations', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(46, 'en', 'language', 'Language', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(47, 'en', 'lead_created_date', 'Lead Created Date', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(48, 'en', 'integrations', 'Integrations', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(49, 'en', 'members', 'Members', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(50, 'en', 'templates', 'Templates', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(51, 'en', 'sms', 'SMS', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(52, 'en', 'whatsapp', 'Whatsapp', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(53, 'en', 'lead_booked_date', 'Lead Booked Date', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(54, 'en', 'mail_field', 'Mail Field', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(55, 'en', 'title', 'Title', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(56, 'en', 'from', 'From', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(57, 'en', 'subject', 'Subject', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(58, 'en', 'module', 'Module', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(59, 'en', 'deal_closed_by', 'Deal Closed By', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(60, 'en', 'save', 'Save', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(61, 'en', 'search', 'Search', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(62, 'en', 'start_time', 'Start Time', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(63, 'en', 'end_time', 'End Time', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(64, 'en', 'ceated_at', 'Ceated At', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(65, 'en', 'released_amount', 'Released Amount', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(66, 'en', 'admin', 'Admin', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(67, 'en', 'notifications', 'Notifications', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(68, 'en', 'sign_out', 'Sign Out', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(69, 'en', 'no_notifications', 'No Notifications', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(70, 'en', 'undefined_undefined', 'Undefined Undefined', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(71, 'en', 'overview', 'Overview', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(72, 'en', 'profile_details', 'Profile Details', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(73, 'en', 'edit_profile', 'Edit Profile', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(74, 'en', 'employee_id', 'Employee Id', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(75, 'en', 'branch', 'Branch', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(76, 'en', 'personal_contact_number', 'Personal Contact  Number', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(77, 'en', 'full_name', 'Full Name', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(78, 'en', 'emergency_contact_number', 'Emergency Contact Number', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(79, 'en', 'official_contact_number', 'Official Contact Number', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(80, 'en', 'official_mail', 'Official Mail', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(81, 'en', 'aadhar_number', 'Aadhar Number', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(82, 'en', 'pan_number', 'PAN Number', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(83, 'en', 'date_of_birth', 'Date of Birth', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(84, 'en', 'past_employment_history', 'Past Employment History', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(85, 'en', 'date_of_joining', 'Date of Joining', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(86, 'en', 'permenent_address', 'Perment Address', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(87, 'en', 'correspondant_address', 'Correspondant Address', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(88, 'en', 'listez', 'ListEz', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(89, 'en', 'sign_in_to_listez', 'Sign In To ListEz', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(90, 'en', 'password', 'Password', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(91, 'en', 'forgot_password', 'Forgot Password', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(92, 'en', 'login', 'Login', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(93, 'en', 'edit_organization', 'Edit Organization', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(94, 'en', 'email', 'Email', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(95, 'en', 'organization_details', 'Organization Details', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(96, 'en', 'organization_name', 'Organization Name', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(97, 'en', 'phone', 'Phone', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(98, 'en', 'gst_number', 'GST Number', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(99, 'en', 'cin_number', 'CIN Number', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(100, 'en', 'tan_number', 'TAN Number', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(101, 'en', 'billed_amount', 'Billed Amount', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(102, 'en', 'registered_address', 'Registered Address', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(103, 'en', 'state', 'State', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(104, 'en', 'percent', 'Percent', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(105, 'en', 'paid_amount', 'Paid Amount', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(106, 'en', 'currency', 'Currency', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(107, 'en', 'approval', 'Approval', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(108, 'en', 'last_name', 'Last Name', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(109, 'en', 'social_media_links', 'Social Media Links', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(110, 'en', 'submit', 'Submit', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(111, 'en', 'avatar', 'Avatar', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(112, 'en', 'first_name', 'First Name', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(113, 'en', 'official_mobile_number', 'Official Mobile Number', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(114, 'en', 'sign_in_method', 'Sign In Method', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(115, 'en', 'save_changes', 'Save Changes', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(116, 'en', 'enter_your_email_to_reset_your_password', 'Enter Your Email To Reset Your Password', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(117, 'en', 'add_contact', 'Add Contact', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(118, 'en', 'please_wait', 'Please Wait', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(119, 'en', 'source', 'Source', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(120, 'en', 'project_name', 'Project Name', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(121, 'en', 'contact_group', 'Contact Group', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(122, 'en', 'contact_type', 'Contact Type', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(123, 'en', 'contact_category', 'Contact Category', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(124, 'en', 'if_yes_transaction_id', 'if Yes Transactions ID', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(125, 'en', 'company_name', 'Company Name', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(126, 'en', 'assign_to', 'Assign To', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(127, 'en', 'is_secondary_contact', 'Is Secondary Contact', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(128, 'en', 'developer_name', 'Developer Name', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(129, 'en', 'secondary_contact', 'Secoundary Contact', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(130, 'en', 'address_details', 'Address Details', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(131, 'en', 'address_line_1', 'Address Line 1', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(132, 'en', 'address_line_2', 'Address Line 2', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(133, 'en', 'locality', 'Locality', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(134, 'en', 'billable', 'Billable', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(135, 'en', 'zip_code', 'Zip Code', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(136, 'en', 'country_code', 'Country Code', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(137, 'en', 'more_details', 'More Details', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(138, 'en', 'invoice_name', 'Invoice Name', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(139, 'en', 'team_member', 'Team Member', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(140, 'en', 'national_id', 'National Id', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(141, 'en', 'do_not_disturb', 'Do Not Disturb', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(142, 'en', 'marital_status', 'Marital Status', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(143, 'en', 'gender', 'Gender', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(144, 'en', 'no_of_children', 'No.of Children', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(145, 'en', 'wedding_anniversary', 'Weding Anniversary', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(146, 'en', 'nationality', 'Nationality', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(147, 'en', 'd_o_b', 'D.O.B', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(148, 'en', 'pet_owner', 'Pet Owner', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(149, 'en', 'id_number', 'Id Number', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(150, 'en', 'social_links', 'Social Links', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(151, 'en', 'remarks', 'Remarks', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(152, 'en', 'total', 'Total', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(153, 'en', 'add', 'Add', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(154, 'en', 'sort_by', 'Sort By', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(155, 'en', 'personal_id_documents', 'Personal Id Documents', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(156, 'en', 'grid_view', 'Grid View', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(157, 'en', 'action', 'Action', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(158, 'en', 'created_ascending', 'Created Ascending', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(159, 'en', 'created_descending', 'Created Descending', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(160, 'en', 'updated_ascending', 'Updated Ascending', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(161, 'en', 'updated_descending', 'Updated Descending', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(162, 'en', 'list_view', 'List View', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(163, 'en', 'client_name', 'Client Name', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(164, 'en', 'contact_no', 'Contact No', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(165, 'en', 'caimpaign_name', 'Caimpaign Name', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(166, 'en', 'last_note', 'Last Note', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(167, 'en', 'last_task_date', 'Last Task Date', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(168, 'en', 'next_task_date', 'Next Task Date', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(169, 'en', 'export', 'Export', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(170, 'en', 'import', 'Import', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(171, 'en', 'contact_filter', 'Contact Filter', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(172, 'en', 'property', 'Property', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(173, 'en', 'group', 'Group', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(174, 'en', 'include_archived_records', 'Include Archived Records', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(175, 'en', 'reset', 'Reset', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(176, 'en', 'filter', 'Filter', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(177, 'en', 'due_amount', 'Due Amount', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(178, 'en', 'add_lead', 'Add Lead', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(179, 'en', 'contact_person', 'Contact Person', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(180, 'en', 'looking_for', 'Looking For', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(181, 'en', 'segment', 'Segment', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(182, 'en', 'property_type', 'Property Type', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(183, 'en', 'sales_manager', 'Sales Manager', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(184, 'en', 'lead_priority', 'Lead Priority', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(185, 'en', 'lead_source', 'Lead Source', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(186, 'en', 'lead_group', 'Lead Group', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(187, 'en', 'invoice_id', 'Invoice ID', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(188, 'en', 'requirement', 'Requirement', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(189, 'en', 'bedrooms', 'Bedrooms', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(190, 'en', 'project_facing', 'Project Facing', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(191, 'en', 'bathrooms', 'Bathrooms', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(192, 'en', 'budget_range', 'Budget Range', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(193, 'en', 'opportunity_value', 'Opportunity Value', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(194, 'en', 'built_area_range', 'Built Area Range', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(195, 'en', 'plot_area_range', 'Plot Area Range', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(196, 'en', 'no_of_car_park', 'No.of Car Park', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(197, 'en', 'timeline_for_closure', 'Timeline For Closure', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(198, 'en', 'requirement_locations', 'Requirement Locations', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(199, 'en', 'vasthu_feng_sui_compliant', 'Vasthu / Feng Sui Compliant', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(200, 'en', 'amenities', 'Amenities', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(201, 'en', 'furnishing_status', 'Furnishing Status', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(202, 'en', 'posession_status', 'Posession Status', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(203, 'en', 'priority_high_low', 'Priority High - Low', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(204, 'en', 'priority_low_high', 'Priority Low - High', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(205, 'en', 'contact_number', 'Contact Number', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(206, 'en', 'brokerage_row_data', 'Brokerage rowData', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(207, 'en', 'location', 'Location', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(208, 'en', 'bedroom_min', 'Bedroom Min', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(209, 'en', 'builtup_area_max', 'Builtup Area Max', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(210, 'en', 'builtup_area_min', 'Builtup Area Min', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(211, 'en', 'bedroom_max', 'Bedroom Max', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(212, 'en', 'budget_min', 'Budget Min', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(213, 'en', 'budget_max', 'Budget Max', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(214, 'en', 'posession', 'Posession', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(215, 'en', 'last_called_date', 'Last Called Date', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(216, 'en', 'next_calling_date', 'Next Calling Date', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(217, 'en', 'price_range', 'Price Range', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(218, 'en', 'builtup_area_range', 'Builtup Area Range', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(219, 'en', 'want_to_save_filter', 'Want To Save Filter', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(220, 'en', 'no', 'No', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(221, 'en', 'yes', 'Yes', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(222, 'en', 'filter_name', 'Filter Name', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(223, 'en', 'success', 'Success', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(224, 'en', 'transaction_id', 'Transaction ID', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(225, 'en', 'lead_created_successfully', 'Lead Created Successfully', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(226, 'en', 'contact_filtered_reset_successfully', 'Contact Filtered Reset Successfully', 0, 1, '2023-05-08 10:29:45', '2023-05-05 06:35:03'),
(227, 'en', 'mode', 'Mode', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(228, 'en', 'add_project', 'Add Project', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(229, 'en', 'available_for', 'Available for', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(230, 'en', 'commission', 'Commission', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(231, 'en', 'gst', 'GST', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(232, 'en', 'invoicing_name', 'Invoicing Name', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(233, 'en', 'property_indepth', 'Property Indepth', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(234, 'en', 'property_source', 'Property Source', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(235, 'en', 'legal_approval', 'Legal Approval', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(236, 'en', 'project_address', 'Project Address', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(237, 'en', 'property_status', 'Property Status', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(238, 'en', 'name_of_building', 'Name of Building', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(239, 'en', 'module_number', 'Module Number', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(240, 'en', 'pending_receivable_amount', 'Pending Receivable Amount', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(241, 'en', 'latitude', 'Latitude', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(242, 'en', 'longitude', 'Longitude', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(243, 'en', 'project_stage', 'Project Stage', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(244, 'en', 'age_of_project', 'Age of Project', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(245, 'en', 'furnishing', 'Furnishing', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(246, 'en', 'project_tower', 'Project Tower', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(247, 'en', 'u_d_s', 'UDS', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(248, 'en', 'no_of_floors', 'No of Floors', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(249, 'en', 'ownership_type', 'Ownership Type', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(250, 'en', 'no_of_balcony', 'No of Balcony', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(251, 'en', 'project_features', 'Project Features', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(252, 'en', 'kitchen_type', 'Kitchen Type', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(253, 'en', 'flooring', 'Flooring', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(254, 'en', 'vasthu_compliant', 'Vasthu Compliant', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(255, 'en', 'currenty_under_loan', 'Currenty Under Loan', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(256, 'en', 'available_from', 'Available From', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(257, 'en', 'site_visit_preferences', 'Site Visit Preferences', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(258, 'en', 'key_custody', 'Key Custody', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(259, 'en', 'car_park_type', 'Car Park Type', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(260, 'en', 'water_supply', 'Water Supply', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(261, 'en', 'agenda', 'Agenda', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(262, 'en', 'property_highlight', 'Property Highlight', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(263, 'en', 'rera_registered', 'RERA Registered', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(264, 'en', 'total_term', 'Total Term', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(265, 'en', 'project_plot_area', 'Project Plot Area', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(266, 'en', 'unit_type', 'Unit Type', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(267, 'en', 'builtup_area', 'Builtup Area', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(268, 'en', 'total_no_of_units', 'Total No of Units', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(269, 'en', 'local_currency', 'Local Currency', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(270, 'en', 'sale_price', 'Sale Price', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(271, 'en', 'description', 'Description', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(272, 'en', 'project_images_floor_plan_documents', 'Project Images Floor Plan Documents', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(273, 'en', 'tds_amount_2', 'TDS Amount2', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(274, 'en', 'contact_name', 'Contact Name', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(275, 'en', 'project_filter', 'Project Filter', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(276, 'en', 'after_tds_brokerage_5', 'After TDS Brokerage5', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(277, 'en', 'agent_source', 'Agent Source', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(278, 'en', 'tds_deducted_by_builder_3', 'TDS % Deducted by Builder3', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(279, 'en', 'facing', 'Facing', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(280, 'en', 'vasthu', 'Vasthu', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(281, 'en', 'no_of_units', 'No of Units', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(282, 'en', 'floors', 'Floors', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(283, 'en', 'property_created_successfully', 'Property Created Successfully', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(284, 'en', 'upload_files_here', 'Upload Files Here', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(285, 'en', 'transaction', 'Transaction', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(286, 'en', 'add_transaction', 'Add Transaction', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(287, 'en', 'select_lead', 'Select Lead', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(288, 'en', 'booking_date', 'Booking Date', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(289, 'en', 'team_leader', 'Team Leader', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(290, 'en', 'f_r_c', 'FRC', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(291, 'en', 'gross_brokerage_value_2', 'Gross Brokerage Value2', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(292, 'en', 'unit_number', 'Unit Number', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(293, 'en', 'floor_number', 'Floor Number', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(294, 'en', 'b_h_k_type', 'BHK Type', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(295, 'en', 'unit_size', 'Unit Size', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(296, 'en', 'basic_price', 'Basic Price', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(297, 'en', 'tower_block_no_name', 'Tower/Block (No./Name)', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(298, 'en', 'p_l_c', 'PLC', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(299, 'en', 'car_parking_cost', 'Car Parking Cost', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(300, 'en', 'agreement_value', 'Agreement Value', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(301, 'en', 'brokerage', 'Brokerage %', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(302, 'en', 'a_o_p', 'AOP %', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(303, 'en', 'brokerage_value', 'Brokerage Value', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(304, 'en', 'discount_if_any', 'Discount % (if any)', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(305, 'en', 'discount_amount', 'Discount Amount', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(306, 'en', 't_d_s_value', 'TDS Value @ 5%', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(307, 'en', 'discount_paid', 'Discount Paid', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(308, 'en', 'revenue', 'Revenue', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(309, 'en', 'task', 'Task', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(310, 'en', 'add_task', 'Add Task', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(311, 'en', 'task_details', 'Task Details', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(312, 'en', 'task_type', 'Task Type', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(313, 'en', 'priority', 'Priority', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(314, 'en', 'task_name', 'Task Name', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(315, 'en', 'finish_time', 'Finish Time', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(316, 'en', 'select_contact', 'Select Contact', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(317, 'en', 'task_status', 'Task Status', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(318, 'en', 'task_description', 'Task Description', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(319, 'en', 'month', 'Month', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(320, 'en', 'week', 'Week', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(321, 'en', 'day', 'Day', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(322, 'en', 'task_filter', 'Task Filter', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(323, 'en', 'finance', 'Finance', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(324, 'en', 'proforma_invoice', 'Proforma Invoice', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(325, 'en', 'invoice', 'Invoice', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(326, 'en', 'collection', 'Collection', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(327, 'en', 'expenses', 'Expenses', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(328, 'en', 'incentive', 'Incentive', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(329, 'en', 'cashback', 'Cashback', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(330, 'en', 'no_transactions_available', 'No Transactions Available', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(331, 'en', 'no_fee_confirmations_available', 'No Fee Confirmations Available', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(332, 'en', 'no_proforma_invoices_available', 'No Proforma Invoices Available', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(333, 'en', 'fee_confirmation', 'Fee Confirmation', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(334, 'en', 'no_expenses_available', 'No Expenses Available', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(335, 'en', 'no_incentives_available', 'No Incentives Available', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(336, 'en', 'no_cashback_available', 'No Cashback Available', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(337, 'en', 'add_proforma_invoice', 'Add Proforma Invoice', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(338, 'en', 'tax', 'Tax', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(339, 'en', 'no_invoices_available', 'No Invoices Available', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(340, 'en', 'no_collections_available', 'No Collections Available', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(341, 'en', 'due_date', 'Due Date', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(342, 'en', 'total_amount', 'Total Amount', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(343, 'en', 'message', 'Message', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(344, 'en', 'file', 'File', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(345, 'en', 'report', 'Report', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(346, 'en', 'favorite', 'Favorite', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(347, 'en', 'gst_amount_2', 'GST Amount2', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(348, 'en', 'call', 'Call', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(349, 'en', 'i_gst_4', 'I GST %4', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(350, 'en', 'hr', 'HR', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(351, 'en', 'lead_report', 'Lead Report', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(352, 'en', 'c_gst_3', 'C GST %3', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(353, 'en', 'transaction_report', 'Transaction Report', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(354, 'en', 'site_visit', 'Site Visit', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(355, 'en', 'project_wise_lead_report', 'Project Wise Lead Report', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(356, 'en', 'city_wise_lead_report', 'City Wise Lead Report', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(357, 'en', 'lead_stage_report', 'Lead Stage Report', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(358, 'en', 'lead_source_report', 'Lead Source Report', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(359, 'en', 'lead_group_chart', 'Lead Group Chart', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(360, 'en', 'builder_wise_revenue_report', 'Builder Wise Revenue Report', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(361, 'en', 'lead_by_property_type', 'Lead By Property Type', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(362, 'en', 'lead_budget_wise', 'Lead Budget Wise', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(363, 'en', 'lead_campaign_wise', 'Lead Campaign Wise', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(364, 'en', 'lost_lead', 'Lost Lead', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(365, 'en', 'lead_reassignment_report', 'Lead Reassignment Report', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(366, 'en', 'lead_task_report', 'Lead Task Report', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(367, 'en', 'lead_cost_report', 'Lead Cost Report', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(368, 'en', 'citywise_leads_report', 'Citywise Leads Report', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(369, 'en', 'lead_registration_report', 'Lead Registration Report', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(370, 'en', 'project_wise_report', 'Project Wise Report', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(371, 'en', 'opportunity_value_report', 'Opportunity Value Report', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(372, 'en', 'transaction_source_report', 'Transaction Source Report', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(373, 'en', 'incoming_calls', 'Incoming Calls', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(374, 'en', 'outgoing_reports', 'Outgoing Reports', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(375, 'en', 'site_inspection_report', 'Site Inspection Report', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(376, 'en', 'city_wise_project_report', 'City Wise Project Report', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(377, 'en', 'builder_wise_report', 'Builder Wise Report', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(378, 'en', 'configuration_wise_report', 'Configurations Wise Report', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(379, 'en', 'property_type_wise_report', 'Property Type Wise Report', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(380, 'en', 'project_status_report', 'Project Status Report', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(381, 'en', 'citywise_transaction_report', 'Citywise Transaction Report', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(382, 'en', 'task_status_report', 'Task Status Report', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(383, 'en', 'project_segment', 'Project Segment', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(384, 'en', 'task_type_report', 'Task Type Report', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(385, 'en', 'invoice_created_report', 'Invoice Created Report', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(386, 'en', 'project_wise_invoice_report', 'Project Wise Invoice Report', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(387, 'en', 'collection_report', 'Collection Report', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(388, 'en', 'collection_mode_report', 'Collections Mode Report', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(389, 'en', 'user_location', 'User Location', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(390, 'en', 'leave_type_report', 'Leave Type Report', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(391, 'en', 'expenses_report', 'Expenses Report', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(392, 'en', 'user_demographic_report', 'User Demographic Report', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(393, 'en', 'reach_out_to_mahipal_rajpurohit_on', 'Reach out to Mahipal Rajpurohit on', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(394, 'en', 'attendance_report', 'Attendance Report', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(395, 'en', 'alerts_template', 'Alerts Template', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(396, 'en', 'lock_in', 'Lock In', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(397, 'en', 'for_any_queries_or_feedbacks', 'for any queries or feedbacks', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(398, 'en', 'have_some_questions', 'Have Some Questions', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(399, 'en', 'alerts_notification_settings', 'Alerts & Notification Settings', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(400, 'en', 'we_are_all', 'We\'re All', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(401, 'en', 'escalation', 'Escalation', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(402, 'en', 'security_deposit', 'Security Deposit', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(403, 'en', 'cc', 'CC', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(404, 'en', 'parking_charges', 'Parking Charges', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(405, 'en', 'maintainance', 'Maintainance', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(406, 'en', 'quoted_rent_price', 'Quoted Rent Price', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(407, 'en', 'commercial_conventional', 'Commercial Conventional', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(408, 'en', 'theme_builder', 'Theme Builder', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(409, 'en', 'theme_setup', 'Theme Setup', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(410, 'en', 'tertiary', 'Tertiary', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(411, 'en', 'my_profile', 'My Profile', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(412, 'en', 'lead_reg_date', 'Lead Reg Date', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(413, 'en', 'module_setting', 'Module Setting', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(414, 'en', 'contact', 'Contact', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(415, 'en', 'primary', 'Primary', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(416, 'en', 'secondary', 'Secondary', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(417, 'en', 's_gst_2', 'S GST %2', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(418, 'en', 'pending_brokerage', 'Pending Brokerage', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(419, 'en', 'amount_recevied', 'Amount Recevied', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(420, 'en', 'receiving_date', 'Receiving Date', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(421, 'en', 'savefilters', 'Savefilters', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(422, 'en', 'current_password', 'Current Password', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(423, 'en', 'new_password', 'New Password', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(424, 'en', 'confirm_new_password', 'Confirm New Password', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(425, 'en', 'email_address', 'Email Address', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(426, 'en', 'update_password', 'Update Password', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(427, 'en', 'cancel', 'Cancel', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(428, 'en', 'password_must_be_at_least_8_character_and_contain_symbols', 'Password Must Be At Least 8 Character And Contain Symbols', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(429, 'en', 'today', 'Today', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(430, 'en', 'yesterday', 'Yesterday', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(431, 'en', 'last_week', 'Last Week', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(432, 'en', 'last_month', 'Last Month', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(433, 'en', 'this_year', 'This Year', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(434, 'en', 'this_month', 'This Month', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(435, 'en', 'custom_date', 'Custom Date', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(436, 'en', 'type', 'Type', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(437, 'en', 'category', 'Category', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(438, 'en', 'city', 'City', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(439, 'en', 'payment_status', 'Payment Status', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(440, 'en', 'pending', 'Pending %', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(441, 'en', 'company', 'Company', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(442, 'en', 'raised', 'Raised %', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(443, 'en', 'propert_type', 'Project Type', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(444, 'en', 'property_name', 'Property Name', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(445, 'en', 'invoice_status', 'Invoice Status', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(446, 'en', 'status_changed', 'Status Changed', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(447, 'en', 'lead_generated', 'Lead Generated', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(448, 'en', 'goal', 'Goal', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(449, 'en', 'customer_null', 'Customer Null', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(450, 'en', 'additional_information', 'Additional Information', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(451, 'en', 'transactions', 'Transactions', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(452, 'en', 'tasks_overview', 'Tasks Overview', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(453, 'en', 'notes', 'Notes', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(454, 'en', 'contact_address', 'Contact Address', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(455, 'en', 'messages', 'Messages', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(456, 'en', 'add_note', 'Add Note', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(457, 'en', 'notes_list', 'Notes List', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(458, 'en', 'project_builtup_area', 'Project Builtup Area', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(459, 'en', 'project_highlight', 'Project Highlight', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(460, 'en', 'rera_number', 'RERA Number', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(461, 'en', 'files', 'Files', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(462, 'en', 'user_id', 'User Id', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(463, 'en', 'user_name', 'User Name', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(464, 'en', 'module_name', 'Module Name', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(465, 'en', 'note', 'Note', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(466, 'en', 'net_incentive_earned', 'Net Incentive Earned', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(467, 'en', 'created_by', 'Created By', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(468, 'en', 'block_no', 'Block No', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(469, 'en', 'closed_by', 'Closed By', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(470, 'en', 'collected', 'Collected', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(471, 'en', 'due', 'Due', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(472, 'en', 'updated_date', 'Updated Date', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(473, 'en', 'shared_with', 'Shared With', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(474, 'en', 'team_leader_shared_with', 'Team Leader / Shared With', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(475, 'en', 'booked_date', 'Booked Date', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(476, 'en', 'created_on', 'Created On', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(477, 'en', 'closed_by_shared_by', 'Closed By / Shared By', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(478, 'en', 'lead_creation_date', 'Lead Creation Date', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(479, 'en', 'block_tower_no', 'Block / Tower No', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(480, 'en', 'unit_no', 'Unit No', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(481, 'en', 'floor_no', 'Floor No', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(482, 'en', 'sizes', 'Sizes', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(483, 'en', 'd_o_a', 'DOA', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(484, 'en', 'general_task', 'General Task', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(485, 'en', 's_gst', 'S GST %', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(486, 'en', 'c_gst', 'C GST %', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(487, 'en', 'i_gst', 'I GST %', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(488, 'en', 'gst_amount', 'GST Amount', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(489, 'en', 'gross_brokerage_value', 'Gross Brokerage Value', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(490, 'en', 'tds_deducted_by_builder', 'TDS % Deducted by Builder', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(491, 'en', 'tds_amount', 'TDS Amount', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(492, 'en', 'actual_receivable_amount', 'Actual Receivable Amount', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(493, 'en', 't_d_s', 'TDS %', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(494, 'en', 'add_new_organization', 'Add New Organization', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(495, 'en', 'something_went_wrong', 'Something Went Wrong', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(496, 'en', 'error', 'Error', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(497, 'en', 'incentive_without_tds', 'Incentive Without TDS', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(498, 'en', 'upload_a_valid_watermark_image', 'Upload a valid Watermark Image', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(499, 'en', 'organization_updated_successfully', 'Organization Updated Successfully', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(500, 'en', 'manage_users', 'Manage Users', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(501, 'en', 'upload_a_valid_logo', 'Upload a valid Logo', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(502, 'en', 'role_profile', 'Role Profile', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(503, 'en', 'email_already_exist', 'Email Already Exist', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(504, 'en', 'user_updated_successfully', 'User Updated Successfully', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(505, 'en', 'goal_details', 'Goal Details', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(506, 'en', 'after_tds_brokerage', 'After TDS Brokerage', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(507, 'en', 'name_as_per_bank_record', 'Name As Per Bank Record', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(508, 'en', 'last_company_phone', 'Last Company Phone', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(509, 'en', 'last_company_mail', 'Last Company Mail', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(510, 'en', 'target_for_fy_rs', 'Target For Fy RS', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(511, 'en', 'target_for_fy_units', 'Target For Fy Units', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(512, 'en', 'add_user', 'Add User', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(513, 'en', 'symbol', 'Symbol', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(514, 'en', 'language_code', 'Language Code', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(515, 'en', 'language_key', 'Language Key', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(516, 'en', 'language_value', 'Language Value', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03');
INSERT INTO `lz_translations` (`id`, `lang`, `lang_key`, `lang_value`, `created_by`, `status`, `created_at`, `updated_at`) VALUES
(517, 'en', 'integration_field', 'Integration Field', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(518, 'en', 'integration_field_mapping', 'Integration Field Mapping', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(519, 'en', 'translation', 'Translation', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(520, 'en', 'amount_collected', 'Amount Collected', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(521, 'en', 'payment_gateway', 'Payment Gateway', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(522, 'en', 'payment_gateway_key', 'Payment Gateway Key', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(523, 'en', 'payment_gateway_value', 'Payment Gateway Value', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(524, 'en', 'subscription_name', 'Subscription Name', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(525, 'en', 'validity', 'Validity', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(526, 'en', 'subscription', 'Subscription', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(527, 'en', 'no_of_days', 'No of Days', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(528, 'en', 'start_date', 'Start Date', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(529, 'en', 'transaction_time', 'Transaction Time', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(530, 'en', 'amount', 'Amount', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(531, 'en', 'customer_subscriptions', 'Customer Subcriptions', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(532, 'en', 'mode_of_payment', 'Mode of Payment', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(533, 'en', 'transaction_status', 'Transaction Status', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(534, 'en', 'alert_title', 'Alert Title', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(535, 'en', 'alert_template', 'Alert Template', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(536, 'en', 'record_type', 'Record Type', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(537, 'en', 'event_type', 'Event Type', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(538, 'en', 'alert_type', 'Alert Type', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(539, 'en', 'sender_id', 'Sender Id', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(540, 'en', 'email_subject', 'Email Subject', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(541, 'en', 'text', 'Text', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(542, 'en', 'completion_certificate', 'Completion Certificate', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(543, 'en', 'lead_registration', 'Lead Registration', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(544, 'en', 'contact_registration', 'Contact Registration', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(545, 'en', 'email_list', 'Email List', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(546, 'en', 'email_field', 'Email Field', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(547, 'en', 'sms_field', 'SMS Field', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(548, 'en', 'whatsapp_list', 'Whatsapp List', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(549, 'en', 'watsapp_field', 'Whatsapp Field', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(550, 'en', 'body', 'Body', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(551, 'en', 'amount_due', 'Amount Due', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(552, 'en', 'font_family', 'Font Family', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(553, 'en', 'sms_list', 'SMS List', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(554, 'en', 'add_contact_settings', 'Add Contect Settings', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(555, 'en', 'created_at', 'Created At', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(556, 'en', 'kid_name_1', 'Kid Name 1', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(557, 'en', 'kid_name_2', 'Kid Name 2', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(558, 'en', 'no_of_kids', 'No of Kids', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(559, 'en', 'spouse_name', 'Spouse Name', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(560, 'en', 'spouse_dob', 'Spouse DOB', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(561, 'en', 'profile_compleation', 'Profile Compleation', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(562, 'en', 'father_name', 'Father Name', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(563, 'en', 'emergency_contact_person_name', 'Emergency Contact Person Name', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(564, 'en', 'emergency_contact_person_relation', 'Emergency Contact Person Relation', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(565, 'en', 'anniversary_date', 'Anniversary Date', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(566, 'en', 'official_email', 'Official Email', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(567, 'en', 'secondary_mobile', 'Secondary Mobile', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(568, 'en', 'bank_record_name', 'Bank Record Name', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(569, 'en', 'kid_1_name', 'Kid 1 Name', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(570, 'en', 'kid_2_name', 'Kid 2 Name', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(571, 'en', 'kid_3_name', 'Kid 3 Name', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(572, 'en', 'no_features_available', 'No Features Available', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(573, 'en', 'project_indepth', 'Project Indepth', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(574, 'en', 'ownership_stage', 'Ownership Stage', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(575, 'en', 'no_more_projects_to_show', 'No More Project To Show!!!', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(576, 'en', 'location_details', 'Location Details', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(577, 'en', 'door_number', 'Door Number', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(578, 'en', 'project_details', 'Project Details', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(579, 'en', 'specify_stage', 'Specify Stage', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(580, 'en', 'configuration', 'Configuration', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(581, 'en', 'total_no_of_floors', 'Total No of Floors', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(582, 'en', 'if_other_specify', 'If Other Specify', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(583, 'en', 'currently_under_loan', 'Currently Under Loan', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(584, 'en', 'specifications_of_flat_villa_bungalow', 'Specifications of Flat Villa Bungalow', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(585, 'en', 'furnishing', 'Furnishing', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(586, 'en', 'project_residentials', 'Project Residentials', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(587, 'en', 'maintainance_cost', 'Maintainance Cost', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(588, 'en', 'gated_community', 'Gated Community', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(589, 'en', 'project_images_floor_plan_and_documents', 'Project Images Floor Plan And Documents', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(590, 'en', 'type_of_building', 'Type of Building', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(591, 'en', 'total_project_builtup_area', 'Total Project Builtup Area', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(592, 'en', 'offered_area', 'Offered Area', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(593, 'en', 'no_of_workstations', 'No of Workstations', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(594, 'en', 'no_of_cabins', 'No of Cabins', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(595, 'en', 'conference_rooms_size', 'Conference Rooms Size', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(596, 'en', 'no_of_people', 'No of People', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(597, 'en', 'building_structure', 'Building Structure', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(598, 'en', 'car_parking', 'Car Parking', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(599, 'en', 'no_of_washrooms', 'No of Washrooms', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(600, 'en', 'site_visit_preference', 'Site Visit Preference', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(601, 'en', 'floor_plate_area', 'Floor Plate Area', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(602, 'en', 'offered_floor', 'Offered Floor', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(603, 'en', 'workstation_size', 'Workstations Size', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(604, 'en', 'grade_of_building', 'Grade of Building', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(605, 'en', 'no_of_conference_rooms', 'No of Conference Rooms', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(606, 'en', 'pantry', 'Pantry', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(607, 'en', 'washrooms', 'Washrooms', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(608, 'en', 'if_specify', 'If Specify', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(609, 'en', 'contact', 'Contact', 0, 1, '2023-04-18 13:22:49', '2023-04-18 13:24:45'),
(610, 'en', 'bike_parking', 'Bike Parking', 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(611, 'en', NULL, NULL, 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(612, 'en', NULL, NULL, 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(613, 'en', NULL, NULL, 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(614, 'en', NULL, NULL, 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(615, 'en', NULL, NULL, 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(616, 'en', NULL, NULL, 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(617, 'en', NULL, NULL, 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(618, 'en', NULL, NULL, 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(619, 'en', NULL, NULL, 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(620, 'en', NULL, NULL, 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(621, 'en', NULL, NULL, 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(622, 'en', NULL, NULL, 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(623, 'en', NULL, NULL, 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(624, 'en', NULL, NULL, 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(625, 'en', NULL, NULL, 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(626, 'en', NULL, NULL, 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(627, 'en', NULL, NULL, 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(628, 'en', NULL, NULL, 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(629, 'en', NULL, NULL, 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(630, 'en', NULL, NULL, 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(631, 'en', NULL, NULL, 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(632, 'en', NULL, NULL, 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(633, 'en', NULL, NULL, 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(634, 'en', NULL, NULL, 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(635, 'en', NULL, NULL, 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(636, 'en', NULL, NULL, 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(637, 'en', NULL, NULL, 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(638, 'en', NULL, NULL, 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(639, 'en', NULL, NULL, 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(640, 'en', NULL, NULL, 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(641, 'en', NULL, NULL, 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(642, 'en', NULL, NULL, 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(643, 'en', NULL, NULL, 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(644, 'en', NULL, NULL, 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(645, 'en', NULL, NULL, 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(646, 'en', NULL, NULL, 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(647, 'en', NULL, NULL, 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(648, 'en', NULL, NULL, 0, 1, '2023-04-18 13:22:49', '2023-05-05 06:35:03'),
(649, 'en', 'User_management', 'User Management', 0, 1, '2023-04-20 10:43:00', '2023-05-05 06:35:03'),
(650, 'en', 'alerts_and_notification_settings', 'Alerts & Notification Settings', 0, 1, '2023-04-20 10:43:51', '2023-05-05 06:35:03'),
(651, 'en', 'from_date', 'From Date', 0, 1, '2023-04-20 10:44:32', '2023-05-05 06:35:03'),
(652, 'en', 'to_date', 'To Date', 0, 1, '2023-04-20 10:44:49', '2023-05-05 06:35:03'),
(653, 'en', 'active_timeline', 'Active Timeline', 0, 1, '2023-04-20 10:45:45', '2023-05-05 06:35:03'),
(654, 'en', 'active_timeline', 'Active Timeline', 0, 1, '2023-04-20 10:48:08', '2023-05-05 06:35:03'),
(655, 'en', 'phone_number', 'Phone Number', 0, 1, '2023-04-20 10:49:56', '2023-05-05 06:35:03'),
(656, 'en', 'confirmation', 'Confirmation', 0, 1, '2023-04-20 10:53:00', '2023-05-05 06:35:03'),
(657, 'en', 'User_management', 'User Management', 0, 1, '2023-04-20 10:53:50', '2023-05-05 06:35:03'),
(658, 'en', 'calender_view', 'Calender View', 0, 1, '2023-04-27 10:50:20', '2023-05-05 06:35:03'),
(659, 'en', 'pipeline_view', 'Pipeline View', 0, 1, '2023-04-27 10:50:51', '2023-05-05 06:35:03'),
(660, 'en', 'saved_filters', 'Saved Filters', 0, 1, '2023-04-27 10:52:40', '2023-05-05 06:35:03'),
(661, 'en', 'status', 'Status', 0, 1, '2023-04-27 10:55:03', '2023-05-05 06:35:03'),
(662, 'en', 'reminder', 'Reminder', 0, 1, '2023-04-27 10:59:42', '2023-05-05 06:35:03'),
(663, 'en', 'no_active_timelines_available', 'No Active Timelines Available', 0, 1, '2023-04-27 11:00:44', '2023-05-05 06:35:03'),
(664, 'en', 'assigned_to', 'Assigned To', 0, 1, '2023-04-27 11:01:35', '2023-05-05 06:35:03'),
(665, 'en', 'nothing_more_to_show', 'Nothing more to show', 0, 1, '2023-04-27 11:02:18', '2023-05-05 06:35:03'),
(666, 'en', 'phone_number_type', 'Phone number type', 0, 1, '2023-04-27 11:02:59', '2023-05-05 06:35:03'),
(667, 'en', 'dob', 'DOB', 0, 1, '2023-04-27 11:08:29', '2023-05-05 06:35:03'),
(668, 'en', 'person_id_documents', 'Person ID documents', 0, 1, '2023-04-27 11:09:01', '2023-05-05 06:35:03'),
(669, 'en', 'upload', 'Upload', 0, 1, '2023-04-27 11:09:38', '2023-05-05 06:35:03'),
(670, 'en', 'duplicate', 'Duplicate', 0, 1, '2023-04-27 11:12:46', '2023-05-05 06:35:03'),
(671, 'en', 'tasks', 'Tasks', 0, 1, '2023-04-27 11:13:13', '2023-05-05 06:35:03'),
(672, 'en', 'address_1', 'Address 1', 0, 1, '2023-04-27 11:14:57', '2023-05-05 06:35:03'),
(673, 'en', 'Address 2', 'Address 2', 0, 1, '2023-04-27 11:15:25', '2023-05-05 06:35:03'),
(674, 'en', 'no_lead_contacts_available', 'No lead contacts available', 0, 1, '2023-04-27 11:16:54', '2023-05-05 06:35:03'),
(675, 'en', 'no_duplicate_contacts_available', 'No duplicate contacts available', 0, 1, '2023-04-27 11:17:26', '2023-05-05 06:35:03'),
(676, 'en', 'no_tasks_available', 'No tasks available', 0, 1, '2023-04-27 11:21:46', '2023-05-05 06:35:03'),
(677, 'en', 'support', 'Support', 0, 1, '2023-04-28 10:41:39', '2023-05-05 06:35:03'),
(678, 'en', 'are_you_sure_want_to_delete', 'Are you sure want to delete', 0, 1, '2023-04-28 10:43:24', '2023-05-05 06:35:03'),
(679, 'en', 'upload_sheet', 'Upload sheet', 0, 1, '2023-04-28 11:54:33', '2023-05-05 06:35:03'),
(680, 'en', 'upload_profile_image', 'Upload profile image', 0, 1, '2023-04-28 12:09:27', '2023-05-05 06:35:03'),
(681, 'en', 'basic_details', 'Basic details', 0, 1, '2023-04-28 12:11:01', '2023-05-05 06:35:03'),
(682, 'en', 'contact_added_successfully', 'Contact added successfully', 0, 1, '2023-04-28 12:11:42', '2023-05-05 06:35:03'),
(683, 'en', 'contact_imported_successfully', 'Contact imported successfully', 0, 1, '2023-04-28 12:12:21', '2023-05-05 06:35:03'),
(684, 'en', 'sample_file', 'Sample file', 0, 1, '2023-04-28 12:12:45', '2023-05-05 06:35:03'),
(685, 'en', 'import_excel_sheet', 'Import excel sheet', 0, 1, '2023-04-28 12:13:35', '2023-05-05 06:35:03'),
(686, 'en', 'no_secondary_contacts_available', 'No secondary contacts available', 0, 1, '2023-04-28 12:20:44', '2023-05-05 06:35:03'),
(687, 'en', 'send', 'Send', 0, 1, '2023-04-28 12:21:03', '2023-05-05 06:35:03'),
(688, 'en', 'share_with', 'Share with', 0, 1, '2023-04-28 12:21:33', '2023-05-05 06:35:03'),
(689, 'en', 'send_mail', 'Send mail', 0, 1, '2023-04-28 12:22:08', '2023-05-05 06:35:03'),
(690, 'en', 'mail_list', 'Mail list', 0, 1, '2023-04-28 12:22:36', '2023-05-05 06:35:03'),
(691, 'en', 'calls', 'Calls', 0, 1, '2023-04-28 12:23:03', '2023-05-05 06:35:03'),
(692, 'en', 'reply', 'Reply', 0, 1, '2023-04-28 12:23:20', '2023-05-05 06:35:03'),
(693, 'en', 'address_2', 'Address 2', 0, 1, '2023-04-28 12:23:45', '2023-05-05 06:35:03'),
(694, 'en', 'translation_deleted_successfully', 'Translation deleted successfully', 0, 1, '2023-04-28 12:25:40', '2023-05-05 06:35:03'),
(695, 'en', 'translation_updated_successfully', 'Translation updated successfully', 0, 1, '2023-04-28 12:26:41', '2023-05-05 06:35:03'),
(696, 'en', 'translation_added_successfully', 'Translation added successfully', 0, 1, '2023-04-28 12:27:32', '2023-04-28 13:05:21'),
(697, 'en', 'Translation', 'Translation', 0, 1, '2023-04-28 12:28:41', '2023-05-05 06:35:03'),
(698, 'en', 'loading', 'Loading', 0, 1, '2023-04-28 12:33:40', '2023-05-05 06:35:03'),
(699, 'en', 'language_deleted_successfully', 'Language deleted successfully', 0, 1, '2023-04-28 12:34:43', '2023-05-05 06:35:03'),
(700, 'en', 'language_updated_successfully', 'Language updated successfully', 0, 1, '2023-04-28 12:35:27', '2023-05-05 06:35:03'),
(701, 'en', 'language_added_successfully', 'Language added successfully', 0, 1, '2023-04-28 12:36:06', '2023-05-05 06:35:03'),
(702, 'en', 'subscriptions', 'Subscriptions', 0, 1, '2023-04-28 12:37:28', '2023-05-05 06:35:03'),
(703, 'en', 'localization', 'Localization', 0, 1, '2023-04-28 12:38:00', '2023-05-05 06:35:03'),
(704, 'en', 'user_management', 'User management', 0, 1, '2023-04-28 12:38:26', '2023-05-05 06:35:03'),
(705, 'en', 'theme_reset_successfully', 'Theme Re-seted successfully', 0, 1, '2023-04-28 12:41:07', '2023-05-05 06:35:03'),
(706, 'en', 'theme_updated_successfully', 'Theme updated successfully', 0, 1, '2023-04-28 12:41:48', '2023-05-05 06:35:03'),
(707, 'en', 'MENU.DASHBOARD', 'Dashboard', 0, 1, '2023-04-28 12:42:44', '2023-05-05 06:35:03'),
(708, 'en', 'reach_out_to', 'Reach out to', 0, 1, '2023-04-28 12:44:43', '2023-05-05 06:35:03'),
(709, 'en', 'calender_view', 'Calender view', 0, 1, '2023-04-28 12:53:15', '2023-05-05 06:35:03'),
(710, 'en', 'large_files_removed', 'Large files removed', 0, 1, '2023-04-28 12:53:56', '2023-05-05 06:35:03'),
(711, 'en', 'warning', 'Warning', 0, 1, '2023-04-28 12:54:13', '2023-05-05 06:35:03'),
(712, 'en', 'task_not_updated', 'Task not updated', 0, 1, '2023-04-28 12:54:46', '2023-05-05 06:35:03'),
(713, 'en', 'larger_files_eleminated', 'Larger files eliminated', 0, 1, '2023-04-28 12:55:24', '2023-04-28 12:56:12'),
(714, 'en', 'task_file_size_cannot_be_more_than_2_mb', 'Task file size cannot be more than 2 mb', 0, 1, '2023-04-28 12:57:19', '2023-05-05 06:35:03'),
(715, 'en', 'task_status_updated_successfully', 'Task status updated successfully', 0, 1, '2023-04-28 12:58:28', '2023-05-05 06:35:03'),
(716, 'en', 'task_priority_updated_successfully', 'Task priority updated successfully', 0, 1, '2023-04-28 12:59:46', '2023-05-05 06:35:03'),
(717, 'en', 'task_filter_saved_successfully', 'Task filter saved successfully', 0, 1, '2023-04-28 13:00:26', '2023-05-05 06:35:03'),
(718, 'en', 'task_filter_removed_successfully', 'Task filter removed successfully', 0, 1, '2023-04-28 13:01:01', '2023-05-05 06:35:03'),
(719, 'en', 'task_filter_applied_successfully', 'Task filter applied successfully', 0, 1, '2023-04-28 13:01:37', '2023-05-05 06:35:03'),
(720, 'en', 'task_files_deleted_successfully', 'Task files deleted successfully', 0, 1, '2023-04-28 13:02:16', '2023-05-05 06:35:03'),
(721, 'en', 'task_files_uploaded_successfully', 'Task files uploaded successfully', 0, 1, '2023-04-28 13:03:26', '2023-05-05 06:35:03'),
(722, 'en', 'task_note_updated_successfully', 'Task note updated successfully', 0, 1, '2023-04-28 13:04:12', '2023-05-05 06:35:03'),
(723, 'en', 'task_note_deleted_successfully', 'Task note deleted successfully', 0, 1, '2023-04-28 13:04:52', '2023-05-05 06:35:03'),
(724, 'en', 'task_note_reply_posted_successfully', 'Task note reply posted successfully', 0, 1, '2023-04-28 13:06:17', '2023-05-05 06:35:03'),
(725, 'en', 'task_note_added_successfully', 'Task note added successfully', 0, 1, '2023-04-28 13:06:55', '2023-05-05 06:35:03'),
(726, 'en', 'task_deleted_successfully', 'Task deleted successfully', 0, 1, '2023-04-28 13:07:27', '2023-05-05 06:35:03'),
(727, 'en', 'something_went_wrong', 'Something went wrong', 0, 1, '2023-04-28 13:08:03', '2023-05-05 06:35:03'),
(728, 'en', 'task_updated_successfully', 'Task updated successfully', 0, 1, '2023-04-28 13:08:38', '2023-05-05 06:35:03'),
(729, 'en', 'task_added_successfully', 'Task added successfully', 0, 1, '2023-04-28 13:09:10', '2023-05-05 06:35:03'),
(730, 'en', 'no_more_tasks_to_show', 'No more tasks to show', 0, 1, '2023-04-28 13:09:49', '2023-05-05 06:35:03'),
(731, 'en', 'close', 'Close', 0, 1, '2023-04-28 13:10:17', '2023-05-05 06:35:03'),
(732, 'en', 'calendar_view', 'Calender view', 0, 1, '2023-04-28 13:11:14', '2023-05-05 06:35:03'),
(733, 'en', 'somthing_went_wrong', 'Something went wrong', 0, 1, '2023-04-28 13:12:46', '2023-05-05 06:35:03'),
(734, 'en', 'nothing_to_show', 'Nothing to show', 0, 1, '2023-04-28 13:13:26', '2023-05-05 06:35:03'),
(735, 'en', 'project_imported_successfully', 'Project imported successfully', 0, 1, '2023-04-28 13:16:04', '2023-05-05 06:35:03'),
(736, 'en', 'project_imported_successfully', 'Project imported successfully', 0, 1, '2023-04-28 13:18:45', '2023-05-05 06:35:03'),
(737, 'en', 'project_created_successfully', 'Project created successfully', 0, 1, '2023-04-28 13:19:12', '2023-05-05 06:35:03'),
(738, 'en', 'project_updated_successfully', 'Project updated successfully', 0, 1, '2023-04-28 13:19:30', '2023-05-05 06:35:03'),
(739, 'en', 'project_status_deleted_successfully', 'Project status deleted successfully', 0, 1, '2023-04-28 13:19:53', '2023-05-05 06:35:03'),
(740, 'en', 'project_status_updated_successfully', 'Project status updated successfully', 0, 1, '2023-04-28 13:20:15', '2023-05-05 06:35:03'),
(741, 'en', 'project_updated_successfully', 'Project updated successfully', 0, 1, '2023-04-28 13:20:34', '2023-05-05 06:35:03'),
(742, 'en', 'certifications', 'Certifications', 0, 1, '2023-04-28 13:23:22', '2023-05-05 06:35:03'),
(743, 'en', 'specify', 'Specify', 0, 1, '2023-04-28 13:23:37', '2023-05-05 06:35:03'),
(744, 'en', 'commercial_plot', 'Commercial plot', 0, 1, '2023-04-28 13:24:02', '2023-05-05 06:35:03'),
(745, 'en', 'current_status', 'Current status', 0, 1, '2023-04-28 13:24:33', '2023-05-05 06:35:03'),
(746, 'en', 'boundary_wall', 'Boundary wall', 0, 1, '2023-04-28 13:24:59', '2023-05-05 06:35:03'),
(747, 'en', 'authority_approved', 'Authority approved', 0, 1, '2023-04-28 13:25:23', '2023-05-05 06:35:03'),
(748, 'en', 'corner_property', 'Corner property', 0, 1, '2023-04-28 13:25:54', '2023-05-05 06:35:03'),
(749, 'en', 'road_width', 'Road width', 0, 1, '2023-04-28 13:26:18', '2023-05-05 06:35:03'),
(750, 'en', 'dimensions', 'Dimensions', 0, 1, '2023-04-28 13:26:42', '2023-05-05 06:35:03'),
(751, 'en', 'frontage', 'Frontage', 0, 1, '2023-04-28 13:26:57', '2023-05-05 06:35:03'),
(752, 'en', 'fsi', 'FSI', 0, 1, '2023-04-28 13:27:13', '2023-05-05 06:35:03'),
(753, 'en', 'plot_area', 'Plot area', 0, 1, '2023-04-28 13:27:34', '2023-05-05 06:35:03'),
(754, 'en', 'Frontage', 'Frontage', 0, 1, '2023-04-28 13:28:46', '2023-05-05 06:35:03'),
(755, 'en', 'plot_type', 'Plot type', 0, 1, '2023-04-28 13:29:09', '2023-05-05 06:35:03'),
(756, 'en', 'commercial_reatail', 'Commercial reatail', 0, 1, '2023-04-28 13:29:34', '2023-05-05 06:35:03'),
(757, 'en', 'server_room', 'Server room', 0, 1, '2023-04-28 13:29:57', '2023-05-05 06:35:03'),
(758, 'en', 'age_of_structure', 'Age of structure', 0, 1, '2023-04-28 13:30:27', '2023-05-05 06:35:03'),
(759, 'en', 'possession_status', 'Possession status', 0, 1, '2023-04-28 13:30:54', '2023-05-05 06:35:03'),
(760, 'en', 'fire_safety', 'Fire safety', 0, 1, '2023-04-28 13:31:15', '2023-04-28 13:40:31'),
(761, 'en', 'floor_ceiling_height', 'Floor ceiling height', 0, 1, '2023-04-28 13:32:18', '2023-05-05 06:35:03'),
(762, 'en', 'typical_floor_plate_size', 'Typical floor plate size', 0, 1, '2023-04-28 13:33:01', '2023-05-05 06:35:03'),
(763, 'en', 'building_material', 'Building material', 0, 1, '2023-04-28 13:33:31', '2023-04-28 13:41:00'),
(764, 'en', 'warehouse_industrial_area', 'Warehouse industrial area', 0, 1, '2023-04-28 13:34:20', '2023-05-05 06:35:03'),
(765, 'en', 'office_area', 'Office area', 0, 1, '2023-04-28 13:34:45', '2023-05-05 06:35:03'),
(766, 'en', 'offered_plot_area', 'Offered plot area', 0, 1, '2023-04-28 13:35:22', '2023-05-05 06:35:03'),
(767, 'en', 'offered_builtup_area', 'Offered built-up area', 0, 1, '2023-04-28 13:35:51', '2023-04-28 13:36:39'),
(768, 'en', 'visibility', 'Visibility', 0, 1, '2023-04-28 13:37:15', '2023-05-05 06:35:03'),
(769, 'en', 'property_suited_for', 'Property suited for', 0, 1, '2023-04-28 13:37:45', '2023-05-05 06:35:03'),
(770, 'en', 'situated_at', 'Situated at', 0, 1, '2023-04-28 13:38:11', '2023-05-05 06:35:03'),
(771, 'en', 'commercial_industrial', 'Commercial industrial', 0, 1, '2023-04-28 13:38:40', '2023-05-05 06:35:03'),
(772, 'en', 'commercial_retail', 'Commercial retail', 0, 1, '2023-04-28 13:39:44', '2023-04-28 13:40:06'),
(773, 'en', 'total_plot_area', 'Total plot area', 0, 1, '2023-04-28 13:41:31', '2023-05-05 06:35:03'),
(774, 'en', 'total_builtup_area', 'Total built-up area', 0, 1, '2023-04-28 13:42:07', '2023-04-28 13:42:33'),
(775, 'en', 'total_project_area', 'Total project area', 0, 1, '2023-04-28 13:42:59', '2023-05-05 06:35:03'),
(776, 'en', 'sub_type', 'Sub type', 0, 1, '2023-04-28 13:43:21', '2023-05-05 06:35:03'),
(777, 'en', 'parking_charges_bike', 'Parking charges (bike)', 0, 1, '2023-04-28 13:43:59', '2023-05-05 06:35:03'),
(778, 'en', 'parking_charges_car', 'Parking charges (car)', 0, 1, '2023-04-28 13:44:57', '2023-05-05 06:35:03'),
(779, 'en', 'ontime_setup_cost', 'Ontime setup cost', 0, 1, '2023-04-28 13:45:51', '2023-05-05 06:35:03'),
(780, 'en', 'commercial_coworking', 'Commercial co-working', 0, 1, '2023-04-28 13:46:34', '2023-05-05 06:35:03'),
(781, 'en', 'office_work_hours', 'Office work hours', 0, 1, '2023-04-28 13:47:02', '2023-05-05 06:35:03'),
(782, 'en', 'conferance_room_size', 'Conference room size', 0, 1, '2023-04-28 13:47:35', '2023-04-28 13:48:05'),
(783, 'en', 'total_offered_workstations', 'Total offered workstations', 0, 1, '2023-04-28 13:48:42', '2023-05-05 06:35:03'),
(784, 'en', 'co-working_type', 'Co-working type', 0, 1, '2023-04-28 13:49:13', '2023-05-05 06:35:03'),
(785, 'en', 'years', 'Years', 0, 1, '2023-04-28 13:49:37', '2023-05-05 06:35:03'),
(786, 'en', 'total_number_of_workstations', 'Total number of workstations', 0, 1, '2023-04-28 13:50:16', '2023-05-05 06:35:03'),
(787, 'en', 'total_offered_floor', 'Total offered floor', 0, 1, '2023-04-28 13:50:42', '2023-05-05 06:35:03'),
(788, 'en', 'project_images_floor_plan_and_ocuments', 'Project images floor plan and documents', 0, 1, '2023-04-28 13:52:06', '2023-05-05 06:35:03'),
(789, 'en', 'upload_floor_plan', 'Upload floor plan', 0, 1, '2023-04-28 13:52:36', '2023-05-05 06:35:03'),
(790, 'en', 'uds', 'UDS', 0, 1, '2023-04-28 13:52:58', '2023-05-05 06:35:03'),
(791, 'en', 'developer', 'Developer', 0, 1, '2023-04-28 13:53:12', '2023-05-05 06:35:03'),
(792, 'en', 'plot', 'Plot', 0, 1, '2023-04-28 13:53:29', '2023-05-05 06:35:03'),
(793, 'en', 'commercial', 'Commercial', 0, 1, '2023-04-28 13:53:48', '2023-05-05 06:35:03'),
(794, 'en', 'residential', 'Residential', 0, 1, '2023-04-28 13:54:05', '2023-05-05 06:35:03'),
(795, 'en', 'poject_features', 'Project features', 0, 1, '2023-04-28 13:55:27', '2023-05-05 06:35:03'),
(796, 'en', 'onetime_setup_cost', 'Onetime setup cost', 0, 1, '2023-04-28 13:56:29', '2023-05-05 06:35:03'),
(797, 'en', 'conference_room_size', 'Conference room size', 0, 1, '2023-04-28 13:56:58', '2023-05-05 06:35:03'),
(798, 'en', 'total_no_of_workstations', 'Total no of workstations', 0, 1, '2023-04-28 13:57:44', '2023-05-05 06:35:03'),
(799, 'en', 'filters', 'Filters', 0, 1, '2023-04-28 13:59:37', '2023-05-05 06:35:03'),
(800, 'en', 'months', 'Months', 0, 1, '2023-04-28 13:59:49', '2023-05-05 06:35:03'),
(801, 'en', 'bathroom', 'Bathroom', 0, 1, '2023-04-28 14:00:11', '2023-05-05 06:35:03'),
(802, 'en', 'bathroom', 'Bathroom', 0, 1, '2023-04-28 14:00:28', '2023-05-05 06:35:03'),
(803, 'en', 'lead_filter', 'Lead filter', 0, 1, '2023-04-28 14:00:52', '2023-05-05 06:35:03'),
(804, 'en', 'lead_imported_successfully', 'Lead imported successfully', 0, 1, '2023-04-28 14:01:29', '2023-05-05 06:35:03'),
(805, 'en', 'requirement_location', 'Requirement location', 0, 1, '2023-04-28 14:02:00', '2023-05-05 06:35:03'),
(806, 'en', 're_assign', 'Re-assign', 0, 1, '2023-04-28 14:02:27', '2023-05-05 06:35:03'),
(808, 'en', 'site_settings', 'Site Settings', 1, 1, '2023-05-05 06:41:07', '2023-05-05 06:41:07'),
(809, 'en', 'support_ticket', 'Support Ticket', 1, 1, '2023-05-05 06:41:24', '2023-05-05 06:41:24'),
(810, 'en', 'client_subscriptions', 'Client Subscription', 1, 1, '2023-05-05 06:41:41', '2023-05-05 06:41:41'),
(811, 'en', 'users', 'Users', 1, 1, '2023-05-05 06:41:57', '2023-05-05 06:41:57'),
(812, 'en', 'plans', 'Plans', 1, 1, '2023-05-05 06:42:10', '2023-05-05 06:42:10'),
(813, 'En', 'email_settings', 'Email Settings', 1, 1, '2023-05-05 07:16:06', '2023-05-05 07:16:06'),
(814, 'En', 'contact_settings', 'Contact Settings', 1, 1, '2023-05-05 08:59:07', '2023-05-05 08:59:07'),
(815, 'En', 'already_exist', 'Already Exist', 1, 1, '2023-05-05 08:59:42', '2023-05-05 08:59:42'),
(816, 'En', 'image_size_exceeded', 'Image size exceeded', 1, 1, '2023-05-05 09:01:36', '2023-05-05 09:01:36'),
(817, 'En', 'site_setting_updated_successfully', 'Site setting updated successfully', 1, 1, '2023-05-05 09:02:26', '2023-05-05 09:02:26'),
(818, 'En', 'upload_favicon', 'Upload Favicon', 1, 1, '2023-05-05 09:03:49', '2023-05-05 09:03:04'),
(819, 'En', 'upload_logo', 'Upload Logo', 1, 1, '2023-05-05 09:03:39', '2023-05-05 09:03:39'),
(820, 'En', 'confirm_password', 'Confirm Password', 1, 1, '2023-05-05 09:04:53', '2023-05-05 09:04:53'),
(821, 'En', 'website', 'Website', 1, 1, '2023-05-05 09:09:13', '2023-05-05 09:05:13'),
(822, 'En', 'organization Name', 'Organization Name', 1, 1, '2023-05-05 09:06:09', '2023-05-05 09:06:09'),
(823, 'En', 'upload_watermark', 'Upload watermark', 1, 1, '2023-05-05 09:06:34', '2023-05-05 09:06:34'),
(824, 'En', 'upload_atermark', 'Upload watermark', 1, 1, '2023-05-05 09:10:06', '2023-05-05 09:10:06'),
(825, 'En', 'please_upload_image_size_below_2_MB', 'Please upload image size below 2 MB', 1, 1, '2023-05-05 09:12:45', '2023-05-05 09:12:45'),
(826, 'En', 'organization_created_successfully', 'Organization created successfully', 1, 1, '2023-05-05 09:13:12', '2023-05-05 09:13:12'),
(827, 'En', 'organization_deleted_successfully', 'Organization deleted successfully', 1, 1, '2023-05-05 09:13:44', '2023-05-05 09:13:44'),
(828, 'En', 'client_subscription deleted_successfully', 'Client subscription deleted successfully', 1, 1, '2023-05-05 09:15:10', '2023-05-05 09:15:10'),
(829, 'En', 'client_subscription updated_successfully', 'Client subscription updated successfully', 1, 1, '2023-05-05 09:15:40', '2023-05-05 09:15:40'),
(830, 'En', 'client_subscription added_successfully', 'Client subscription added successfully', 1, 1, '2023-05-05 09:17:50', '2023-05-05 09:17:50'),
(831, 'En', 'subscription_deleted_successfully', 'Subscription deleted successfully', 1, 1, '2023-05-05 09:20:27', '2023-05-05 09:20:27'),
(832, 'En', 'subscription_updated_successfully', 'Subscription updated successfully', 1, 1, '2023-05-05 09:20:56', '2023-05-05 09:20:56'),
(833, 'En', 'subscription_added_successfully', 'Subscription added successfully', 1, 1, '2023-05-05 09:23:52', '2023-05-05 09:23:52'),
(834, 'En', 'no_subscriptions_available', 'No subscriptions available', 1, 1, '2023-05-05 09:25:03', '2023-05-05 09:25:03'),
(835, 'En', 'support_ticket_updated_successfully', 'Support ticket updated successfully', 1, 1, '2023-05-05 09:25:50', '2023-05-05 09:25:50'),
(836, 'En', 'ticket_name', 'Ticket name', 1, 1, '2023-05-05 09:26:18', '2023-05-05 09:26:18'),
(837, 'En', 'mail_driver', 'Mail driver', 1, 1, '2023-05-05 09:27:40', '2023-05-05 09:27:40'),
(838, 'En', 'mail_host', 'Mail host', 1, 1, '2023-05-05 09:28:00', '2023-05-05 09:28:00'),
(839, 'En', 'mail_port', 'Mail port', 1, 1, '2023-05-05 09:28:17', '2023-05-05 09:28:17'),
(840, 'En', 'mail_username', 'Mail username', 1, 1, '2023-05-05 09:28:35', '2023-05-05 09:28:35'),
(841, 'En', 'mail_password', 'Mail password', 1, 1, '2023-05-05 09:28:53', '2023-05-05 09:28:53'),
(842, 'En', 'mail_encryption', 'Mail encryption', 1, 1, '2023-05-05 09:29:09', '2023-05-05 09:29:09'),
(843, 'En', 'mail_from_address', 'Mail from address', 1, 1, '2023-05-05 09:29:29', '2023-05-05 09:29:29'),
(844, 'En', 'mail_from_name', 'Mail from name', 1, 1, '2023-05-05 09:29:55', '2023-05-05 09:29:55'),
(845, 'En', 'razor_key', 'Razor key', 1, 1, '2023-05-05 09:30:18', '2023-05-05 09:30:18'),
(846, 'En', 'razor_secret', 'Razor secret', 1, 1, '2023-05-05 09:30:34', '2023-05-05 09:30:34'),
(847, 'En', 'stripe_key', 'Stripe key', 1, 1, '2023-05-05 09:30:52', '2023-05-05 09:30:52'),
(848, 'En', 'stripe_secret', 'Stripe secret', 1, 1, '2023-05-05 09:31:06', '2023-05-05 09:31:06'),
(849, 'En', 'email_setting_updated_successfully', 'Email setting updated successfully', 1, 1, '2023-05-05 09:33:06', '2023-05-05 09:33:06'),
(850, 'En', 'payment_gateway_settings_updated_successfully', 'Payment gateway settings updated successfully', 1, 1, '2023-05-05 09:35:29', '2023-05-05 09:35:29'),
(851, 'En', 'razor_pay', 'Razor Pay', 1, 1, '2023-05-05 09:36:18', '2023-05-05 09:36:18'),
(852, 'En', 'stripe_pay', 'Stripe Pay', 1, 1, '2023-05-05 09:36:37', '2023-05-05 09:36:37'),
(853, 'En', 'payment_gateway_settings', 'Payment Gateway Settings', 1, 1, '2023-05-05 09:37:15', '2023-05-05 09:37:15'),
(854, 'En', 'themes', 'Themes', 1, 1, '2023-05-05 14:28:01', '2023-05-05 14:28:01'),
(857, 'En', 'payment', 'Payment', 1, 1, '2023-05-06 11:59:35', '2023-05-06 11:59:35'),
(858, 'En', 'language_name', 'Language name', 1, 1, '2023-05-06 12:00:34', '2023-05-06 12:00:34'),
(859, 'En', 'country_added_successfully', 'Country added successfully', 1, 1, '2023-05-06 12:09:56', '2023-05-06 12:09:56'),
(860, 'En', 'state_added_successfully', 'State added successfully', 1, 1, '2023-05-06 12:10:34', '2023-05-06 12:10:34'),
(861, 'En', 'city_added_successfully', 'City added successfully', 1, 1, '2023-05-06 12:10:59', '2023-05-06 12:10:59'),
(862, 'En', 'currency_added_successfully', 'Currency added successfully', 1, 1, '2023-05-06 12:11:47', '2023-05-06 12:11:47'),
(863, 'En', 'country_updated_successfully', 'Country updated successfully', 1, 1, '2023-05-06 12:12:40', '2023-05-06 12:12:40'),
(864, 'En', 'state_updated_successfully', 'State updated successfully', 1, 1, '2023-05-06 12:14:28', '2023-05-06 12:13:09'),
(865, 'En', 'city_updated_successfully', 'City updated successfully', 1, 1, '2023-05-06 12:13:39', '2023-05-06 12:13:39'),
(866, 'En', 'currency_updated_successfully', 'Currency updated successfully', 1, 1, '2023-05-06 12:14:15', '2023-05-06 12:14:15'),
(867, 'En', 'country_deleted_successfully', 'Country deleted successfully', 1, 1, '2023-05-06 12:14:58', '2023-05-06 12:14:58'),
(868, 'En', 'state_deleted_successfully', 'State deleted successfully', 1, 1, '2023-05-06 12:15:25', '2023-05-06 12:15:25'),
(869, 'En', 'city_deleted_successfully', 'City deleted successfully', 1, 1, '2023-05-06 12:15:49', '2023-05-06 12:15:49'),
(870, 'En', 'currency_deleted_successfully', 'Currency deleted successfully', 1, 1, '2023-05-06 12:16:20', '2023-05-06 12:16:20'),
(871, 'En', 'project', 'Project', 1, 1, '2023-05-06 12:17:37', '2023-05-06 12:17:37'),
(872, 'En', 'ticket', 'Ticket', 1, 1, '2023-05-06 12:19:04', '2023-05-06 12:19:04'),
(873, 'En', 'master_added_successfully', 'Master added successfully', 1, 1, '2023-05-06 12:19:59', '2023-05-06 12:19:59'),
(874, 'En', 'master_updated_successfully', 'Master updated successfully', 1, 1, '2023-05-06 12:20:30', '2023-05-06 12:20:30'),
(875, 'En', 'master_deleted_successfully', 'Master deleted successfully', 1, 1, '2023-05-06 12:21:07', '2023-05-06 12:21:07'),
(876, 'En', 'database', 'Database', 1, 1, '2023-05-08 07:40:43', '2023-05-08 07:40:43'),
(877, 'En', 'sub_domain', 'Sub Domain', 1, 1, '2023-05-08 07:41:21', '2023-05-08 07:41:21'),
(878, 'En', 'twitter_url', 'Twitter URL', 1, 1, '2023-05-08 07:41:59', '2023-05-08 07:41:59'),
(879, 'En', 'instagram_url', 'Instagram URL', 1, 1, '2023-05-08 07:42:41', '2023-05-08 07:42:41'),
(880, 'En', 'linkedin_url', 'Linked-in URL', 1, 1, '2023-05-08 07:43:18', '2023-05-08 07:43:18'),
(881, 'En', 'facebook_url', 'Facebook URL', 1, 1, '2023-05-08 07:43:50', '2023-05-08 07:43:50'),
(882, 'En', 'sub_domain_database_name', 'Sub-domain database name', 1, 1, '2023-05-08 07:44:50', '2023-05-08 07:44:50'),
(883, 'En', 'linkind_url', 'Linked URL', 1, 1, '2023-05-08 07:46:23', '2023-05-08 07:46:23'),
(884, 'En', 'linkindin_url', 'Linked-in URL', 1, 1, '2023-05-08 07:47:53', '2023-05-08 07:47:53'),
(885, 'En', 'edit_admin', 'Edit Admin', 1, 1, '2023-05-08 09:31:19', '2023-05-08 09:31:19'),
(886, 'En', 'subscription_plans', 'Subscription Plans', 1, 1, '2023-05-08 09:38:41', '2023-05-08 09:38:41'),
(887, 'En', 'recently_added', 'Recently Added', 1, 1, '2023-05-08 09:39:05', '2023-05-08 09:39:05'),
(888, 'En', 'expireing_in_30_days', 'Expiring in 30 days', 1, 1, '2023-05-08 09:41:48', '2023-05-08 09:39:59'),
(889, 'En', 'expiring_in_30_days', 'Expiring in 30 days', 1, 1, '2023-05-08 09:42:26', '2023-05-08 09:42:26'),
(890, 'En', 'organizations', 'Organizations', 1, 1, '2023-05-08 09:44:06', '2023-05-08 09:44:06'),
(891, 'En', 'lead', 'test', 1, 1, '2023-05-08 14:34:20', '2023-05-08 14:34:05'),
(892, 'En', 'lead', 'testing', 1, 1, '2023-05-09 07:37:23', '2023-05-08 14:34:36'),
(893, 'En', 'lead', 'form', 1, 1, '2023-05-09 07:37:06', '2023-05-09 07:37:06');

-- --------------------------------------------------------

--
-- Table structure for table `lz_users`
--

CREATE TABLE `lz_users` (
  `id` int NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `org_id` int DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `status` int DEFAULT '1',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `lz_users`
--

INSERT INTO `lz_users` (`id`, `email`, `password`, `org_id`, `created_by`, `status`, `created_at`, `updated_at`) VALUES
(1, 'admin@listez.in', '$2b$10$7e/XWq.gzJdfkuSSNESzfuvEpu3ZGGXlyjTP.lbhragorsVldDtmC', 1, 1, 1, '2023-05-06 13:46:11', '2023-05-06 13:46:11'),
(2, 'org2@listez.in', '$2b$10$BslaTSH40N3Crovum9fbbuorYd/Tm4K6W637XwlvTjf3Iz4PEVFR6', 2, 1, 1, '2023-05-06 13:52:16', '2023-05-06 13:53:09'),
(3, 'adertertertertmin@listez.in', '$2b$10$1zMuSTxFH82/i85aM9lLM.2LLH5eCMO9/xOznWJqE/xuHuk2zuiLa', 3, 1, 1, '2023-05-08 09:02:42', '2023-05-08 09:02:42'),
(4, 'admingdfghfhgrr@listez.in', '$2b$10$NBQFI5db41UmvTOfp1/LS.8UNIFWmtPVjdGxGYQxlKO7CXu8WN7We', 4, 1, 1, '2023-05-08 09:03:45', '2023-05-08 09:03:45'),
(5, 'ertertertertetrert@gmail.com', '$2b$10$NLDfPqYJqzECFrzrkJMn5ed4SQD6GP5E4rfQZk.TbTM5kKOk8fy8O', 5, 1, 1, '2023-05-08 09:07:00', '2023-05-08 09:07:00'),
(6, 'erterterterterterterter@listez.in', '$2b$10$iy7AVbRb5xxAwxznSou6Ju2353u32Qu/gzz9hpxf8kz6vRgkghp.a', 6, 1, 1, '2023-05-08 09:09:08', '2023-05-08 09:09:08'),
(7, 'admiwerwerwerwwgdfgn@listez.in', '$2b$10$XC2tZ7azvFY89YDjfQGHJejU8KVVIpSGwa6Nloh/h9nBrjgTrFIJ6', 7, 1, 1, '2023-05-08 09:10:57', '2023-05-08 09:10:57'),
(8, 'gowshierterterttguifguyk@vrikshatech.in', '$2b$10$sKcaW8.tKAYlxk/QczwOh.xG9FVKL4rCFQCY3NBNNvI31SPw3oNAe', 8, 1, 1, '2023-05-08 09:12:47', '2023-05-08 15:21:44'),
(9, 'adretrtegfkhfgwrrlkjlkndfmin@listez.in', '$2b$10$z7EpwVZYuFtkCh2bAMNmy.9rNCbFHio6cyG1s3R9qStHGjKGXNNmW', 9, 1, 1, '2023-05-08 09:14:58', '2023-05-08 09:14:58'),
(10, 'rgkegtuytguyg@jhd.dih', '$2b$10$kcTpYkNgB68vWhNL20rQ3.vkcN9DbuXLfIqAHDfvbzTJYD78pTUl2', 10, 1, 1, '2023-05-08 15:21:03', '2023-05-08 15:21:03'),
(11, 'adminertertertert@listez.in', '$2b$10$nPtyrxLxjFDZYH0X3e2PoeoTw5j1ZjtyCS..9n5Rq6uoONwGrIwwW', 11, 1, 1, '2023-05-09 05:57:37', '2023-05-09 05:57:37'),
(12, 'admerterterteyfdsfin@listez.in', '$2b$10$h6W17s9U8gxu9sOe1aZRN.m1P4dWL4bpBctOmiEPHw7uxOkQtxlx6', 12, 1, 1, '2023-05-09 06:09:18', '2023-05-09 06:09:18'),
(13, 'sdjsahtsgch@gmail.com', '$2b$10$wurwGdHUcKZAcFpUiTtKReEh9ntsUKq3z7lncM5rmCYEbknl.5Me6', 13, 1, 1, '2023-05-09 06:11:08', '2023-05-09 06:11:08'),
(14, 'admerterterfgdgadawdein@listez.in', '$2b$10$whd09Qb3D2XGSa2RGjRU2.7ulZpLEPSebqVY/H5zrQv2wnZDB14mK', 14, 1, 1, '2023-05-09 06:14:12', '2023-05-09 06:14:12'),
(15, 'artertegfgjhghgddmin@listez.in', '$2b$10$uF95WiPL2oxVFqHATqKgauA/9LfjMG5mh.a3.1iJa7RGMsidc1e4y', 15, 1, 1, '2023-05-09 06:16:08', '2023-05-09 06:16:08'),
(16, 'sdfhhgfdjhsjygf@jgjef.she', '$2b$10$MLTQYPFY3hKrXNsY4DSctu1svjkgf8UAM.chKd9/IfcdTYi18Ss5i', 16, 1, 1, '2023-05-09 06:17:46', '2023-05-09 06:17:46'),
(17, 'admthfghfghghin@listez.in', '$2b$10$24Gdu6YL91qLIerrOUb03.Q1h/EnpCDPWiJS.fLYcqmIIxa9aOFlq', 17, 1, 1, '2023-05-09 06:24:21', '2023-05-09 06:24:21'),
(18, 'hafgywefwtef@bjehf.com', '$2b$10$1bmpUPpTs3YbU5CT72qLNeFsvQoHGE6NPisoH86I1mX3HikZqeFzy', 18, 1, 1, '2023-05-09 06:25:03', '2023-05-09 06:25:03'),
(19, 'gretgjegijh@hdlkfl.dfhg', '$2b$10$jgf4RMipk4mmUwqgYZAm8uzzAAvRvG3Wr7IVBJcycgLNpQCNcDCze', 19, 1, 1, '2023-05-09 06:28:18', '2023-05-09 06:28:18'),
(20, 'hiurytgjrbtkerj@jgjg.hfg', '$2b$10$uLr.ODOWhmxkZod3mKddCuWhm9NeCEzcuu2Ksj607DqVtkRgi6kZG', 20, 1, 1, '2023-05-09 06:29:07', '2023-05-09 06:29:07'),
(21, 'adrtkjhertugreutkjmin@listez.in', '$2b$10$pSQwdNq0jJo8urCGjj4mluAvueopi..JF/wjvhqHv9OgrBRal0Q1y', 21, 1, 1, '2023-05-09 06:30:20', '2023-05-09 06:30:20');

-- --------------------------------------------------------

--
-- Table structure for table `lz_user_timeline`
--

CREATE TABLE `lz_user_timeline` (
  `id` int NOT NULL,
  `user_id` int DEFAULT NULL,
  `login_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `logout_time` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `lz_user_timeline`
--

INSERT INTO `lz_user_timeline` (`id`, `user_id`, `login_time`, `logout_time`, `created_at`, `updated_at`) VALUES
(1, 1, '2023-05-03 06:50:48', '2023-05-06 09:31:14', '2023-05-03 06:50:48', '2023-05-06 09:31:14'),
(2, 1, '2023-05-04 09:13:05', NULL, '2023-05-04 09:13:05', '2023-05-04 09:13:05'),
(3, 1, '2023-05-04 09:14:20', NULL, '2023-05-04 09:14:20', '2023-05-04 09:14:20'),
(4, 1, '2023-05-04 11:00:43', NULL, '2023-05-04 11:00:43', '2023-05-04 11:00:43'),
(5, 1, '2023-05-04 12:38:05', NULL, '2023-05-04 12:38:05', '2023-05-04 12:38:05'),
(6, 1, '2023-05-04 12:38:34', NULL, '2023-05-04 12:38:34', '2023-05-04 12:38:34'),
(7, 1, '2023-05-04 12:57:27', NULL, '2023-05-04 12:57:27', '2023-05-04 12:57:27'),
(8, 1, '2023-05-04 13:52:14', NULL, '2023-05-04 13:52:14', '2023-05-04 13:52:14'),
(9, 1, '2023-05-04 14:23:35', NULL, '2023-05-04 14:23:35', '2023-05-04 14:23:35'),
(10, 1, '2023-05-05 05:31:06', NULL, '2023-05-05 05:31:06', '2023-05-05 05:31:06'),
(11, 1, '2023-05-05 05:31:10', NULL, '2023-05-05 05:31:10', '2023-05-05 05:31:10'),
(12, 1, '2023-05-05 05:46:25', NULL, '2023-05-05 05:46:25', '2023-05-05 05:46:25'),
(13, 1, '2023-05-05 05:48:38', NULL, '2023-05-05 05:48:38', '2023-05-05 05:48:38'),
(14, 1, '2023-05-05 05:49:56', NULL, '2023-05-05 05:49:56', '2023-05-05 05:49:56'),
(15, 1, '2023-05-05 05:55:00', NULL, '2023-05-05 05:55:00', '2023-05-05 05:55:00'),
(16, 1, '2023-05-05 05:56:39', NULL, '2023-05-05 05:56:39', '2023-05-05 05:56:39'),
(17, 1, '2023-05-05 05:57:24', NULL, '2023-05-05 05:57:24', '2023-05-05 05:57:24'),
(18, 1, '2023-05-05 05:58:27', NULL, '2023-05-05 05:58:27', '2023-05-05 05:58:27'),
(19, 1, '2023-05-05 06:00:22', NULL, '2023-05-05 06:00:22', '2023-05-05 06:00:22'),
(20, 1, '2023-05-05 06:01:17', NULL, '2023-05-05 06:01:17', '2023-05-05 06:01:17'),
(21, 1, '2023-05-05 06:14:01', NULL, '2023-05-05 06:14:01', '2023-05-05 06:14:01'),
(22, 1, '2023-05-05 06:17:40', NULL, '2023-05-05 06:17:40', '2023-05-05 06:17:40'),
(23, 1, '2023-05-05 06:35:57', NULL, '2023-05-05 06:35:57', '2023-05-05 06:35:57'),
(24, 1, '2023-05-05 06:37:09', NULL, '2023-05-05 06:37:09', '2023-05-05 06:37:09'),
(25, 1, '2023-05-05 06:37:55', NULL, '2023-05-05 06:37:55', '2023-05-05 06:37:55'),
(26, 1, '2023-05-05 06:42:32', NULL, '2023-05-05 06:42:32', '2023-05-05 06:42:32'),
(27, 1, '2023-05-05 06:45:28', NULL, '2023-05-05 06:45:28', '2023-05-05 06:45:28'),
(28, 1, '2023-05-05 06:54:18', NULL, '2023-05-05 06:54:18', '2023-05-05 06:54:18'),
(29, 1, '2023-05-05 07:05:44', NULL, '2023-05-05 07:05:44', '2023-05-05 07:05:44'),
(30, 1, '2023-05-05 07:11:09', NULL, '2023-05-05 07:11:09', '2023-05-05 07:11:09'),
(31, 1, '2023-05-05 07:13:56', NULL, '2023-05-05 07:13:56', '2023-05-05 07:13:56'),
(32, 1, '2023-05-05 07:16:23', NULL, '2023-05-05 07:16:23', '2023-05-05 07:16:23'),
(33, 1, '2023-05-05 07:23:08', NULL, '2023-05-05 07:23:08', '2023-05-05 07:23:08'),
(34, 1, '2023-05-05 07:55:19', NULL, '2023-05-05 07:55:19', '2023-05-05 07:55:19'),
(35, 1, '2023-05-05 08:36:57', NULL, '2023-05-05 08:36:57', '2023-05-05 08:36:57'),
(36, 1, '2023-05-05 08:51:24', NULL, '2023-05-05 08:51:24', '2023-05-05 08:51:24'),
(37, 1, '2023-05-05 08:52:52', NULL, '2023-05-05 08:52:52', '2023-05-05 08:52:52'),
(38, 1, '2023-05-05 09:04:18', NULL, '2023-05-05 09:04:18', '2023-05-05 09:04:18'),
(39, 1, '2023-05-05 09:07:07', NULL, '2023-05-05 09:07:07', '2023-05-05 09:07:07'),
(40, 1, '2023-05-05 09:10:46', NULL, '2023-05-05 09:10:46', '2023-05-05 09:10:46'),
(41, 1, '2023-05-05 09:11:27', NULL, '2023-05-05 09:11:27', '2023-05-05 09:11:27'),
(42, 1, '2023-05-05 09:14:16', NULL, '2023-05-05 09:14:16', '2023-05-05 09:14:16'),
(43, 1, '2023-05-05 09:19:45', NULL, '2023-05-05 09:19:45', '2023-05-05 09:19:45'),
(44, 1, '2023-05-05 09:24:29', NULL, '2023-05-05 09:24:29', '2023-05-05 09:24:29'),
(45, 1, '2023-05-05 09:26:57', NULL, '2023-05-05 09:26:57', '2023-05-05 09:26:57'),
(46, 1, '2023-05-05 09:31:26', NULL, '2023-05-05 09:31:26', '2023-05-05 09:31:26'),
(47, 1, '2023-05-05 09:33:39', NULL, '2023-05-05 09:33:39', '2023-05-05 09:33:39'),
(48, 1, '2023-05-05 09:37:38', NULL, '2023-05-05 09:37:38', '2023-05-05 09:37:38'),
(49, 1, '2023-05-05 09:54:48', NULL, '2023-05-05 09:54:48', '2023-05-05 09:54:48'),
(50, 1, '2023-05-05 10:30:10', NULL, '2023-05-05 10:30:10', '2023-05-05 10:30:10'),
(51, 1, '2023-05-05 10:46:21', NULL, '2023-05-05 10:46:21', '2023-05-05 10:46:21'),
(52, 1, '2023-05-05 10:46:58', NULL, '2023-05-05 10:46:58', '2023-05-05 10:46:58'),
(53, 1, '2023-05-05 10:55:27', NULL, '2023-05-05 10:55:27', '2023-05-05 10:55:27'),
(54, 1, '2023-05-05 11:00:54', NULL, '2023-05-05 11:00:54', '2023-05-05 11:00:54'),
(55, 1, '2023-05-05 11:00:58', NULL, '2023-05-05 11:00:58', '2023-05-05 11:00:58'),
(56, 1, '2023-05-05 11:01:01', NULL, '2023-05-05 11:01:01', '2023-05-05 11:01:01'),
(57, 1, '2023-05-05 11:01:04', NULL, '2023-05-05 11:01:04', '2023-05-05 11:01:04'),
(58, 1, '2023-05-05 11:06:22', NULL, '2023-05-05 11:06:22', '2023-05-05 11:06:22'),
(59, 1, '2023-05-05 11:28:12', NULL, '2023-05-05 11:28:12', '2023-05-05 11:28:12'),
(60, 1, '2023-05-05 12:15:13', NULL, '2023-05-05 12:15:13', '2023-05-05 12:15:13'),
(61, 1, '2023-05-05 12:21:15', NULL, '2023-05-05 12:21:15', '2023-05-05 12:21:15'),
(62, 1, '2023-05-05 12:37:23', NULL, '2023-05-05 12:37:23', '2023-05-05 12:37:23'),
(63, 1, '2023-05-05 12:43:06', NULL, '2023-05-05 12:43:06', '2023-05-05 12:43:06'),
(64, 1, '2023-05-05 14:16:03', NULL, '2023-05-05 14:16:03', '2023-05-05 14:16:03'),
(65, 1, '2023-05-06 05:57:50', NULL, '2023-05-06 05:57:50', '2023-05-06 05:57:50'),
(66, 1, '2023-05-06 05:57:54', NULL, '2023-05-06 05:57:54', '2023-05-06 05:57:54'),
(67, 1, '2023-05-06 06:41:41', NULL, '2023-05-06 06:41:41', '2023-05-06 06:41:41'),
(68, 1, '2023-05-06 08:31:31', NULL, '2023-05-06 08:31:31', '2023-05-06 08:31:31'),
(69, 1, '2023-05-06 08:47:17', '2023-05-06 09:30:23', '2023-05-06 08:47:17', '2023-05-06 09:30:23'),
(70, 1, '2023-05-06 09:30:34', '2023-05-06 10:13:49', '2023-05-06 09:30:34', '2023-05-06 10:13:49'),
(71, 1, '2023-05-06 09:36:31', '2023-05-06 09:56:27', '2023-05-06 09:36:31', '2023-05-06 09:56:27'),
(72, 1, '2023-05-06 09:55:46', '2023-05-06 09:56:03', '2023-05-06 09:55:46', '2023-05-06 09:56:03'),
(73, 1, '2023-05-06 09:56:44', '2023-05-06 09:57:02', '2023-05-06 09:56:44', '2023-05-06 09:57:02'),
(74, 1, '2023-05-06 09:57:16', '2023-05-06 10:14:23', '2023-05-06 09:57:16', '2023-05-06 10:14:23'),
(75, 1, '2023-05-06 10:14:25', '2023-05-06 10:15:00', '2023-05-06 10:14:25', '2023-05-06 10:15:00'),
(76, 1, '2023-05-06 10:15:04', NULL, '2023-05-06 10:15:04', '2023-05-06 10:15:04'),
(77, 3, '2023-05-06 10:16:24', NULL, '2023-05-06 10:16:24', '2023-05-06 10:16:24'),
(78, 1, '2023-05-06 10:16:39', '2023-05-06 10:31:52', '2023-05-06 10:16:39', '2023-05-06 10:31:52'),
(79, 1, '2023-05-06 11:53:57', '2023-05-06 12:17:04', '2023-05-06 11:53:57', '2023-05-06 12:17:04'),
(80, 1, '2023-05-06 12:17:06', '2023-05-06 12:21:39', '2023-05-06 12:17:06', '2023-05-06 12:21:39'),
(81, 1, '2023-05-06 12:21:46', NULL, '2023-05-06 12:21:46', '2023-05-06 12:21:46'),
(82, 1, '2023-05-06 12:24:01', NULL, '2023-05-06 12:24:01', '2023-05-06 12:24:01'),
(83, 1, '2023-05-06 12:24:31', NULL, '2023-05-06 12:24:31', '2023-05-06 12:24:31'),
(84, 1, '2023-05-06 12:25:45', NULL, '2023-05-06 12:25:45', '2023-05-06 12:25:45'),
(85, 1, '2023-05-06 12:26:11', NULL, '2023-05-06 12:26:11', '2023-05-06 12:26:11'),
(86, 1, '2023-05-06 12:26:45', NULL, '2023-05-06 12:26:45', '2023-05-06 12:26:45'),
(87, 1, '2023-05-06 13:46:26', NULL, '2023-05-06 13:46:26', '2023-05-06 13:46:26'),
(88, 1, '2023-05-06 14:26:10', NULL, '2023-05-06 14:26:10', '2023-05-06 14:26:10'),
(89, 1, '2023-05-08 05:42:20', NULL, '2023-05-08 05:42:20', '2023-05-08 05:42:20'),
(90, 1, '2023-05-08 05:55:13', '2023-05-08 07:45:04', '2023-05-08 05:55:13', '2023-05-08 07:45:04'),
(91, 1, '2023-05-08 07:45:06', '2023-05-08 07:46:37', '2023-05-08 07:45:06', '2023-05-08 07:46:37'),
(92, 1, '2023-05-08 07:46:38', '2023-05-08 07:48:41', '2023-05-08 07:46:38', '2023-05-08 07:48:41'),
(93, 1, '2023-05-08 07:48:42', '2023-05-08 08:29:48', '2023-05-08 07:48:42', '2023-05-08 08:29:48'),
(94, 1, '2023-05-08 08:29:50', NULL, '2023-05-08 08:29:50', '2023-05-08 08:29:50'),
(95, 1, '2023-05-08 09:02:26', NULL, '2023-05-08 09:02:26', '2023-05-08 09:02:26'),
(96, 2, '2023-05-08 09:02:51', NULL, '2023-05-08 09:02:51', '2023-05-08 09:02:51'),
(97, 1, '2023-05-08 09:03:00', NULL, '2023-05-08 09:03:00', '2023-05-08 09:03:00'),
(98, 2, '2023-05-08 09:11:02', NULL, '2023-05-08 09:11:02', '2023-05-08 09:11:02'),
(99, 2, '2023-05-08 09:11:55', NULL, '2023-05-08 09:11:55', '2023-05-08 09:11:55'),
(100, 2, '2023-05-08 09:12:27', NULL, '2023-05-08 09:12:27', '2023-05-08 09:12:27'),
(101, 1, '2023-05-08 09:13:08', NULL, '2023-05-08 09:13:08', '2023-05-08 09:13:08'),
(102, 1, '2023-05-08 09:13:27', NULL, '2023-05-08 09:13:27', '2023-05-08 09:13:27'),
(103, 2, '2023-05-08 09:14:47', NULL, '2023-05-08 09:14:47', '2023-05-08 09:14:47'),
(104, 1, '2023-05-08 09:19:05', '2023-05-08 09:31:32', '2023-05-08 09:19:05', '2023-05-08 09:31:32'),
(105, 2, '2023-05-08 09:30:28', NULL, '2023-05-08 09:30:28', '2023-05-08 09:30:28'),
(106, 2, '2023-05-08 09:30:50', NULL, '2023-05-08 09:30:50', '2023-05-08 09:30:50'),
(107, 2, '2023-05-08 09:30:56', NULL, '2023-05-08 09:30:56', '2023-05-08 09:30:56'),
(108, 2, '2023-05-08 09:31:16', NULL, '2023-05-08 09:31:16', '2023-05-08 09:31:16'),
(109, 1, '2023-05-08 09:31:34', NULL, '2023-05-08 09:31:34', '2023-05-08 09:31:34'),
(110, 2, '2023-05-08 09:31:38', NULL, '2023-05-08 09:31:38', '2023-05-08 09:31:38'),
(111, 2, '2023-05-08 09:31:53', NULL, '2023-05-08 09:31:53', '2023-05-08 09:31:53'),
(112, 2, '2023-05-08 09:32:29', NULL, '2023-05-08 09:32:29', '2023-05-08 09:32:29'),
(113, 2, '2023-05-08 09:32:42', NULL, '2023-05-08 09:32:42', '2023-05-08 09:32:42'),
(114, 1, '2023-05-08 09:33:39', NULL, '2023-05-08 09:33:39', '2023-05-08 09:33:39'),
(115, 1, '2023-05-08 09:35:49', '2023-05-08 09:40:12', '2023-05-08 09:35:49', '2023-05-08 09:40:12'),
(116, 1, '2023-05-08 09:40:13', NULL, '2023-05-08 09:40:13', '2023-05-08 09:40:13'),
(117, 1, '2023-05-08 09:40:18', '2023-05-08 09:41:36', '2023-05-08 09:40:18', '2023-05-08 09:41:36'),
(118, 1, '2023-05-08 09:42:25', '2023-05-08 09:42:52', '2023-05-08 09:42:25', '2023-05-08 09:42:52'),
(119, 1, '2023-05-08 09:42:54', NULL, '2023-05-08 09:42:54', '2023-05-08 09:42:54'),
(120, 1, '2023-05-08 10:13:49', '2023-05-08 10:15:17', '2023-05-08 10:13:49', '2023-05-08 10:15:17'),
(121, 1, '2023-05-08 10:15:22', '2023-05-08 10:16:31', '2023-05-08 10:15:22', '2023-05-08 10:16:31'),
(122, 1, '2023-05-08 10:17:30', '2023-05-08 10:18:37', '2023-05-08 10:17:30', '2023-05-08 10:18:37'),
(123, 1, '2023-05-08 10:18:45', NULL, '2023-05-08 10:18:45', '2023-05-08 10:18:45'),
(124, 2, '2023-05-08 11:13:04', NULL, '2023-05-08 11:13:04', '2023-05-08 11:13:04'),
(125, 1, '2023-05-08 11:13:31', '2023-05-08 11:27:41', '2023-05-08 11:13:31', '2023-05-08 11:27:41'),
(126, 2, '2023-05-08 11:13:44', NULL, '2023-05-08 11:13:44', '2023-05-08 11:13:44'),
(127, 2, '2023-05-08 11:21:24', NULL, '2023-05-08 11:21:24', '2023-05-08 11:21:24'),
(128, 2, '2023-05-08 11:21:31', NULL, '2023-05-08 11:21:31', '2023-05-08 11:21:31'),
(129, 2, '2023-05-08 11:27:50', NULL, '2023-05-08 11:27:50', '2023-05-08 11:27:50'),
(130, 1, '2023-05-08 11:31:35', '2023-05-08 11:31:44', '2023-05-08 11:31:35', '2023-05-08 11:31:44'),
(131, 2, '2023-05-08 11:32:01', NULL, '2023-05-08 11:32:01', '2023-05-08 11:32:01'),
(132, 2, '2023-05-08 11:34:25', NULL, '2023-05-08 11:34:25', '2023-05-08 11:34:25'),
(133, 2, '2023-05-08 11:50:24', NULL, '2023-05-08 11:50:24', '2023-05-08 11:50:24'),
(134, 2, '2023-05-08 11:52:27', NULL, '2023-05-08 11:52:27', '2023-05-08 11:52:27'),
(135, 2, '2023-05-08 11:53:05', NULL, '2023-05-08 11:53:05', '2023-05-08 11:53:05'),
(136, 2, '2023-05-08 11:55:34', NULL, '2023-05-08 11:55:34', '2023-05-08 11:55:34'),
(137, 1, '2023-05-08 11:56:07', '2023-05-08 11:57:28', '2023-05-08 11:56:07', '2023-05-08 11:57:28'),
(138, 2, '2023-05-08 11:57:39', '2023-05-08 12:02:45', '2023-05-08 11:57:39', '2023-05-08 12:02:45'),
(139, 1, '2023-05-08 12:07:59', '2023-05-08 12:15:28', '2023-05-08 12:07:59', '2023-05-08 12:15:28'),
(140, 2, '2023-05-08 12:17:03', '2023-05-08 12:18:14', '2023-05-08 12:17:03', '2023-05-08 12:18:14'),
(141, 2, '2023-05-08 12:18:18', '2023-05-08 12:50:16', '2023-05-08 12:18:18', '2023-05-08 12:50:16'),
(142, 2, '2023-05-08 13:06:12', '2023-05-08 13:07:06', '2023-05-08 13:06:12', '2023-05-08 13:07:06'),
(143, 2, '2023-05-08 13:08:27', '2023-05-08 13:09:58', '2023-05-08 13:08:27', '2023-05-08 13:09:58'),
(144, 1, '2023-05-08 13:08:45', NULL, '2023-05-08 13:08:45', '2023-05-08 13:08:45'),
(145, 1, '2023-05-08 13:10:13', '2023-05-08 13:10:34', '2023-05-08 13:10:13', '2023-05-08 13:10:34'),
(146, 1, '2023-05-08 13:10:56', '2023-05-08 13:11:10', '2023-05-08 13:10:56', '2023-05-08 13:11:10'),
(147, 2, '2023-05-08 13:11:00', NULL, '2023-05-08 13:11:00', '2023-05-08 13:11:00'),
(148, 2, '2023-05-08 13:11:17', NULL, '2023-05-08 13:11:17', '2023-05-08 13:11:17'),
(149, 2, '2023-05-08 13:12:01', NULL, '2023-05-08 13:12:01', '2023-05-08 13:12:01'),
(150, 2, '2023-05-08 13:12:23', NULL, '2023-05-08 13:12:23', '2023-05-08 13:12:23'),
(151, 2, '2023-05-08 13:12:47', NULL, '2023-05-08 13:12:47', '2023-05-08 13:12:47'),
(152, 2, '2023-05-08 13:14:04', NULL, '2023-05-08 13:14:04', '2023-05-08 13:14:04'),
(153, 2, '2023-05-08 13:14:18', NULL, '2023-05-08 13:14:18', '2023-05-08 13:14:18'),
(154, 2, '2023-05-08 13:15:07', NULL, '2023-05-08 13:15:07', '2023-05-08 13:15:07'),
(155, 2, '2023-05-08 13:15:42', NULL, '2023-05-08 13:15:42', '2023-05-08 13:15:42'),
(156, 2, '2023-05-08 13:15:55', NULL, '2023-05-08 13:15:55', '2023-05-08 13:15:55'),
(157, 2, '2023-05-08 13:16:04', NULL, '2023-05-08 13:16:04', '2023-05-08 13:16:04'),
(158, 2, '2023-05-08 13:16:28', NULL, '2023-05-08 13:16:28', '2023-05-08 13:16:28'),
(159, 1, '2023-05-08 13:16:36', NULL, '2023-05-08 13:16:36', '2023-05-08 13:16:36'),
(160, 2, '2023-05-08 13:23:34', NULL, '2023-05-08 13:23:34', '2023-05-08 13:23:34'),
(161, 2, '2023-05-08 13:37:13', NULL, '2023-05-08 13:37:13', '2023-05-08 13:37:13'),
(162, 2, '2023-05-08 13:37:28', NULL, '2023-05-08 13:37:28', '2023-05-08 13:37:28'),
(163, 2, '2023-05-08 13:38:26', NULL, '2023-05-08 13:38:26', '2023-05-08 13:38:26'),
(164, 2, '2023-05-08 13:38:45', NULL, '2023-05-08 13:38:45', '2023-05-08 13:38:45'),
(165, 2, '2023-05-08 13:39:30', NULL, '2023-05-08 13:39:30', '2023-05-08 13:39:30'),
(166, 2, '2023-05-08 13:39:43', NULL, '2023-05-08 13:39:43', '2023-05-08 13:39:43'),
(167, 2, '2023-05-08 13:39:50', '2023-05-08 13:43:17', '2023-05-08 13:39:50', '2023-05-08 13:43:17'),
(168, 1, '2023-05-08 13:43:24', '2023-05-08 13:45:27', '2023-05-08 13:43:24', '2023-05-08 13:45:27'),
(169, 1, '2023-05-08 13:45:28', '2023-05-08 13:47:44', '2023-05-08 13:45:28', '2023-05-08 13:47:44'),
(170, 1, '2023-05-08 13:48:08', '2023-05-08 14:00:03', '2023-05-08 13:48:08', '2023-05-08 14:00:03'),
(171, 2, '2023-05-08 14:00:08', NULL, '2023-05-08 14:00:08', '2023-05-08 14:00:08'),
(172, 2, '2023-05-08 14:00:09', NULL, '2023-05-08 14:00:09', '2023-05-08 14:00:09'),
(173, 2, '2023-05-08 14:00:18', NULL, '2023-05-08 14:00:18', '2023-05-08 14:00:18'),
(174, 2, '2023-05-08 14:00:20', NULL, '2023-05-08 14:00:20', '2023-05-08 14:00:20'),
(175, 2, '2023-05-08 14:00:31', NULL, '2023-05-08 14:00:31', '2023-05-08 14:00:31'),
(176, 1, '2023-05-08 14:00:38', NULL, '2023-05-08 14:00:38', '2023-05-08 14:00:38'),
(177, 1, '2023-05-08 14:00:45', NULL, '2023-05-08 14:00:45', '2023-05-08 14:00:45'),
(178, 1, '2023-05-08 14:19:47', NULL, '2023-05-08 14:19:47', '2023-05-08 14:19:47'),
(179, 1, '2023-05-08 14:20:08', NULL, '2023-05-08 14:20:08', '2023-05-08 14:20:08'),
(180, 1, '2023-05-08 14:22:40', NULL, '2023-05-08 14:22:40', '2023-05-08 14:22:40'),
(181, 1, '2023-05-08 14:29:10', '2023-05-08 14:42:53', '2023-05-08 14:29:10', '2023-05-08 14:42:53'),
(182, 1, '2023-05-08 14:42:54', '2023-05-08 14:43:07', '2023-05-08 14:42:54', '2023-05-08 14:43:07'),
(183, 1, '2023-05-08 14:43:13', '2023-05-08 15:13:13', '2023-05-08 14:43:13', '2023-05-08 15:13:13'),
(184, 1, '2023-05-08 15:19:20', '2023-05-08 15:23:35', '2023-05-08 15:19:20', '2023-05-08 15:23:35'),
(185, 10, '2023-05-08 15:23:21', NULL, '2023-05-08 15:23:21', '2023-05-08 15:23:21'),
(186, 1, '2023-05-08 15:23:37', '2023-05-08 15:26:17', '2023-05-08 15:23:37', '2023-05-08 15:26:17'),
(187, 8, '2023-05-08 15:24:03', NULL, '2023-05-08 15:24:03', '2023-05-08 15:24:03'),
(188, 1, '2023-05-08 15:26:17', NULL, '2023-05-08 15:26:17', '2023-05-08 15:26:17'),
(189, 1, '2023-05-09 04:56:58', '2023-05-09 05:35:44', '2023-05-09 04:56:58', '2023-05-09 05:35:44'),
(190, 2, '2023-05-09 05:40:37', '2023-05-09 05:42:17', '2023-05-09 05:40:37', '2023-05-09 05:42:17'),
(191, 2, '2023-05-09 05:42:54', '2023-05-09 05:48:49', '2023-05-09 05:42:54', '2023-05-09 05:48:49'),
(192, 1, '2023-05-09 05:48:56', NULL, '2023-05-09 05:48:56', '2023-05-09 05:48:56'),
(193, 2, '2023-05-09 05:55:20', '2023-05-09 05:56:57', '2023-05-09 05:55:20', '2023-05-09 05:56:57'),
(194, 1, '2023-05-09 05:57:00', '2023-05-09 05:59:48', '2023-05-09 05:57:00', '2023-05-09 05:59:48'),
(195, 11, '2023-05-09 05:58:16', NULL, '2023-05-09 05:58:16', '2023-05-09 05:58:16'),
(196, 11, '2023-05-09 05:58:22', NULL, '2023-05-09 05:58:22', '2023-05-09 05:58:22'),
(197, 11, '2023-05-09 05:58:38', NULL, '2023-05-09 05:58:38', '2023-05-09 05:58:38'),
(198, 1, '2023-05-09 05:59:50', '2023-05-09 06:01:11', '2023-05-09 05:59:50', '2023-05-09 06:01:11'),
(199, 11, '2023-05-09 06:00:42', NULL, '2023-05-09 06:00:42', '2023-05-09 06:00:42'),
(200, 1, '2023-05-09 06:01:13', '2023-05-09 06:57:12', '2023-05-09 06:01:13', '2023-05-09 06:57:12'),
(201, 21, '2023-05-09 06:56:50', NULL, '2023-05-09 06:56:50', '2023-05-09 06:56:50'),
(202, 1, '2023-05-09 06:57:14', '2023-05-09 06:57:51', '2023-05-09 06:57:14', '2023-05-09 06:57:51'),
(203, 21, '2023-05-09 06:57:22', NULL, '2023-05-09 06:57:22', '2023-05-09 06:57:22'),
(204, 21, '2023-05-09 06:57:46', NULL, '2023-05-09 06:57:46', '2023-05-09 06:57:46'),
(205, 21, '2023-05-09 06:58:08', NULL, '2023-05-09 06:58:08', '2023-05-09 06:58:08'),
(206, 1, '2023-05-09 07:36:05', '2023-05-09 07:36:21', '2023-05-09 07:36:05', '2023-05-09 07:36:21'),
(207, 1, '2023-05-09 07:36:24', '2023-05-09 08:09:07', '2023-05-09 07:36:24', '2023-05-09 08:09:07'),
(208, 1, '2023-05-09 08:55:08', NULL, '2023-05-09 08:55:08', '2023-05-09 08:55:08'),
(209, 2, '2023-05-09 12:33:08', '2023-05-09 13:04:08', '2023-05-09 12:33:08', '2023-05-09 13:04:08'),
(210, 1, '2023-05-11 05:38:11', '2023-05-11 06:24:27', '2023-05-11 05:38:11', '2023-05-11 06:24:27'),
(211, 2, '2023-05-12 05:43:12', '2023-05-12 05:47:31', '2023-05-12 05:43:12', '2023-05-12 05:47:31'),
(212, 1, '2023-05-12 05:47:38', NULL, '2023-05-12 05:47:38', '2023-05-12 05:47:38'),
(213, 1, '2023-05-12 05:49:10', '2023-05-12 05:53:27', '2023-05-12 05:49:10', '2023-05-12 05:53:27'),
(214, 1, '2023-05-12 05:54:24', NULL, '2023-05-12 05:54:24', '2023-05-12 05:54:24'),
(215, 1, '2023-05-13 11:18:47', NULL, '2023-05-13 11:18:47', '2023-05-13 11:18:47'),
(216, 2, '2023-05-19 04:22:29', NULL, '2023-05-19 04:22:29', '2023-05-19 04:22:29'),
(217, 1, '2023-05-19 10:29:31', NULL, '2023-05-19 10:29:31', '2023-05-19 10:29:31'),
(218, 1, '2023-05-19 10:29:37', '2023-05-19 10:47:17', '2023-05-19 10:29:37', '2023-05-19 10:47:17'),
(219, 1, '2023-05-22 05:28:28', '2023-05-22 05:28:34', '2023-05-22 05:28:28', '2023-05-22 05:28:34'),
(220, 2, '2023-05-22 05:28:41', NULL, '2023-05-22 05:28:41', '2023-05-22 05:28:41'),
(221, 1, '2023-05-23 05:37:47', NULL, '2023-05-23 05:37:47', '2023-05-23 05:37:47'),
(222, 2, '2023-05-23 05:39:38', NULL, '2023-05-23 05:39:38', '2023-05-23 05:39:38'),
(223, 2, '2023-05-23 12:37:19', NULL, '2023-05-23 12:37:19', '2023-05-23 12:37:19'),
(224, 2, '2023-05-26 05:42:15', '2023-05-26 05:42:25', '2023-05-26 05:42:15', '2023-05-26 05:42:25'),
(225, 1, '2023-05-26 05:42:31', '2023-05-26 05:49:53', '2023-05-26 05:42:31', '2023-05-26 05:49:53'),
(226, 2, '2023-05-26 05:50:16', '2023-05-26 05:50:21', '2023-05-26 05:50:16', '2023-05-26 05:50:21'),
(227, 2, '2023-05-26 05:50:26', '2023-05-26 05:50:35', '2023-05-26 05:50:26', '2023-05-26 05:50:35'),
(228, 1, '2023-05-26 05:50:48', '2023-05-26 07:24:37', '2023-05-26 05:50:48', '2023-05-26 07:24:37');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tokens`
--

CREATE TABLE `tokens` (
  `id` int NOT NULL,
  `token` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `postId` (`postId`);

--
-- Indexes for table `lz_business_settings`
--
ALTER TABLE `lz_business_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lz_city`
--
ALTER TABLE `lz_city`
  ADD PRIMARY KEY (`id`),
  ADD KEY `country_id` (`country_id`),
  ADD KEY `state_id` (`state_id`);

--
-- Indexes for table `lz_client_subscription`
--
ALTER TABLE `lz_client_subscription`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lz_country`
--
ALTER TABLE `lz_country`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lz_currency`
--
ALTER TABLE `lz_currency`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lz_language`
--
ALTER TABLE `lz_language`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lz_masters`
--
ALTER TABLE `lz_masters`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lz_modules`
--
ALTER TABLE `lz_modules`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lz_organization`
--
ALTER TABLE `lz_organization`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lz_roles`
--
ALTER TABLE `lz_roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lz_settings`
--
ALTER TABLE `lz_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lz_state`
--
ALTER TABLE `lz_state`
  ADD PRIMARY KEY (`id`),
  ADD KEY `country_id` (`country_id`);

--
-- Indexes for table `lz_subscription`
--
ALTER TABLE `lz_subscription`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lz_support_ticket`
--
ALTER TABLE `lz_support_ticket`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lz_templates`
--
ALTER TABLE `lz_templates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lz_translations`
--
ALTER TABLE `lz_translations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lz_users`
--
ALTER TABLE `lz_users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lz_user_timeline`
--
ALTER TABLE `lz_user_timeline`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tokens`
--
ALTER TABLE `tokens`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lz_business_settings`
--
ALTER TABLE `lz_business_settings`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `lz_city`
--
ALTER TABLE `lz_city`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `lz_client_subscription`
--
ALTER TABLE `lz_client_subscription`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `lz_country`
--
ALTER TABLE `lz_country`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `lz_currency`
--
ALTER TABLE `lz_currency`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `lz_language`
--
ALTER TABLE `lz_language`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `lz_masters`
--
ALTER TABLE `lz_masters`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `lz_modules`
--
ALTER TABLE `lz_modules`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `lz_organization`
--
ALTER TABLE `lz_organization`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `lz_roles`
--
ALTER TABLE `lz_roles`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `lz_settings`
--
ALTER TABLE `lz_settings`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lz_state`
--
ALTER TABLE `lz_state`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `lz_subscription`
--
ALTER TABLE `lz_subscription`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `lz_support_ticket`
--
ALTER TABLE `lz_support_ticket`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `lz_templates`
--
ALTER TABLE `lz_templates`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `lz_translations`
--
ALTER TABLE `lz_translations`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=894;

--
-- AUTO_INCREMENT for table `lz_users`
--
ALTER TABLE `lz_users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `lz_user_timeline`
--
ALTER TABLE `lz_user_timeline`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=229;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tokens`
--
ALTER TABLE `tokens`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `comments_ibfk_1` FOREIGN KEY (`postId`) REFERENCES `posts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `lz_city`
--
ALTER TABLE `lz_city`
  ADD CONSTRAINT `lz_city_ibfk_4` FOREIGN KEY (`country_id`) REFERENCES `lz_country` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `lz_city_ibfk_5` FOREIGN KEY (`state_id`) REFERENCES `lz_state` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `lz_state`
--
ALTER TABLE `lz_state`
  ADD CONSTRAINT `lz_state_ibfk_1` FOREIGN KEY (`country_id`) REFERENCES `lz_country` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
