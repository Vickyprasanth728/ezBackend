import React, { Fragment, useState, useEffect } from "react";
import Breadcrumb from "../common/breadcrumb";
import data from "../../assets/data/listPages";
import Datatable from "../common/datatable";
import DataTable from "react-data-table-component";
import { Offcanvas, Toast } from 'bootstrap';
import { ToastContainer, toast } from 'react-toastify';
import { useFormik } from 'formik';
import 'react-toastify/dist/ReactToastify.css';
import { json, Link, useNavigate } from 'react-router-dom';
import * as Yup from 'yup';
import { getPages, savePage, PageEdit, updatePage, deletePage} from "../pages/core/_requests"
import { Card, CardBody, CardHeader, Col, Container, Row } from "reactstrap";


const initialValues = {
    "id": "",
    "type": "",
    "title": "",
    "slug": "",
    "content": "",
    "meta_title": "",
    "meta_description": "",
    "keywords": "",
    "meta_image": "",
}

const ListPages = () => {

	const pageSchema = Yup.object().shape({
        title: Yup.string()
        .min(3, 'Minimum 3 characters')
        .max(50, 'Maximum 50 characters')
        .required('* Title is required'),
    })

    const [allPageList, setAllPageList] = useState([]);
    const [selectedId, setSelectedId] = useState('');
	const [deleteOpen, setDeleteOpen] = useState(false);


	// const PageList = async () => {
    //     const pageResponse = await getPages()
    //     console.log('All Pages List');
    //     console.log(pageResponse.Data);
    //     setAllPageList(pageResponse.Data);
    // }

	const PageList = async () => {
        const pageResponse = await getPages()
        console.log('All Pages List', pageResponse.Data);

		let new_array = [];
		for(let i=0; i<pageResponse.Data.length;i++) {
			let cur_obj = {
				...pageResponse.Data[i],
				'sl_no': i + 1 
			}
			new_array.push(cur_obj)
		}
        setAllPageList(new_array);
		console.log('New Array', new_array);
		console.log('Page Response', pageResponse.Data);
    }

	const columns = [
		{
			name: "id",
			selector:  row => row.sl_no,
			sortable: true,
		},
		{
			name: "Title",
			selector: row => row.title,
			sortable: true,
		},
		// {
		// 	name: "Type",
		// 	selector: row => row.type,
		// 	sortable: true,
		// },
		{
			name: "Slug",
			selector: row => row.slug,
			sortable: true,
		},
		{
			name: "Content",
			selector: row => row.content,
			sortable: true,
		},
		// {
		// 	name: "Meta Description",
		// 	selector: row => row.meta_description,
		// 	sortable: true,
		// },
		{
			name:"Actions",
			cell: (row, index) => (
				<div>
					{/* <span>
						<button
						className="btn btn-danger btn-sm fa fa-pencil mx-2 m-2"
						data-toggle="modal"
						// onClick={() => EditBlog(row.id)}
						>
						</button>
					</span> */}
					<span >
						<button
						className="btn btn-primary btn-sm fa fa-trash mx-2"
						onClick={() => PageDelete(row.id)}
						data-bs-toggle='modal' 
						data-bs-target={'#delete_confirm_popup452222' + selectedId}
						>
						</button>
					</span>
				</div>
			),
		}
	]

	const onDelete = async (id) => {
        console.log(id);
        await deletePage(id);
        PageList();
    }

	const onDeleteModal = () => {
		setDeleteOpen(true);
	};

	const oncloseDeleteModal = () => {
		setDeleteOpen(false);
	};

	const PageDelete = async (id) => {
        setSelectedId(id);
		onDeleteModal(id);
    }

	useEffect(() => {
        PageList();
    }, []);

	return (
		<Fragment>
			<Breadcrumb title="List Pages" parent="Pages" />
			<Container fluid={true}>
				<Row>
					<Col sm="12">
						<Card>
							{/* <CardHeader>
								<h5>Page List</h5>
							</CardHeader> */}
							<CardHeader className="mb-4">
								<div className='row align-items-center'>
									<div className='col-auto'>
										<h5>Page List</h5>
									</div>
									<div className='d-flex justify-content-end col' data-kt-user-table-toolbar='base'>
										<Link to='/pages/create-page' className="btn btn-primary">
											Create Page
										</Link>
									</div>
								</div>
							</CardHeader>
							<CardBody>
								<div
									id="batchDelete"
									className="category-table order-table coupon-list-delete"
								>
									{/* <Datatable
										multiSelectOption={true}
										myData={data}
										pageSize={7}
										pagination={false}
										class="-striped -highlight"
									/> */}
									<Fragment>
									<DataTable 
										// myData={allBrands}
										data={allPageList}
										columns={columns}
										multiSelectOption={true}
										pageSize={10}
										pagination={true}
										class="-striped -highlight"
										className="text-center"
									/>
								</Fragment>
								</div>
							</CardBody>
						</Card>
					</Col>
				</Row>
			</Container>

			{/* Delete Modal */}
			<div isOpen={deleteOpen} toggle={oncloseDeleteModal}>
				<div className='modal fade p-6' id={'delete_confirm_popup452222' + selectedId} aria-hidden='true'>
					<div className='modal-dialog modal-dialog-centered'>
						<div className='modal-content'>
							<div className='modal-header'>
								<h3 className="text-dark">Confirmation</h3>
								<div className='btn btn-sm btn-icon btn-active-color-primary' data-bs-dismiss='modal'>
								</div>
							</div>
							<div className='modal-body'>
								<div className='text-center'>
									<h4>Are you sure want to Delete ? </h4>
								</div>
								<div className='d-flex align-items-center justify-content-center'>
									<button className='btn btn-sm btn-outline-danger mx-4 mt-3' data-bs-dismiss='modal' onClick={(e) => onDelete(selectedId)}>
										Yes
									</button>
									<button className='btn btn-sm btn-outline-secondary mt-3 me-3' data-bs-dismiss='modal'>
										No
									</button>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</Fragment>
	);
};

export default ListPages;
