import React, { Fragment, useState, useEffect } from "react";
import { Tabs, TabList, TabPanel, Tab } from "react-tabs";
import { Button, Form, Input, Label } from "reactstrap";
import MDEditor from "@uiw/react-md-editor";
import DataTable from "react-data-table-component";
import { Offcanvas, Toast } from 'bootstrap';
import { ToastContainer, toast } from 'react-toastify';
import { useFormik } from 'formik';
import { Link, useNavigate } from 'react-router-dom';
import 'react-toastify/dist/ReactToastify.css';
import * as Yup from 'yup';
import { getPages, savePage, PageEdit, updatePage, deletePage} from "../pages/core/_requests"

const initialValues = {
    "id": "",
    "type": "",
    "title": "",
    "slug": "",
    "content": "",
    "meta_title": "",
    "meta_description": "",
    "keywords": "",
    "meta_image": "",
}

const TabsetPage = () => {

    const navigate = useNavigate();
	
	const pageSchema = Yup.object().shape({
        title: Yup.string()
        .min(3, '* Minimum 3 characters')
        .max(50, '* Maximum 50 characters')
        .required('* Title is required'),
    })

    const [allPageList, setAllPageList] = useState([]);
    const [pageEditId, setPageEditId] = useState([]);
	
    const [selectedId, setSelectedId] = useState('');
    const [dataBinded, setDataBinded] = useState(false);
    const [loading, setLoading] = useState(false);
	const [value, setValue] = useState([])
    const [added_by, setAddedBy] = useState();

	const onChange = (e) =>{
		setAddedBy(e)
	}

	const pageList = async () => {
        const pageResponse = await getPages()
        console.log('All Pages List');
        console.log(pageResponse.Data);
        setAllPageList(pageResponse.Data);
    }

	const formik = useFormik({
        initialValues,
        validationSchema: pageSchema,
        onSubmit: async (values, { setStatus, setSubmitting, resetForm }) => {
            setLoading(true)
            try {
                const body = {
                    "type": values.type || "type",
                    "title": values.title,
                    "slug": values.slug,
                    "content": added_by,
                    "meta_title": values.meta_title,
                    "meta_description": values.meta_description,
                    "keywords": values.keywords,
                    "meta_image": values.meta_image,
                }

                console.log('lead form body');
                console.log(body);
                if (!dataBinded) {
                    const savePageData = await savePage(body);

                    if (savePageData != null) {
                        setLoading(false);
                        document.getElementById('kt_team_close')?.click();
                        // var toastEl = document.getElementById('myToastAdd');
                        // const bsToast = new Toast(toastEl);
                        // bsToast.show();
                        resetForm();
                        pageList();
						setAddedBy();
						NavPage();
                    }

                } else {
                    const updatePageData = await updatePage(selectedId, body);

                    if (updatePageData != null) {
                        setLoading(false);
                        // var toastEl = document.getElementById('myToastUpdate');
                        // const bsToast = new Toast(toastEl);
                        // bsToast.show();
                        resetForm();
                        pageList();
                    }
                }

            } catch (error) {
                console.error(error)
                setStatus('The registration details is incorrect')
                setSubmitting(false)
                setLoading(false)
            }
            pageList();
			NavPage();
            resetForm();
        }
    })

	const EditPage = async (id) => {
        setSelectedId(id);
        const pageEdit = await PageEdit(id)
        setPageEditId(pageEdit.Data);

        setDataBinded(true);
        formik.setFieldValue('title', pageEdit.Data.title);
    }

	const NavPage =()=>{
        setTimeout(
            () => navigate('/pages/list-page'),
            2000
          );
        }

	useEffect(() => {
        pageList();
    }, []);

	return (
		<Fragment>
			<div>
				<Tabs>
					<TabList className="nav nav-tabs tab-coupon">
						<Tab className="nav-link">General</Tab>
						{/* <Tab className="nav-link">SEO</Tab> */}
					</TabList>
					<Form className="needs-validation" noValidate onSubmit={formik.handleSubmit}>

					<TabPanel>
							<h4>General</h4>
							<div className="form-group row">
								<Label className="col-xl-3 col-md-4">
									Title
								</Label>
								<div className="col-xl-8 col-md-7 p-0">
									{formik.touched.title && formik.errors.title && (
										<div className='fv-plugins-message-container mb-2'>
											<div className='fv-help-block'>
												<span role='alert' className='text-danger'>{formik.errors.title}</span>
											</div>
										</div>
									)}
									<Input
										className="form-control"
										placeholder="Title"
										id="validationCustom0"
										type="text"
										{...formik.getFieldProps('title')}
									/>
								</div>
							</div>
							<div className="form-group row editor-label">
								<Label className="col-xl-3 col-md-4">
									 Content
								</Label>
									
								<div className="col-xl-8 col-md-7 editor-space p-0">
								<MDEditor
									className="form-control"
									id="validationCustom0"
									type="text"
									value={added_by}
									onChange={onChange}
									// onChange = {(e)=> setAddedBy(e.target.value)}
									textareaProps={{
										placeholder: "Content"
									}}
								/>
								</div>
							</div>
							{/* <div className="form-group row">
								<Label className="col-xl-3 col-md-4">Status</Label>
								<div className="col-xl-8 col-md-7 px-1">
									<Label className="d-block">
										<Input
											className="checkbox_animated"
											id="chk-ani1"
											type="checkbox"
										/>
										Enable the Coupon
									</Label>
								</div>
							</div> */}

							{/* <div className="pull-right">
								<Button type="submit" color="primary">
									Save
								</Button>
							</div> */}
					{/* </TabPanel>
					<TabPanel> */}
						<Form className="needs-validation">
							{/* <h4>SEO</h4> */}
							<div className="form-group row">
								<Label className="col-xl-3 col-md-4">Meta Title</Label>
								<div className="col-xl-8 col-md-7 p-0">
									<Input
										className="form-control"
										id="validationCustom2"
										placeholder="Meta Title"
										type="text"
										{...formik.getFieldProps('meta_title')}
									/>
								</div>
							</div>
							<div className="form-group row editor-label">
								<Label className="col-xl-3 col-md-4">Meta Description</Label>
								<textarea rows="4" className="col-xl-8 col-md-7" placeholder="Meta Description" {...formik.getFieldProps('meta_description')}></textarea>
							</div>
						</Form>
					</TabPanel>
					<div className="pull-right">
						<Button type="submit" color="primary">
							Save
						</Button>
					</div>
					</Form>
				</Tabs>
				{/* <div className="pull-right">
					<Button type="submit" color="primary">
						Save
					</Button>
				</div> */}
			</div>
		</Fragment>
	);
};

export default TabsetPage;
