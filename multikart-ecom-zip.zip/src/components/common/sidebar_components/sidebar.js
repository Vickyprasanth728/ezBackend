import React, { Fragment, useState,useRef, useEffect } from "react";
import UserPanel from "./user-panel";
import { MENUITEMS } from "../../../constants/menu";
// import vts_india from "../../../../public/icons/vts_india.png";

// image import
// import logo from "../../../assets/images/dashboard/multikart-logo.png";
import { useFormik } from 'formik';
import DataTable from "react-data-table-component";
import { Link, useNavigate } from 'react-router-dom';
// import Datatable from "../../common/datatable";
import { Offcanvas, Toast } from 'bootstrap';
import * as Yup from 'yup';
import {getBSList, saveBS, deleteBS,getBSEdit, updateBS } from '../../settings/General/core/_requests';
import logo from "../../../assets/icons/no_image.jpg";

const initialValues = {
    "header_logo": "",
    // "site_name": "",
    "id": "",
    "type": "",
    "value": "",
    "lang": "",
  }

const Sidebar = () => {
	const [mainmenu, setMainMenu] = useState(MENUITEMS);
	const [isChange, setIsChange] = useState(false);

	useEffect(() => {
		const currentUrl = window.location.pathname;
		mainmenu.map((items) => {
			mainMenu.filter((Items) => {
				if (Items.path === currentUrl) setNavActive(Items);
				if (!Items.children) return false;
				Items.children.filter((subItems) => {
					if (subItems.path === currentUrl) setNavActive(subItems);
					if (!subItems.children) return false;
					subItems.children.filter((subSubItems) => {
						if (subSubItems.path === currentUrl) {
							setNavActive(subSubItems);
							return true;
						} else {
							return false;
						}
					});
					return subItems;
				});
				return Items;
			});
			return items;
		});
		return () => {
			setMainMenu(MENUITEMS);
		};
	},[isChange]);

	const setNavActive = (item) => {
		setIsChange(!isChange)
		MENUITEMS.filter((menuItem) => {
			if (menuItem !== item) menuItem.active = false;
			if (menuItem.children && menuItem.children.includes(item))
				menuItem.active = true;
			if (menuItem.children) {
				menuItem.children.filter((submenuItems) => {
					if (submenuItems !== item) {
						submenuItems.active = false;
					}
					if (submenuItems.children) {
						submenuItems.children.map(
							(childItem) => (childItem.active = false)
						);
						if (submenuItems.children.includes(item)) {
							submenuItems.active = true;
							menuItem.active = true;
						}
					}
					return false;
				});
			}
			return false;
		});
		item.active = !item.active;
		setMainMenu(MENUITEMS);
	};
	
	const mainMenu = mainmenu.map((menuItem, i) => (
		<li className={`${menuItem.active ? "active" : ""}`} key={i}>
			{menuItem.sidebartitle ? (
				<div className="sidebar-title">{menuItem.sidebartitle}</div>
			) : (
				""
			)}
			{menuItem.type === "sub" ? (
				<a
					className="sidebar-header "
					href="#javaScript"
					onClick={(event) =>{event.preventDefault(); return setNavActive(menuItem)}}
				>
					<menuItem.icon />
					<span>{menuItem.title}</span>
					<i className="fa fa-angle-right pull-right"></i>
				</a>
			) : (
				""
			)}
			{menuItem.type === "link" ? (
				<Link
					to={`${process.env.PUBLIC_URL}${menuItem.path}`}
					className={`sidebar-header ${menuItem.active ? "active" : ""}`}
					onClick={() => setNavActive(menuItem)}
				>
					<menuItem.icon />
					<span>{menuItem.title}</span>
					{menuItem.children ? (
						<i className="fa fa-angle-right pull-right"></i>
					) : (
						""
					)}
				</Link>
			) : (
				""
			)}
			{menuItem.children ? (
				<ul
					className={`sidebar-submenu ${menuItem.active ? "menu-open" : ""}`}
					style={
						menuItem.active
							? { opacity: 1, transition: "opacity 500ms ease-in" }
							: {}
					}
				>
					{menuItem.children.map((childrenItem, index) => (
						<li
							key={index}
							className={
								childrenItem.children
									? childrenItem.active
										? "active"
										: ""
									: ""
							}
						>
							{childrenItem.type === "sub" ? (
								<a href="#javaScript" onClick={(event) =>{event.preventDefault(); return setNavActive(childrenItem)}}>
									<i className="fa fa-circle"></i>
									{childrenItem.title}{" "}
									<i className="fa fa-angle-right pull-right"></i>
								</a>
							) : (
								""
							)}

							{childrenItem.type === "link" ? (
								<Link
									to={`${process.env.PUBLIC_URL}${childrenItem.path}`}
									className={childrenItem.active ? "active" : ""}
									onClick={() => setNavActive(childrenItem)}
								>
									<i className="fa fa-circle"></i>
									{childrenItem.title}{" "}
								</Link>
							) : (
								""
							)}
							{childrenItem.children ? (
								<ul
									className={`sidebar-submenu ${
										childrenItem.active ? "menu-open" : "active"
									}`}
								>
									{childrenItem.children.map((childrenSubItem, key) => (
										<li
											className={childrenSubItem.active ? "active" : ""}
											key={key}
										>
											{childrenSubItem.type === "link" ? (
												<Link
													to={`${process.env.PUBLIC_URL}${childrenSubItem.path}`}
													className={childrenSubItem.active ? "active" : ""}
													onClick={() => setNavActive(childrenSubItem)}
												>
													<i className="fa fa-circle"></i>
													{childrenSubItem.title}
												</Link>
											) : (
												""
											)}
										</li>
									))}
								</ul>
							) : (
								""
							)}
						</li>
					))}
				</ul>
			) : (
				""
			)}
		</li>
	));
	

	const BSSchema = Yup.object().shape({
        // name: Yup.string().required('* Name is required'),
    })

    var userId = localStorage.getItem('userId')
	console.log("oo",userId)

    const [allBSList, setBSList] = useState([]);
    const [allBSEdit, setBSEdit] = useState([]);
    const [selectedId, setSelectedId] = useState('');
    const [dataBinded, setDataBinded] = useState(false);
    const viewLogo = useRef(null);
    const [loading, setLoading] = useState(false);
    const [isLoading, setIsLoading] = useState(false);

    const [uploadImagePreview, setuploadImagePreview] = useState(null);
    const viewUpload = useRef(null);
    const [UploadImage, setUploadImage] = useState(null);

    const BSList = async () => {
        const BSResponse = await getBSList()
        setBSList(BSResponse.Data);
        console.log("BSResponse", BSResponse.Data);

		document.getElementById('headerID')?.click()
    }

    const formik = useFormik({
        initialValues,
        validationSchema: BSSchema,
        onSubmit: async (values, { setStatus, setSubmitting, resetForm }) => {
            setLoading(true)
            try {

                var formData = new FormData();

                // formData.append('id',  id.toString());
                // formData.append('type', allBSEdit.type);
                // formData.append('value', UploadImage);
               
                // formData.append('type', values.type);
                // formData.append('value', UploadImage);

                formData.append('type', values.id);
                formData.append('value', values.site_name);
        
                const updateUserData = await updateBS('site_name', formData)
        
                console.log('updateUserData');
                console.log(updateUserData);
                if(updateUserData!= null){
                    setLoading(false)
                    document.getElementById('kt_useredit_close')?.click();
                    var toastEl = document.getElementById('myToastUpdate');
                    const bsToast = new Toast(toastEl);
                    bsToast.show();
                    console.log("check");
                } 

            } catch (error) {
                console.error(error)
                setStatus('The color details is incorrect')
                setSubmitting(false)
                setLoading(false)
            }
        }
    })

	// const EditBS = async (id) => {
    //     setSelectedId(id);

    //     const BSEditResponse = await getBSEdit(id);
    //     setBSEdit(BSEditResponse);
        
    //     console.log("BS", BSEditResponse);
    //     console.log("Type ID", BSEditResponse.type);
    //     setDataBinded(true);
    //     formik.setFieldValue('id', BSEditResponse.id);
    //     formik.setFieldValue('type', BSEditResponse.type);
    //     formik.setFieldValue('value', BSEditResponse.value);
    // }


	const EditBusSet = async (type) => {
        setSelectedId(type);

        const busSetResponse = await getBSEdit(type)
        setBSEdit(busSetResponse.Data);
        setDataBinded(true);
		console.log("busSetResponse", busSetResponse.Data);
    }
	useEffect(() => {
        BSList();
    }, []);

	return (
		<Fragment>
			<div className="page-sidebar">
				<div className="main-header-left d-none d-lg-block">
					<div className="logo-wrapper mx-auto d-block">
						<Link to={`${process.env.PUBLIC_URL}/dashboard`}>
							{/* <img className="blur-up lazyloaded img-fluid" src={logo} alt="" /> */}
							{/* <img className="blur-up lazyloaded" src={vts_india} alt="" /> */}
							{(allBSEdit.value !== "null" )? 
								<div className="file-preview box sm">
									<img src={process.env.REACT_APP_API_BASE_URL + 'uploads/setting/values/' + allBSEdit.type + '/' + allBSEdit.value} className="mx-auto d-block blur-up lazyloaded" height={60} width={150} alt='' />
								</div> :
								<img
								src={logo}
								alt=""
								className="img-80 mx-auto d-block blur-up lazyloaded"
							/>
							}
						</Link>
					</div>
				</div>
				<button onClick={(e) => EditBusSet("header_logo")} id="headerID" className='d-none'></button>
				<div className="sidebar custom-scrollbar">
					<UserPanel />
					<ul className="sidebar-menu">{mainMenu}</ul>
				</div>
			</div>
		</Fragment>
	);
};

export default Sidebar;
