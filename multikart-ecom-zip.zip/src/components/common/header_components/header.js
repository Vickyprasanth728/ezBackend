import React, { Fragment, useState, useEffect } from "react";
import SearchHeader from "./searchHeader";
import Notification from "./notification";
import UserMenu from "./user-menu";
import Language from "./language";
import {
	AlignLeft,
	Maximize2,
	Bell,
	MessageSquare,
	MoreHorizontal,
} from "react-feather";
import {getBSList, saveBS, deleteBS,getBSEdit, updateBS } from '../../settings/General/core/_requests';

//images
// import logo from "../../../assets/images/dashboard/multikart-logo.png";
import logo from "../../../assets/icons/vts-sidebar-logo.png";

const Header = () => {
	const [sidebar, setSidebar] = useState(true);
	const [rightSidebar, setRightSidebar] = useState(true);
	const [navMenus, setNavMenus] = useState(false);

	const [allBSList, setBSList] = useState([]);
    const [allBSEdit, setBSEdit] = useState([]);
    const [selectedId, setSelectedId] = useState([]);
    const [dataBinded, setDataBinded] = useState(false);

	const BSList = async () => {
        const BSResponse = await getBSList()
        setBSList(BSResponse.Data);
        document.getElementById('bsId')?.click()
    }

	const EditBS = async (type) => {
        setSelectedId(type);

        const allBSEdit = await getBSEdit(type);
        setBSEdit(allBSEdit.Data);
        
        console.log("Type ID", allBSEdit.Data.type);
        console.log("Value ID", allBSEdit.Data.value);
        setDataBinded(true);

    }

	const toggle = () => {
		// setNavMenus((prevState) => ({
		// 	navMenus: !prevState.navMenus,
		// }));
		setNavMenus(!navMenus)
	};

	const showRightSidebar = () => {
		if (rightSidebar) {
			setRightSidebar(false);
			document.querySelector(".right-sidebar").classList.add("show");
		} else {
			setRightSidebar(true);
			document.querySelector(".right-sidebar").classList.remove("show");
		}
	};
	const goFull = () => {
		if (
			(document.fullScreenElement && document.fullScreenElement !== null) ||
			(!document.mozFullScreen && !document.webkitIsFullScreen)
		) {
			if (document.documentElement.requestFullScreen) {
				document.documentElement.requestFullScreen();
			} else if (document.documentElement.mozRequestFullScreen) {
				document.documentElement.mozRequestFullScreen();
			} else if (document.documentElement.webkitRequestFullScreen) {
				document.documentElement.webkitRequestFullScreen(
					Element.ALLOW_KEYBOARD_INPUT
				);
			}
		} else {
			if (document.cancelFullScreen) {
				document.cancelFullScreen();
			} else if (document.mozCancelFullScreen) {
				document.mozCancelFullScreen();
			} else if (document.webkitCancelFullScreen) {
				document.webkitCancelFullScreen();
			}
		}
	};
	const openCloseSidebar = () => {
		if (sidebar) {
			setSidebar(false);
			document.querySelector(".page-main-header").classList.add("open");
			document.querySelector(".page-sidebar").classList.add("open");
			document.querySelector(".footer").classList.add("open");
		} else {
			setSidebar(true);
			document.querySelector(".page-main-header").classList.remove("open");
			document.querySelector(".page-sidebar").classList.remove("open");
			document.querySelector(".footer").classList.remove("open");
		}
	};
    useEffect(() => {
        BSList();
    }, []);
	return (
		<Fragment>
			{/* open */}
			<button onClick={(e) => EditBS("site_name")} id="bsId" className='d-none'></button>
			<div className="page-main-header ">
				<div className="main-header-right row">
					<div className="main-header-left d-lg-none col-auto">
						<div className="logo-wrapper">
							<a href="index.html">
								<img className="blur-up lazyloaded img-fluid" src={logo} alt="" />
							</a>
						</div>
					</div>
					<div className="mobile-sidebar col-auto p-0">
						<div className="media-body text-end switch-sm">
							<label className="switch">
								<a href="#javaScript" onClick={openCloseSidebar}>
									<AlignLeft />
								</a>
							</label>
						</div>
					</div>
					<div className="col-auto p-0">
						<div className="text-end">
							<div className="mt-3 mx-2"> 
								<h4 className="text-uppercase font-weight-bold">{allBSEdit.value}</h4>
							</div>
						</div>
					</div>
					<div className="nav-right col">
						<ul className={"nav-menus " + (navMenus ? "open" : "")}>
							
							<li>
								<SearchHeader />
							</li>
							<li>
								<a onClick={goFull} className="text-dark" href="#javaScript">
									<Maximize2 />
								</a>
							</li>
							<li className="onhover-dropdown">
								<a className="txt-dark" href="#javaScript">
									<h6>EN</h6>
								</a>
								<Language />
							</li>

							<li className="onhover-dropdown">
								<Bell />
								<span className="badge rounded-pill badge-primary pull-right notification-badge">
									3
								</span>
								<span className="dot"></span>
								<Notification />
							</li>
							<li>
								<a href="#javaScript" onClick={showRightSidebar}>
									<MessageSquare />
									<span className="dot"></span>
								</a>
							</li>
							<UserMenu />
						</ul>
						<div
							className="d-lg-none mobile-toggle pull-right"
							onClick={() => toggle()}
						>
							<MoreHorizontal />
						</div>
					</div>
				</div>
			</div>
		</Fragment>
	);
};

export default Header;
