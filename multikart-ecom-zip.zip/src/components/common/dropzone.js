import React, { Fragment, useState,useRef, useEffect } from "react";
import { useFormik } from 'formik';
import Dropzone from 'react-dropzone-uploader'
import { Offcanvas, Toast } from 'bootstrap';
import * as Yup from 'yup';
import { getUploads, saveUpload,editUpload, deleteUpload} from "../media/core/_requests"
import {
	Button,
	Card,
	CardBody,
	CardHeader,
	Col,
	Container,
	Form,
	FormGroup,
	Input,
	Label,
	Modal,
	ModalBody,
	ModalFooter,
	ModalHeader,
	Row,
} from "reactstrap";

const initialValues = {
  "id": "",
  "file_original_name": "",
  "file_name": "",
  "user_id": "",
  "file_size": "",
  "extension": "",
  "type": "",
  "external_link": "",
}

const MyUploader = () => {
  var userId = localStorage.getItem('userId')
	console.log("oo",userId);

  const MediaSchema = Yup.object().shape({
    // file_name: Yup.string().required('* File name is required'),
  })

  const [display, setDisplay] = useState(false);
  const [logoImagePreview, setlogoImagePreview] = useState(null);
  const [selectedId, setSelectedId] = useState('');
  const [dataBinded, setDataBinded] = useState(false);
  const viewLogo = useRef(null);
  const [logoImage, setLogoImage] = useState(null);
  const [loading, setLoading] = useState(false);
  const [editClicked, setEditClicked] = useState(false);
  const [editId, setEditId] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const [allUploads, setAllUploads] = useState([]);
  const [deleteOpen, setDeleteOpen] = useState(false);

const UploadList = async () => {
      const uploadResponse = await getUploads()
      console.log('Upload List');
      console.log(uploadResponse.Data);
      setAllUploads(uploadResponse.Data);
  }

  const formik = useFormik({
    initialValues,
    validationSchema: MediaSchema,
    onSubmit: async (values, { setStatus, setSubmitting, resetForm }) => {
        setLoading(true)
        try {

            var formData = new FormData();

            // const body = {
            //     "name": values.name,
            //     "logo": values.logo,
            //     "top": values.top,
            //     "slug": values.slug,
            //     "meta_title": values.meta_title,
            //     "meta_description": values.meta_description,
            // }

            formData.append('file_name', logoImage);
            formData.append('user_id', userId);
            formData.append('external_link', values.external_link || null);

            const headers = {
                headers: {
                    "Content-type": "multipart/form-data",
                },
            }

            console.log('lead form body');
            console.log(formData);
            if (!dataBinded) {
                const uploadData = await saveUpload(formData, headers);

                if (uploadData != null) {
                    setLoading(false);
                    document.getElementById('kt_team_close')?.click();
                    // var toastEl = document.getElementById('myToastAdd');
                    // const bsToast = new Toast(toastEl);
                    // bsToast.show();
                    resetForm();
                    UploadList();
                }
            } else {
                // const updateBrandData = await updateBrand(selectedId, formData);

                // if (updateBrandData != null) {
                //     setLoading(false);
                //     var toastEl = document.getElementById('myToastUpdate');
                //     const bsToast = new Toast(toastEl);
                //     bsToast.show();
                //     resetForm();
                //     setDataBinded(false);
                //     clearForm();
                // }
            }
            UploadList();
          document.getElementById('uploadRender')?.click()

        } catch (error) {
            console.error(error)
            setStatus('The registration details is incorrect')
            setSubmitting(false)
            setLoading(false)
        }
    }
})

const handleLogoPreview = (e) => {
  let image_as_base64 = URL.createObjectURL(e.target.files[0])
  let image_as_files = e.target.files[0];

  let fields = viewLogo.current?.value.split(".");

  let fileType = fields [fields.length - 1];

  if (fileType == 'jpg' || fileType == 'jpeg' || fileType == 'pdf'  || fileType == 'png') {
      setlogoImagePreview(image_as_base64);
      setLogoImage(image_as_files);
  } else {
      setlogoImagePreview(null);
      setLogoImage(null);
      if (viewLogo.current != null) {
          viewLogo.current.value = "";
      }
  }
  console.log(viewLogo.current?.value);
  console.log(image_as_files);
  console.log(fileType);
}

const removeLogo = () => {
  console.log(viewLogo.current?.value);
  if (viewLogo.current != null) {
      setlogoImagePreview(null);
      setLogoImage(null);
      viewLogo.current.value = "";
  }
}

useEffect(() => {
  UploadList();
}, [display])

  // specify upload params and url for your files
  const getUploadParams = () => {
    setDisplay(!display)
    return { url: "https://httpbin.org/post"};
  };

  // called every time a file's `status` changes
  const handleChangeStatus = ({ meta }, status) => {
    setDisplay(!display)
    console.log("handleChangeStatus", status, meta);
  };

  // receives array of files that are done uploading when submit button is clicked
  const handleSubmit = (files, allFiles) => {
    console.log("HandleSubmit",files.map(f => f.meta));
    allFiles.forEach(f => f.remove());
  };


  return (
    <div className="dropzone">
      <Form noValidate onSubmit={formik.handleSubmit}>
        <div className="form-group mb-0">
          {/* <label className='text-gray-700 fw-bold m-2'>Upload Files</label> */}
          <div className="col-md-12">
            {/* <div className="input-group" data-toggle="aizuploader" data-type="image" data-multiple="true"> */}
              {/* <input type="file" className="form-control file-amount mt-2" name="profile_image" /> */}
              <span className="btn btn-file">
                  <i className="fa fa-upload my-2" aria-hidden="true"></i>
                  <p className='text_primary'>Upload Media Files</p>
                  {/* <input type="file" className='form-control' name="profile_image"/> */}
                  <input type="file" className='form-control' name="profile_image" ref={viewLogo} onChange={handleLogoPreview} />

              </span>
              {/* <input type="file" className='form-control' name="profile_image" ref={viewLogo} onChange={handleLogoPreview} /> */}
            {/* </div> */}
            <div className="file-preview box sm">
            </div>
          </div>
          <div className="file-preview box sm d-flex justify-content-center align-items-center mt-4 mx-4">
          {logoImagePreview != null && (
            <div className='profile_preview position-relative image-input image-input-outline'>
              <img src={logoImagePreview} alt="image preview" className='image-input-wrapper w-100px h-100px' height={100} width={100} />
              <div onClick={removeLogo} className="p-1 fa fa-remove text-danger" style={{fontSize:"30px" , cursor:"pointer"}}>
							</div>
            </div>
          )}
          </div>
        </div>

        <div className='card-footer py-5 text-center' id='kt_task_footer'>
          <button
            type='submit'
            id='submit_button'
            className='btn btn-primary text-white mx-2'
            disabled={formik.isSubmitting}
            style={{ backgroundColor: '#ffbe57' }}
          // onClick={()=>{toComponentB()}}
          // onClick={() => alert()}
          >
            {!loading && <span className='indicator-label'>Submit
            </span>}
            {loading && (
              <span className='indicator-progress' style={{ display: 'block' }}>
                Please wait...{' '}
                <span className='spinner-border spinner-border-sm align-middle ms-2'></span>
              </span>
            )}
          </button>
        </div>
      </Form>
     {/* <Dropzone
      getUploadParams={getUploadParams}
      onChangeStatus={handleChangeStatus}
      onSubmit={handleSubmit}
      styles={{ dropzone: { minHeight: 300, maxHeight: 300 } }}
    /> */}
    </div>
    
  )
}

export default MyUploader