import axios, {AxiosResponse}  from 'axios'

const API_URL = process.env.REACT_APP_API_URL

// Uploads // Media
export const GET_UPLOADS = `${API_URL}/get_upload_files`
export const SAVE_UPLOAD = `${API_URL}/save_upload_file`
export const EDIT_UPLOAD = `${API_URL}/edit_upload_file`
export const DELETE_UPLOAD = `${API_URL}/delete_uploads_file`

export function getUploads() {
    return axios.get(GET_UPLOADS)
    .then((response => response.data))
}

export function saveUpload(body) {
    return axios.post(SAVE_UPLOAD, body)
    .then((response => response.data))
}

export function editUpload(id) {
    return axios.get(EDIT_UPLOAD+'/'+id)
    .then((response => response.data))
}

export function deleteUpload(id) {
    return axios.put(DELETE_UPLOAD+'/'+id)
    .then((response => response.data))
}