import React, { Fragment, useState, useEffect } from "react";
import Breadcrumb from "../common/breadcrumb";
import MyDropzone from "../common/dropzone";
import Datatable from "../common/datatable";
import data from "../../assets/data/media";
import DataTable from "react-data-table-component";
import { Offcanvas, Toast } from 'bootstrap';
import { ToastContainer, toast } from 'react-toastify';
import { useFormik } from 'formik';
import 'react-toastify/dist/ReactToastify.css';
import * as Yup from 'yup';
import { Card, CardBody, CardHeader, Container } from "reactstrap";
import { getUploads, saveUpload, editUpload, deleteUpload} from "../media/core/_requests"
import logo from "../../assets/icons/no_image.jpg";


const initialValues = {
    "id": "",
    "file_original_name": "",
    "file_name": "",
    "user_id": "",
    "file_size": "",
    "extension": "",
    "type": "",
    "external_link": "",
}

const Media = () => {

	const MediaSchema = Yup.object().shape({
        file_name: Yup.string().required('* File name is required'),
    })

    const [allUploads, setAllUploads] = useState([]);
    const [selectedId, setSelectedId] = useState('');
	const [deleteOpen, setDeleteOpen] = useState(false);

	// const UploadList = async () => {
    //     const uploadResponse = await getUploads()
    //     console.log('Upload List');
    //     console.log(uploadResponse.Data);
    //     setAllUploads(uploadResponse.Data);
    // }

	const UploadList = async () => {
        const uploadResponse = await getUploads()
        console.log('Upload List', uploadResponse.Data);
    
		let new_array = [];
		for(let i=0; i<uploadResponse.Data.length;i++) {
			let cur_obj = {
				...uploadResponse.Data[i],
				'sl_no': i + 1 
			}
			new_array.push(cur_obj)
		}
        setAllUploads(new_array);
		console.log('New Array', new_array);
		console.log('Upload Response', uploadResponse.Data);
    }

	const columns = [
		{
			name: "id",
			selector:  row => row.sl_no,
			sortable: true,
		},
		{
			name: "Images",
			selector: row => 
				<div>
				{row.file_name !== null || "" ? 
					<div className="file-preview box sm">
						<img src={process.env.REACT_APP_API_BASE_URL + 'uploads/all_uploads/file_name/' + row.id + '/' + row.file_name} className=""  height={50} width={80}  alt='' />
					</div> :
					<img src={logo} className="" height={50} width={80} alt='' />
				}
				</div>
		},
		{
			name: "File",
			selector: row => row.file_original_name,
			sortable: true,
		},
		{
			name: "User Name",
			selector: row => row.user_name,
			sortable: true,
		},
		{
			name: "File Size",
			selector: row => row.file_size,
			sortable: true,
		},
		// {
		// 	name: "Extension",
		// 	selector: row => row.extension,
		// 	sortable: true,
		// },
		// {
		// 	name:"Actions",
		// 	cell: (row, index) => (
		// 		<div>
		// 			{/* <span>
		// 				<button
		// 				className="btn btn-danger btn-sm fa fa-pencil mx-2 m-2"
		// 				data-toggle="modal"
		// 				// onClick={() => EditUpload(row.id)}
		// 				>
		// 				</button>
		// 			</span> */}
		// 			<span >
		// 				<button
		// 				className="btn btn-primary btn-sm fa fa-trash mx-2"
		// 				onClick={() => UploadDelete(row.id)}
		// 				data-bs-toggle='modal' 
		// 				data-bs-target={'#delete_confirm_popup452222' + selectedId}
		// 				>
		// 				</button>
		// 			</span>
		// 		</div>
		// 	),
		// }
	]

	const onDelete = async (id) => {
        console.log(id);
        await deleteUpload(id);
        UploadList();
    }

	const onDeleteModal = () => {
		setDeleteOpen(true);
	};

	const oncloseDeleteModal = () => {
		setDeleteOpen(false);
	};

	const UploadDelete = async (id) => {
        setSelectedId(id);
		onDeleteModal(id);
    }

	useEffect(() => {
        UploadList();
    }, []);

	return (
		<Fragment>
			<button type="button" className="d-none" id="uploadRender" onClick={()=>UploadList()}></button>
			<Breadcrumb title="Media" parent="Media" />
			<Container fluid={true}>
				<Card>
					<CardHeader>
						<h5>Dropzone Media</h5>
					</CardHeader>
					<CardBody>
						<MyDropzone />
					</CardBody>
				</Card>
				<Card>
					<CardHeader>
						<h5>Media File List</h5>
					</CardHeader>
					<CardBody>
						<div
							id="batchDelete"
							className="category-table media-table coupon-list-delete"
						>
							{/* <Datatable
								multiSelectOption={true}
								myData={data}
								pageSize={10}
								pagination={true}
								class="-striped -highlight"
							/> */}
								<Fragment>
									<DataTable 
										// myData={allBrands}
										data={allUploads}
										columns={columns}
										multiSelectOption={true}
										pageSize={10}
										pagination={true}
										class="-striped -highlight"
										className="text-center"
									/>
								</Fragment>
						</div>
					</CardBody>
				</Card>
			</Container>
			{/* Delete Modal */}
			<div isOpen={deleteOpen} toggle={oncloseDeleteModal}>
				<div className='modal fade p-6' id={'delete_confirm_popup452222' + selectedId} aria-hidden='true'>
					<div className='modal-dialog modal-dialog-centered'>
						<div className='modal-content'>
							<div className='modal-header'>
								<h3 className="text-dark">Confirmation</h3>
								<div className='btn btn-sm btn-icon btn-active-color-primary' data-bs-dismiss='modal'>
								</div>
							</div>
							<div className='modal-body'>
								<div className='text-center'>
									<h4>Are you sure want to Delete ? </h4>
								</div>
								<div className='d-flex align-items-center justify-content-center'>
									<button className='btn btn-sm btn-outline-danger mx-4 mt-3' data-bs-dismiss='modal' onClick={(e) => onDelete(selectedId)}>
										Yes
									</button>
									<button className='btn btn-sm btn-outline-secondary mt-3 me-3' data-bs-dismiss='modal'>
										No
									</button>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</Fragment>
	);
};

export default Media;
