import axios, {AxiosResponse}  from 'axios'

const API_URL = process.env.REACT_APP_API_URL

// Users
export const GET_USERS = `${API_URL}/get_users`
export const SEND_NEWSLETTER_MAIL = `${API_URL}/send_newsletter_mail`


// Users
export function getUsers() {
    return axios.get(GET_USERS)
    .then((response => response.data))
}

export function sendNewsletterMail(postData, headers) {
    return axios.post(SEND_NEWSLETTER_MAIL, postData, headers)
    .then((response => response.data))
}
