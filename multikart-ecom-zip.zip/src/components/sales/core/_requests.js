import axios, {AxiosResponse}  from 'axios'

const API_URL = process.env.REACT_APP_API_URL

// Users
export const GET_ORDERS = `${API_URL}/get_all_orders_list`
export const DELETE_ORDER = `${API_URL}/delete_sales_list`
export const EDIT_ORDER = `${API_URL}/get_sales_list_id`
export const UPDATE_ORDER = `${API_URL}/update_order`

// payment_status
export const GET_PAYMENT_STATUS = `${API_URL}/get_payment_status`
export const GET_DELIVERY_STATUS = `${API_URL}/get_delivery_status`
export const GET_SHIPPING_TYPE = `${API_URL}/get_shipping_type`

// Users
export function getOrders() {
    return axios.get(GET_ORDERS)
    .then((response => response.data))
}

export function editOrder(id) {
    return axios.get(EDIT_ORDER+'/'+id)
    .then((response => response.data))
}

export function updateOrder(id ,body) {
    return axios.put(UPDATE_ORDER+'/'+id, body)
    .then((response => response.data))
}

export function deleteOrder(id) {
    return axios.delete(DELETE_ORDER+'/'+id)
    .then((response => response.data))
}

// Masters
// Payment Status
export function getPaymentStatus() {
    return axios.get(GET_PAYMENT_STATUS)
    .then((response => response.data))
}
// Delievery Status
export function getDeliveryStatus() {
    return axios.get(GET_DELIVERY_STATUS)
    .then((response => response.data))
}
// Shipping Type
export function getShippingType() {
    return axios.get(GET_SHIPPING_TYPE)
    .then((response => response.data))
}