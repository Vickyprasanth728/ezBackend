import axios, {AxiosResponse}  from 'axios'

const API_URL = process.env.REACT_APP_API_URL

// Users
export const GET_USERS = `${API_URL}/get_users`
export const SAVE_USER = `${API_URL}/save_user`
export const EDIT_USER = `${API_URL}/get_user_id`
export const UPDATE_USER = `${API_URL}/put_user`
export const DELETE_USER = `${API_URL}/delete_user`
// Roles
export const GET_ROLES = `${API_URL}/get_roles `


// Users
export function getUsers() {
    return axios.get(GET_USERS)
    .then((response => response.data))
}

export function saveUser(postData, headers) {
    return axios.post(SAVE_USER, postData, headers)
    .then((response => response.data))
}

export function editUser(id) {
    return axios.get(EDIT_USER+'/'+id)
    .then((response => response.data))
}

export function updateUser(id ,body) {
    return axios.put(UPDATE_USER+'/'+id, body)
    .then((response => response.data))
}

export function deleteUser(id) {
    return axios.delete(DELETE_USER+'/'+id)
    .then((response => response.data))
}

// Roles
export function getRoles() {
    return axios.get(GET_ROLES)
    .then((response => response.data))
}

