import React, { Fragment, useState, useRef, useEffect } from "react";
import Breadcrumb from "../common/breadcrumb";
import data from "../../assets/data/listUser";
import Datatable from "../common/datatable";
import { useFormik } from 'formik';
import DataTable from "react-data-table-component";
import { Link, useNavigate } from 'react-router-dom';
import { Offcanvas, Toast } from 'bootstrap';
import * as Yup from 'yup';
import { 
	Card, 
	CardBody, 
	CardHeader, 
	Container, 	
	Modal,
	ModalBody,
	ModalFooter,
	ModalHeader, 
	Form
} from "reactstrap";
import { getUsers, saveUser, editUser, updateUser, deleteUser, getRoles } from '../users/core/_requests';
import logo from "../../assets/icons/no_image.jpg";

const initialValues = {
    "id" : "",
    "referred_by" : "",
    "provider_id" : "",
    "user_type" : "",
    "name" : "",
    "email" : "",
    "email_verified_at" : "",
    "verification_code" : "",
    "new_email_verificiation_code" : "",
    "password" : "" ,
    "remember_token" : "" ,
    "device_token" : "",
    "avatar" : ""  ,
    "avatar_original" : "",
    "address" : "",
    "country" : "",
    "state" : "",
    "city" : "",
    "postal_code" : "" ,
    "phone" : "",
    "balance" : "" ,
    "banned" : "" ,
    "referral_code" : "",
    "customer_package_id" : "" ,
    "remaining_uploads" : "",
}

const List_user = () => {

	const UsersSchema = Yup.object().shape({
        name: Yup.string()
		.min(3, '* Minimum 3 characters')
		.max(50, '* Maximum 50 characters')
		.required('* Name is required'),
        email: Yup.string()
            .email('Wrong email format')
            .min(3, '* Minimum 3 characters')
            .max(50, '* Maximum 50 characters')
            .required('* Email is required'),
        password: Yup.string().required('* Password is required'),
        phone: Yup.string()
        .min(10, '* Minimum 10 symbols')
        .max(10, '* Maximum 10 symbols'),
    })

	var userId = localStorage.getItem('userId')
	console.log("User ID",userId);

    const [allUsers, setAllUsers] = useState([]);
    const [allRoles, setAllRoles] = useState([]);
    const [allUserEdit, setAllUserEdit] = useState([]);
    const [allCategoryBlogs, setAllCategoryBlogs] = useState([]);
    const [loading, setLoading] = useState(false);
    const [editClicked, setEditClicked] = useState(false);
    const [editId, setEditId] = useState('');
    const [selectedId, setSelectedId] = useState('');
    const [blogEdit, setBlogEdit] = useState([]);
    const [dataBinded, setDataBinded] = useState(false);
    const [changeClicked, setChangeClicked] = useState(false);

	const [open, setOpen] = useState(false);
	const [editOpen, setEditOpen] = useState(false);
	const [deleteOpen, setDeleteOpen] = useState(false);

	const [logoImagePreview, setlogoImagePreview] = useState(null);
    const viewLogo = useRef(null);
    const [logoImage, setLogoImage] = useState(null);

    // const UsersList = async () => {
    //     const UsersResponse = await getUsers()
    //     console.log('All Users List');
    //     console.log(UsersResponse.Data);
    //     setAllUsers(UsersResponse.Data);
    // }
	
    const UsersList = async () => {
        const UsersResponse = await getUsers()
        console.log('All Users List', UsersResponse.Data);

		let new_array = [];
		for(let i=0; i<UsersResponse.Data.length; i++) {
			let cur_obj = {
				...UsersResponse.Data[i],
				'sl_no': i + 1 
			}
			new_array.push(cur_obj)
		}
        setAllUsers(new_array);
		console.log('New Array', new_array);
		console.log('Users Response', UsersResponse.Data);
    }

    const RolesList = async () => {
        const UsersResponse = await getRoles()
        console.log('All Users List');
        console.log(UsersResponse);
        setAllRoles(UsersResponse);
    }

	const formik = useFormik({
        initialValues,
        validationSchema: UsersSchema,
        onSubmit: async (values, {setStatus, setSubmitting, resetForm}) => {
          setLoading(true)
          try {
              
            const body = {

                // "id" : values.id,
                // "referred_by" : values.referred_by,
                // "provider_id" : values.provider_id,
                // "user_type" : values.user_type,
                // "name" : values.name,
                // "email" : values.email,
                // "email_verified_at" : values.email_verified_at,
                // "verification_code" : values.verification_code,
                // "new_email_verificiation_code" : values.new_email_verificiation_code,
                // "password" : values.password,
                // "remember_token" : values.remember_token,
                // "device_token" : values.device_token,
                // "avatar" : values.avatar,
                // "avatar_original" : values.avatar_original,
                // "address" : values.address,
                // "country" : values.country,
                // "state" : values.state,
                // "city" : values.city,
                // "postal_code" : values.postal_code,
                // "phone" : values.phone,
                // "balance" : values.balance,
                // "banned" : values.banned,
                // "referral_code" : values.referral_code,
                // "customer_package_id" : values.customer_package_id,
                // "remaining_uploads" : values.remaining_uploads,
           
            }

            var formData = new FormData();

            formData.append("id" , values.id);
            formData.append("referred_by" , values.referred_by);
            formData.append("provider_id" , values.provider_id);
            formData.append("user_type" , values.user_type);
            formData.append('name', values.name);
            formData.append('email', values.email);
            formData.append('email_verified_at', values.email_verified_at);
            formData.append('verification_code', values.verification_code);
            formData.append('new_email_verificiation_code', values.new_email_verificiation_code);
            formData.append('password', values.password);
            formData.append('remember_token', values.remember_token);
            formData.append('device_token', values.device_token);
            formData.append('avatar', logoImage);
            formData.append('avatar_original', values.avatar_original);
            formData.append('address', values.address);
            formData.append('country', values.country);
            formData.append('state', values.state);
            formData.append('city', values.city);
            formData.append('postal_code', values.postal_code);
            formData.append('phone', values.phone);
            formData.append('balance', values.balance);
            formData.append('banned', values.banned);
            formData.append('referral_code', values.referral_code);
            formData.append('customer_package_id', values.customer_package_id);
            formData.append('remaining_uploads', values.remaining_uploads);
            
            const headers = {
                headers: {
                    "Content-type": "multipart/form-data",
                },
            }
                
            console.log('lead form body');
            console.log(formData);
            if(!dataBinded){
                const saveUsersData = await saveUser(formData, headers);
            
                if(saveUsersData != null) {
                    setLoading(false);
                    document.getElementById('kt_team_close')?.click();
                    var toastEl = document.getElementById('myToastAdd');
                    const bsToast = new Toast(toastEl);
                    bsToast.show();
                    resetForm();
                    UsersList();
                }

            } else {
                const updateUserData = await updateUser(selectedId, formData);

                if (updateUserData != null) {
                    setLoading(false);
                    var toastEl = document.getElementById('myToastUpdate');
                    const bsToast = new Toast(toastEl);
                    bsToast.show();
                    resetForm();
                    setDataBinded(false);
                    UsersList();
                    resetForm();
                }
            }
            UsersList();
			setEditOpen(false);
			document.getElementById('sampleTest')?.click()
			document.getElementById('sampleTest2')?.click()
			document.getElementById('sampleTest3')?.click()
			document.getElementById('sampleTest4')?.click()
    
          } catch (error) {
            console.error(error)
            setStatus('The registration details is incorrect')
            setSubmitting(false)
            setLoading(false)
        }
          UsersList();
          resetForm();
		  onCloseEdit();
        }
    })

	const handleLogoPreview = (e) => {
        let image_as_base64 = URL.createObjectURL(e.target.files[0])
        let image_as_files = e.target.files[0];

        let fields = viewLogo.current?.value.split(".");

        let fileType = fields [fields.length - 1];

        if (fileType == 'jpg' || fileType == 'jpeg' || fileType == 'pdf'  || fileType == 'png') {
            setlogoImagePreview(image_as_base64);
            setLogoImage(image_as_files);
        } else {
            setlogoImagePreview(null);
            setLogoImage(null);
            if (viewLogo.current != null) {
                viewLogo.current.value = "";
            }
        }
        console.log(viewLogo.current?.value);
        console.log(image_as_files);
        console.log(fileType);
    }

    const removeLogo = () => {
        console.log(viewLogo.current?.value);
        if (viewLogo.current != null) {
            setlogoImagePreview(null);
            setLogoImage(null);
            viewLogo.current.value = "";
        }
    }

	const columns = [
		{
			name: "id",
			selector:  row => row.sl_no,
			sortable: true,
		},
		{
			name: "Avatar",
			selector: row => 
            <div>
                {row.avatar !== null ? 
                    <div className="file-preview box sm">
                        <img src={process.env.REACT_APP_API_BASE_URL + 'uploads/users/avatar/' + row.id + '/' + row.avatar} className="img-fluid img-60" height={80} width={80} alt='' />
                    </div>
                     :
                    <img src={logo} className="img-fluid img-60" height={80} width={80} alt='' />
                }
			</div>
		},
		{
			name: "Name",
			selector: row => row.name,
			sortable: true,
		},
		{
			name: "Email",
			selector: row => row.email,
			sortable: true,
		},
		{
			name: "Role",
			selector: row => row.user_type,
			sortable: true,
		},
		{
			name:"Actions",
			cell: (row, index) => (
				<div>
					<span>
						<button
						className="btn btn-danger btn-sm fa fa-pencil mx-2 m-2 button_size"
						data-toggle="modal"
						onClick={() => UserEditId(row.id)}
						>
						</button>
					</span>
					<span >
						<button
						className="btn btn-primary btn-sm fa fa-trash mx-2 button_size"
						onClick={() => UserDelete(row.id)}
						data-bs-toggle='modal' 
						data-bs-target={'#delete_confirm_popup452222' + selectedId}
						>
						</button>
					</span>
				</div>
			),
		}
	]

	const onEditModal = () => {
		setEditOpen(true);
	};
	const onCloseEdit = () => {
		setEditOpen(false);
		removeLogo();
	};
	const onDeleteModal = () => {
		setDeleteOpen(true);
	};
	const oncloseDeleteModal = () => {
		setDeleteOpen(false);
	};

    const UserDelete = async (id) => {
        setSelectedId(id);
		onDeleteModal(id);
    }
    const clearForm = () => {
        formik.resetForm();
        // setDataBinded(false);
		setOpen(false);
		setEditOpen(false);
		removeLogo();
    }
    const allClear = () => {
        formik.resetForm();
        setDataBinded(false);
		removeLogo();
    }

	const UserEditId = async (id) => {
        setSelectedId(id);
        const allUserEdit = await editUser(id)
        setAllUserEdit(allUserEdit.Data);
        setDataBinded(true);
        formik.setFieldValue('name', allUserEdit.Data.name);
        formik.setFieldValue('email', allUserEdit.Data.email);
        formik.setFieldValue('password', allUserEdit.Data.password);
        formik.setFieldValue('address', allUserEdit.Data.address);
        formik.setFieldValue('phone', allUserEdit.Data.phone);
        formik.setFieldValue('user_type', allUserEdit.Data.user_type);
		onEditModal();
    }

    const onDelete = async (id) => {
        console.log(id);
        await deleteUser(id);
		var toastEl = document.getElementById('myToastDelete');
		const bsToast = new Toast(toastEl);
		bsToast.show();
        UsersList();
    }

    const clearButton = () => {
        formik.resetForm();
        setDataBinded(false);
    }

    useEffect(() => {
        UsersList();
        RolesList();
    }, []);

	return (
		<Fragment>
			<Breadcrumb title="User List" parent="Users" />
			<Container fluid={true}>
				<Card className="shadow">
					<CardHeader>
						<h5>User Details</h5>
					</CardHeader>
					<CardBody>
						<div className="btn-popup pull-right">
							<Link to="/users/create-user" className="btn btn-primary">
								Create User
							</Link>
						</div>

					{/* Edit Modal */}
					<Modal isOpen={editOpen} toggle={onCloseEdit} className='modal-lg'>
						<ModalHeader toggle={onCloseEdit}>
							<h5
								className="modal-title f-w-600"
								id="exampleModalLabel2"
							>
								Edit User
							</h5>
						</ModalHeader>
						<ModalBody>
						<Form noValidate onSubmit={formik.handleSubmit}>
							<div className="row">
								<div className="form-group mb-4 col-lg-6">
									<label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold m-2">Name</label>
									<div className="input-group">
										<input type="text" className="form-control" placeholder="Name" {...formik.getFieldProps('name')} />
									</div>
									{formik.touched.name && formik.errors.name && (
										<div className='fv-plugins-message-container'>
											<div className='fv-help-block'>
												<span role='alert' className='text-danger'>{formik.errors.name}</span>
											</div>
										</div>
									)}
								</div>
								<div className="form-group mb-4 col-lg-6">
									<label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold m-2">Email</label>
									<div className="input-group">
										<input type="text" className="form-control" placeholder="Email" {...formik.getFieldProps('email')} />
									</div>
									{formik.touched.email && formik.errors.email && (
										<div className='fv-plugins-message-container'>
											<div className='fv-help-block'>
												<span role='alert' className='text-danger'>{formik.errors.email}</span>
											</div>
										</div>
									)}
								</div>
							</div>

							<div className="row">
								<div className="form-group mb-4 col-lg-6">
									<label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold">Address</label>
									<div className="input-group">
										<textarea type="text" className="form-control" placeholder="Address" {...formik.getFieldProps('address')} ></textarea>
									</div>
									{formik.touched.address && formik.errors.address && (
										<div className='fv-plugins-message-container'>
											<div className='fv-help-block'>
												<span role='alert' className='text-danger'>{formik.errors.address}</span>
											</div>
										</div>
									)}
								</div>
								<div className="form-group mb-4 col-lg-6">
									<label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold">Phone</label>
									<div className="input-group">
										<input type="number" className="form-control" placeholder="Phone" {...formik.getFieldProps('phone')} />
									</div>
									{formik.touched.phone && formik.errors.phone && (
										<div className='fv-plugins-message-container'>
											<div className='fv-help-block'>
												<span role='alert' className='text-danger'>{formik.errors.phone}</span>
											</div>
										</div>
									)}
								</div>
							</div>
							
							<div className="row">
								<div className="form-group mb-0 col-lg-6">
									<label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold">Avatar</label>
									<div className="">
										<div className="input-group" data-toggle="aizuploader" data-type="image" data-multiple="true">

											{/* <input type="file" className="form-control file-amount mt-2" name="profile_image" /> */}
											<input type="file" className='form-control ' name="profile_image" ref={viewLogo} onChange={handleLogoPreview} />
										</div>
										<div className="file-preview box sm">
										</div>
									</div>
									<div className="file-preview box sm d-flex justify-content-center align-items-center mt-4 mx-4">
									{/* {logoImagePreview != null && (
										<div className='profile_preview position-relative image-input image-input-outline'>
											<img src={logoImagePreview} alt="image preview" className='image-input-wrapper w-100px h-100px' height={100} width={150} />
											<div onClick={removeLogo} className="p-1 fa fa-remove" style={{fontSize:"36px"}}>
											
											</div>
										</div>
									)} */}
										{logoImagePreview != null ? <div className="file-preview box sm">
											{logoImagePreview != null && (
												<div className='profile_preview position-relative image-input image-input-outline'>
													<img src={logoImagePreview} alt="image preview" className='image-input-wrapper w-100px h-100px' height={100} width={150} />
													<div onClick={removeLogo} className="p-1 fa fa-remove text-danger" style={{fontSize:"30px" , cursor:"pointer"}}>
													</div>	
												</div>
											)}
										</div> : allUserEdit.avatar == null ? <img src={logo} className="" height={100} width={150} alt='' />  :
											<div className='profile_preview position-relative image-input image-input-outline'>
												<img src={process.env.REACT_APP_API_BASE_URL + 'uploads/users/avatar/' + allUserEdit.id + '/' + allUserEdit.avatar} className="image-input-wrapper w-100px h-100px shadow" height={100} width={150} alt='' />
											</div> 
										}
									</div>
									</div>
								{/* <div className="form-group mb-4 col-lg-6">
									<label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold">Phone</label>
									<div className="input-group">
										<input type="number" className="form-control" placeholder="Phone" {...formik.getFieldProps('phone')} />
									</div>
									{formik.touched.phone && formik.errors.phone && (
										<div className='fv-plugins-message-container'>
											<div className='fv-help-block'>
												<span role='alert' className='text-danger'>{formik.errors.phone}</span>
											</div>
										</div>
									)}
								</div> */}
							</div>

							{/* <div className="row">
								<div className="form-group mb-4 col-lg-6">
									<label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold">Unit Price</label>
									<div className="input-group">
										<input type="number" className="form-control" placeholder="Unit Price" {...formik.getFieldProps('unit_price')} />
									</div>
									{formik.touched.unit_price && formik.errors.unit_price && (
										<div className='fv-plugins-message-container'>
											<div className='fv-help-block'>
												<span role='alert' className='text-danger'>{formik.errors.unit_price}</span>
											</div>
										</div>
									)}
								</div>
								<div className="form-group mb-3 col-lg-6">
									<label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold">Gallery Img</label>
									<div className="col-xl-12 col-sm-7">
										<div className="input-group" data-toggle="aizuploader" data-type="image" data-multiple="true">
											<input type="file" className='form-control' ref={viewLogo} onChange={handleLogoPreview} />
										</div>
										<div className="file-preview box sm">
											{logoImagePreview != null && (
												<div className='profile_preview position-relative image-input image-input-outline'>
													<img src={logoImagePreview} alt="image preview" className='image-input-wrapper w-100px h-100px' height={100} width={100} />
													<div onClick={removeLogo} className="p-1 cursor-pointer">
														
													</div>
												</div>
											)}
										</div>
									</div>
									<div className="valid-feedback">Looks good!</div>
								</div>
							</div> */}
								<div className='card-footer py-5 text-center' id='kt_task_footer'>
									<button
										type='submit'
										id='submit_button'
										className='btn btn-primary text-white mx-2'
										disabled={formik.isSubmitting}
										style={{backgroundColor:'#ffbe57'}}
										// onClick={()=>{toComponentB()}}
										// onClick={() => alert()}
									>
										{!loading && <span className='indicator-label'> Update
										</span>}
										{loading && (
											<span className='indicator-progress' style={{ display: 'block' }}>
												Please wait...{' '}
												<span className='spinner-border spinner-border-sm align-middle ms-2'></span>
											</span>
										)}
									</button>

									<div className='btn btn-danger text-white' onClick={clearForm} > Cancel</div>
								</div>
						</Form>
						</ModalBody>
					</Modal>
					
					{/* Delete Modal */}
					<div isOpen={deleteOpen} toggle={oncloseDeleteModal}>
						<div className='modal fade p-6' id={'delete_confirm_popup452222' + selectedId} aria-hidden='true'>
							<div className='modal-dialog modal-dialog-centered'>
								<div className='modal-content'>
									<div className='modal-header'>
										<h3 className="text-dark">Confirmation</h3>
										<div className='btn btn-sm btn-icon btn-active-color-primary' data-bs-dismiss='modal'>
										</div>
									</div>
									<div className='modal-body'>
										<div className='text-center'>
											<h4>Are you sure want to Delete ? </h4>
										</div>
										<div className='d-flex align-items-center justify-content-center'>
											<button className='btn btn-sm btn-outline-danger mx-4 mt-3' data-bs-dismiss='modal' onClick={(e) => onDelete(selectedId)}>
												Yes
											</button>
											<button className='btn btn-sm btn-outline-secondary mt-3 me-3' data-bs-dismiss='modal' onClick={clearForm}>
												No
											</button>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
						<div className="clearfix"></div>
						<div id="basicScenario" className="product-physical">
									{/* <Datatable
										myData={data}
										columns={columns}
										multiSelectOption={false}
										pageSize={10}
										pagination={true}
										class="-striped -highlight"
									/> */}
			                    <Fragment>
									<DataTable 
										// myData={data}
										data={allUsers}
										columns={columns}
										multiSelectOption={true}
										pageSize={10}
										pagination={true}
										class="-striped -highlight"
										className="text-center"
									/>
								</Fragment>
								</div>
					</CardBody>
				</Card>
			</Container>
			<div aria-atomic="true" aria-live="assertive" className="toast text-white position-fixed end-0 bottom-0 m-3" id="myToastAdd" style={{backgroundColor: "#027a02"}}>
				<div className="toast-header">
					<strong className="me-auto">Success</strong>
					<button aria-label="Close" className="btn-close"
						data-bs-dismiss="toast" type="button">
					</button>
				</div>
				<div className="toast-body">
					Users Saved Successfully!
				</div>
			</div>
			<div aria-atomic="true" aria-live="assertive" className="toast text-white position-fixed end-0 bottom-0 m-3" id="myToastUpdate" style={{backgroundColor: "#f7572a"}}>
				<div className="toast-header">
					<strong className="me-auto">Success</strong>
					<button aria-label="Close" className="btn-close"
						data-bs-dismiss="toast" type="button">
					</button>
				</div>
				<div className="toast-body">
					Users Updated Successfully!
				</div>
			</div>
			<div aria-atomic="true" aria-live="assertive" className="toast text-white position-fixed end-0 bottom-0 m-3" id="myToastDelete" style={{backgroundColor: "#d1061b"}}>
				<div className="toast-header">
					<strong className="me-auto">Success</strong>
					<button aria-label="Close" className="btn-close"
						data-bs-dismiss="toast" type="button">
					</button>
				</div>
				<div className="toast-body">
					Users Deleted Successfully!
				</div>
			</div>
		</Fragment>
	);
};

export default List_user;
