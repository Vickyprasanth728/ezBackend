import axios, {AxiosResponse}  from 'axios'

const API_URL = process.env.REACT_APP_API_URL

// user api's
export const GET_LANGUAGES = `${API_URL}/get_languages `
export const SAVE_LANGUAGE = `${API_URL}/save_language `
export const GET_LANGUAGE_EDIT = `${API_URL}/get_language_id`
export const UPDATE_LANGUAGE = `${API_URL}/put_language`
export const UPDATE_LANGUAGE_STATUS = `${API_URL}/update_language_status`
export const DELETE_LANGUAGE = `${API_URL}/delete_language`

export function getLanguages() {
    return axios.get(GET_LANGUAGES)
    .then((response => response.data))
}

export function saveLanguage(body) {
    return axios.post(SAVE_LANGUAGE, body)
    .then((response => response.data))
}

export function getLanguageEdit(id) {
    return axios.get(GET_LANGUAGE_EDIT+'/'+id)
    .then((response => response.data))
}

export function updateLanguage(id ,body) {
    return axios.put(UPDATE_LANGUAGE+'/'+id, body)
    .then((response => response.data))
}
export function updateLanguageStatus(id ,body) {
    return axios.put(UPDATE_LANGUAGE_STATUS+'/'+id, body)
    .then((response => response.data))
}

export function deleteLanguage(id) {
    return axios.delete(DELETE_LANGUAGE+'/'+id)
    .then((response => response.data))
}
