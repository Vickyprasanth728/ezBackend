import React, { Fragment, useState, useEffect, useRef} from "react";
import { Tabs, TabList, TabPanel, Tab } from "react-tabs";
import { User, Settings } from "react-feather";
// import { Button, Col, Input, Label, Row, Table } from "reactstrap";
import {getProfile, saveProfile, getProfileEdit, updateProfile, deleteProfile } from './core/_requests';
import { Link, useNavigate } from 'react-router-dom';
import { useFormik } from 'formik';
import { Offcanvas, Toast } from 'bootstrap';
import { ToastContainer, toast } from 'react-toastify';
import {
	Button,
	Card,
	CardBody,
	CardHeader,
	Col,
	Container,
	Form,
	FormGroup,
	Input,
	Label,
	Modal,
	ModalBody,
	ModalFooter,
	ModalHeader,
	Row,
	Table,
} from "reactstrap";
import 'react-toastify/dist/ReactToastify.css';
// import man from "../../assets/images/dashboard/man.png";
import man from "../../assets/icons/no_image.jpg";
import logo from "../../assets/icons/no_image.jpg";
import * as Yup from 'yup';

const initialValues = {
    "id" : "",
    "referred_by" : "",
    "provider_id" : "",
    "user_type" : "",
    "name" : "",
    "email" : "",
    "email_verified_at" : "",
    "verification_code" : "",
    "new_email_verificiation_code" : "",
    "password" : "" ,
    "remember_token" : "" ,
    "device_token" : "",
    "avatar" : ""  ,
    "avatar_original" : "",
    "address" : "",
    "country" : "",
    "state" : "",
    "city" : "",
    "postal_code" : "" ,
    "phone" : "",
    "balance" : "" ,
    "banned" : "" ,
    "referral_code" : "",
    "customer_package_id" : "" ,
    "remaining_uploads" : "",
    "role_id":""
}

const TabsetProfile = () => {

	const ProfileSchema = Yup.object().shape({
        name: Yup.string().required('* Name is required'),
        email: Yup.string()
            .email('Wrong email format')
            .min(3, 'Minimum 3 characters')
            .max(50, 'Maximum 50 characters')
            .required('Email is required'),
        phone: Yup.string()
        .min(10, '* Minimum 10 symbols')
        .max(10, '* Maximum 10 symbols'),
    })

	const [allProfile, setAllProfile] = useState([]);
	const [allEditProfile, setEditProfile] = useState([]);
    const [selectedId, setSelectedId] = useState('');
    const [dataBinded, setDataBinded] = useState(false);

    const [loading, setLoading] = useState(false);
    const [open, setOpen] = useState(false);
	const [editOpen, setEditOpen] = useState(false);

	const [logoImagePreview, setlogoImagePreview] = useState(null);
    const viewLogo = useRef(null);
    const [logoImage, setLogoImage] = useState(null);

	// var userId = initialValues.id;
	var userId = localStorage.getItem('userId')
	console.log("User ID",userId);

	var userPass = localStorage.getItem('userPassword')
	console.log("User Pass",userPass);


	const ProfileList = async () => {
        const ProfileResponse = await getProfile()
        console.log('Profile List');
        console.log(ProfileResponse.Data);
        setAllProfile(ProfileResponse.Data);
    }

	const formik = useFormik({
        initialValues,
        validationSchema: ProfileSchema,
        onSubmit: async (values, {setStatus, setSubmitting, resetForm}) => {
          setLoading(true)
          try {

            var formData = new FormData();

            formData.append("id" , values.id);
            formData.append("referred_by" , values.referred_by);
            formData.append("provider_id" , values.provider_id);
            formData.append("user_type" , values.user_type);
            formData.append('name', values.name);
            formData.append('email', values.email);
            formData.append('email_verified_at', values.email_verified_at);
            formData.append('verification_code', values.verification_code);
            formData.append('new_email_verificiation_code', values.new_email_verificiation_code);
            formData.append('password', values.password);
            formData.append('remember_token', values.remember_token);
            formData.append('device_token', values.device_token);
            formData.append('avatar', logoImage);
            formData.append('avatar_original', values.avatar_original);
            formData.append('address', values.address);
            formData.append('country', values.country);
            formData.append('state', values.state);
            formData.append('city', values.city);
            formData.append('postal_code', values.postal_code);
            formData.append('phone', values.phone);
            formData.append('balance', values.balance || "0");
            formData.append('banned', values.banned || "0");
            formData.append('referral_code', values.referral_code);
            formData.append('customer_package_id', values.customer_package_id);
            formData.append('remaining_uploads', values.remaining_uploads || "0");
            
            const headers = {
                headers: {
                    "Content-type": "multipart/form-data",
                },
            }
                
            console.log('lead form body');
            console.log(formData);
            if(!dataBinded){
                const saveCustomerData = await saveProfile(formData, headers);
            
                if(saveCustomerData != null){
                    setLoading(false);
                    // document.getElementById('kt_team_close')?.click();
                    // var toastEl = document.getElementById('myToastAdd');
                    // const bsToast = new Toast(toastEl);
                    // bsToast.show();
                    resetForm();
                    ProfileList();
                }

            } else {
                const updateCustomerData = await updateProfile(selectedId, formData);

                if (updateCustomerData != null) {
                    setLoading(false);
                    resetForm();
                    setDataBinded(false);
                    ProfileList();
                    resetForm();
					var toastEl = document.getElementById('myToastUpdate');
                    const bsToast = new Toast(toastEl);
                    bsToast.show();
                }
            }
            ProfileList();
            // onCloseModal();
          document.getElementById('sampleTest')?.click()
          document.getElementById('sampleTest2')?.click()
          document.getElementById('sampleTest3')?.click()
          document.getElementById('sampleTest4')?.click()
          } catch (error) {
            console.error(error)
            setStatus('The registration details is incorrect')
            setSubmitting(false)
            setLoading(false)

            // toast.error('Email Already Exits', {
            //     position: "bottom-right",
            //     autoClose: 5000,
            //     hideProgressBar: false,
            //     closeOnClick: true,
            //     pauseOnHover: true,
            //     draggable: true,
            //     progress: undefined,
            //     theme: "light",
            // });
        }
          ProfileList();
          resetForm();
		  removeLogo();
		  setEditOpen(false);

        //   setEditOpen(false);
        }
    })

	const handleLogoPreview = (e) => {
        let image_as_base64 = URL.createObjectURL(e.target.files[0])
        let image_as_files = e.target.files[0];

        let fields = viewLogo.current?.value.split(".");

        let fileType = fields [fields.length - 1];

        if (fileType == 'jpg' || fileType == 'jpeg' || fileType == 'pdf'  || fileType == 'png') {
            setlogoImagePreview(image_as_base64);
            setLogoImage(image_as_files);
        } else {
            setlogoImagePreview(null);
            setLogoImage(null);
            if (viewLogo.current != null) {
                viewLogo.current.value = "";
            }
        }
        console.log(viewLogo.current?.value);
        console.log(image_as_files);
        console.log(fileType);
    }

    const removeLogo = () => {
        console.log(viewLogo.current?.value);
        if (viewLogo.current != null) {
            setlogoImagePreview(null);
            setLogoImage(null);
            viewLogo.current.value = "";
        }
    }

	const EditProfile = async (id) => {
		// var userId = initialValues.id
        setSelectedId(id);
        const allProfileEdit = await getProfileEdit(userId)
        setEditProfile(allProfileEdit.Data);
		console.log("profile id" ,allProfileEdit.Data);
		formik.setFieldValue('name', allProfileEdit.Data.name);
        formik.setFieldValue('email', allProfileEdit.Data.email);
        // formik.setFieldValue('password', allProfileEdit.Data.password);
        formik.setFieldValue('address', allProfileEdit.Data.address);
        formik.setFieldValue('phone', allProfileEdit.Data.phone);
        formik.setFieldValue('city', allProfileEdit.Data.city);
        formik.setFieldValue('state', allProfileEdit.Data.state);
        formik.setFieldValue('avatar', allProfileEdit.Data.avatar);
        setDataBinded(true);
		console.log("profile id" ,allProfileEdit.Data);
		// onEditModal();
    }
	const modalEditProfile = async (id) => {
		// var userId = initialValues.id
        setSelectedId(id);
        const allProfileEdit = await getProfileEdit(userId)
        setEditProfile(allProfileEdit.Data);
		console.log("profile id" ,allProfileEdit.Data);
		formik.setFieldValue('name', allProfileEdit.Data.name);
        formik.setFieldValue('email', allProfileEdit.Data.email);
        // formik.setFieldValue('password', allProfileEdit.Data.password);
        formik.setFieldValue('address', allProfileEdit.Data.address);
        formik.setFieldValue('phone', allProfileEdit.Data.phone);
        formik.setFieldValue('city', allProfileEdit.Data.city);
        formik.setFieldValue('state', allProfileEdit.Data.state);
        formik.setFieldValue('avatar', allProfileEdit.Data.avatar);
        setDataBinded(true);
		console.log("profile id" ,allProfileEdit.Data);
		onEditModal();
    }

	const onEditModal = () => {
		setEditOpen(true);
	};

	const onCloseModal = () => {
		setEditOpen(false);
		setOpen(false);
	};

	const clearForm = () => {
        formik.resetForm();
        setDataBinded(false);
		setOpen(false);
		setEditOpen(false);
		removeLogo();
    }

	useEffect(() => {
		ProfileList();
		EditProfile();
		}, []);

	return (
		<div>
			<button type="button" className="d-none" id="sampleTest4" onClick={()=>EditProfile()}></button>
			<Tabs>
				<TabList className="nav nav-tabs tab-coupon row">
					<Tab className="nav-link col">
						<User className="me-2" />
						Profile
					</Tab>
					{/* <Tab className="nav-link">
						<Settings className="me-2" />
						Contact
					</Tab> */}
					<button className="btn btn-sm btn-primary col-lg-3 mb-2" onClick={() => modalEditProfile(allEditProfile.id)}>
						Edit Profile
					</button>
				</TabList>

				<TabPanel>
					<div className="tab-pane fade show active">
						<h5 className="f-w-600 f-16">Profile</h5>
						<div className="table-responsive profile-table">
						{/* {allProfile.map((profileMap, i) => {
                        return ( */}
							<Table className="table-responsive">
								{/* <tbody>
									<tr>
										<td>First Name:</td>
										<td>Steve</td>
									</tr>
									<tr>
										<td>Last Name:</td>
										<td>Deo</td>
									</tr>
									<tr>
										<td>Email:</td>
										<td>johndeo@gmail.com</td>
									</tr>
									<tr>
										<td>Gender:</td>
										<td>Male</td>
									</tr>
									<tr>
										<td>Mobile Number:</td>
										<td>2124821463</td>
									</tr>
									<tr>
										<td>DOB:</td>
										<td>Dec, 15 1993</td>
									</tr>
									<tr>
										<td>Location:</td>
										<td>USA</td>
									</tr>
								</tbody> */}
								<tbody>
									<tr>
										<td>Name :</td>
										<td>{allEditProfile.name}</td>
									</tr>
									<tr>
										<td>Email :</td>
										<td>{allEditProfile.email}</td>
									</tr>
									<tr>
										<td>Address :</td>
										<td>{allEditProfile.address}</td>
									</tr>
									{/* <tr>
										<td>Avatar:</td>
										<td><img src={process.env.REACT_APP_API_BASE_URL + 'uploads/users/avatar/' + allEditProfile.id + '/' + allEditProfile.avatar} className="img-fluid" height={80} width={80} alt='' /></td>
									</tr> */}
									<tr>
										<td>Phone :</td>
										<td>{allEditProfile.phone}</td>
									</tr>
									<tr>
										<td>Country :</td>
										<td>{allEditProfile.email}</td>
									</tr>
									<tr>
										<td>City :</td>
										<td>{allEditProfile.city}</td>
									</tr>
								</tbody>
							</Table>
							
							 {/* );
						 })}  */}
						</div>
					</div>
				</TabPanel>
				<TabPanel>
					{/* <div className="tab-pane fade"> */}
					<div className="account-setting">
						<h5 className="f-w-600 f-16">Notifications</h5>
						<Row>
							<Col>
								<Label className="d-block form-label">
									<Input
										className="checkbox_animated"
										id="chk-ani"
										type="checkbox"
										defaultChecked
									/>
									Allow Desktop Notifications
								</Label>
								<Label className="d-block form-label">
									<Input
										className="checkbox_animated"
										id="chk-ani1"
										type="checkbox"
									/>
									Enable Notifications
								</Label>
								<Label className="d-block form-label">
									<Input
										className="checkbox_animated"
										id="chk-ani2"
										type="checkbox"
									/>
									Get notification for my own activity
								</Label>
								<Label className="d-block mb-0">
									<Input
										className="checkbox_animated"
										id="chk-ani3"
										type="checkbox"
										defaultChecked
									/>
									DND
								</Label>
							</Col>
						</Row>
					</div>
					<div className="account-setting deactivate-account">
						<h5 className="f-w-600 f-16">Deactivate Account</h5>
						<Row>
							<Col>
								<Label className="d-block form-label">
									<Input
										className="radio_animated"
										id="edo-ani"
										type="radio"
										name="rdo-ani"
										defaultChecked
									/>
									I have a privacy concern
								</Label>
								<Label className="d-block form-label">
									<Input
										className="radio_animated"
										id="edo-ani1"
										type="radio"
										name="rdo-ani"
									/>
									This is temporary
								</Label>
								<Label className="d-block mb-0">
									<Input
										className="radio_animated"
										id="edo-ani2"
										type="radio"
										name="rdo-ani"
										defaultChecked
									/>
									Other
								</Label>
							</Col>
						</Row>
						<Button type="button" color="primary">
							Deactivate Account
						</Button>
					</div>
					<div className="account-setting deactivate-account">
						<h5 className="f-w-600 f-16">Delete Account</h5>
						<Row>
							<Col>
								<Label className="d-block form-label">
									<Input
										className="radio_animated"
										id="edo-ani3"
										type="radio"
										name="rdo-ani1"
										defaultChecked
									/>
									No longer usable
								</Label>
								<Label className="d-block form-label">
									<Input
										className="radio_animated"
										id="edo-ani4"
										type="radio"
										name="rdo-ani1"
									/>
									Want to switch on other account
								</Label>
								<Label className="d-block mb-0">
									<Input
										className="radio_animated"
										id="edo-ani5"
										type="radio"
										name="rdo-ani1"
										defaultChecked
									/>
									Other
								</Label>
							</Col>
						</Row>
						<Button type="button" color="primary">
							Delete Account
						</Button>
					</div>
					{/* </div> */}
				</TabPanel>
			</Tabs>

			
			<Modal isOpen={editOpen} toggle={onCloseModal} className='modal-lg'>
				<ModalHeader toggle={onCloseModal}>
					<h5
						className="modal-title f-w-600"
						id="exampleModalLabel2"
					>
						Edit Profile
					</h5>
				</ModalHeader>
				<ModalBody>
				<Form noValidate onSubmit={formik.handleSubmit}>
					<div className="row">
						<div className="form-group col-lg-6">
							<label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold">Name</label>
							<div className="input-group">
								<input type="text" className="form-control" placeholder="Name" {...formik.getFieldProps('name')} />
							</div>
							{formik.touched.name && formik.errors.name && (
								<div className='fv-plugins-message-container'>
									<div className='fv-help-block'>
										<span role='alert' className='text-danger'>{formik.errors.name}</span>
									</div>
								</div>
							)}
						</div>
						<div className="form-group col-lg-6">
							<label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold">Phone</label>
							<div className="input-group">
								<input type="number" className="form-control" placeholder="Phone" {...formik.getFieldProps('phone')} min='1' />
							</div>
							{formik.touched.phone && formik.errors.phone && (
								<div className='fv-plugins-message-container'>
									<div className='fv-help-block'>
										<span role='alert' className='text-danger'>{formik.errors.phone}</span>
									</div>
								</div>
							)}
						</div>
					</div>
					<div className="row">
						<div className="form-group">
							<label className=' text-gray-700 fw-bold m-2'>Avatar</label>
							<div className="row">
							<div className="col-lg-6">
								<div className="input-group" data-toggle="aizuploader" data-type="image" data-multiple="true">

									{/* <input type="file" className="form-control file-amount mt-2" name="profile_image" /> */}
									<input type="file" className='form-control' ref={viewLogo} onChange={handleLogoPreview} />
								</div>
								<div className="file-preview box sm">
									
								</div>
							</div>
							{/* <div className="file-preview box sm m-10">
							</div> */}
							<div className="col-lg-6">
							{/* {logoImagePreview != null && (
								<div className='profile_preview position-relative image-input image-input-outline'>
									<img src={logoImagePreview} alt="image preview" className='image-input-wrapper w-100px h-100px' height={100} width={150} />
									<div onClick={removeLogo} className="p-1 fa fa-remove" style={{fontSize:"36px"}}>
									</div>
								</div> 
							)} */}
							<div className="file-preview box sm m-10 d-flex justify-content-center align-items-center">
							{logoImagePreview != null ? <div className="file-preview box sm">
								{logoImagePreview != null && (
									<div className='profile_preview position-relative image-input image-input-outline'>
										<img src={logoImagePreview} alt="image preview" className='image-input-wrapper w-100px h-100px shadow' height={100} width={150} />
											<div onClick={removeLogo} className="p-1 fa fa-remove text-danger" style={{fontSize:"30px" , cursor:"pointer"}}>
											</div>
									</div>
								)}
							</div> : allEditProfile.avatar == null ? <img src={logo} className="" height={100} width={150} alt='' />  :
								<div className='profile_preview position-relative image-input image-input-outline'>
									<img src={process.env.REACT_APP_API_BASE_URL + 'uploads/users/avatar/' + allEditProfile.id + '/' + allEditProfile.avatar} className="image-input-wrapper w-100px h-100px shadow" height={100} width={150} alt='' />
								</div> 
							}
							</div>
							</div>
							</div>
						</div>
					</div>
					<div className="row">
						<div className="form-group col-lg-6">
							<label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold m-2">Email</label>
							<div className="input-group">
								<input type="text" className="form-control" placeholder="Email" {...formik.getFieldProps('email')} />
							</div>
							{formik.touched.email && formik.errors.email && (
								<div className='fv-plugins-message-container'>
									<div className='fv-help-block'>
										<span role='alert' className='text-danger'>{formik.errors.email}</span>
									</div>
								</div>
							)}
						</div>
						<div className="form-group col-lg-6">
							<label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold m-2">Address</label>
							<div className="input-group">
								<textarea type="text" className="form-control" placeholder="Address" {...formik.getFieldProps('address')} ></textarea>
							</div>
							{formik.touched.address && formik.errors.address && (
								<div className='fv-plugins-message-container'>
									<div className='fv-help-block'>
										<span role='alert' className='text-danger'>{formik.errors.address}</span>
									</div>
								</div>
							)}
						</div>
					</div>
					<div className="row">
						<div className="form-group col-lg-6">
							<label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold m-2">City</label>
							<div className="input-group">
								<input type="text" className="form-control" placeholder="City" {...formik.getFieldProps('city')}/>
							</div>
							{formik.touched.city && formik.errors.city && (
								<div className='fv-plugins-message-container'>
									<div className='fv-help-block'>
										<span role='alert' className='text-danger'>{formik.errors.city}</span>
									</div>
								</div>
							)}
						</div>
						<div className="form-group col-lg-6">
							<label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold m-2">State</label>
							<div className="input-group">
								<input type="text" className="form-control" placeholder="State" {...formik.getFieldProps('state')}/>
							</div>
							{formik.touched.state && formik.errors.state && (
								<div className='fv-plugins-message-container'>
									<div className='fv-help-block'>
										<span role='alert' className='text-danger'>{formik.errors.state}</span>
									</div>
								</div>
							)}
						</div>
					</div>
						<div className='card-footer py-5 text-center' id='kt_task_footer'>
							<button
								type='submit'
								id='submit_button'
								className='btn btn-primary text-white mx-2 m-2'
								disabled={formik.isSubmitting}
								style={{backgroundColor:'#ffbe57'}}
								// onClick={()=>{toComponentB()}}
								// onClick={() => alert()}
							>
								{!loading && <span className='indicator-label'>Submit
								</span>}
								{loading && (
									<span className='indicator-progress' style={{ display: 'block' }}>
										Please wait...{' '}
										<span className='spinner-border spinner-border-sm align-middle ms-2'></span>
									</span>
								)}
							</button>

							<div className='btn btn-danger text-white' onClick={clearForm} style={{backgroundColor:'#0fb2f7'}}> Cancel</div>
						</div>

					</Form>
				</ModalBody>
			</Modal>
			<div aria-atomic="true" aria-live="assertive" className="toast text-white position-fixed end-0 bottom-0 m-3" id="myToastUpdate" style={{backgroundColor: "#f7572a"}}>
				<div className="toast-header">
					<strong className="me-auto">Success</strong>
					<button aria-label="Close" className="btn-close"
						data-bs-dismiss="toast" type="button">
					</button>
				</div>
				<div className="toast-body">
					Profile Updated Successfully!
				</div>
			</div>
		</div>
	);
};

export default TabsetProfile;
