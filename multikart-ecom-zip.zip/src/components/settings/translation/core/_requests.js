import axios, {AxiosResponse}  from 'axios'

const API_URL = process.env.REACT_APP_API_URL

// user api's
export const GET_TRANSLATIONS = `${API_URL}/get_translations `
export const SAVE_TRANSLATION = `${API_URL}/save_translation `
export const GET_TRANSLATION_EDIT = `${API_URL}/get_translation_id`
export const UPDATE_TRANSLATION = `${API_URL}/put_translation`
export const DELETE_TRANSLATION = `${API_URL}/delete_translation`

export function getTranslations() {
    return axios.get(GET_TRANSLATIONS)
    .then((response => response.data))
}

export function saveTranslation(body) {
    return axios.post(SAVE_TRANSLATION, body)
    .then((response => response.data))
}

export function getTranslationEdit(id) {
    return axios.get(GET_TRANSLATION_EDIT+'/'+id)
    .then((response => response.data))
}

export function updateTranslation(id ,body) {
    return axios.put(UPDATE_TRANSLATION+'/'+id, body)
    .then((response => response.data))
}

export function deleteTranslation(id) {
    return axios.delete(DELETE_TRANSLATION+'/'+id)
    .then((response => response.data))
}