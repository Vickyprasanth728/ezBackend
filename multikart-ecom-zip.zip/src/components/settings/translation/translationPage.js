import React, { Fragment, useState, useEffect } from "react";
import Breadcrumb from "../../common/breadcrumb";
import "react-toastify/dist/ReactToastify.css";
import { useFormik } from 'formik';
// import Datatable from "../../common/datatable";
import DataTable from "react-data-table-component";
import { Offcanvas, Toast } from 'bootstrap';
import * as Yup from 'yup';
import { getTranslations, saveTranslation, getTranslationEdit, updateTranslation, deleteTranslation} from "./core/_requests";

import {
	Button,
	Card,
	CardBody,
	CardHeader,
	Col,
	Container,
	Form,
	FormGroup,
	Input,
	Label,
	Modal,
	ModalBody,
	ModalFooter,
	ModalHeader,
	Row,
} from "reactstrap";

const initialValues = {
    "id": "",
    "lang": "",
    "lang_key": "",
    "lang_value": "",
}

const TranslationPage = () => {

    const TranslationSchema = Yup.object().shape({
        // name: Yup.string().required('* Name is required'),     
    })

	const [open, setOpen] = useState(false);
	const [editOpen, setEditOpen] = useState(false);
	const [deleteOpen, setDeleteOpen] = useState(false);
    const [allTranslations, setAllTranslations] = useState([{}]);
    const [TranslationEdit, setTranslationEdit] = useState([]);
    const [loading, setLoading] = useState(false);
    const [dataBinded, setDataBinded] = useState(false);
    const [isLoading, setIsLoading] = useState(false);
    const [selectedId, setSelectedId] = useState('');


	// const TranslationList = async () => {
	//   const TranslationResponse = await getTranslations()
	//   console.log('All Translations');
	//   console.log(TranslationResponse.Data);
	//   setAllTranslations(TranslationResponse.Data);
	// }

	const TranslationList = async () => {
	  const TranslationResponse = await getTranslations()
	  console.log('All Translations', TranslationResponse.Data);
	  
	  let new_array = [];
	  for(let i=0; i<TranslationResponse.Data.length;i++) {
		  let cur_obj = {
			  ...TranslationResponse.Data[i],
			  'sl_no': i + 1 
		  }
		  new_array.push(cur_obj)
	  }
	  setAllTranslations(new_array);
	  console.log('New Array', new_array);
	  console.log('Translation Response', TranslationResponse.Data);
	}

	const columns = [
		{
			name: "id",
			selector:  row => row.sl_no,
			sortable: true,
		},
		{
			name: "Lang",
			selector: row => row.lang,
			sortable: true,
		},
		{
			name: "Lang Key",
			selector: row => row.lang_key,
			sortable: true,
		},
		{
			name: "Lang Value",
			selector: row => row.lang_value,
			sortable: true,
		},
		{
			name:"Actions",
			cell: (row, index) => (
				<div>
					<span>
						<button
						className="btn btn-danger btn-sm fa fa-pencil mx-2 m-2 button_size"
						data-toggle="modal"
						onClick={() => EditTranslation(row.id)}
						>
						</button>
					</span>
					<span >
						<button
						className="btn btn-primary btn-sm fa fa-trash mx-2 button_size"
						onClick={() => DeleteTranslation(row.id)}
						data-bs-toggle='modal' 
						data-bs-target={'#delete_confirm_popup452222' + selectedId}
						>
						</button>
					</span>
				</div>
			),
		}
	]

	const oncloseDeleteModal = () => {
		setDeleteOpen(false);
	};

	const onOpenModal = () => {
		setOpen(true);
		allClear();
	};

	const onCloseModal = () => {
		setOpen(false);
		setEditOpen(false);
	};

	const onEditModal = () => {
		setEditOpen(true);
	};

	const onDeleteModal = () => {
		setDeleteOpen(true);
	};

	const allClear = () => {
        formik.resetForm();
        setDataBinded(false);
    }

	const DeleteTranslation = async (id) => {
        setSelectedId(id);
		onDeleteModal(id);
    }

    const formik = useFormik({
        initialValues,
        validationSchema: TranslationSchema,
        onSubmit: async (values, { setStatus, setSubmitting, resetForm }) => {
            setLoading(true)
            try {

                const body = {
                    "lang": values.lang,
                    "lang_key": values.lang_key,
                    "lang_value": values.lang_value,
                }

                console.log('lead form body');
                if (!dataBinded) {
                    const saveTranslationData = await saveTranslation(body);

                    if (saveTranslationData != null) {
                        setLoading(false);
                        document.getElementById('kt_team_close')?.click();
                        var toastEl = document.getElementById('myToastAdd');
                        const bsToast = new Toast(toastEl);
                        bsToast.show();
                        resetForm();
                        TranslationList();
                        clearForm();
                    }
					setOpen(false);
					TranslationList();
                } else {
                    const updateTranslationData = await updateTranslation(selectedId, body);

                    if (updateTranslationData != null) {
                        setLoading(false);
                        var toastEl = document.getElementById('myToastUpdate');
                        const bsToast = new Toast(toastEl);
                        bsToast.show();
                        resetForm();
                        setDataBinded(false);
                        TranslationList();
                        clearForm();
                    }
                }

            } catch (error) {
                console.error(error)
                setStatus('The registration details is incorrect')
                setSubmitting(false)
                setLoading(false)
            }
			setOpen(false);
			setEditOpen(false);
			TranslationList();
        }
    })

	const EditTranslation = async (id) => {
        setSelectedId(id);
        const allTranslationEdit = await getTranslationEdit(id)
        setTranslationEdit(allTranslationEdit.data);
        setDataBinded(true);
        formik.setFieldValue('lang', allTranslationEdit.data.lang);
        formik.setFieldValue('lang_key', allTranslationEdit.data.lang_key);
        formik.setFieldValue('lang_value', allTranslationEdit.data.lang_value);
		onEditModal();
    }

    const clearForm = () => {
        formik.resetForm();
        // setDataBinded(false);
		setOpen(false);
		setEditOpen(false);
    }
    
	const onDelete = async (id) => {
        setIsLoading(false);
        console.log(id);
        await deleteTranslation(id);
        TranslationList();
    }

	useEffect(() => {
        TranslationList();
      }, []);

	return (
		<Fragment>
			<Breadcrumb title="Translation" parent="Physical" />
			<Container fluid={true}>
				<Row>
					<Col sm="12">
						<Card>
							<CardHeader>
								<h5>Translation List</h5>
							</CardHeader>
							<CardBody>
								<div className="btn-popup pull-right">
									<Button
										type="button"
										color="primary"
										onClick={onOpenModal}
										data-toggle="modal"
										data-original-title="test"
										data-target="#exampleModal"
									>
										Add Translation
									</Button>
									{/* Save Modal */}
									<Modal isOpen={open} toggle={onCloseModal}>
										<ModalHeader toggle={onCloseModal}>
											<h5
												className="modal-title f-w-600"
												id="exampleModalLabel2"
											>
												Add Translation
											</h5>
										</ModalHeader>
										<ModalBody>
											<Form noValidate onSubmit={formik.handleSubmit}>

											<div className="form-group mb-4">
												<label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold m-2">Language</label>
												<div className="input-group">
													<input type="text" className="form-control" placeholder="Language" {...formik.getFieldProps('lang')} />
												</div>
												{formik.touched.lang && formik.errors.lang && (
													<div className='fv-plugins-message-container'>
														<div className='fv-help-block'>
															<span role='alert' className='text-danger'>{formik.errors.lang}</span>
														</div>
													</div>
												)}
											</div>
											<div className="form-group mb-4">
												<label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold m-2">Language Key</label>
												<div className="input-group">
													<input type="text" className="form-control" placeholder="Language Key" {...formik.getFieldProps('lang_key')} />
												</div>
												{formik.touched.lang_key && formik.errors.lang_key && (
													<div className='fv-plugins-message-container'>
														<div className='fv-help-block'>
															<span role='alert' className='text-danger'>{formik.errors.lang_key}</span>
														</div>
													</div>
												)}
											</div>
											<div className="form-group mb-4">
												<label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold m-2">Language Value</label>
												<div className="input-group">
													<input type="text" className="form-control" placeholder="Language Value" {...formik.getFieldProps('lang_value')} />
												</div>
												{formik.touched.lang_value && formik.errors.lang_value && (
													<div className='fv-plugins-message-container'>
														<div className='fv-help-block'>
															<span role='alert' className='text-danger'>{formik.errors.lang_value}</span>
														</div>
													</div>
												)}
											</div>
											{/* <div className="form-group mb-4">
												<label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold m-2">Rtl</label>
												<div className="input-group">
													<input type="text" className="form-control" placeholder="Rtl" {...formik.getFieldProps('rtl')} />
												</div>
												{formik.touched.rtl && formik.errors.rtl && (
													<div className='fv-plugins-message-container'>
														<div className='fv-help-block'>
															<span role='alert' className='text-danger'>{formik.errors.rtl}</span>
														</div>
													</div>
												)}
											</div>
											<div className="form-group mb-4">
												<label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold m-2">Status</label>
												<div className="input-group">
													<input type="text" className="form-control" placeholder="Status" {...formik.getFieldProps('status')} />
												</div>
												{formik.touched.status && formik.errors.status && (
													<div className='fv-plugins-message-container'>
														<div className='fv-help-block'>
															<span role='alert' className='text-danger'>{formik.errors.status}</span>
														</div>
													</div>
												)}
											</div> */}
											
															{/* <FormGroup>
													<Label
														htmlFor="recipient-name"
														className="col-form-label"
													>
														Languages Name :
													</Label>
													<Input type="text" className="form-control" />
												</FormGroup> */}

												{/* <FormGroup>
													<Label
														htmlFor="message-text"
														className="col-form-label"
													>
														Category Image :
													</Label>
													<Input
														className="form-control"
														id="validationCustom02"
														type="file"
													/>
												</FormGroup> */}

                                                <div className='card-footer py-5 text-center' id='kt_task_footer'>
													<button
														type='submit'
														id='submit_button'
														className='btn btn-primary text-white mx-2'
														disabled={formik.isSubmitting}
														style={{backgroundColor:'#ffbe57'}}
														// onClick={()=>{toComponentB()}}
														// onClick={() => alert()}
													>
														{!loading && <span className='indicator-label'>Submit
														</span>}
														{loading && (
															<span className='indicator-progress' style={{ display: 'block' }}>
																Please wait...{' '}
																<span className='spinner-border spinner-border-sm align-middle ms-2'></span>
															</span>
														)}
													</button>

													<div className='btn btn-danger text-white' onClick={clearForm}> Cancel</div>
												</div>

											</Form>
										</ModalBody>
										<ModalFooter>
											{/* <Button
												type="button"
												color="primary"
												onClick={() => onCloseModal("VaryingMdo")}
											>
												Save
											</Button>
											<Button
												type="button"
												color="secondary"
												onClick={() => onCloseModal("VaryingMdo")}
											>
												Close
											</Button> */}
										</ModalFooter>
									</Modal>

									{/* Edit Modal */}
									<Modal isOpen={editOpen} toggle={onCloseModal}>
										<ModalHeader toggle={onCloseModal}>
											<h5
												className="modal-title f-w-600"
												id="exampleModalLabel2"
											>
												Edit Language
											</h5>
										</ModalHeader>
										<ModalBody>
											<Form noValidate onSubmit={formik.handleSubmit}>

											<div className="form-group mb-0">
												<label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold m-2">Language</label>
												<div className="input-group">
													<input type="text" className="form-control" placeholder="Language" {...formik.getFieldProps('lang')} />
												</div>
												{formik.touched.lang && formik.errors.lang && (
													<div className='fv-plugins-message-container'>
														<div className='fv-help-block'>
															<span role='alert' className='text-danger'>{formik.errors.lang}</span>
														</div>
													</div>
												)}
											</div>
											<div className="form-group mb-0">
												<label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold m-2">Language Key</label>
												<div className="input-group">
													<input type="text" className="form-control" placeholder="Language Key" {...formik.getFieldProps('lang_key')} />
												</div>
												{formik.touched.lang_key && formik.errors.lang_key && (
													<div className='fv-plugins-message-container'>
														<div className='fv-help-block'>
															<span role='alert' className='text-danger'>{formik.errors.lang_key}</span>
														</div>
													</div>
												)}
											</div>
											<div className="form-group mb-0">
												<label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold m-2">Language value</label>
												<div className="input-group">
													<input type="text" className="form-control" placeholder="Language Value" {...formik.getFieldProps('lang_value')} />
												</div>
												{formik.touched.lang_value && formik.errors.lang_value && (
													<div className='fv-plugins-message-container'>
														<div className='fv-help-block'>
															<span role='alert' className='text-danger'>{formik.errors.lang_value}</span>
														</div>
													</div>
												)}
											</div>

											<div className='card-footer py-5 text-center' id='kt_task_footer'>
												<button
													type='submit'
													id='submit_button'
													className='btn btn-primary text-white mx-2'
													disabled={formik.isSubmitting}
													style={{backgroundColor:'#ffbe57'}}
													// onClick={()=>{toComponentB()}}
													// onClick={() => alert()}
												>
													{!loading && <span className='indicator-label'>Update
													</span>}
													{loading && (
														<span className='indicator-progress' style={{ display: 'block' }}>
															Please wait...{' '}
															<span className='spinner-border spinner-border-sm align-middle ms-2'></span>
														</span>
													)}
												</button>

												<div className='btn btn-danger text-white' onClick={clearForm}> Cancel</div>
											</div>
											</Form>
										</ModalBody>
									</Modal>

									{/* Delete Modal */}
									<div isOpen={deleteOpen} toggle={oncloseDeleteModal}>
										<div className='modal fade p-6' id={'delete_confirm_popup452222' + selectedId} aria-hidden='true'>
											<div className='modal-dialog modal-dialog-centered'>
												<div className='modal-content'>
													<div className='modal-header'>
														<h3 className="text-dark">Confirmation</h3>
														<div className='btn btn-sm btn-icon btn-active-color-primary' data-bs-dismiss='modal'>
														</div>
													</div>
													<div className='modal-body'>
														<div className='text-center'>
															<h4>Are you sure want to Delete ? </h4>
															<p className='text-danger'></p>
														</div>
														<div className='d-flex align-items-center justify-content-center'>
															<button className='btn btn-sm btn-outline-danger mx-4 mt-3' data-bs-dismiss='modal' onClick={(e) => onDelete(selectedId)}>
																Yes
															</button>
															<button className='btn btn-sm btn-outline-secondary mt-3 me-3' data-bs-dismiss='modal'>
																No
															</button>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div className="clearfix"></div>
								<div id="basicScenario" className="product-physical">
									{/* <Datatable
										myData={allTranslations}
										multiSelectOption={false}
										pageSize={10}
										pagination={true}
										class="-striped -highlight"
									/> */}
								<Fragment>
									<DataTable 
										// myData={allBrands}
										data={allTranslations}
										columns={columns}
										multiSelectOption={true}
										pageSize={10}
										pagination={true}
										class="-striped -highlight"
										className="text-center"
									/>
								</Fragment>
								</div>
							</CardBody>
						</Card>
					</Col>
				</Row>
			</Container>
		</Fragment>
	);
};

export default TranslationPage;

