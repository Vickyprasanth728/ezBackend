import axios, {AxiosResponse}  from 'axios'

const API_URL = process.env.REACT_APP_API_URL

// Blogs
export const GET_BLOGS = `${API_URL}/get_blogs`
export const SAVE_BLOG = `${API_URL}/save_blog`
export const EDIT_BLOG_EDIT = `${API_URL}/get_blog_id`
export const UPDATE_BLOG = `${API_URL}/put_blog`
export const DELETE_BLOG = `${API_URL}/delete_blog`

// Media - Upload
export const GET_UPLOADS = `${API_URL}/get_upload_files`
export const EDIT_UPLOAD = `${API_URL}/edit_upload_file`

// Blog Categories
export const GET_CATEGORIES_BLOG = `${API_URL}/get_blog_categories`
export const SAVE_BLOG_CATEGORY = `${API_URL}/save_blog_category`
export const EDIT_BLOG_CATEGORY = `${API_URL}/get_blog_category_id`
export const UPDATE_BLOG_CATEGORY = `${API_URL}/put_blog_category`
export const DELETE_BC = `${API_URL}/delete_blog_category`

// Blogs
export function getBlogs() {
    return axios.get(GET_BLOGS)
    .then((response => response.data))
}

export function saveBlog(postData, headers) {
    return axios.post(SAVE_BLOG, postData, headers)
    .then((response => response.data))
}

export function BlogEdit(id) {
    return axios.get(EDIT_BLOG_EDIT+'/'+id)
    .then((response => response.data))
}

export function updateBlogID(id ,body) {
    return axios.put(UPDATE_BLOG+'/'+id, body)
    .then((response => response.data))
}

export function deleteBlog(id) {
    return axios.delete(DELETE_BLOG+'/'+id)
    .then((response => response.data))
}

// Media - Upload
export function getUploads() {
    return axios.get(GET_UPLOADS)
    .then((response => response.data))
}

export function editUpload(id) {
    return axios.get(EDIT_UPLOAD+'/'+id)
    .then((response => response.data))
}

// Blog Categories
export function getCategoryBlogs() {
    return axios.get(GET_CATEGORIES_BLOG)
    .then((response => response.data))
}

export function saveBlogCategory(body) {
    return axios.post(SAVE_BLOG_CATEGORY, body)
    .then((response => response.data))
}

export function getBCEdit(id) {
    return axios.get(EDIT_BLOG_CATEGORY+'/'+id)
    .then((response => response.data))
}

export function updateBlogCategory(id ,body) {
    return axios.put(UPDATE_BLOG_CATEGORY+'/'+id, body)
    .then((response => response.data))
}

export function deleteBC(id) {
    return axios.delete(DELETE_BC+'/'+id)
    .then((response => response.data))
}