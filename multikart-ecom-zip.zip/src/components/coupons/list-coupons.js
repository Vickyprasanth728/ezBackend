import React, { Fragment, useState, useEffect } from "react";
import Breadcrumb from "../common/breadcrumb";
import data from "../../assets/data/listCoupons";
import { useFormik } from 'formik';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import Datatable from "../common/datatable";
import DataTable from "react-data-table-component";
import { Offcanvas, Toast } from 'bootstrap';
import { ToastContainer, toast, Zoom, Bounce } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import * as Yup from 'yup';
import { json, Link, useNavigate } from 'react-router-dom';
import {getCoupons, saveCoupon, editCoupon, updateCoupon , deleteCoupon} from "../coupons/core/_requests"
import {
	Button,
	Card,
	CardBody,
	CardHeader,
	Col,
	Container,
	Form,
	FormGroup,
	Input,
	Label,
	Modal,
	ModalBody,
	ModalFooter,
	ModalHeader,
	Row,
} from "reactstrap";

const initialValues = {
    "id":"",
    "user_id":"",
    "type": "",
    "code": "",
    "details": "",
    "discount": "",
    "discount_type": "",
    "start_date": "",
    "end_date": "",
}

const ListCoupons = () => {

    var userId = localStorage.getItem('userId')
	console.log("User ID",userId)

	const couponSchema = Yup.object().shape({
        // type: Yup.string().required('* Type Name is required'),
    })

	const [allCoupons, setAllCoupons] = useState([]);
	const [allCouponsDetails, setAllCouponsDetails] = useState([]);
	const [allCouponEdit, setAllCouponEdit] = useState([]);
    const [loading, setLoading] = useState(false);
    const [selectedId, setSelectedId] = useState('');
    const [dataBinded, setDataBinded] = useState(false);

	const [open, setOpen] = useState(false);
	const [editOpen, setEditOpen] = useState(false);
	const [deleteOpen, setDeleteOpen] = useState(false);

	const [startDate, setstartDate] = useState(new Date());
	const [endDate, setendDate] = useState(new Date());

	const handleStartDate = (date) => {
		setstartDate(date);
	};

	const handleEndDate = (date) => {
		setendDate(date);
	};

	const clickActive = (event) => {
		document.querySelector(".nav-link").classList.remove("show");
		event.target.classList.add("show");
	};
	
    // const CouponList = async () => {
    //     const couponsResponse = await getCoupons()
    //     console.log('All Coupons');
    //     console.log(couponsResponse.Data);
    //     setAllCoupons(couponsResponse.Data);
	// }

    const CouponList = async () => {
        const couponsResponse = await getCoupons()
        console.log('All Coupons',couponsResponse.Data);
    
		let new_array = [];
		for(let i=0; i<couponsResponse.Data.length;i++) {
			let cur_obj = {
				...couponsResponse.Data[i],
				'sl_no': i + 1 
			}
			new_array.push(cur_obj)
		}
        setAllCoupons(new_array);
		console.log('New Array', new_array);
		console.log('Coupons Response', couponsResponse.Data);
	}

	const formik = useFormik({
        initialValues,
        validationSchema: couponSchema,
        onSubmit: async (values, {setStatus, setSubmitting, resetForm}) => {
          setLoading(true)
          try {

			const val = {
				"min_buy": values.min_buy , 
				"max_discount": values.max_discount,
			}
			const detailsValues = JSON.stringify(val)
              
			const body = {
				"id": values.id,
				"user_id":userId,
				"type": values.type,
				"code": values.code,
				"details": detailsValues,
				"discount": values.discount,
				"discount_type": values.discount_type,
				"start_date": startDate,
				"end_date": endDate,
			}
                
            console.log('lead form body');
            console.log(body);
            if(!dataBinded){
                const saveCouponData = await saveCoupon(body);
            
                if(saveCouponData != null){
                    setLoading(false);
                    resetForm();
                    CouponList();
            		setOpen(false);
                    document.getElementById('kt_team_close')?.click();
                    var toastEl = document.getElementById('myToastAdd');
                    const bsToast = new Toast(toastEl);
                    bsToast.show();
                }

            } else {
                const updateCouponData = await updateCoupon(selectedId, body);
            
                if(updateCouponData != null){
                    setLoading(false);
                    resetForm();
                    CouponList();
                    setDataBinded(false);
		            setEditOpen(false);
                    // var toastEl = document.getElementById('myToastUpdate');
                    // const bsToast = new Toast(toastEl);
                    // bsToast.show();
					toast.success('Coupon Updated Sucessfully!', {
						position: "bottom-right",
						autoClose: 2000,
						transition:Bounce ,
						hideProgressBar: false,
						closeOnClick: true,
						pauseOnHover: true,
						draggable: true,
						progress: undefined,
						// theme: "dark",
						className:"text-dark",
						// style: {backgroundColor: "#f7572a"},
					});
                }
            }
            setEditOpen(false);
    
          } catch (error) {
            console.error(error)
            setStatus('The registration details is incorrect')
            setSubmitting(false)
            setLoading(false)
          }
          CouponList();
          setEditOpen(false);
          resetForm();
    }})

	const EditCouponID = async (id) => {
        setSelectedId(id);
        const couponEditResponse = await editCoupon(id)
        setAllCouponEdit(couponEditResponse.Data);

        setDataBinded(true);
        formik.setFieldValue('type', couponEditResponse.Data.type);
        formik.setFieldValue('code', couponEditResponse.Data.code);
        formik.setFieldValue('discount', couponEditResponse.Data.discount);
        formik.setFieldValue('discount_type', couponEditResponse.Data.discount_type);
        formik.setFieldValue('start_date', couponEditResponse.Data.start_date);
        formik.setFieldValue('end_date', couponEditResponse.Data.end_date);
        formik.setFieldValue('min_buy', couponEditResponse.Data.min_buy);
        formik.setFieldValue('max_discount', couponEditResponse.Data.max_discount);
        onEditModal();
    }

	const detailsValues =  '{"min_buy" : "3" , "max_discount" : "5"}'
	const obj = JSON.parse(detailsValues);
	console.log("obj",obj);

	const columns = [ 
		{
			name: "id",
			selector:  row => row.sl_no,
			sortable: true,
		},
		{
			name: "Type",
			selector: row => row.type,
			sortable: true,
		},
		{
			name: "Code",
			selector: row => row.code,
			sortable: true,
		},
		{
			name: "Discount",
			selector: row => row.discount+" %",
			sortable: true,
		},
		{
			name: "Start date",
			selector: row => row.start_date,
			sortable: true,
		},
		{
			name: "End date",
			selector: row => row.end_date,
			sortable: true,
		},
		{
			name:"Actions",
			cell: (row, index) => (
                <div>
                <span>
                    <button
                    className="btn btn-danger btn-sm fa fa-pencil mx-2 m-2 button_size"
                    data-toggle="modal"
                    onClick={() => EditCouponID(row.id)}
                    >
                    </button>
                </span>
                <span >
                    <button
                    className="btn btn-primary btn-sm fa fa-trash mx-2 button_size"
                    onClick={() => DeleteCoupon(row.id)}
                    data-bs-toggle='modal' 
                    data-bs-target={'#delete_confirm_popup452222' + selectedId}
                    >
                    </button>
                </span>
            </div>
			),
		}
	]

	const onEditModal = () => {
		setEditOpen(true);
	};
	
	const onCloseEdit = () => {
		setEditOpen(false);
        formik.resetForm();
	};

	const onDeleteModal = () => {
		setDeleteOpen(true);
	};

	const oncloseDeleteModal = () => {
		setDeleteOpen(false);
		CouponList();
	};

	const DeleteCoupon = async (id) => {
        setSelectedId(id);
		onDeleteModal(id);
    }
    const onDelete = async (id) => {
        console.log(id);
        await deleteCoupon(id);
        CouponList();
        // var toastEl = document.getElementById('myToastDelete');
        // const bsToast = new Toast(toastEl);
        // bsToast.show();
		toast('Coupon Deleted Sucessfully!', {
            position: "bottom-right",
            autoClose: 2000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
            // theme: "dark",
            className:"text-white",
            style: {backgroundColor: "#e02828"},
        });
    }

	const clearForm = () => {
        formik.resetForm();
		setEditOpen(false);
	}
	
    useEffect(() => {
        CouponList();
    }, []);

	return (
		<Fragment>
			<ToastContainer/>
			<Breadcrumb title="List Coupons" parent="Coupons" />
			<Container fluid={true}>
				<Row>
					<Col sm="12">
						<Card>
							{/* <CardHeader>
								<h5>Coupon List</h5>
							</CardHeader> */}
							<CardHeader className="mb-4">
								<div className='row align-items-center'>
									<div className='col-auto'>
										<h5>Coupon List </h5>
									</div>
									<div className='d-flex justify-content-end col' data-kt-user-table-toolbar='base'>
										<Link to='/coupons/create-coupons' className="btn btn-primary">
											Create Coupon
										</Link>
									</div>
								</div>
							</CardHeader>
							<CardBody>
								<div
									id="batchDelete"
									className="category-table order-table coupon-list-delete"
								>
									{/* <Datatable
										multiSelectOption={true}
										myData={data}
										pageSize={10}
										pagination={true}
										class="-striped -highlight"
									/> */}
								<Fragment>
									<DataTable 
										// myData={allBrands}
										data={allCoupons}
										columns={columns}
										multiSelectOption={false}
										pageSize={10}
										pagination={true}
										class="-striped -highlight"
										className="text-center"
									/>
								</Fragment>
								</div>
							</CardBody>
						</Card>
					</Col>
				</Row>

				{/* Edit Modal */}
				<Modal isOpen={editOpen} toggle={onCloseEdit} className='modal-lg'>
					<ModalHeader toggle={onCloseEdit}>
						<h5
							className="modal-title f-w-600"
							id="exampleModalLabel2"
						>
							Edit Coupon
						</h5>
					</ModalHeader>
					<ModalBody>
					<Form noValidate onSubmit={formik.handleSubmit}>
						<div className="row">
							<div className="form-group mb-4 col-lg-6">
								<label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold m-2">Type</label>
								<div className="input-group">
									<input type="text" className="form-control" placeholder="Type" {...formik.getFieldProps('type')} />
								</div>
								{formik.touched.type && formik.errors.type && (
									<div className='fv-plugins-message-container'>
										<div className='fv-help-block'>
											<span role='alert' className='text-danger'>{formik.errors.type}</span>
										</div>
									</div>
								)}
							</div>
							<div className="form-group mb-4 col-lg-6">
								<label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold m-2">Code</label>
								<div className="input-group">
									<input type="text" className="form-control" placeholder="Code" {...formik.getFieldProps('code')} />
								</div>
								{formik.touched.code && formik.errors.code && (
									<div className='fv-plugins-message-container'>
										<div className='fv-help-block'>
											<span role='alert' className='text-danger'>{formik.errors.code}</span>
										</div>
									</div>
								)}
							</div>
						</div>
						<div className="row">
							<div className="form-group mb-4 col-lg-6">
								<label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold">Discount</label>
								<div className="input-group">
									<input type="text" className="form-control" placeholder="Discount" {...formik.getFieldProps('discount')} />
								</div>
								{formik.touched.discount && formik.errors.discount && (
									<div className='fv-plugins-message-container'>
										<div className='fv-help-block'>
											<span role='alert' className='text-danger'>{formik.errors.discount}</span>
										</div>
									</div>
								)}
							</div>
							<div className="form-group mb-4 col-lg-6">
								<label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold">Discount Type</label>
								<div className="input-group">
									<input type="text" className="form-control" placeholder="Discount Type" {...formik.getFieldProps('discount_type')} />
								</div>
								{formik.touched.discount_type && formik.errors.discount_type && (
									<div className='fv-plugins-message-container'>
										<div className='fv-help-block'>
											<span role='alert' className='text-danger'>{formik.errors.discount_type}</span>
										</div>
									</div>
								)}
							</div>
						</div>
						<div className="row">
							<div className="form-group mb-4 col-lg-6">
								<label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold">Min Buy</label>
								<div className="input-group">
									<input type="number" className="form-control" placeholder="Min Buy" {...formik.getFieldProps('min_buy')} />
								</div>
								{formik.touched.min_buy && formik.errors.min_buy && (
									<div className='fv-plugins-message-container'>
										<div className='fv-help-block'>
											<span role='alert' className='text-danger'>{formik.errors.min_buy}</span>
										</div>
									</div>
								)}
							</div>
							<div className="form-group mb-4 col-lg-6">
								<label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold">Max Discount</label>
								<div className="input-group">
									<input type="number" className="form-control" placeholder="Max Discount" {...formik.getFieldProps('max_discount')} />
								</div>
								{formik.touched.max_discount && formik.errors.max_discount && (
									<div className='fv-plugins-message-container'>
										<div className='fv-help-block'>
											<span role='alert' className='text-danger'>{formik.errors.max_discount}</span>
										</div>
									</div>
								)}
							</div>
						</div>
						<div className="row">
							<div className="form-group mb-4 col-lg-6">
								<label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold">Start date</label>
								<div className="input-group">
									{/* <input type="date" className="form-control" placeholder="Start date" {...formik.getFieldProps('start_date')} /> */}
								<DatePicker
									selected={startDate}
									onChange={handleStartDate}
									className='col-lg-12 text-center'
								/>
								</div>

								{formik.touched.start_date && formik.errors.start_date && (
									<div className='fv-plugins-message-container'>
										<div className='fv-help-block'>
											<span role='alert' className='text-danger'>{formik.errors.start_date}</span>
										</div>
									</div>
								)}
							</div>
							<div className="form-group mb-4 col-lg-6">
								<label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold">End Date</label>
								<div className="input-group">
									{/* <input type="date" className="form-control" placeholder="End Date" {...formik.getFieldProps('end_date')} /> */}
								<DatePicker
									selected={endDate}
									endDate={endDate}
									onChange={handleEndDate}
									className='col-lg-12 text-center'
								/>
								</div>

								{formik.touched.end_date && formik.errors.end_date && (
									<div className='fv-plugins-message-container'>
										<div className='fv-help-block'>
											<span role='alert' className='text-danger'>{formik.errors.end_date}</span>
										</div>
									</div>
								)}
							</div>
						</div>
							<div className='card-footer py-5 text-center' id='kt_task_footer'>
								<button
									type='submit'
									id='submit_button'
									className='btn btn-primary text-white mx-2'
									disabled={formik.isSubmitting}
									style={{backgroundColor:'#ffbe57'}}
									// onClick={()=>{toComponentB()}}
									// onClick={() => alert()}
								>
									{!loading && <span className='indicator-label'> Update
									</span>}
									{loading && (
										<span className='indicator-progress' style={{ display: 'block' }}>
											Please wait...{' '}
											<span className='spinner-border spinner-border-sm align-middle ms-2'></span>
										</span>
									)}
								</button>

								<div className='btn btn-danger text-white' onClick={clearForm} > Cancel</div>
							</div>
					</Form>
					</ModalBody>
				</Modal>

				{/* Delete Modal */}
				<div isOpen={deleteOpen} toggle={oncloseDeleteModal}>
					<div className='modal fade p-6' id={'delete_confirm_popup452222' + selectedId} aria-hidden='true'>
						<div className='modal-dialog modal-dialog-centered'>
							<div className='modal-content'>
								<div className='modal-header'>
									<h3 className="text-dark">Confirmation</h3>
									<div className='btn btn-sm btn-icon btn-active-color-primary' data-bs-dismiss='modal'>
									</div>
								</div>
								<div className='modal-body'>
									<div className='text-center'>
										<h4>Are you sure want to Delete ? </h4>
										<p className='text-danger'></p>
									</div>
									<div className='d-flex align-items-center justify-content-center'>
										<button className='btn btn-sm btn-outline-danger mx-4 mt-3' data-bs-dismiss='modal' onClick={(e) => onDelete(selectedId)}>
											Yes
										</button>
										<button className='btn btn-sm btn-outline-secondary mt-3 me-3' data-bs-dismiss='modal'>
											No
										</button>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</Container>
		</Fragment>
	);
};

export default ListCoupons;
