import React, { Fragment } from "react";
import { Card, CardBody, CardHeader, Container } from "reactstrap";
import Breadcrumb from "../common/breadcrumb";
import Tabset from "./tabset";
import { Link, useNavigate } from 'react-router-dom';

const Create_coupons = () => {
	return (
		<Fragment>
			<Breadcrumb title="Create Coupon" parent="Coupon" />
			<Container fluid={true}>
				<Card>
					{/* <CardHeader>
						<h5>Discount Coupon Details</h5>
					</CardHeader> */}
					<CardHeader>
						<div className='row align-items-center'>
							<div className='col-auto'>
								<h5>Create Coupon</h5>
							</div>
							<div className='d-flex justify-content-end col' data-kt-user-table-toolbar='base'>
								<Link to='/coupons/list-coupons' className="btn btn-primary">
									Coupon List
								</Link>
							</div>
						</div>
					</CardHeader>
					<CardBody>
						<Tabset />
					</CardBody>
				</Card>
			</Container>
		</Fragment>
	);
};

export default Create_coupons;
