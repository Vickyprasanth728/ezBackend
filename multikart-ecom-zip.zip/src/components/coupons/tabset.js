import React, { Fragment, useState, useEffect } from "react";
import { Tabs, TabList, TabPanel, Tab } from "react-tabs";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { Button, Col, Form, Input, Label, Row } from "reactstrap";
import { useFormik } from 'formik';
import { json, Link, useNavigate } from 'react-router-dom';
// import Datatable from "../common/datatable";
import DataTable from "react-data-table-component";
import { Offcanvas, Toast } from 'bootstrap';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import * as Yup from 'yup';
import {getCoupons, saveCoupon, editCoupon, updateCoupon , deleteCoupon} from "../coupons/core/_requests"

const initialValues = {
    "id":"",
    "user_id":"",
    "type": "",
    "code": "",
    "details": "",
    "discount": "",
    "discount_type": "",
    "start_date": "",
    "end_date": "",
}

const Tabset = () => {
    const navigate = useNavigate();

	var userId = localStorage.getItem('userId')
	console.log("User ID",userId)

	const couponSchema = Yup.object().shape({
        // type: Yup.string().required('* Type is required'),
    })

	const [allCoupons, setAllCoupons] = useState([]);
	const [allCouponEdit, setAllCouponEdit] = useState([]);
    const [loading, setLoading] = useState(false);
    const [selectedId, setSelectedId] = useState('');
    const [dataBinded, setDataBinded] = useState(false);

	const [open, setOpen] = useState(false);
	const [editOpen, setEditOpen] = useState(false);
	const [deleteOpen, setDeleteOpen] = useState(false);

	const [startDate, setstartDate] = useState(new Date());
	const [endDate, setendDate] = useState(new Date());

	const CouponList = async () => {
        const couponsResponse = await getCoupons()
        console.log('All Coupons');
        console.log(couponsResponse.Data);
        setAllCoupons(couponsResponse.Data);
    }

	const formik = useFormik({
        initialValues,
        validationSchema: couponSchema,
        onSubmit: async (values, {setStatus, setSubmitting, resetForm}) => {
          setLoading(true)
          try {
              
			const val = {
				"min_buy": values.min_buy , 
				"max_discount": values.max_discount,
			}
			const detailsValues = JSON.stringify(val);

			const body = {
				"id": values.id,
				"user_id":userId,
				"type": values.type,
				"code": values.code,
				"details": detailsValues,
				"discount": values.discount,
				"discount_type": values.discount_type,
				"start_date": startDate,
				"end_date": endDate,
			}
                
            console.log('lead form body');
            console.log(body);
            if(!dataBinded){
                const saveCouponData = await saveCoupon(body);
            
                if(saveCouponData != null){
                    setLoading(false);
                    resetForm();
                    CouponList();
            		setOpen(false);
                    document.getElementById('kt_team_close')?.click();
					NavPageList();
                    // var toastEl = document.getElementById('myToastAdd');
                    // const bsToast = new Toast(toastEl);
                    // bsToast.show();
					toast(' Coupon Saved Sucessfully!', { 
						position: "bottom-right",
						autoClose: 3000,
						hideProgressBar: false,
						closeOnClick: true,
						pauseOnHover: true,
						draggable: true,
						progress: undefined,
						// theme: "dark",
						className:"text-white",
						style: {backgroundColor: "#027a02"},
					});
                }

            } else {
                const updateCouponData = await updateCoupon(selectedId, body);
            
                if(updateCouponData != null){
                    setLoading(false);
                    resetForm();
                    CouponList();
                    setDataBinded(false);
		            setEditOpen(false);
                    var toastEl = document.getElementById('myToastUpdate');
                    const bsToast = new Toast(toastEl);
                    bsToast.show();
                }
            }
            setEditOpen(false);
    
          } catch (error) {
            console.error(error)
            setStatus('The registration details is incorrect')
            setSubmitting(false)
            setLoading(false)
          }
          CouponList();
          setEditOpen(false);
          resetForm();
    }})

	const EditCouponID = async (id) => {
        setSelectedId(id);
        const couponEditResponse = await editCoupon(id)
        setAllCouponEdit(couponEditResponse.Data);

        setDataBinded(true);
        formik.setFieldValue('type', couponEditResponse.Data.type);
        formik.setFieldValue('code', couponEditResponse.Data.code);
        formik.setFieldValue('discount', couponEditResponse.Data.discount);
        // onEditModal();
    }

	const handleStartDate = (date) => {
		setstartDate(date);
	};

	const handleEndDate = (date) => {
		setendDate(date);
	};

	const clickActive = (event) => {
		document.querySelector(".nav-link").classList.remove("show");
		event.target.classList.add("show");
	};

	const NavPageList = () => {
        setTimeout(
            () => navigate('/coupons/list-coupons'),
            2000
          );
        }
			
	useEffect(() => {
		CouponList();
	}, []);

	return (
		<Fragment>
			<ToastContainer/>
			<Tabs>
				<TabList className="nav nav-tabs tab-coupon">
					<Tab className="nav-link" onClick={(e) => clickActive(e)}>
						General
					</Tab>
					{/* <Tab className="nav-link" onClick={(e) => clickActive(e)}>
						Restriction
					</Tab>
					<Tab className="nav-link" onClick={(e) => clickActive(e)}>
						Usage
					</Tab> */}
				</TabList>

				<TabPanel>
					<div className="tab-pane fade active show">
						<Form className="needs-validation" noValidate onSubmit={formik.handleSubmit}>
							<h4>General</h4>
							<Row>
								<Col sm="12">
									<div className="form-group row">
										<Label className="col-xl-3 col-md-4">
											<span>*</span> Type
										</Label>
										<div className="col-md-7">
											<Input
												className="form-control"
												id="validationCustom0"
												type="text"
												required=""
												placeholder="Type"
												{...formik.getFieldProps('type')} 
											/>
											{formik.touched.type && formik.errors.type && (
												<div className='fv-plugins-message-container'>
													<div className='fv-help-block'>
														<span role='alert' className='text-danger'>{formik.errors.type}</span>
													</div>
												</div>
											)}
										</div>
									</div>
									<div className="form-group row">
										<Label className="col-xl-3 col-md-4">
											<span>*</span> Code
										</Label>
										<div className="col-md-7">
											<Input
												className="form-control"
												id="validationCustom1"
												type="text"
												required=""
												placeholder="Code"
												{...formik.getFieldProps('code')} 
											/>
											{formik.touched.code && formik.errors.code && (
												<div className='fv-plugins-message-container'>
													<div className='fv-help-block'>
														<span role='alert' className='text-danger'>{formik.errors.code}</span>
													</div>
												</div>
											)}
										</div>
										<div className="valid-feedback">
											Please Provide a Valid Coupon Code.
										</div>
									</div>
									<div className="form-group row">
										<Label className="col-xl-3 col-md-4">Start Date</Label>
										<div className="col-md-7">
											<DatePicker
												selected={startDate}
												onChange={handleStartDate}
											/>
										</div>
									</div>
									<div className="form-group row">
										<Label className="col-xl-3 col-md-4">End Date</Label>
										<div className="col-md-7">
											<DatePicker
												selected={endDate}
												endDate={endDate}
												onChange={handleEndDate}
											/>
										</div>
									</div>
									{/* <div className="form-group row">
										<Label className="col-xl-3 col-md-4">Free Shipping</Label>
										<div className="col-md-7">
											<Label className="d-block">
												<Input
													className="checkbox_animated"
													id="chk-ani2"
													type="checkbox"
												/>
												Allow Free Shipping
											</Label>
										</div>
									</div> */}
									<div className="form-group row">
										<Label className="col-xl-3 col-md-4">Min Buy</Label>
										<div className="col-md-7">
											<Input
												className="form-control"
												type="number"
												required=""
												placeholder="Min Buy"
												{...formik.getFieldProps('min_buy')} 
											/>
											{formik.touched.min_buy && formik.errors.min_buy && (
												<div className='fv-plugins-message-container'>
													<div className='fv-help-block'>
														<span role='alert' className='text-danger'>{formik.errors.min_buy}</span>
													</div>
												</div>
											)}
										</div>
									</div>
									<div className="form-group row">
										<Label className="col-xl-3 col-md-4">Max Discount</Label>
										<div className="col-md-7">
											<Input
												className="form-control"
												type="number"
												required=""
												placeholder="Max Discount"
												{...formik.getFieldProps('max_discount')} 
											/>
											{formik.touched.max_discount && formik.errors.max_discount && (
												<div className='fv-plugins-message-container'>
													<div className='fv-help-block'>
														<span role='alert' className='text-danger'>{formik.errors.max_discount}</span>
													</div>
												</div>
											)}
										</div>
									</div>
									
									<div className="form-group row">
										<Label className="col-xl-3 col-md-4">Discount</Label>
										<div className="col-md-7">
											<Input
												className="form-control"
												type="number"
												required=""
												placeholder="Discount %"
												{...formik.getFieldProps('discount')} 
											/>
											{formik.touched.discount && formik.errors.discount && (
												<div className='fv-plugins-message-container'>
													<div className='fv-help-block'>
														<span role='alert' className='text-danger'>{formik.errors.discount}</span>
													</div>
												</div>
											)}
										</div>
									</div>
									{/* <div className="form-group row">
										<Label className="col-xl-3 col-md-4">Quantity</Label>
										<div className="col-md-7">
											<Input
												className="form-control"
												type="number"
												required=""
											/>
										</div>
									</div> */}
									<div className="form-group row">
										<Label className="col-xl-3 col-md-4">Discount Type</Label>
										<div className="col-md-7">
											<select className="form-select" required="" {...formik.getFieldProps('discount_type')} >
												<option value="">--Select--</option>
												<option value="1">Percent</option>
												<option value="2">Fixed</option>
											</select>
										</div>
									</div>
									{/* <div className="form-group row">
										<Label className="col-xl-3 col-md-4">Status</Label>
										<div className="col-md-7">
											<Label className="d-block">
												<Input
													className="checkbox_animated"
													id="chk-ani2"
													type="checkbox"
												/>
												Enable the Coupon
											</Label>
										</div>
									</div> */}
								</Col>
							</Row>
							<div className="pull-right">
								<Button type="submits" color="primary">
									Save
								</Button>
							</div>
						</Form>
					</div>
				</TabPanel>
				<TabPanel>
					<Form className="needs-validation" noValidate="">
						<h4>Restriction</h4>
						<div className="form-group row">
							<Label className="col-xl-3 col-md-4">Products</Label>
							<div className="col-md-7">
								<Input
									className="form-control"
									id="validationCustom3"
									type="text"
									required=""
								/>
							</div>
							<div className="valid-feedback">
								Please Provide a Product Name.
							</div>
						</div>
						<div className="form-group row">
							<Label className="col-xl-3 col-md-4">Category</Label>
							<div className="col-md-7">
								<select className="form-select" required="">
									<option value="">--Select--</option>
									<option value="1">Electronics</option>
									<option value="2">Clothes</option>
									<option value="2">Shoes</option>
									<option value="2">Digital</option>
								</select>
							</div>
						</div>
						<div className="form-group row">
							<Label className="col-xl-3 col-md-4">Minimum Spend</Label>
							<div className="col-md-7">
								<Input
									className="form-control"
									id="validationCustom4"
									type="number"
								/>
							</div>
						</div>
						<div className="form-group row">
							<Label className="col-xl-3 col-md-4">Maximum Spend</Label>
							<div className="col-md-7">
								<Input
									className="form-control"
									id="validationCustom5"
									type="number"
								/>
							</div>
						</div>
					</Form>
				</TabPanel>
				<TabPanel>
					<Form className="needs-validation" noValidate="">
						<h4>Usage Limits</h4>
						<div className="form-group row">
							<Label className="col-xl-3 col-md-4">Per Limit</Label>
							<div className="col-md-7">
								<Input
									className="form-control"
									id="validationCustom6"
									type="number"
								/>
							</div>
						</div>
						<div className="form-group row">
							<Label className="col-xl-3 col-md-4">Per Customer</Label>
							<div className="col-md-7">
								<Input
									className="form-control"
									id="validationCustom7"
									type="number"
								/>
							</div>
						</div>
					</Form>
				</TabPanel>
			</Tabs>
			{/* <div className="pull-right">
				<Button type="button" color="primary">
					Save
				</Button>
			</div> */}
		</Fragment>
	);
};

export default Tabset;
