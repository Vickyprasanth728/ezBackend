import React, { FC, useState, useEffect, Fragment } from "react";
import { Tabs, TabList, TabPanel, Tab } from "react-tabs";
import { User, Unlock } from "react-feather";
import { Route, useNavigate } from "react-router-dom";
import { Button, Form, FormGroup, Input, Label } from "reactstrap";
import { login, getUserByToken } from "./core/_requests";
import bootstrap from "bootstrap/dist/js/bootstrap.min";
import { Offcanvas, Toast } from 'bootstrap';
import { ToastContainer, toast } from 'react-toastify';
import {useFormik} from 'formik'
import * as Yup from 'yup'
import clsx from 'clsx'

const loginSchema = Yup.object().shape({
	email: Yup.string()
	  .email('Wrong email format')
	  .min(3, 'Minimum 3 symbols')
	  .max(50, 'Maximum 50 symbols')
	  .required('* Email is required'),
	password: Yup.string()
	  .matches(
	  /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})/,
	  "Must Contain 8 Characters, One Uppercase, One Lowercase, One Number and One Special Case Character"
	  )
	  .required('* Password is required'),
  })

  const initialValues = {
	email: '',
	password: '',
	remember_token:'',
  }

const LoginTabset = () => {
	const history = useNavigate();

	const [loading, setLoading] = useState(false)
	// const {saveAuth, setCurrentUser} = useAuth()
	const [logindata, setLogindata] = useState();
	const [loginToken, setLoginToken] = useState("");
	const [loginStatus, setLoginStatus] = useState("");
  
	const formik = useFormik({
	  initialValues,
	  validationSchema: loginSchema,
	  onSubmit: async (values, {setStatus, setSubmitting}) => {
		setLoading(true)
		try {
		//   const {data: auth} = await login(values.email, values.password)
		//   saveAuth(auth)
		//   const {data: user} = await getUserByToken(auth.remember_token)
		//   setCurrentUser(user)

		let email = values.email
		let password = values.password

		const userLogin = await login(email, password);
		setLogindata(userLogin.Data);
		console.log("userToken", userLogin.remember_token);

		let remember_token = userLogin.Data.remember_token

		const userToken = await getUserByToken(remember_token);
		// localStorage.setItem('userId',logindata.Data.id)
		setLoginToken(userToken);
		console.log("userLogin", logindata);
		history(`${process.env.PUBLIC_URL}/dashboard`);
		localStorage.setItem("userId",userLogin.Data.id);
		
		} catch (error) {
		  console.error(error)
		//   saveAuth(undefined)
		  setStatus('Incorrect password')
		  setLoginStatus('Incorrect password')
		  setSubmitting(false)
		  setLoading(false)

		  toast.error('Invalid Password', {
			position: "bottom-right",
			autoClose: 5000,
			hideProgressBar: false,
			closeOnClick: true,
			pauseOnHover: true,
			draggable: true,
			progress: undefined,
			theme: "light",
			});
		}
	  },
	})
	console.log("formik status",formik.status);

	
	
	// const [show, setShow] = useState("password");
	// function showpassword() {
	// 	const type = show === "password" ? "text" : "password";
	// 	setShow(type);
	// }

	// useEffect(() => {
	// 	if (Object.keys(formErrors).length === 0 && isSubmit) {
	// 	}
	//   }, [formErrors]);


	// const initialValues = {email: "", password: ""};
	// const [formValues, setFormValues] = useState(initialValues);
	// const [isSubmit, setIsSubmit] = useState(false);

	// const handleChange = (e) => {
	// 	const { name, value } = e.target;
	// 	setFormValues({ ...formValues, [name]: value });
	// };

	// const handleSubmit = async (e) => {
	// 	e.preventDefault();
	// 	// setFormErrors(validate(formValues));
	// 	setIsSubmit(true);

		// let email = formValues.email
		// let password = formValues.password

		// const userLogin = await login(email, password);
		// setLogindata(userLogin.data);
		// console.log("userLogin", userLogin);
		// history(`${process.env.PUBLIC_URL}/dashboard`);

	// 	var myModalEl = document.getElementById('exampleModalToggle');
	// 	var modal = bootstrap.Modal.getInstance(myModalEl)
	// 	modal.hide();
	// 	window.location.reload();
	// 	document.getElementById('overAllcountData')?.click()
	// };

	// useEffect(() => {
	// 	if (Object.keys(formErrors).length === 0 && isSubmit) {
	// 	}
	//   }, [formErrors]);

	// const validate = (values) => {
	// 	const errors = {};
	// 	const regex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i;
	// 	if (!values.email) {
	// 		errors.email = "Email is required!";
	// 	} else if (!regex.test(values.email)) {
	// 		errors.email = "This is not a valid email format!";
	// 	}
	// 	if (!values.password) {
	// 		errors.password = "Password is required";
	// 	}
	// 	return errors;
	// };

	// const clickActive = (event) => {
	// 	document.querySelector(".nav-link").classList.remove("show");
	// 	event.target.classList.add("show");
	// };

	// const routeChange = () => {
	// 	history(`${process.env.PUBLIC_URL}/dashboard`);
	// };
	return (
		<div>
			<Fragment>
				<ToastContainer/>
				<Tabs>
					{/* <TabList className="nav nav-tabs tab-coupon">
						<Tab className="nav-link" onClick={(e) => clickActive(e)}>
							<User />
							Login
						</Tab>
						<Tab className="nav-link" onClick={(e) => clickActive(e)}>
							<Unlock />
							Register
						</Tab>
					</TabList> */}

					{/* <TabPanel>
						<Form className="form-horizontal auth-form" onSubmit={handleSubmit}>
							<FormGroup>
								<Input
									type="email"
									name="email"
									className="form-control"
									placeholder="Enter you Email"
									aria-describedby="emailHelp"
									id="email"
									// onChange={(e) => setEmail(e.target.value)}
									value={formValues.email}
									onChange={handleChange}
								/>
							</FormGroup>
							<FormGroup>
								<Input
									type={show}
									className="form-control"
									placeholder="password"
									name="password"
									id="password-field"
									// onChange={(e) => setPassword(e.target.value)}
									value={formValues.password}
									onChange={handleChange}
								/>
							</FormGroup>
							<div className="form-terms">
								<div className="custom-control custom-checkbox me-sm-2">
									<Label className="d-block">
										<Input
											className="checkbox_animated"
											id="chk-ani2"
											type="checkbox"
										/>
										Reminder Me{" "}
										<span className="pull-right">
											{" "}
											<a href="/#" className="btn btn-default forgot-pass p-0">
												lost your password
											</a>
										</span>
									</Label>
								</div>
							</div>
							<div className="form-button">
								<Button
									color="primary"
									type="submit"
								// onClick={() => routeChange()}
								>
									Login
								</Button>
							</div>
							<div className="form-footer">
								<span>Or Login up with social platforms</span>
								<ul className="social">
									<li>
										<a href="/#">
											<i className="icon-facebook"></i>
										</a>
									</li>
									<li>
										<a href="/#">
											<i className="icon-twitter-alt"></i>
										</a>
									</li>
									<li>
										<a href="/#">
											<i className="icon-instagram"></i>
										</a>
									</li>
									<li>
										<a href="/#">
											<i className="icon-pinterest-alt"></i>
										</a>
									</li>
								</ul>
							</div>
						</Form>
					</TabPanel> */}
					{/* <TabPanel>
						<Form className="form-horizontal auth-form">
							<FormGroup>
								<Input
									required=""
									name="login[username]"
									type="email"
									className="form-control"
									placeholder="Username"
									id="exampleInputEmail12"
								/>
							</FormGroup>
							<FormGroup>
								<Input
									required=""
									name="login[password]"
									type="password"
									className="form-control"
									placeholder="Password"
								/>
							</FormGroup>
							<FormGroup>
								<Input
									required=""
									name="login[password]"
									type="password"
									className="form-control"
									placeholder="Confirm Password"
								/>
							</FormGroup>
							<div className="form-terms">
								<div className="custom-control custom-checkbox me-sm-2">
									<Label className="d-block">
										<Input
											className="checkbox_animated"
											id="chk-ani2"
											type="checkbox"
										/>
										I agree all statements in{" "}
										<span>
											<a href="/#">Terms &amp; Conditions</a>
										</span>
									</Label>
								</div>
							</div>
							<div className="form-button">
								<Button
									color="primary"
									type="submit"
									onClick={() => routeChange()}
								>
									Register
								</Button>
							</div>
							<div className="form-footer">
								<span>Or Sign up with social platforms</span>
								<ul className="social">
									<li>
										<a href="/#">
											<i className="icon-facebook"></i>
										</a>
									</li>
									<li>
										<a href="/#">
											<i className="icon-twitter-alt"></i>
										</a>
									</li>
									<li>
										<a href="/#">
											<i className="icon-instagram"></i>
										</a>
									</li>
									<li>
										<a href="/#">
											<i className="icon-pinterest-alt"></i>
										</a>
									</li>
								</ul>
							</div>
						</Form>
					</TabPanel> */}
				</Tabs>
				<div className="justify-content-center mx-5">
				<div  className="text-center my-4">
					<h4 className="fw-bold"> <User  style={{color:"#54a0fe"}}/> Login</h4>
				</div>
				{/* <Form className="form-horizontal auth-form mt-5" onSubmit={handleSubmit}> */}
				<Form className="form-horizontal auth-form mt-5"  onSubmit={formik.handleSubmit}>
				<FormGroup>
							<Label className="py-1">Email</Label>
								<Input
									type="email"
									name="email"
									// className="form-control mb-3"
									placeholder="Enter you Email"
									aria-describedby="emailHelp"
									id="email"
									// onChange={(e) => setEmail(e.target.value)}
									// value={formValues.email}
									// onChange={handleChange}
									{...formik.getFieldProps('email')}
									className={clsx(
									  'form-control bg-transparent',
									  { 'is-invalid': formik.touched.email && formik.errors.email },
									  {
										'is-valid': formik.touched.email && !formik.errors.email,
									  }
									)}
									autoComplete='off'
								/>
								{formik.touched.email && formik.errors.email && (
									<div className='fv-plugins-message-container'>
										<div className='fv-help-block'>
											<span role='alert' className='text-danger'>{formik.errors.email}</span>
										</div>
									</div>
								)}
							</FormGroup>
							<FormGroup style={{position:'relative'}}>
							<Label className="py-1">Password</Label>
								<Input
									// type={show}
									// className="form-control"
									placeholder="password"
									name="password"
									id="password-field"
									// onChange={(e) => setPassword(e.target.value)}
									// value={formValues.password}
									// onChange={handleChange}
									type='password'
									autoComplete='off'
									{...formik.getFieldProps('password')}
									className={clsx(
									  'form-control bg-transparent',
									  {
										'is-invalid': formik.touched.password && formik.errors.password,
									  },
									  {
										'is-valid': formik.touched.password && !formik.errors.password,
									  }
									)}
								/>
								{formik.touched.password && formik.errors.password && (
									<div className='fv-plugins-message-container'>
										<div className='fv-help-block'>
											<span role='alert' className='text-danger'>{formik.errors.password}</span>
										</div>
									</div>
								)}
								{formik.status && <p className="text-danger text-start mt-2">{formik.status}</p>}
							</FormGroup>
							<div className="form-terms">
								<div className="custom-control custom-checkbox me-sm-2 d-flex justify-content-between">
									<Label className="d-block text-truncate">
										<Input
											className="checkbox_animated mb-5"
											id="chk-ani2"
											type="checkbox"
										/>
										Reminder Me{" "}
	
									</Label>
									<span className="pull-right">
											{" "}
											<a href="/#" className="btn btn-default forgot-pass p-0 ">
												Forget password
											</a>
										</span>
								</div>
							</div>
							<div className="form-button log-btn text-center">
								<Button
									// color="primary"
									type="submit"
								// onClick={() => routeChange()}
								>
									Login
								</Button>
							</div>
							
						</Form>
						</div>
			</Fragment>
		</div>
	);
};

export default LoginTabset;
