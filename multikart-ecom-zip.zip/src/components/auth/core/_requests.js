import axios from 'axios'

const API_URL = process.env.REACT_APP_API_URL

export const GET_USER_BY_ACCESSTOKEN_URL = `${API_URL}/verify_token`
export const LOGIN_URL = `${API_URL}/login`

// Login API
export function login(email,password){
    return axios.post(LOGIN_URL,{
        email,
        password,
    }).then(response =>response.data)
}

export function getUserByToken(token) {
  return axios.post(GET_USER_BY_ACCESSTOKEN_URL, {
    remember_token: token,
  })
}