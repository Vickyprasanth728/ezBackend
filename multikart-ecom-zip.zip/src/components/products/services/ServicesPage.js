import React, { Fragment, useState,useRef, useEffect } from "react";
import Breadcrumb from "../../common/breadcrumb";
import "react-toastify/dist/ReactToastify.css";
import { data } from "../../../assets/data/category";
import { useFormik } from 'formik';
import DataTable from "react-data-table-component";
import { Link, useNavigate } from 'react-router-dom';
// import Datatable from "../../common/datatable";
import { Offcanvas, Toast } from 'bootstrap';
import * as Yup from 'yup';
import { getServices, saveService, getServiceEdit, updateService, deleteService, getCategories } from '../services/core/_requests.js';
import logo from "../../../assets/icons/no_image.jpg";

import {
	Button,
	Card,
	CardBody,
	CardHeader,
	Col,
	Container,
	Form,
	FormGroup,
	Input,
	Label,
	Modal,
	ModalBody,
	ModalFooter,
	ModalHeader,
	Row,
} from "reactstrap";

const initialValues = {
    "id": "",
    "category_id": "",
    "parent_category_id": "",
    "seller_id": "",
    "name": "",
    "price": "",
    "discount_price": "",
    "duration": "",
    "description": "",
    "images": "",
}

const ServicePage = () => {

    const serviceSchema = Yup.object().shape({
        name: Yup.string()
			.min(3, '* Minimum 3 characters')
            .max(50, '* Maximum 50 characters')
			.required('* Name is required'),
        category_id: Yup.string().required('* Category is required'),
        price: Yup.string()
		.min(3, '* Minimum 3 characters')
        .required('* Price is required'),
        discount_price: Yup.string()
        .min(2, '* Minimum 2 characters')
        .required('* Discount Price is required'),
    })

	const [open, setOpen] = useState(false);
	const [editOpen, setEditOpen] = useState(false);
	const [deleteOpen, setDeleteOpen] = useState(false);
    const [allServices, setAllServices] = useState([]);
    const [allCategories, setAllCategories] = useState([]);
    const [serviceEdit, setServiceEdit] = useState([]);
    const [logoImagePreview, setlogoImagePreview] = useState(null);
    const [selectedId, setSelectedId] = useState('');
    const [dataBinded, setDataBinded] = useState(false);
    const viewLogo = useRef(null);
    const [logoImage, setLogoImage] = useState(null);
    const [loading, setLoading] = useState(false);
    const [editClicked, setEditClicked] = useState(false);
    const [editId, setEditId] = useState('');
    const [isLoading, setIsLoading] = useState(false);

    // const ServicesList = async () => {
    //     const ServiceResponse = await getServices()
    //     setAllServices(ServiceResponse.Data);
    // }

	const ServicesList = async () => {
        const ServiceResponse = await getServices();
		let new_array = [];
		for(let i=0; i<ServiceResponse.Data.length;i++) {
			let cur_obj = {
				...ServiceResponse.Data[i],
				'sl_no': i + 1 
			}
			new_array.push(cur_obj)
		}
        setAllServices(new_array);
		
		console.log('New Array', new_array);
		console.log('Service Response', ServiceResponse.Data);
    }
	
    const CategoriesList = async () => {
        const categoryResponse = await getCategories()
        console.log('categories list');
        console.log(categoryResponse.Data);
        setAllCategories(categoryResponse.Data);
    }

    const formik = useFormik({
        initialValues,
        validationSchema: serviceSchema,
        onSubmit: async (values, { setStatus, setSubmitting, resetForm }) => {
            setLoading(true)
            try {

                var formData = new FormData();

                // const body = {
                //     "name": values.name,
                //     "logo": values.logo,
                //     "top": values.top,
                //     "slug": values.slug,
                //     "meta_title": values.meta_title,
                //     "meta_description": values.meta_description,
                // }

                formData.append('category_id', values.category_id);
                formData.append('parent_category_id', values.parent_category_id);
                formData.append('seller_id', values.seller_id);
                formData.append('name', values.name);
                formData.append('price', values.price);
                formData.append('discount_price', values.discount_price);
                formData.append('duration', values.duration);
                formData.append('description', values.description);
                formData.append('images', logoImage);

                const headers = {
                    headers: {
                        "Content-type": "multipart/form-data",
                    },
                }

                console.log('lead form body');
                console.log(formData);
                if (!dataBinded) {
                    const BrandData = await saveService(formData, headers);

                    if (BrandData != null) {
                        setLoading(false);
                        document.getElementById('kt_team_close')?.click();
                        resetForm();
                        clearForm();
                        ServicesList();
                		setOpen(false);
						var toastEl = document.getElementById('myToastAdd');
                        const bsToast = new Toast(toastEl);
                        bsToast.show();
                    }
            		setOpen(false);
                } else {
                    const updateBrandData = await updateService(selectedId, formData);

                    if (updateBrandData != null) {
                        setLoading(false);
                        resetForm();
                        setDataBinded(false);
                        clearForm();
						ServicesList();
						var toastEl = document.getElementById('myToastUpdate');
                        const bsToast = new Toast(toastEl);
                        bsToast.show();
                    }
                }
				ServicesList();
            } catch (error) {
                console.error(error)
                setStatus('The registration details is incorrect')
                setSubmitting(false)
                setLoading(false)
            }
			setOpen(false);
     		setEditOpen(false);
			ServicesList();
			clearForm();
        }
    })

    const handleLogoPreview = (e) => {
        let image_as_base64 = URL.createObjectURL(e.target.files[0])
        let image_as_files = e.target.files[0];

        let fields = viewLogo.current?.value.split(".");

        let fileType = fields [fields.length - 1];

        if (fileType == 'jpg' || fileType == 'jpeg' || fileType == 'pdf'  || fileType == 'png') {
            setlogoImagePreview(image_as_base64);
            setLogoImage(image_as_files);
        } else {
            setlogoImagePreview(null);
            setLogoImage(null);
            if (viewLogo.current != null) {
                viewLogo.current.value = "";
            }
        }
        console.log(viewLogo.current?.value);
        console.log(image_as_files);
        console.log(fileType);
    }

    const removeLogo = () => {
        console.log(viewLogo.current?.value);
        if (viewLogo.current != null) {
            setlogoImagePreview(null);
            setLogoImage(null);
            viewLogo.current.value = "";
        }
    }
	const onOpenModal = () => {
		setOpen(true);
        formik.resetForm();
        allClear();
	};
	const onCloseModal = () => {
		setOpen(false);
	};
	const onEditModal = () => {
		setEditOpen(true);
	};
	const onCloseEdit = () => {
		setEditOpen(false);
	};
	const onDeleteModal = () => {
		setDeleteOpen(true);
	};
	const oncloseDeleteModal = () => {
		setDeleteOpen(false);
	};


    const EditService = async (id) => {
        setSelectedId(id);
        const allServiceEdit = await getServiceEdit(id)
        setServiceEdit(allServiceEdit.Data);
        setDataBinded(true);
        formik.setFieldValue('category_id', allServiceEdit.Data.category_id);
        formik.setFieldValue('parent_category_id', allServiceEdit.Data.parent_category_id);
        formik.setFieldValue('seller_id', allServiceEdit.Data.seller_id);
        formik.setFieldValue('name', allServiceEdit.Data.name);
        formik.setFieldValue('price', allServiceEdit.Data.price);
        formik.setFieldValue('discount_price', allServiceEdit.Data.discount_price);
        formik.setFieldValue('duration', allServiceEdit.Data.duration);
        // formik.setFieldValue('description', allServiceEdit.Data.description);
        formik.setFieldValue('images', allServiceEdit.Data.images);
		onEditModal();
    }
    const ServiceDelete = async (id) => {
        setSelectedId(id);
		onDeleteModal(id);
    }
    const clearForm = () => {
        formik.resetForm();
        // setDataBinded(false);
		setOpen(false);
		setEditOpen(false);
		removeLogo();
    }

    const allClear = () => {
        formik.resetForm();
        setDataBinded(false);
    }
    
    const onDelete = async (id) => {
        console.log(id);
        await deleteService(id);
        ServicesList();
		var toastEl = document.getElementById('myToastDelete');
		const bsToast = new Toast(toastEl);
		bsToast.show();
    }

	const columns = [
		{
			name: "id",
			selector: row => row.sl_no,
			sortable: true,
		},
		{
			name: "Name",
			selector: row => row.name,
			sortable: true,
		},
		{
			name: "Images",
			selector: row => <img src={process.env.REACT_APP_API_BASE_URL + 'uploads/service/images/' + row.id + '/' + row.images} className="img-fluid img-70" height={80} width={80} alt='' />,
			// sortable: true,
		},
		{
			name: "Category",
			selector: row => row.category_name,
			sortable: true,
		},
		{
			name: "Duration",
			selector: row => row.duration,
			sortable: true,
		},
		{
			name: "Price",
			selector: row => row.price +' Rs',
			sortable: true,
		},
		{
			name: "Discount Price",
			selector: row => row.discount_price  +' Rs',
			sortable: true,
		},
		{
			name:"Actions",
			cell: (row, index) => (
				<div>
					<span>
						<button
						className="btn btn-danger btn-sm fa fa-pencil mx-2 m-2 button_size"
						data-toggle="modal"
						onClick={() => EditService(row.id)}
						>
						</button>
					</span>
					<span >
						<button
						className="btn btn-primary btn-sm fa fa-trash mx-2 button_size"
						onClick={() => ServiceDelete(row.id)}
						data-bs-toggle='modal' 
						data-bs-target={'#delete_confirm_popup452222' + selectedId}
						>
						</button>
					</span>
				</div>
			),
		}
	]

    // const data1 = allBrands;
	
	useEffect(() => {
        ServicesList();
        CategoriesList();
      }, []);

	return (
		<Fragment>
			<Breadcrumb title="Services" parent="Services" />
			<Container fluid={true}>
				<Row>
					<Col sm="12">
						<Card>
							<CardHeader>
								<h5>Services</h5>
							</CardHeader>
							<CardBody>
								<div className="btn-popup pull-right">
									<Button
										type="button"
										color="primary"
										onClick={onOpenModal}
										data-toggle="modal"
										data-original-title="test"
										data-target="#exampleModal"
									>
										Add Service
									</Button>
									{/* Save Modal */}
									<Modal isOpen={open} toggle={onCloseModal}>
										<ModalHeader toggle={onCloseModal}>
											<h5
												className="modal-title f-w-600"
												id="exampleModalLabel2"
											>
												Add Service
											</h5>
										</ModalHeader>
										<ModalBody>
											<Form noValidate onSubmit={formik.handleSubmit}>

											<div className="form-group mb-0">
												<label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold m-2">Name</label>
												<div className="input-group">
													<input type="text" className="form-control" placeholder="Name" {...formik.getFieldProps('name')} />
												</div>
												{formik.touched.name && formik.errors.name && (
													<div className='fv-plugins-message-container'>
														<div className='fv-help-block'>
															<span role='alert' className='text-danger'>{formik.errors.name}</span>
														</div>
													</div>
												)}
											</div>
                                            <div className="form-group mb-0">
                                                <label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold m-2">Category</label>
                                                <select className="form-control mt-2 form-select" {...formik.getFieldProps('category_id')} name="category_id" id="category_id"
                                                    data-selected="" data-live-search="true" required>
                                                    <option>-- Category Select -- </option>
                                                    {allCategories.map((CategoryValues, i) => {
                                                        return (
                                                            <option selected={i == 0 ? true : false} value={CategoryValues.id} key={i}>{CategoryValues.name}</option>
                                                        )
                                                    })}
                                                </select>
                                                {formik.touched.category_id && formik.errors.category_id && (
                                                    <div className='fv-plugins-message-container'>
                                                        <div className='fv-help-block'>
                                                            <span role='alert' className='text-danger mx-2'>{formik.errors.category_id}</span>
                                                        </div>
                                                    </div>
                                                )}
                                            </div>
                                            <div className="form-group mb-0">
                                                <label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold m-2">Parent Category</label>
                                                <select className="form-control mt-2 form-select" {...formik.getFieldProps('parent_category_id')} name="parent_category_id" id="parent_category_id"
                                                    data-selected="" data-live-search="true" required>
                                                    <option>-- Parent Category Select -- </option>
                                                    {allCategories.map((ParentCategoryValues, i) => {
                                                        return (
                                                            <option selected={i == 0 ? true : false} value={ParentCategoryValues.id} key={i}>{ParentCategoryValues.name}</option>
                                                        )
                                                    })}
                                                </select>
                                                {formik.touched.parent_category_id && formik.errors.parent_category_id && (
                                                    <div className='fv-plugins-message-container'>
                                                        <div className='fv-help-block'>
                                                            <span role='alert' className='text-danger mx-2'>{formik.errors.parent_category_id}</span>
                                                        </div>
                                                    </div>
                                                )}
                                            </div>
											<div className="form-group mb-0">
												<label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold m-2">Duration</label>
												<div className="input-group">
													<input type="time" className="form-control" placeholder="Duration" {...formik.getFieldProps('duration')} min="1" />
												</div>
												{formik.touched.duration && formik.errors.duration && (
													<div className='fv-plugins-message-container'>
														<div className='fv-help-block'>
															<span role='alert' className='text-danger'>{formik.errors.duration}</span>
														</div>
													</div>
												)}
											</div>
											<div className="form-group mb-0">
												<label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold m-2">Price</label>
												<div className="input-group">
													<input type="number" className="form-control" placeholder="Price" {...formik.getFieldProps('price')} min="1" />
												</div>
												{formik.touched.price && formik.errors.price && (
													<div className='fv-plugins-message-container'>
														<div className='fv-help-block'>
															<span role='alert' className='text-danger'>{formik.errors.price}</span>
														</div>
													</div>
												)}
											</div>
											<div className="form-group mb-0">
												<label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold m-2">Discount Price</label>
												<div className="input-group">
													<input type="number" className="form-control" placeholder="Discount Price" {...formik.getFieldProps('discount_price')} min="1"/>
												</div>
												{formik.touched.discount_price && formik.errors.discount_price && (
													<div className='fv-plugins-message-container'>
														<div className='fv-help-block'>
															<span role='alert' className='text-danger'>{formik.errors.discount_price}</span>
														</div>
													</div>
												)}
											</div>
											<div className="form-group mb-0">
												<label className=' text-gray-700 fw-bold m-2'>Image Upload</label>
												<div className="col-md-12">
													<div className="input-group" data-toggle="aizuploader" data-type="image" data-multiple="true">

														{/* <input type="file" className="form-control file-amount mt-2" name="profile_image" /> */}
														<input type="file" className='form-control' ref={viewLogo} onChange={handleLogoPreview} />
													</div>
													<div className="file-preview box sm">
														
													</div>
												</div>
                                                <div className="file-preview box sm d-flex justify-content-center align-items-center mt-4 mx-4">
                                                {logoImagePreview != null && (
                                                    <div className='profile_preview position-relative image-input image-input-outline'>
                                                        <img src={logoImagePreview} alt="image preview" className='image-input-wrapper w-100px h-100px' height={100} width={150} />
                                                        <div onClick={removeLogo} className="p-1 fa fa-remove text-danger" style={{fontSize:"30px" , cursor:"pointer"}}>
											            
														</div>
                                                    </div>
                                                )}
                                                </div>
											</div>
											{/* <div className="form-group mb-4">
												<label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold m-2">Rtl</label>
												<div className="input-group">
													<input type="text" className="form-control" placeholder="Rtl" {...formik.getFieldProps('rtl')} />
												</div>
												{formik.touched.rtl && formik.errors.rtl && (
													<div className='fv-plugins-message-container'>
														<div className='fv-help-block'>
															<span role='alert' className='text-danger'>{formik.errors.rtl}</span>
														</div>
													</div>
												)}
											</div>
											<div className="form-group mb-4">
												<label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold m-2">Status</label>
												<div className="input-group">
													<input type="text" className="form-control" placeholder="Status" {...formik.getFieldProps('status')} />
												</div>
												{formik.touched.status && formik.errors.status && (
													<div className='fv-plugins-message-container'>
														<div className='fv-help-block'>
															<span role='alert' className='text-danger'>{formik.errors.status}</span>
														</div>
													</div>
												)}
											</div> */}
											
															{/* <FormGroup>
													<Label
														htmlFor="recipient-name"
														className="col-form-label"
													>
														Languages Name :
													</Label>
													<Input type="text" className="form-control" />
												</FormGroup> */}

												{/* <FormGroup>
													<Label
														htmlFor="message-text"
														className="col-form-label"
													>
														Category Image :
													</Label>
													<Input
														className="form-control"
														id="validationCustom02"
														type="file"
													/>
												</FormGroup> */}

                                                <div className='card-footer py-5 text-center' id='kt_task_footer'>
													<button
														type='submit'
														id='submit_button'
														className='btn btn-primary text-white mx-2'
														disabled={formik.isSubmitting}
														style={{backgroundColor:'#ffbe57'}}
														// onClick={()=>{toComponentB()}}
														// onClick={() => alert()}
													>
														{!loading && <span className='indicator-label'>Submit
														</span>}
														{loading && (
															<span className='indicator-progress' style={{ display: 'block' }}>
																Please wait...{' '}
																<span className='spinner-border spinner-border-sm align-middle ms-2'></span>
															</span>
														)}
													</button>

													<div className='btn btn-danger text-white' onClick={clearForm}> Cancel</div>
												</div>
											</Form>
										</ModalBody>
										<ModalFooter>
											{/* <Button
												type="button"
												color="primary"
												onClick={() => onCloseModal("VaryingMdo")}
											>
												Save
											</Button>
											<Button
												type="button"
												color="secondary"
												onClick={() => onCloseModal("VaryingMdo")}
											>
												Close
											</Button> */}
										</ModalFooter>
									</Modal>

									{/* Edit Modal */}
									<Modal isOpen={editOpen} toggle={onCloseEdit}>
										<ModalHeader toggle={onCloseEdit}>
											<h5
												className="modal-title f-w-600"
												id="exampleModalLabel2"
											>
												Edit Services
											</h5>
										</ModalHeader>
										<ModalBody>
                                        <Form noValidate onSubmit={formik.handleSubmit}>
                                            <div className="form-group mb-0">
                                                <label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold m-2">Name</label>
                                                <div className="input-group">
                                                    <input type="text" className="form-control" placeholder="Name" {...formik.getFieldProps('name')} />
                                                </div>
                                                {formik.touched.name && formik.errors.name && (
                                                    <div className='fv-plugins-message-container'>
                                                        <div className='fv-help-block'>
                                                            <span role='alert' className='text-danger'>{formik.errors.name}</span>
                                                        </div>
                                                    </div>
                                                )}
                                            </div>
                                            <div className="form-group mb-0">
                                                <label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold m-2">Category</label>
                                                <select className="form-control mt-2 form-select" {...formik.getFieldProps('category_id')} name="category_id" id="category_id"
                                                    data-selected="" data-live-search="true" required>
                                                    <option>-- Category Select -- </option>
                                                    {allCategories.map((CategoryValues, i) => {
                                                        return (
                                                            <option selected={i == 0 ? true : false} value={CategoryValues.id} key={i}>{CategoryValues.name}</option>
                                                        )
                                                    })}
                                                </select>
                                                {formik.touched.category_id && formik.errors.category_id && (
                                                    <div className='fv-plugins-message-container'>
                                                        <div className='fv-help-block'>
                                                            <span role='alert' className='text-danger mx-2'>{formik.errors.category_id}</span>
                                                        </div>
                                                    </div>
                                                )}
                                            </div>
											<div className="form-group mb-0">
                                                <label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold m-2">Parent Category</label>
                                                <select className="form-control mt-2 form-select" {...formik.getFieldProps('parent_category_id')} name="parent_category_id" id="parent_category_id"
                                                    data-selected="" data-live-search="true" required>
                                                    <option>-- Parent Category Select -- </option>
                                                    {allCategories.map((ParentCategoryValues, i) => {
                                                        return (
                                                            <option selected={i == 0 ? true : false} value={ParentCategoryValues.id} key={i}>{ParentCategoryValues.name}</option>
                                                        )
                                                    })}
                                                </select>
                                                {formik.touched.parent_category_id && formik.errors.parent_category_id && (
                                                    <div className='fv-plugins-message-container'>
                                                        <div className='fv-help-block'>
                                                            <span role='alert' className='text-danger mx-2'>{formik.errors.parent_category_id}</span>
                                                        </div>
                                                    </div>
                                                )}
                                            </div>
                                            <div className="form-group mb-0">
												<label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold m-2">Duration</label>
												<div className="input-group">
													<input type="time" className="form-control" placeholder="Duration" {...formik.getFieldProps('duration')} min="1" />
												</div>
												{formik.touched.duration && formik.errors.duration && (
													<div className='fv-plugins-message-container'>
														<div className='fv-help-block'>
															<span role='alert' className='text-danger'>{formik.errors.duration}</span>
														</div>
													</div>
												)}
											</div>
                                            <div className="form-group mb-0">
                                                <label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold m-2">Price</label>
                                                <div className="input-group">
                                                    <input type="number" className="form-control" placeholder="Price" {...formik.getFieldProps('price')} min="1" />
                                                </div>
                                                {formik.touched.price && formik.errors.price && (
                                                    <div className='fv-plugins-message-container'>
                                                        <div className='fv-help-block'>
                                                            <span role='alert' className='text-danger'>{formik.errors.price}</span>
                                                        </div>
                                                    </div>
                                                )}
                                            </div>
                                            <div className="form-group mb-0">
                                                <label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold m-2">Discount Price</label>
                                                <div className="input-group">
                                                    <input type="number" className="form-control" placeholder="Discount Price" {...formik.getFieldProps('discount_price')} min="1"/>
                                                </div>
                                                {formik.touched.discount_price && formik.errors.discount_price && (
                                                    <div className='fv-plugins-message-container'>
                                                        <div className='fv-help-block'>
                                                            <span role='alert' className='text-danger'>{formik.errors.discount_price}</span>
                                                        </div>
                                                    </div>
                                                )}
                                            </div>
                                            <div className="form-group mb-0">
                                                <label className=' text-gray-700 fw-bold m-2'>Image Upload</label>
                                                <div className="col-md-12">
                                                    <div className="input-group" data-toggle="aizuploader" data-type="image" data-multiple="true">

                                                        {/* <input type="file" className="form-control file-amount mt-2" name="profile_image" /> */}
                                                        <input type="file" className='form-control' ref={viewLogo} onChange={handleLogoPreview} />
                                                    </div>
                                                    <div className="file-preview box sm">
                                                        
                                                    </div>
                                                </div>
                                                <div className="file-preview box sm d-flex justify-content-center align-items-center mt-4 mx-4">
                                                {/* {logoImagePreview != null && (
                                                    <div className='profile_preview position-relative image-input image-input-outline'>
                                                        <img src={logoImagePreview} alt="image preview" className='image-input-wrapper w-100px h-100px' height={100} width={150} />
                                                        <div onClick={removeLogo} className="p-1 fa fa-remove text-danger" style={{fontSize:"30px" , cursor:"pointer"}}>
											            
														</div>
                                                    </div>
                                                )} */}

												{logoImagePreview != null ? <div className="file-preview box sm">
													{logoImagePreview != null && (
														<div className='profile_preview position-relative image-input image-input-outline'>
															<img src={logoImagePreview} alt="image preview" className='image-input-wrapper w-100px h-100px' height={100} width={150} />
															<div onClick={removeLogo} className="p-1 fa fa-remove text-danger" style={{fontSize:"30px" , cursor:"pointer"}}>
															
															</div>
														</div>
													)}
												</div> : serviceEdit.images == null ? <img src={logo} className="" height={100} width={150} alt='' />  :
													<div className='profile_preview position-relative image-input image-input-outline'>
														<img src={process.env.REACT_APP_API_BASE_URL + 'uploads/service/images/' + serviceEdit.id + '/' + serviceEdit.images} className="image-input-wrapper w-100px h-100px shadow" height={100} width={150} alt='' />
													</div> 
												}
                                                </div>
                                            </div>
                                            {/* <div className="form-group mb-4">
                                                <label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold m-2">Rtl</label>
                                                <div className="input-group">
                                                    <input type="text" className="form-control" placeholder="Rtl" {...formik.getFieldProps('rtl')} />
                                                </div>
                                                {formik.touched.rtl && formik.errors.rtl && (
                                                    <div className='fv-plugins-message-container'>
                                                        <div className='fv-help-block'>
                                                            <span role='alert' className='text-danger'>{formik.errors.rtl}</span>
                                                        </div>
                                                    </div>
                                                )}
                                            </div>
                                            <div className="form-group mb-4">
                                                <label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold m-2">Status</label>
                                                <div className="input-group">
                                                    <input type="text" className="form-control" placeholder="Status" {...formik.getFieldProps('status')} />
                                                </div>
                                                {formik.touched.status && formik.errors.status && (
                                                    <div className='fv-plugins-message-container'>
                                                        <div className='fv-help-block'>
                                                            <span role='alert' className='text-danger'>{formik.errors.status}</span>
                                                        </div>
                                                    </div>
                                                )}
                                            </div> */}

                                                            {/* <FormGroup>
                                                    <Label
                                                        htmlFor="recipient-name"
                                                        className="col-form-label"
                                                    >
                                                        Languages Name :
                                                    </Label>
                                                    <Input type="text" className="form-control" />
                                                </FormGroup> */}

                                                {/* <FormGroup>
                                                    <Label
                                                        htmlFor="message-text"
                                                        className="col-form-label"
                                                    >
                                                        Category Image :
                                                    </Label>
                                                    <Input
                                                        className="form-control"
                                                        id="validationCustom02"
                                                        type="file"
                                                    />
                                                </FormGroup> */}

                                                <div className='card-footer py-5 text-center' id='kt_task_footer'>
                                                    <button
                                                        type='submit'
                                                        id='submit_button'
                                                        className='btn btn-primary text-white mx-2'
                                                        disabled={formik.isSubmitting}
                                                        style={{backgroundColor:'#ffbe57'}}
                                                        // onClick={()=>{toComponentB()}}
                                                        // onClick={() => alert()}
                                                    >
                                                        {!loading && <span className='indicator-label'>Submit
                                                        </span>}
                                                        {loading && (
                                                            <span className='indicator-progress' style={{ display: 'block' }}>
                                                                Please wait...{' '}
                                                                <span className='spinner-border spinner-border-sm align-middle ms-2'></span>
                                                            </span>
                                                        )}
                                                    </button>

                                                    <div className='btn btn-danger text-white' onClick={clearForm}> Cancel</div>
                                                </div>
                                            </Form>
										</ModalBody>
									</Modal>
									
									{/* Delete Modal */}
									<div isOpen={deleteOpen} toggle={oncloseDeleteModal}>
										<div className='modal fade p-6' id={'delete_confirm_popup452222' + selectedId} aria-hidden='true'>
											<div className='modal-dialog modal-dialog-centered'>
												<div className='modal-content'>
													<div className='modal-header'>
														<h3 className="text-dark">Confirmation</h3>
														<div className='btn btn-sm btn-icon btn-active-color-primary' data-bs-dismiss='modal'>
														</div>
													</div>
													<div className='modal-body'>
														<div className='text-center'>
															<h4>Are you sure want to Delete ? </h4>
															<p className='text-danger'>{serviceEdit.name}</p>
														</div>
														<div className='d-flex align-items-center justify-content-center'>
															<button className='btn btn-sm btn-outline-danger mx-4 mt-3' data-bs-dismiss='modal' onClick={(e) => onDelete(selectedId)}>
																Yes
															</button>
															<button className='btn btn-sm btn-outline-secondary mt-3 me-3' data-bs-dismiss='modal' onClick={clearForm}>
																No
															</button>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div className="clearfix"></div>
								<div id="basicScenario" className="product-physical">
									{/* <Datatable
										myData={allBrands}
										columns={columns}
										// multiSelectOption={false}
										// pageSize={10}
										// pagination={true}
										// class="-striped -highlight"
									/> */}
			                    <Fragment>
									<DataTable 
										// myData={allBrands}
										data={allServices}
										columns={columns}
										multiSelectOption={true}
										pageSize={10}
										pagination={true}
										class="-striped -highlight"
										className="text-center"
									/>
								</Fragment>
								</div>
							</CardBody>
						</Card>
					</Col>
				</Row>
			</Container>

			<div aria-atomic="true" aria-live="assertive" className="toast text-white position-fixed end-0 bottom-0 m-3" id="myToastAdd" style={{backgroundColor: "#027a02"}}>
				<div className="toast-header">
					<strong className="me-auto">Success</strong>
					<button aria-label="Close" className="btn-close"
						data-bs-dismiss="toast" type="button">
					</button>
				</div>
				<div className="toast-body">
					Service Saved Successfully!
				</div>
			</div>
			<div aria-atomic="true" aria-live="assertive" className="toast text-white position-fixed end-0 bottom-0 m-3" id="myToastUpdate" style={{backgroundColor: "#f7572a"}}>
				<div className="toast-header">
					<strong className="me-auto">Success</strong>
					<button aria-label="Close" className="btn-close"
						data-bs-dismiss="toast" type="button">
					</button>
				</div>
				<div className="toast-body">
					Service Updated Successfully!
				</div>
			</div>
			<div aria-atomic="true" aria-live="assertive" className="toast text-white position-fixed end-0 bottom-0 m-3" id="myToastDelete" style={{backgroundColor: "#d1061b"}}>
				<div className="toast-header">
					<strong className="me-auto">Success</strong>
					<button aria-label="Close" className="btn-close"
						data-bs-dismiss="toast" type="button">
					</button>
				</div>
				<div className="toast-body">
					Service Deleted Successfully!
				</div>
			</div>
		</Fragment>
	);
};

export default ServicePage;
