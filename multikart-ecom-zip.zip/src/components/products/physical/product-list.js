import React, { FC, useState, useEffect, useRef, Fragment } from "react";
import Breadcrumb from "../../common/breadcrumb";
import data from "../../../assets/data/physical_list";
import { Edit, Trash2 } from "react-feather";
import { Offcanvas, Toast } from 'bootstrap';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import { Link, useNavigate } from 'react-router-dom';
import { ToastContainer, toast } from 'react-toastify';
import {
    Button,
    Card,
    CardBody,
    CardHeader,
    Col,
    Container,
    Form,
    FormGroup,
    Input,
    Label,
    Modal,
    ModalBody,
    ModalFooter,
    ModalHeader,
    Row,
} from "reactstrap";
import { getProducts, saveProduct, getProductEdit, updateProduct, deleteProduct, getCategories, getBrands } from "../core/_requests";
import logo from "../../../assets/icons/no_image.jpg";

const initialValues = {
    "id": '',
    "name": "",
    "added_by": "admin",
    "user_id": "",
    "category_id": "",
    "brand_id": "",
    "photos": "",
    "thumbnail_img": "",
    "video_provider": "",
    "video_link": "",
    "tags": "",
    "description": "",
    "unit_price": "",
    "purchase_price": "",
    "variant_product": "",
    "attributes": "",
    "choice_options": "",
    "colors": "",
    "variations": "",
    "todays_deal": "",
    "published": "",
    "approved": "",
    "stock_visibility_state": "",
    "cash_on_delivery": "",
    "featured": "",
    "seller_featured": "",
    "current_stock": "",
    "unit": "",
    "weight": "",
    "min_qty": "",
    "low_stock_quantity": "",
    "discount": "",
    "discount_type": "",
    "discount_start_date": "",
    "discount_end_date": "",
    "tax": "",
    "tax_type": "",
    "shipping_type": "",
    "shipping_cost": "",
    "is_quantity_multiplied": "",
    "est_shipping_days": "",
    "num_of_sale": "",
    "meta_title": "",
    "meta_description": "",
    "meta_img": "",
    "pdf": "",
    "slug": "",
    "rating": "",
    "barcode": "",
    "digital": "0",
    "auction_product": "",
    "file_name": "",
    "file_path": "",
    "external_link": "",
    "external_link_btn": "",
    "wholesale_product": "",
}


const Product_list = () => {

    const productSchema = Yup.object().shape({
        // name: Yup.string().required('* Product Name is required'),
        // category_id: Yup.string().required('* Category Name is required'),
        // brand_id: Yup.string().required('* Brand Name is required'),
        // unit: Yup.string().required('* Unit is required'),
        // weight: Yup.string().required('* Weight is required'),
        // min_qty: Yup.string().required('* Minimun Quantity is required'),
        // unit_price: Yup.string().required('* Unit Price is required'),
    })

    const [open, setOpen] = useState(false);
    const [allProducts, setAllProducts] = useState([]);
    const [productEdit, setProductEdit] = useState([]);
    const [allCategories, setAllCategories] = useState([]);
    const [allBrands, setAllBrands] = useState([]);
    const [isLoading, setIsLoading] = useState(false);
    const [loading, setLoading] = useState(false);
    const [dataBinded, setDataBinded] = useState(false);
    const [selectedId, setSelectedId] = useState('');


    const [logoImagePreview, setlogoImagePreview] = useState(null);
    const [thumbImagePreview, setThumbImagePreview] = useState(null);
    const viewLogo = useRef(null);
    const viewThumbImage = useRef(null);
    const [photoImage, setPhotoImage] = useState(null);
    const [thumbImage, setThumbImage] = useState(null);


    const ProductList = async () => {
        const ProductResponse = await getProducts()
        console.log('all products');
        console.log(ProductResponse.Data);
        setAllProducts(ProductResponse.Data);
    }

    const CategoriesList = async () => {
        const categoryResponse = await getCategories()
        console.log('categories list');
        console.log(categoryResponse.Data);
        setAllCategories(categoryResponse.Data);
    }

    const BrandList = async () => {
        const brandResponse = await getBrands()
        console.log('brand list');
        console.log(brandResponse.Data);
        setAllBrands(brandResponse.Data);
    }

    const formik = useFormik({
        initialValues,
        validationSchema: productSchema,
        onSubmit: async (values, { setStatus, setSubmitting, resetForm }) => {
            setLoading(true)
            try {

                var formData = new FormData();

                // const body = {
                //     "name": values.name,
                //     "logo": values.logo,
                //     "top": values.top,
                //     "slug": values.slug,
                //     "meta_title": values.meta_title,
                //     "meta_description": values.meta_description,
                // }

                formData.append('id', values.id);
                formData.append('name', values.name);
                formData.append('added_by', values.added_by);
                formData.append('user_id', values.user_id);
                formData.append('category_id', values.category_id);
                formData.append('brand_id', values.brand_id);
                formData.append('photos', photoImage);
                formData.append('thumbnail_img', thumbImage);
                formData.append('video_provider', values.video_provider);
                formData.append('video_link', values.video_link);
                formData.append('tags ', values.tags);
                formData.append('description', values.description);
                formData.append('unit_price', values.unit_price);
                formData.append('purchase_price', values.purchase_price);
                formData.append('variant_product', values.variant_product);
                formData.append('attributes', values.attributes);
                formData.append('choice_options', values.choice_options);
                formData.append('colors', values.colors);
                formData.append('variations', values.variations);
                formData.append('todays_deal', values.todays_deal || "0");
                formData.append('published', values.published || "0");
                formData.append('approved', values.approved || "0");
                formData.append('stock_visibility_state', values.stock_visibility_state || "0");
                formData.append('cash_on_delivery', values.cash_on_delivery || "0");
                formData.append('featured', values.featured || "0");
                formData.append('seller_featured', values.seller_featured || "0");
                formData.append('current_stock', values.current_stock || "0");
                formData.append('unit', values.unit);
                formData.append('weight', values.weight);
                formData.append('min_qty', values.min_qty);
                formData.append('low_stock_quantity', values.low_stock_quantity);
                formData.append('discount', values.discount);
                formData.append('discount_type', values.discount_type);
                formData.append('discount_start_date', values.discount_start_date);
                formData.append('discount_end_date', values.discount_end_date);
                formData.append('tax', values.tax);
                formData.append('tax_type', values.tax_type);
                formData.append('shipping_type', values.shipping_type || "flat_rate");
                formData.append('shipping_cost', values.shipping_cost || "0");
                formData.append('is_quantity_multiplied', values.is_quantity_multiplied || "0");
                formData.append('est_shipping_days', values.est_shipping_days);
                formData.append('num_of_sale', values.num_of_sale || "0");
                formData.append('meta_title', values.meta_title);
                formData.append('meta_description', values.meta_description);
                formData.append('meta_img', values.meta_img || "0");
                formData.append('pdf', values.pdf || "0");
                formData.append('slug', values.slug || "0");
                formData.append('rating', values.rating || "0");
                formData.append('barcode', values.barcode);
                formData.append('digital', values.digital || "0");
                formData.append('auction_product', values.auction_product || "0");
                formData.append('file_name', values.file_name);
                formData.append('file_path', values.file_path);
                formData.append('external_link', values.external_link);
                formData.append('external_link_btn', values.external_link_btn || "buy_now");
                formData.append('wholesale_product', values.wholesale_product || "0");


                const headers = {
                    headers: {
                        "Content-type": "multipart/form-data",
                    },
                }

                console.log('lead form body');
                console.log(formData);
                if (!dataBinded) {
                    const saveProductData = await saveProduct(formData, headers);

                    if (saveProductData != null) {
                        setLoading(false);
                        document.getElementById('kt_team_close')?.click();
                        // var toastEl = document.getElementById('myToastAdd');
                        // const bsToast = new Toast(toastEl);
                        // bsToast.show();
                        resetForm();
                        clearForm();
                        ProductList();

                        toast(' Product Saved Sucessfully!', {
                            position: "bottom-right",
                            autoClose: 3000,
                            hideProgressBar: false,
                            closeOnClick: true,
                            pauseOnHover: true,
                            draggable: true,
                            progress: undefined,
                            // theme: "dark",
                            className: "text-white",
                            style: { backgroundColor: "#027a02" },
                        });
                    }
                } else {
                    const updateProductData = await updateProduct(selectedId, formData);

                    if (updateProductData != null) {
                        setLoading(false);
                        resetForm();
                        setDataBinded(false);
                        clearForm();
                        ProductList();
                        // var toastEl = document.getElementById('myToastUpdate');
                        // const bsToast = new Toast(toastEl);
                        // bsToast.show();
                        toast(' Product Updated Sucessfully!', {
                            position: "bottom-right",
                            autoClose: 3000,
                            hideProgressBar: false,
                            closeOnClick: true,
                            pauseOnHover: true,
                            draggable: true,
                            progress: undefined,
                            // theme: "dark",
                            className: "text-white",
                            style: { backgroundColor: "#f7572a" },
                        });
                    }
                }
                ProductList();
            } catch (error) {
                console.error(error)
                setStatus('The registration details is incorrect')
                setSubmitting(false)
                setLoading(false)
            }
        }
    })

    const editProduct = async (id) => {
        setSelectedId(id);
        const ProductResponse = await getProductEdit(id)
        setProductEdit(ProductResponse.Data);
        setDataBinded(true);
        formik.setFieldValue('name', ProductResponse.Data.name);
        formik.setFieldValue('user_id', ProductResponse.Data.user_id);
        formik.setFieldValue('category_id', ProductResponse.Data.category_id);
        formik.setFieldValue('brand_id', ProductResponse.Data.brand_id);
        formik.setFieldValue('unit', ProductResponse.Data.unit);
        formik.setFieldValue('min_qty', ProductResponse.Data.min_qty);
        formik.setFieldValue('unit_price', ProductResponse.Data.unit_price);
        formik.setFieldValue('photos', ProductResponse.Data.photos);
        formik.setFieldValue('thumbnail_img', ProductResponse.Data.thumbnail_img);
        // navigate('/products/addProducts',{state:{id:id, name:'check'}});
        onOpenModal();
    }

    const onDelete = async (id) => {
        setIsLoading(false);
        console.log(id);
        await deleteProduct(id);
        setIsLoading(false);
        ProductList();
        // var toastEl = document.getElementById('myToastDelete');
        // const bsToast = new Toast(toastEl);
        // bsToast.show();
        toast(' Product Deleted Sucessfully!', {
            position: "bottom-right",
            autoClose: 3000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
            // theme: "dark",
            className: "text-white",
            style: { backgroundColor: "#d1061b" },
        });
    }

    const clearForm = () => {
        formik.resetForm();
        removeLogo();
        removeThumbImage();
        setDataBinded(false);
        setOpen(false);
    }

    const onOpenModal = () => {
        setOpen(true);
    };

    const onCloseModal = () => {
        setOpen(false);
    };

    const handleLogoPreview = (e) => {
        let image_as_base64 = URL.createObjectURL(e.target.files[0])
        let image_as_files = e.target.files[0];

        let fields = viewLogo.current?.value.split(".");

        let fileType = fields[fields.length - 1];

        if (fileType == 'jpg' || fileType == 'jpeg' || fileType == 'pdf' || fileType == 'png') {
            setlogoImagePreview(image_as_base64);
            setPhotoImage(image_as_files);
        } else {
            setlogoImagePreview(null);
            setPhotoImage(null);
            if (viewLogo.current != null) {
                viewLogo.current.value = "";
            }
        }
        console.log(viewLogo.current?.value);
        console.log(image_as_files);
        console.log(fileType);
    }

    const handleLogoPreview2 = (e) => {
        let image_as_base64 = URL.createObjectURL(e.target.files[0])
        let image_as_files = e.target.files[0];

        let fields = viewThumbImage.current?.value.split(".");

        let fileType = fields[fields.length - 1];

        if (fileType == 'jpg' || fileType == 'jpeg' || fileType == 'pdf' || fileType == 'png') {
            setThumbImagePreview(image_as_base64);
            setThumbImage(image_as_files);
        } else {
            setThumbImagePreview(null);
            setThumbImage(null);
            if (viewThumbImage.current != null) {
                viewThumbImage.current.value = "";
            }
        }
        console.log(viewThumbImage.current?.value);
        console.log(image_as_files);
        console.log(fileType);
    }
    const removeLogo = () => {
        console.log(viewLogo.current?.value);
        if (viewLogo.current != null) {
            setlogoImagePreview(null);
            setPhotoImage(null);
            viewLogo.current.value = "";
        }
    }

    const removeThumbImage = () => {
        console.log(viewThumbImage.current?.value);
        if (viewThumbImage.current != null) {
            setThumbImagePreview(null);
            setThumbImage(null);
            viewThumbImage.current.value = "";
        }
    }

    useEffect(() => {
        ProductList();
        CategoriesList();
        BrandList();
    }, []);

    return (
        <Fragment>
            <ToastContainer />
            <Breadcrumb title="Product List" parent="Physical" />
            <Container fluid={true}>
                <Row className="products-admin ratio_asos">
                    <div>
                        <CardHeader className="mb-4">
                            <div className='row align-items-center'>
                                <div className='col-auto'>
                                    {/* <h5> Add Product</h5> */}
                                </div>
                                <div className='d-flex justify-content-end col' data-kt-user-table-toolbar='base'>
                                    <Link to='/products/physical/add-product' className="btn btn-primary">
                                        Add Product
                                    </Link>
                                </div>
                            </div>
                        </CardHeader>
                    </div>
                    <Modal isOpen={open} toggle={onCloseModal} className='modal-lg'>
                        <ModalHeader toggle={onCloseModal}>
                            <h5
                                className="modal-title f-w-600"
                                id="exampleModalLabel2"
                            >
                                Product Update
                            </h5>
                        </ModalHeader>
                        <ModalBody>
                            <Form noValidate onSubmit={formik.handleSubmit}>
                                <div className="row">
                                    <div className="form-group mb-4 col-lg-6">
                                        <label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold m-2">Name</label>
                                        <div className="input-group">
                                            <input type="text" className="form-control" placeholder="Name" {...formik.getFieldProps('name')} />
                                        </div>
                                        {formik.touched.name && formik.errors.name && (
                                            <div className='fv-plugins-message-container'>
                                                <div className='fv-help-block'>
                                                    <span role='alert' className='text-danger'>{formik.errors.name}</span>
                                                </div>
                                            </div>
                                        )}
                                    </div>
                                    <div className="form-group mb-4 col-lg-6">
                                        <label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold">Category</label>
                                        <select className="form-control mt-2 form-select" {...formik.getFieldProps('category_id')} name="category_id" id="category_id"
                                            data-selected="" data-live-search="true" required>
                                            <option>-- Category Select -- </option>
                                            {allCategories.map((categoriesValues, i) => {
                                                return (
                                                    <option selected={i == 0 ? true : false} value={categoriesValues.id} key={i}>{categoriesValues.name}</option>
                                                )
                                            })}
                                        </select>
                                        {formik.touched.category_id && formik.errors.category_id && (
                                            <div className='fv-plugins-message-container'>
                                                <div className='fv-help-block'>
                                                    <span role='alert' className='text-danger mx-2'>{formik.errors.category_id}</span>
                                                </div>
                                            </div>
                                        )}
                                    </div>
                                </div>
                                <div className="row">
                                    <div className="form-group mb-4 col-lg-6">
                                        <label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold">Brand</label>
                                        <select className="form-control mt-2 form-select" {...formik.getFieldProps('brandid')} name="brand_id" id="brand_id"
                                            data-selected="" data-live-search="true" required>
                                            <option>-- Brands Select -- </option>
                                            {allBrands.map((brandValues, i) => {
                                                return (
                                                    <option selected={i == 0 ? true : false} value={brandValues.id} key={i}>{brandValues.name}</option>
                                                )
                                            })}
                                        </select>
                                        {formik.touched.brand_id && formik.errors.brand_id && (
                                            <div className='fv-plugins-message-container'>
                                                <div className='fv-help-block'>
                                                    <span role='alert' className='text-danger mx-2'>{formik.errors.brand_id}</span>
                                                </div>
                                            </div>
                                        )}
                                    </div>
                                    <div className="form-group mb-4 col-lg-6">
                                        <label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold">Unit</label>
                                        <div className="input-group">
                                            <input type="number" className="form-control" placeholder="Unit" {...formik.getFieldProps('unit')} />
                                        </div>
                                        {formik.touched.unit && formik.errors.unit && (
                                            <div className='fv-plugins-message-container'>
                                                <div className='fv-help-block'>
                                                    <span role='alert' className='text-danger'>{formik.errors.unit}</span>
                                                </div>
                                            </div>
                                        )}
                                    </div>
                                </div>
                                <div className="row">
                                    <div className="form-group mb-4 col-lg-6">
                                        <label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold">Minimum Purchase Qty</label>
                                        <div className="input-group">
                                            <input type="number" className="form-control" placeholder="Min Qty" {...formik.getFieldProps('min_qty')} />
                                        </div>
                                        {formik.touched.min_qty && formik.errors.min_qty && (
                                            <div className='fv-plugins-message-container'>
                                                <div className='fv-help-block'>
                                                    <span role='alert' className='text-danger'>{formik.errors.min_qty}</span>
                                                </div>
                                            </div>
                                        )}
                                    </div>
                                    <div className="form-group mb-4 col-lg-6">
                                        <label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold">Unit Price</label>
                                        <div className="input-group">
                                            <input type="number" className="form-control" placeholder="Unit Price" {...formik.getFieldProps('unit_price')} />
                                        </div>
                                        {formik.touched.unit_price && formik.errors.unit_price && (
                                            <div className='fv-plugins-message-container'>
                                                <div className='fv-help-block'>
                                                    <span role='alert' className='text-danger'>{formik.errors.unit_price}</span>
                                                </div>
                                            </div>
                                        )}
                                    </div>
                                </div>
                                <div className="row">
                                <div className="form-group mb-3 col-lg-6">
                                        <label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold">Gallery Img</label>
                                        <div className="col-xl-12 col-sm-7">
                                            {/* <Input
                                            type="file" className='form-control' name="photos" ref={viewLogo} onChange={handleLogoPreview}
                                            required
                                        /> */}
                                            <div className="input-group" data-toggle="aizuploader" data-type="image" data-multiple="true">
                                                <input type="file" className='form-control' ref={viewLogo} onChange={handleLogoPreview} />
                                            </div>

                                        </div>
                                        <div className="valid-feedback">Looks good!</div>
                                        <div className="file-preview box sm d-flex justify-content-center align-items-center mt-4 mx-4">
                                            {/* {logoImagePreview != null && (
                                                <div className='profile_preview position-relative image-input image-input-outline'>
                                                    <img src={logoImagePreview} alt="image preview" className='image-input-wrapper w-100px h-100px' height={100} width={100} />
                                                    <div onClick={removeLogo} className="p-1 fa fa-remove cursor-pointer" style={{fontSize:"26px"}}>
													</div>
                                                </div>
                                            )} */}

                                            {logoImagePreview != null ? <div className="">
                                                {logoImagePreview != null && (
                                                    <div className='profile_preview position-relative image-input image-input-outline'>
                                                        <img src={logoImagePreview} alt="image preview" className='image-input-wrapper w-100px h-100px' height={100} width={150} />
                                                        <div onClick={removeLogo} className="p-1 fa fa-remove text-danger" style={{ fontSize: "30px", cursor: "pointer" }}>
                                                        </div>
                                                    </div>
                                                )}
                                            </div> : productEdit.photos == null ? <img src={logo} className="" height={100} width={150} alt='' /> :
                                                <div className='profile_preview position-relative image-input image-input-outline'>
                                                    <img src={process.env.REACT_APP_API_BASE_URL + 'uploads/products/photos/' + productEdit.id + '/' + productEdit.photos} className='image-input-wrapper w-100px h-100px' height={100} width={150} alt='' />
                                                </div>
                                            }
                                        </div>
                                    </div>

                                    <div className="form-group mb-3 col-lg-6">
                                        <label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold">Thumbnail Img</label>
                                        <div className="col-xl-12 col-sm-7">
                                            {/* <Input
                                            type="file" className='form-control' name="thumbnail_img" ref={viewThumbImage} onChange={handleLogoPreview2} 
                                            required
                                        /> */}
                                            <div className="input-group" data-toggle="aizuploader" data-type="image" data-multiple="true">
                                                <input type="file" className='form-control' ref={viewThumbImage} onChange={handleLogoPreview2} />
                                            </div>
                                            <div className="file-preview box sm d-flex justify-content-center align-items-center mt-4 mx-4">
                                                {/* {thumbImagePreview != null && (
                                                <div className='profile_preview position-relative image-input image-input-outline'>
                                                    <img src={thumbImagePreview} alt="image preview" className='image-input-wrapper w-100px h-100px' height={100} width={100} />
                                                    <div onClick={removeThumbImage} className="p-1 cursor-pointer">
                                                    </div>
                                                </div>
                                            )} */}

                                                {thumbImagePreview != null ? <div className="">
                                                    {thumbImagePreview != null && (
                                                        <div className='profile_preview position-relative image-input image-input-outline'>
                                                            <img src={thumbImagePreview} alt="image preview" className='image-input-wrapper w-100px h-100px' height={100} width={150} />
                                                            <div onClick={removeThumbImage} className="p-1 fa fa-remove text-danger" style={{ fontSize: "30px", cursor: "pointer" }}>
                                                            </div>
                                                        </div>
                                                    )}
                                                </div> : productEdit.thumbnail_img == null ? <img src={logo} className="" height={100} width={150} alt='' /> :
                                                    <div className='profile_preview position-relative image-input image-input-outline'>
                                                        <img src={process.env.REACT_APP_API_BASE_URL + 'uploads/products/thumbnail_img/' + productEdit.id + '/' + productEdit.thumbnail_img} className='image-input-wrapper w-100px h-100px' height={100} width={150} alt='' />
                                                    </div>
                                                }
                                            </div>
                                        </div>
                                        <div className="valid-feedback">Looks good!</div>
                                    </div>
                                </div>
                                {/* <div className="form-group mb-4">
                                        <label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold m-2">Rtl</label>
                                        <div className="input-group">
                                            <input type="text" className="form-control" placeholder="Rtl" {...formik.getFieldProps('rtl')} />
                                        </div>
                                        {formik.touched.rtl && formik.errors.rtl && (
                                            <div className='fv-plugins-message-container'>
                                                <div className='fv-help-block'>
                                                    <span role='alert' className='text-danger'>{formik.errors.rtl}</span>
                                                </div>
                                            </div>
                                        )}
                                    </div>
                                    <div className="form-group mb-4">
                                        <label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold m-2">Status</label>
                                        <div className="input-group">
                                            <input type="text" className="form-control" placeholder="Status" {...formik.getFieldProps('status')} />
                                        </div>
                                        {formik.touched.status && formik.errors.status && (
                                            <div className='fv-plugins-message-container'>
                                                <div className='fv-help-block'>
                                                    <span role='alert' className='text-danger'>{formik.errors.status}</span>
                                                </div>
                                            </div>
                                        )}
                                    </div> */}

                                {/* <FormGroup>
                                        <Label
                                            htmlFor="recipient-name"
                                            className="col-form-label"
                                        >
                                            Languages Name :
                                        </Label>
                                        <Input type="text" className="form-control" />
                                    </FormGroup> */}

                                {/* <FormGroup>
                                        <Label
                                            htmlFor="message-text"
                                            className="col-form-label"
                                        >
                                            Category Image :
                                        </Label>
                                        <Input
                                            className="form-control"
                                            id="validationCustom02"
                                            type="file"
                                        />
                                    </FormGroup> */}

                                <div className='card-footer py-5 text-center' id='kt_task_footer'>
                                    <button
                                        type='submit'
                                        id='submit_button'
                                        className='btn btn-primary text-white mx-2'
                                        disabled={formik.isSubmitting}
                                        style={{ backgroundColor: '#ffbe57' }}
                                    // onClick={()=>{toComponentB()}}
                                    // onClick={() => alert()}
                                    >
                                        {!loading && <span className='indicator-label'>Update
                                        </span>}
                                        {loading && (
                                            <span className='indicator-progress' style={{ display: 'block' }}>
                                                Please wait...{' '}
                                                <span className='spinner-border spinner-border-sm align-middle ms-2'></span>
                                            </span>
                                        )}
                                    </button>

                                    <div className='btn btn-danger text-white' onClick={clearForm}> Cancel</div>
                                </div>

                            </Form>
                        </ModalBody>
                        <ModalFooter>
                            {/* <Button
                                type="button"
                                color="primary"
                                onClick={() => onCloseModal("VaryingMdo")}
                            >
                                Save
                            </Button>
                            <Button
                                type="button"
                                color="secondary"
                                onClick={() => onCloseModal("VaryingMdo")}
                            >
                                Close
                            </Button> */}
                        </ModalFooter>
                    </Modal>
                    {allProducts.map((myData, i) => {
                        return (
                            <Col xl="3" sm="6" key={i}>
                                <Card>
                                    <div className="products-admin">
                                        <CardBody className="product-box">
                                            <div className="img-wrapper">
                                                <div className="lable-block">
                                                    {myData.tag === "new" ? (
                                                        <span className="lable3">{myData.tag}</span>
                                                    ) : (
                                                        ""
                                                    )}
                                                    {myData.discount === "on sale" ? (
                                                        <span className="lable4">{myData.discount}</span>
                                                    ) : (
                                                        ""
                                                    )}
                                                </div>
                                                <div className="front">
                                                    <a href="/#" className="bg-size">
                                                        {/* <img
															alt=""
															className="img-fluid blur-up bg-img lazyloaded"
															src={myData.photos}
														/> */}
                                                        {/* <img src={process.env.REACT_APP_API_BASE_URL + 'uploads/products/photos/' + myData.id + '/' + myData.photos} className=" img-fluid blur-up bg-img lazyloaded" alt='' /> */}
                                                        {myData.photos !== null ?
                                                            <div className="file-preview box sm">
                                                                <img src={process.env.REACT_APP_API_BASE_URL + 'uploads/products/photos/' + myData.id + '/' + myData.photos} className="img-fluid blur-up bg-img lazyloaded h-auto d-inline-block" alt='' />
                                                            </div>
                                                            :
                                                            <img src={logo} className="img-fluid blur-up bg-img lazyloaded" />
                                                        }
                                                    </a>
                                                    <div className="product-hover">
                                                        <ul>
                                                            <li>
                                                                <Button color="btn" type="button" onClick={(e) => editProduct(myData.id)}>
                                                                    <Edit className="editBtn" />
                                                                </Button>
                                                            </li>
                                                            <li>
                                                                <Button color="btn" type="button" data-bs-toggle='modal' data-bs-target={'#delete_confirm_popup452222' + myData.id} >
                                                                    <Trash2 className="deleteBtn" />
                                                                </Button>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>
                                                <div className='modal fade p-6' id={'delete_confirm_popup452222' + myData.id} aria-hidden='true'>
                                                    <div className='modal-dialog modal-dialog-centered'>
                                                        <div className='modal-content'>
                                                            <div className='modal-header'>
                                                                <h3>Confirmation</h3>
                                                                <div className='btn btn-sm btn-icon btn-active-color-primary' data-bs-dismiss='modal'>
                                                                </div>
                                                            </div>
                                                            <div className='modal-body py-lg-10 px-lg-10'>
                                                                <div className='text-center'>
                                                                    <h4>Are you sure want to Delete ? </h4>
                                                                    <p className='text-danger'>{myData.name}</p>
                                                                </div>
                                                                <div className='d-flex align-items-center justify-content-center'>
                                                                    <button className='btn btn-sm btn-outline-danger mx-4 mt-3' data-bs-dismiss='modal' onClick={(e) => onDelete(myData.id)}>
                                                                        Yes
                                                                    </button>
                                                                    <button className='btn btn-sm btn-outline-secondary mt-3 me-3' data-bs-dismiss='modal' onClick={clearForm}>
                                                                        No
                                                                    </button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="product-detail">
                                                <div className="rating">
                                                    <i className="fa fa-star"></i>
                                                    <i className="fa fa-star"></i>
                                                    <i className="fa fa-star"></i>
                                                    <i className="fa fa-star"></i>
                                                    <i className="fa fa-star"></i>
                                                </div>
                                                <a href="/#">
                                                    {" "}
                                                    <h6>{myData.name}</h6>
                                                </a>
                                                <h4>
                                                    {myData.unit_price} <del>{myData.unit_price}</del>
                                                </h4>
                                                <ul className="color-variant">
                                                    <li className="bg-light0"></li>
                                                    <li className="bg-light1"></li>
                                                    <li className="bg-light2"></li>
                                                </ul>
                                            </div>
                                        </CardBody>
                                    </div>
                                </Card>
                            </Col>
                        );
                    })}
                </Row>
            </Container>
            <div aria-atomic="true" aria-live="assertive" className="toast text-white position-fixed end-0 bottom-0 m-3" id="myToastAdd" style={{ backgroundColor: "#027a02" }}>
                <div className="toast-header">
                    <strong className="me-auto">Success</strong>
                    <button aria-label="Close" className="btn-close"
                        data-bs-dismiss="toast" type="button">
                    </button>
                </div>
                <div className="toast-body">
                    Product Saved Successfully!
                </div>
            </div>
            <div aria-atomic="true" aria-live="assertive" className="toast text-white position-fixed end-0 bottom-0 m-3" id="myToastUpdate" style={{ backgroundColor: "#f7572a" }}>
                <div className="toast-header">
                    <strong className="me-auto">Success</strong>
                    <button aria-label="Close" className="btn-close"
                        data-bs-dismiss="toast" type="button">
                    </button>
                </div>
                <div className="toast-body">
                    Product Updated Successfully!
                </div>
            </div>
            <div aria-atomic="true" aria-live="assertive" className="toast text-white position-fixed end-0 bottom-0 m-3" id="myToastDelete" style={{ backgroundColor: "#d1061b" }}>
                <div className="toast-header">
                    <strong className="me-auto">Success</strong>
                    <button aria-label="Close" className="btn-close"
                        data-bs-dismiss="toast" type="button">
                    </button>
                </div>
                <div className="toast-body">
                    Product Deleted Successfully!
                </div>
            </div>
        </Fragment>
    );
};

export default Product_list;
