import React, { Fragment, useState,useRef, useEffect } from "react";
import Breadcrumb from "../../common/breadcrumb";
import "react-toastify/dist/ReactToastify.css";
import { data } from "../../../assets/data/category";
import { useFormik } from 'formik';
import DataTable from "react-data-table-component";
import { Link, useNavigate } from 'react-router-dom';
// import Datatable from "../../common/datatable";
import { Offcanvas, Toast } from 'bootstrap';
import * as Yup from 'yup';
import { getBrands, saveBrand, getBrandEdit, updateBrand, deleteBrand } from '../brands/core/_requests';
import one from "../../../assets/images/pro3/1.jpg";
import { ToastContainer, toast } from 'react-toastify';
// import logo from "../../../assets/icons/vts-sidebar-logo.png";
import logo from "../../../assets/icons/no_image.jpg";


import {
	Button,
	Card,
	CardBody,
	CardHeader,
	Col,
	Container,
	Form,
	FormGroup,
	Input,
	Label,
	Modal,
	ModalBody,
	ModalFooter,
	ModalHeader,
	Row,
} from "reactstrap";

const initialValues = {
    "name": "",
    "logo": "",
    "top": "",
    "slug": "",
    "meta_title": "",
    "meta_description": "",
}

const BrandPage = () => {

    const brandSchema = Yup.object().shape({
        name: Yup.string()
			.min(3, 'Minimum 3 characters')
            .max(50, 'Maximum 50 characters')
			.required('* Name is required'),
    })
	const [open, setOpen] = useState(false);
	const [editOpen, setEditOpen] = useState(false);
	const [deleteOpen, setDeleteOpen] = useState(false);
    const [allBrands, setAllBrands] = useState([]);
    const [brandEdit, setBrandEdit] = useState([]);
    const [logoImagePreview, setlogoImagePreview] = useState(null);
    const [selectedId, setSelectedId] = useState('');
    const [dataBinded, setDataBinded] = useState(false);
    const viewLogo = useRef(null);
    const [logoImage, setLogoImage] = useState(null);
    const [loading, setLoading] = useState(false);
    const [editClicked, setEditClicked] = useState(false);
    const [editId, setEditId] = useState('');
    const [isLoading, setIsLoading] = useState(false);

	// const brandList = async () => {
    //     const BrandResponse = await getBrands()
    //     setAllBrands(BrandResponse.Data);
    // }

    const brandList = async () => {
        const BrandResponse = await getBrands()
        // setAllBrands(BrandResponse.Data);
		let new_array = [];
		for(let i=0; i<BrandResponse.Data.length;i++) {
			let cur_obj = {
				...BrandResponse.Data[i],
				'sl_no': i + 1 
			}
			new_array.push(cur_obj)
		}
        setAllBrands(new_array);
		console.log('New Array', new_array);
		console.log('Brand Response', BrandResponse.Data);
    }

    const formik = useFormik({
        initialValues,
        validationSchema: brandSchema,
        onSubmit: async (values, { setStatus, setSubmitting, resetForm }) => {
            setLoading(true)
            try {

                var formData = new FormData();

                // const body = {
                //     "name": values.name,
                //     "logo": values.logo,
                //     "top": values.top,
                //     "slug": values.slug,
                //     "meta_title": values.meta_title,
                //     "meta_description": values.meta_description,
                // }

                formData.append('name', values.name);
                formData.append('logo', logoImage);
                formData.append('top', values.top || "0");
                formData.append('slug', values.slug);
                formData.append('meta_title', values.meta_title);
                formData.append('meta_description', values.meta_description);

                const headers = {
                    headers: {
                        "Content-type": "multipart/form-data",
                    },
                }

                console.log('lead form body');
                console.log(formData);
                if (!dataBinded) {
                    const BrandData = await saveBrand(formData, headers);

                    if (BrandData != null) {
                        setLoading(false);
                        document.getElementById('kt_team_close')?.click();
                        // var toastEl = document.getElementById('myToastAdd');
                        // const bsToast = new Toast(toastEl);
                        // bsToast.show();
                        resetForm();
                        clearForm();
                        brandList();
                		setOpen(false);
						toast.info(' Brand Saved Sucessfully!', { 
                            position: "top-right",
                            autoClose: 2000,
                            hideProgressBar: false,
                            closeOnClick: true,
                            pauseOnHover: true,
                            draggable: true,
                            progress: undefined,
                            theme: "light",
                            // theme: "dark",
                            // className:"text-white",
                            // style: {backgroundColor: "#027a02"},
                        });
                    }
            		setOpen(false);
                } else {
                    const updateBrandData = await updateBrand(selectedId, formData);

                    if (updateBrandData != null) {
                        setLoading(false);
                        // var toastEl = document.getElementById('myToastUpdate');
                        // const bsToast = new Toast(toastEl);
                        // bsToast.show();
                        resetForm();
                        setDataBinded(false);
                        clearForm();
						brandList();
						toast.success(' Brand Updated Sucessfully!', {
                            position: "top-right",
                            autoClose: 2000,
                            hideProgressBar: false,
                            closeOnClick: true,
                            pauseOnHover: true,
                            draggable: true,
                            progress: undefined,
                            theme: "light",
                            // className:"text-dark",
                            // style: {backgroundColor: "#f7572a"},
                        });
                    }
                }
				brandList();
            } catch (error) {
                console.error(error)
                setStatus('The registration details is incorrect')
                setSubmitting(false)
                setLoading(false)
            }
			setOpen(false);
     		setEditOpen(false);
			brandList();
			clearForm();
        }
    })

    const handleLogoPreview = (e) => {
        let image_as_base64 = URL.createObjectURL(e.target.files[0])
        let image_as_files = e.target.files[0];

        let fields = viewLogo.current?.value.split(".");

        let fileType = fields [fields.length - 1];

        if (fileType == 'jpg' || fileType == 'jpeg' || fileType == 'pdf'  || fileType == 'png') {
            setlogoImagePreview(image_as_base64);
            setLogoImage(image_as_files);
        } else {
            setlogoImagePreview(null);
            setLogoImage(null);
            if (viewLogo.current != null) {
                viewLogo.current.value = "";
            }
        }
        console.log(viewLogo.current?.value);
        console.log(image_as_files);
        console.log(fileType);
    }

    const removeLogo = () => {
        console.log(viewLogo.current?.value);
        if (viewLogo.current != null) {
            setlogoImagePreview(null);
            setLogoImage(null);
            viewLogo.current.value = "";
        }
    }
	const onOpenModal = () => {
		setOpen(true);
        formik.resetForm();
		allClear();
	};
	const onCloseModal = () => {
		setOpen(false);
	};
	const onEditModal = () => {
		setEditOpen(true);
	};
	const onCloseEdit = () => {
		setEditOpen(false);
	};
	const onDeleteModal = () => {
		setDeleteOpen(true);
	};
	const oncloseDeleteModal = () => {
		setDeleteOpen(false);
	};


    const EditBrand = async (id) => {
        setSelectedId(id);
        const allUserEdit = await getBrandEdit(id)
        setBrandEdit(allUserEdit.Data);
        setDataBinded(true);
		// setLogoImage(URL.createObjectURL(process.env.REACT_APP_API_BASE_URL + 'uploads/brand/logo/' + allUserEdit.id + '/' + allUserEdit.logo))
        formik.setFieldValue('name', allUserEdit.Data.name);
        // formik.setFieldValue('logo', allUserEdit.Data.logo);
        formik.setFieldValue('logo', allUserEdit.Data.logo);
        // formik.setFieldValue('meta_title', allUserEdit.Data.meta_title);
        // formik.setFieldValue('meta_description', allUserEdit.Data.meta_description);
		onEditModal();
    }
    const BrandDelete = async (id) => {
        setSelectedId(id);
		onDeleteModal(id);
    }
    const clearForm = () => {
        formik.resetForm();
        // setDataBinded(false);
		setOpen(false);
		setEditOpen(false);
		removeLogo();
    }
	const allClear = () => {
        formik.resetForm();
        setDataBinded(false);
		removeLogo();
    }

    
    // const onDelete = async (id) => {
    //     setIsLoading(false);
    //     console.log(id);
    //     await deleteBrand(id);
    //     setIsLoading(false);
    //     var toastEl = document.getElementById('myToastDeleteStatus');
    //     const bsToast = new Toast(toastEl);
    //     bsToast.show();
    //     brandList();
    // }
    const onDelete = async (id) => {
		console.log(id);
        await deleteBrand(id);
        brandList();
		// var toastEl = document.getElementById('myToastDelete');
        // const bsToast = new Toast(toastEl);
        // bsToast.show();
		toast.error(' Brand Deleted Sucessfully!', {
            position: "top-right",
            autoClose: 2000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
            theme: "dark",
            // className:"text-white",
            // style: {backgroundColor: "#d1061b"},
        });
    }

	const columns = [
		{
			name: "id",
			selector:  row => row.sl_no,
			sortable: true,
		},
		{
			name: "Name",
			selector: row => row.name,
			sortable: true,
		},
		// {
		// 	name: "Logo",
		// 	selector: row => <img src={process.env.REACT_APP_API_BASE_URL + 'uploads/brand/logo/' + row.id + '/' + row.logo}  className="img-fluid" height={80} width={80} alt='' />,
		// 	// sortable: true,
		// },
		{
			name: "Logo",
			selector: row => 
			<div>
			{row.logo !== null ? 
				<div className="file-preview box sm">
					<img src={process.env.REACT_APP_API_BASE_URL + 'uploads/brand/logo/' + row.id + '/' + row.logo} className="" height={60} width={80} alt='' />
				</div> :
				<img src={logo} className="" height={50} width={80} alt='' />
			}
			</div>
		},
		{
			name:"Actions",
			cell: (row, index) => (
				<div>
					<span>
						<button
						className="btn btn-danger btn-sm fa fa-pencil mx-2 m-2 button_size"
						data-toggle="modal"
						onClick={() => EditBrand(row.id)}
						>
						</button>
					</span>
					<span >
						<button
						className="btn btn-primary btn-sm fa fa-trash mx-2 button_size"
						onClick={() => BrandDelete(row.id)}
						data-bs-toggle='modal' 
						data-bs-target={'#delete_confirm_popup452222' + selectedId}
						>
						</button>
					</span>
				</div>
			),
		}
	]

    // const data1 = allBrands;
	
	useEffect(() => {
        brandList();
      }, []);

	return (
		<Fragment>
			<ToastContainer/>
			<Breadcrumb title="Brands" parent="Brands" />
			<Container fluid={true}>
				<Row>
					<Col sm="12">
						<Card>
							<CardHeader>
								<h5>Brands</h5>
							</CardHeader>
							<CardBody>
								<div className="btn-popup pull-right">
									<Button
										type="button"
										color="primary"
										onClick={onOpenModal}
										data-toggle="modal"
										data-original-title="test"
										data-target="#exampleModal"
									>
										Add Brand
									</Button>
									{/* Save Modal */}
									<Modal isOpen={open} toggle={onCloseModal}>
										<ModalHeader toggle={onCloseModal}>
											<h5
												className="modal-title f-w-600"
												id="exampleModalLabel2"
											>
												Add Brand
											</h5>
										</ModalHeader>
										<ModalBody>
											<Form noValidate onSubmit={formik.handleSubmit}>

											<div className="form-group mb-0">
												<label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold m-2">Name</label>
												<div className="input-group">
													<input type="text" className="form-control" placeholder="Name" {...formik.getFieldProps('name')} />
												</div>
												{formik.touched.name && formik.errors.name && (
													<div className='fv-plugins-message-container'>
														<div className='fv-help-block'>
															<span role='alert' className='text-danger'>{formik.errors.name}</span>
														</div>
													</div>
												)}
											</div>
											{/* <div className="form-group mb-4">
												<label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold m-2">Logo</label>
												<div className="input-group">
													<input type="text" className="form-control" placeholder="Logo" {...formik.getFieldProps('logo')} />
												</div>
												{formik.touched.logo && formik.errors.logo && (
													<div className='fv-plugins-message-container'>
														<div className='fv-help-block'>
															<span role='alert' className='text-danger'>{formik.errors.logo}</span>
														</div>
													</div>
												)}
											</div> */}
											<div className="form-group mb-0">
												<label className=' text-gray-700 fw-bold m-2'>Logo</label>
												<div className="col-md-12">
													<div className="input-group" data-toggle="aizuploader" data-type="image" data-multiple="true">

														{/* <input type="file" className="form-control file-amount mt-2" name="profile_image" /> */}
														<input type="file" className='form-control' name="profile_image" ref={viewLogo} onChange={handleLogoPreview} />
													</div>
													<div className="file-preview box sm">
													</div>
												</div>
												<div className="file-preview box sm d-flex justify-content-center align-items-center mt-4 mx-4">
												{logoImagePreview != null && (
													<div className='profile_preview position-relative image-input image-input-outline'>
														<img src={logoImagePreview} alt="image preview" className='image-input-wrapper w-100px h-100px' height={150} width={200} />
														<div onClick={removeLogo} className="p-1 fa fa-remove text-danger" style={{fontSize:"30px" , cursor:"pointer"}}>
											            
														</div>
													</div>
												)}
												</div>
											</div>
											<div className="form-group mb-0">
												<label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold m-2">Meta Title</label>
												<div className="input-group">
													<input type="text" className="form-control" placeholder="Meta Title" {...formik.getFieldProps('meta_title')} />
												</div>
												{formik.touched.meta_title && formik.errors.meta_title && (
													<div className='fv-plugins-message-container'>
														<div className='fv-help-block'>
															<span role='alert' className='text-danger'>{formik.errors.meta_title}</span>
														</div>
													</div>
												)}
											</div>
											<div className="form-group mb-0">
												<label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold m-2">Meta Description</label>
												<div className="input-group">
													<input type="text" className="form-control" placeholder="Meta Description" {...formik.getFieldProps('meta_description')} />
												</div>
												{formik.touched.meta_description && formik.errors.meta_description && (
													<div className='fv-plugins-message-container'>
														<div className='fv-help-block'>
															<span role='alert' className='text-danger'>{formik.errors.meta_description}</span>
														</div>
													</div>
												)}
											</div>
											{/* <div className="form-group mb-4">
												<label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold m-2">Rtl</label>
												<div className="input-group">
													<input type="text" className="form-control" placeholder="Rtl" {...formik.getFieldProps('rtl')} />
												</div>
												{formik.touched.rtl && formik.errors.rtl && (
													<div className='fv-plugins-message-container'>
														<div className='fv-help-block'>
															<span role='alert' className='text-danger'>{formik.errors.rtl}</span>
														</div>
													</div>
												)}
											</div>
											<div className="form-group mb-4">
												<label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold m-2">Status</label>
												<div className="input-group">
													<input type="text" className="form-control" placeholder="Status" {...formik.getFieldProps('status')} />
												</div>
												{formik.touched.status && formik.errors.status && (
													<div className='fv-plugins-message-container'>
														<div className='fv-help-block'>
															<span role='alert' className='text-danger'>{formik.errors.status}</span>
														</div>
													</div>
												)}
											</div> */}
											
															{/* <FormGroup>
													<Label
														htmlFor="recipient-name"
														className="col-form-label"
													>
														Languages Name :
													</Label>
													<Input type="text" className="form-control" />
												</FormGroup> */}

												{/* <FormGroup>
													<Label
														htmlFor="message-text"
														className="col-form-label"
													>
														Category Image :
													</Label>
													<Input
														className="form-control"
														id="validationCustom02"
														type="file"
													/>
												</FormGroup> */}

                                                <div className='card-footer py-5 text-center' id='kt_task_footer'>
													<button
														type='submit'
														id='submit_button'
														className='btn btn-primary text-white mx-2'
														disabled={formik.isSubmitting}
														style={{backgroundColor:'#ffbe57'}}
														// onClick={()=>{toComponentB()}}
														// onClick={() => alert()}
													>
														{!loading && <span className='indicator-label'>Submit
														</span>}
														{loading && (
															<span className='indicator-progress' style={{ display: 'block' }}>
																Please wait...{' '}
																<span className='spinner-border spinner-border-sm align-middle ms-2'></span>
															</span>
														)}
													</button>

													<div className='btn btn-danger text-white' onClick={clearForm} style={{backgroundColor:'#0fb2f7'}}> Cancel</div>
												</div>
											</Form>
										</ModalBody>
										<ModalFooter>
											{/* <Button
												type="button"
												color="primary"
												onClick={() => onCloseModal("VaryingMdo")}
											>
												Save
											</Button>
											<Button
												type="button"
												color="secondary"
												onClick={() => onCloseModal("VaryingMdo")}
											>
												Close
											</Button> */}
										</ModalFooter>
									</Modal>

									{/* Edit Modal */}
									<Modal isOpen={editOpen} toggle={onCloseEdit}>
										<ModalHeader toggle={onCloseEdit}>
											<h5
												className="modal-title f-w-600"
												id="exampleModalLabel2"
											>
												Edit Brand
											</h5>
										</ModalHeader>
										<ModalBody>
											<Form noValidate onSubmit={formik.handleSubmit}>

											<div className="form-group mb-0">
												<label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold m-2">Name</label>
												<div className="input-group">
													<input type="text" className="form-control" placeholder="Name" {...formik.getFieldProps('name')} />
												</div>
												{formik.touched.name && formik.errors.name && (
													<div className='fv-plugins-message-container'>
														<div className='fv-help-block'>
															<span role='alert' className='text-danger'>{formik.errors.name}</span>
														</div>
													</div>
												)}
											</div>
											<div className="form-group mb-0">
												<label className=' text-gray-700 fw-bold m-2'>Logo</label>
												<div className="col-md-12">
													<div className="input-group" data-toggle="aizuploader" data-type="image" data-multiple="true">

														{/* <input type="file" className="form-control file-amount mt-2" name="profile_image" /> */}
														<input type="file" className='form-control' ref={viewLogo} onChange={handleLogoPreview} />
													</div>
													<div className="file-preview box sm">
														
													</div>
												</div>
												<div className="file-preview box sm d-flex justify-content-center align-items-center mt-4 mx-4">
												{/* {logoImagePreview != null && (
													<div className='profile_preview position-relative image-input image-input-outline'>
														<img src={logoImagePreview} alt="image preview" className='image-input-wrapper w-100px h-100px' height={150} width={200} />
														<div onClick={removeLogo} className="p-1 fa fa-remove text-danger" style={{fontSize:"30px" , cursor:"pointer"}}>
											            
														</div>
													</div>
												)} */}

												{logoImagePreview != null ? <div className="file-preview box sm">
													{logoImagePreview != null && (
														<div className='profile_preview position-relative image-input image-input-outline'>
															<img src={logoImagePreview} alt="image preview" className='image-input-wrapper w-100px h-100px' height={100} width={150} />
															<div onClick={removeLogo} className="p-1 fa fa-remove text-danger" style={{fontSize:"30px" , cursor:"pointer"}}>
															
															</div>
														</div>
													)}
												</div> : brandEdit.logo == null ? <img src={logo} className="" height={100} width={150} alt='' />  :
													<div className='profile_preview position-relative image-input image-input-outline'>
														<img src={process.env.REACT_APP_API_BASE_URL + 'uploads/brand/logo/' + brandEdit.id + '/' + brandEdit.logo} className="image-input-wrapper w-100px h-100px shadow" height={100} width={150} alt='' />
													</div> 
												}
												</div>
											</div>
                                                <div className='card-footer py-5 text-center' id='kt_task_footer'>
													<button
														type='submit'
														id='submit_button'
														className='btn btn-primary text-white mx-2'
														disabled={formik.isSubmitting}
														style={{backgroundColor:'#ffbe57'}}
														// onClick={()=>{toComponentB()}}
														// onClick={() => alert()}
													>
														{!loading && <span className='indicator-label'>Update
														</span>}
														{loading && (
															<span className='indicator-progress' style={{ display: 'block' }}>
																Please wait...{' '}
																<span className='spinner-border spinner-border-sm align-middle ms-2'></span>
															</span>
														)}
													</button>

													<div className='btn btn-danger text-white' onClick={clearForm} style={{backgroundColor:'#0fb2f7'}}> Cancel</div>
												</div>
											</Form>
										</ModalBody>
									</Modal>
									
									{/* Delete Modal */}
									<div isOpen={deleteOpen} toggle={oncloseDeleteModal}>
										<div className='modal fade p-6' id={'delete_confirm_popup452222' + selectedId} aria-hidden='true'>
											<div className='modal-dialog modal-dialog-centered'>
												<div className='modal-content'>
													<div className='modal-header'>
														<h3 className="text-dark">Confirmation</h3>
														<div className='btn btn-sm btn-icon btn-active-color-primary' data-bs-dismiss='modal'>
														</div>
													</div>
													<div className='modal-body'>
														<div className='text-center'>
															<h4>Are you sure want to Delete ? </h4>
														</div>
														<div className='d-flex align-items-center justify-content-center'>
															<button className='btn btn-sm btn-outline-danger mx-4 mt-3' data-bs-dismiss='modal' onClick={(e) => onDelete(selectedId)}>
																Yes
															</button>
															<button className='btn btn-sm btn-outline-secondary mt-3 me-3' data-bs-dismiss='modal' onClick={clearForm}>
																No
															</button>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div className="clearfix"></div>
								<div id="basicScenario" className="product-physical">
									{/* <Datatable
										myData={allBrands}
										columns={columns}
										// multiSelectOption={false}
										// pageSize={10}
										// pagination={true}
										// class="-striped -highlight"
									/> */}
			                    <Fragment>
									<DataTable 
										// myData={allBrands}
										data={allBrands}
										columns={columns}
										multiSelectOption={true}
										pageSize={10}
										pagination={true}
										class="-striped -highlight"
										className="text-center"
									/>
								</Fragment>
								</div>
							</CardBody>
						</Card>
					</Col>
				</Row>
			</Container>
			<div aria-atomic="true" aria-live="assertive" className="toast text-white position-fixed end-0 bottom-0 m-3" id="myToastAdd" style={{backgroundColor: "#027a02"}}>
				<div className="toast-header">
					<strong className="me-auto">Success</strong>
					<button aria-label="Close" className="btn-close"
						data-bs-dismiss="toast" type="button">
					</button>
				</div>
				<div className="toast-body">
					Brand Saved Successfully!
				</div>
			</div>
			<div aria-atomic="true" aria-live="assertive" className="toast text-white position-fixed end-0 bottom-0 m-3" id="myToastUpdate" style={{backgroundColor: "#f7572a"}}>
				<div className="toast-header">
					<strong className="me-auto">Success</strong>
					<button aria-label="Close" className="btn-close"
						data-bs-dismiss="toast" type="button">
					</button>
				</div>
				<div className="toast-body">
					Brand Updated Successfully!
				</div>
			</div>
			<div aria-atomic="true" aria-live="assertive" className="toast text-white position-fixed end-0 bottom-0 m-3" id="myToastDelete" style={{backgroundColor: "#d1061b"}}>
				<div className="toast-header">
					<strong className="me-auto">Success</strong>
					<button aria-label="Close" className="btn-close"
						data-bs-dismiss="toast" type="button">
					</button>
				</div>
				<div className="toast-body">
					Brand Deleted Successfully!
				</div>
			</div>
		</Fragment>
	);
};

export default BrandPage;
