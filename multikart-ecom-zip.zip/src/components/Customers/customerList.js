import React, { Fragment, useState, useEffect } from "react";
import Breadcrumb from "../common/breadcrumb";
import "react-toastify/dist/ReactToastify.css";
// import { data } from "../../../assets/data/category";
import { useFormik } from 'formik';
// import Datatable from "../../common/datatable";
import DataTable from "react-data-table-component";
import { Offcanvas, Toast } from 'bootstrap';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import * as Yup from 'yup';
import {getCustomers, getCustomerEdit,saveCustomer, updateCustomer, deleteCustomer, getRoles, banCustomer } from './core/_requests';
import {
	Button,
	Card,
	CardBody,
	CardHeader,
	Col,
	Container,
	Form,
	FormGroup,
	Input,
	Label,
	Modal,
	ModalBody,
	ModalFooter,
	ModalHeader,
	Row,
} from "reactstrap";


const initialValues = {
    "id" : "",
    "referred_by" : "",
    "provider_id" : "",
    "user_type" : "",
    "name" : "",
    "email" : "",
    "email_verified_at" : "",
    "verification_code" : "",
    "new_email_verificiation_code" : "",
    "password" : "" ,
    "remember_token" : "" ,
    "device_token" : "",
    "avatar" : ""  ,
    "avatar_original" : "",
    "address" : "",
    "country" : "",
    "state" : "",
    "city" : "",
    "postal_code" : "" ,
    "phone" : "",
    "balance" : "" ,
    "banned" : "" ,
    "referral_code" : "",
    "customer_package_id" : "" ,
    "remaining_uploads" : "",
    "role_id":""
}

const CustomerList = () => {

    const CustomerSchema = Yup.object().shape({
        // name: Yup.string().required('* Name is required'),
        // email: Yup.string()
        //     .email('Wrong email format')
        //     .min(3, 'Minimum 3 characters')
        //     .max(50, 'Maximum 50 characters')
        //     .required('Email is required'),
        // password: Yup.string().required('* Password is required'),
        // phone: Yup.string()
        // .min(10, '* Minimum 10 symbols')
        // .max(10, '* Maximum 10 symbols'),
    })

    var userId = localStorage.getItem('userId')
	console.log("User ID",userId)

    const [allCustomers, setAllCustomers] = useState([]);
    const [allRoles, setAllRoles] = useState([]);
    const [allCustEdit, setAllCustEdit] = useState([]);
    const [allCategoryBlogs, setAllCategoryBlogs] = useState([]);
    const [loading, setLoading] = useState(false);
    const [editClicked, setEditClicked] = useState(false);
    const [editId, setEditId] = useState('');
    const [selectedId, setSelectedId] = useState('');
    const [blogEdit, setBlogEdit] = useState([]);
    const [dataBinded, setDataBinded] = useState(false);
	const [banToggle, setBanToggle] = useState(false);


    const [open, setOpen] = useState(false);
	const [editOpen, setEditOpen] = useState(false);
	const [deleteOpen, setDeleteOpen] = useState(false);
	const [banOpen, setBanOpen] = useState(false);
	const [toggle, setToggle] = useState(false);
    const [allLanguages, setAllLanguages] = useState([{}]);
    const [LanguageEdit, setLanguageEdit] = useState([]);
    const [isLoading, setIsLoading] = useState(false);

    var userId = localStorage.getItem('userId')
	console.log("User ID",userId)

    // const CustomerList = async () => {
    //     const CustomerResponse = await getCustomers()
    //     console.log('All Customer List');
    //     console.log(CustomerResponse.Data);
    //     setAllCustomers(CustomerResponse.Data);
    // }
    const CustomerList = async () => {
        const CustomerResponse = await getCustomers()
        console.log('All Customer List');
        console.log(CustomerResponse.Data);

        let new_array = [];
		for(let i=0; i<CustomerResponse.Data.length;i++) {
			let cur_obj = {
				...CustomerResponse.Data[i],
				'sl_no': i + 1 
			}
			new_array.push(cur_obj)
		}
        setAllCustomers(new_array);
        console.log('New Array', new_array);
		console.log('Customer Response', CustomerResponse.Data);
    }

    const RolesList = async () => {
        const UsersResponse = await getRoles()
        console.log('All Users List');
        console.log(UsersResponse);
        setAllRoles(UsersResponse);
    }
    
    const formik = useFormik({
        initialValues,
        validationSchema: CustomerSchema,
        onSubmit: async (values, {setStatus, setSubmitting, resetForm}) => {
          setLoading(true)
          try {

            var formData = new FormData();

            formData.append("id" , values.id);
            formData.append("referred_by" , values.referred_by);
            formData.append("provider_id" , values.provider_id);
            formData.append("user_type" , values.user_type || "customer");
            formData.append('name', values.name);
            formData.append('email', values.email);
            formData.append('email_verified_at', values.email_verified_at);
            formData.append('verification_code', values.verification_code);
            formData.append('new_email_verificiation_code', values.new_email_verificiation_code);
            formData.append('password', values.password);
            formData.append('remember_token', values.remember_token);
            formData.append('device_token', values.device_token);
            formData.append('avatar', values.avatar);
            formData.append('avatar_original', values.avatar_original);
            formData.append('address', values.address);
            formData.append('country', values.country);
            formData.append('state', values.state);
            formData.append('city', values.city);
            formData.append('postal_code', values.postal_code);
            formData.append('phone', values.phone);
            formData.append('balance', values.balance || "0");
            formData.append('banned', values.banned || "0");
            formData.append('referral_code', values.referral_code);
            formData.append('customer_package_id', values.customer_package_id);
            formData.append('remaining_uploads', values.remaining_uploads || "0");
            
            const headers = {
                headers: {
                    "Content-type": "multipart/form-data",
                },
            }
                
            console.log('lead form body');
            console.log(formData);
            if(!dataBinded){
                const saveCustomerData = await saveCustomer(formData, headers);
            
                if(saveCustomerData != null){
                    setLoading(false);
                    document.getElementById('kt_team_close')?.click();
                    var toastEl = document.getElementById('myToastAdd');
                    const bsToast = new Toast(toastEl);
                    bsToast.show();
                    resetForm();
                    CustomerList();
                }

            } else {
                const updateCustomerData = await updateCustomer(selectedId, formData);

                if (updateCustomerData != null) {
                    setLoading(false);
                    var toastEl = document.getElementById('myToastUpdate');
                    const bsToast = new Toast(toastEl);
                    bsToast.show();
                    resetForm();
                    setDataBinded(false);
                    CustomerList();
                    formik.resetForm();
                }
            }
            CustomerList();
            onCloseModal();
    
          } catch (error) {
            console.error(error)
            setStatus('The registration details is incorrect')
            setSubmitting(false)
            setLoading(false)

            // toast.error('Email Already Exits', {
            //     position: "bottom-right",
            //     autoClose: 5000,
            //     hideProgressBar: false,
            //     closeOnClick: true,
            //     pauseOnHover: true,
            //     draggable: true,
            //     progress: undefined,
            //     theme: "light",
            // });
        }
          CustomerList();
          resetForm();
          setEditOpen(false);
        }
    })

    const EditBanUser = async (selectedId) => {
        const body = {
            "banned": banToggle ? "2" : "0" ,
        }
        const updateBanCustomer = await banCustomer(selectedId, body);
        console.log(updateBanCustomer);
        setDataBinded(true);
        CustomerList();
        onBanModal();

        const allCustomerEdit = await getCustomerEdit(selectedId)
        setAllCustEdit(allCustomerEdit.Data);

        if (allCustomerEdit.Data.banned == 2) {
            toast.success('Banned Successfully', {
                position: "top-right",
                autoClose: 2000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
                theme: "dark",
            });
        } else if (allCustomerEdit.Data.banned == 0){

            toast.success('Un-Banned Successfully', {
                position: "top-right",
                autoClose: 2000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
                theme: "light",
            });
        }
    }

    const EditCustomer = async (id) => {
        setSelectedId(id);
        const allCustomerEdit = await getCustomerEdit(id)
        setAllCustEdit(allCustomerEdit.Data);
        setDataBinded(true);
        formik.setFieldValue('name', allCustomerEdit.Data.name);
        formik.setFieldValue('email', allCustomerEdit.Data.email);
        // formik.setFieldValue('password', allCustomerEdit.Data.password);
        formik.setFieldValue('address', allCustomerEdit.Data.address);
        formik.setFieldValue('phone', allCustomerEdit.Data.phone);
        formik.setFieldValue('state', allCustomerEdit.Data.state);
        formik.setFieldValue('city', allCustomerEdit.Data.city);
        formik.setFieldValue('user_type', allCustomerEdit.Data.user_type);
        onEditModal();
    }

	const columns = [
		{
			name: "id",
			selector: row => row.sl_no,
			sortable: true,
		},
		{
			name: "Name",
			selector: row => row.name,
			sortable: true,
		},
		{
			name: "Role",
			selector: row => row.user_type,
			sortable: true,
		},
		{
			name: "Email",
			selector: row => row.email,
			sortable: true,
		},
		{
			name: "Address",
			selector: row => row.address,
			sortable: true,
		},
		{
			name: "Phone",
			selector: row => row.phone,
			sortable: true,
		},
		// {
		// 	// name: "Status",
		// 	// selector: row => row.status,
		// 	// sortable: true,
		// 	name:"Status",
		// 	cell: (row, index) => (
		// 		<div>
		// 			<span>
		// 			<div class="form-switch">
		// 			<input class="form-check-input" type="checkbox" role="switch" id="flexSwitchCheckDefault" onChange={() => {
		// 				EditStatus(row.id);
		// 				setToggle(!toggle);
		// 			}}/>
		// 			</div>
		// 			</span>
		// 		</div>
		// 	)
		// },
		{
			name:"Actions",
			cell: (row, index) => (
				<div >
					{/* <span>
						<button
						className="btn btn-dark btn-sm fa fa-ban mx-2 m-2"
						data-toggle="modal"
						// onClick={() => EditBanUser(row.id)}
                        onClick={() => {
                            // BanCustomer(row.id);
                            BanCustomer(row.id)
                            setBanToggle(!banToggle);
                        }}
                        data-bs-toggle='modal' 
						data-bs-target={'#ban_customer_33333' + selectedId}
						>
						</button>
					</span> */}
					<span>
						{ (row.banned !== 2 ) ? <button
						className="btn text-white btn-sm fa fa-ban button_size"
                        style={{backgroundColor:"#328f4c"}}
						data-toggle="modal"
						// onClick={() => EditBanUser(row.id)}
                        onClick={() => {
                            // BanCustomer(row.id);
                            BanCustomer(row.id)
                            setBanToggle(!banToggle);
                        }}
                        data-bs-toggle='modal' 
						data-bs-target={'#ban_customer_33333' + selectedId}
						>
						</button> : (row.banned == 2 ) ? <button
						className="btn text-white btn-sm fa fa-ban button_size"
                        style={{backgroundColor:"#e33645"}}
						data-toggle="modal"
						// onClick={() => EditBanUser(row.id)}
                        onClick={() => {
                            // BanCustomer(row.id);
                            BanCustomer(row.id)
                            setBanToggle(!banToggle);
                        }}
                        data-bs-toggle='modal' 
						data-bs-target={'#ban_customer_33333' + selectedId}
						>
						</button> : "" }
					</span>
					<span>
						<a
						className="btn btn-danger btn-sm fa fa-pencil mx-2 m-2 button_size"
						data-toggle="modal"
						onClick={() => EditCustomer(row.id)}
						>
						</a>
					</span>
					<span >
						<button
						className="btn btn-primary btn-sm fa fa-trash button_size"
						onClick={() => DeleteCustomer(row.id)}
						data-bs-toggle='modal' 
						data-bs-target={'#delete_confirm_popup452222' + selectedId}
						>
						</button>
					</span>
				</div>
			),
		}
	]

	const onDeleteModal = () => {
		setDeleteOpen(true);
	};
	const DeleteCustomer = async (id) => {
        setSelectedId(id);
		onDeleteModal(id);
    }
    const onBanModal = () => {
        setBanOpen(true);
	};
	const BanCustomer = async(id) => {
        setSelectedId(id);
		onBanModal(id);
    }

	const onOpenModal = () => {
		setOpen(true);
        allClear();
        formik.resetForm();
	};

	// const onCloseModal = () => {
	// 	setOpen(false);
	// };

	const onEditModal = () => {
		setEditOpen(true);
	};

	const onCloseModal = () => {
		setEditOpen(false);
		setOpen(false);
        formik.resetForm();
	};

	const oncloseDeleteModal = () => {
		setDeleteOpen(false);
		CustomerList();
	};
	const oncloseBanModal = () => {
		setBanOpen(false);
		CustomerList();
	};

    const clearForm = () => {
        formik.resetForm();
        setDataBinded(false);
		setOpen(false);
		setEditOpen(false);
    }
    const allClear = () => {
        formik.resetForm();
        setDataBinded(false);
    }
    const onDelete = async (id) => {
        console.log(id);
        await deleteCustomer(id);
        CustomerList();
    }

	useEffect(() => {
        CustomerList();
        RolesList();
      }, []);

	return (
		<Fragment>
			<Breadcrumb title="Customers" parent="Physical" />
			<Container fluid={true}>
				<Row>
					<Col sm="12">
						<Card>
							<CardHeader>
								<h5>Customers List</h5>
							</CardHeader>
							<CardBody>
								<div className="btn-popup pull-right">
									<Button
										type="button"
										color="primary"
										onClick={onOpenModal}
										data-toggle="modal"
										data-original-title="test"
										data-target="#exampleModal"
									>
										Add Customer
									</Button>
									{/* Save Modal */}
									<Modal isOpen={open} toggle={onCloseModal} className='modal-lg'>
										<ModalHeader toggle={onCloseModal}>
											<h5
												className="modal-title f-w-600"
												id="exampleModalLabel2"
											>
												Add Customer
											</h5>
										</ModalHeader>
										<ModalBody>
											<Form noValidate onSubmit={formik.handleSubmit}>
                                            <div className="row">
                                                <div className="form-group mb-4 col-lg-6">
                                                    <label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold">Name</label>
                                                    <div className="input-group">
                                                        <input type="text" className="form-control" placeholder="Name" {...formik.getFieldProps('name')} />
                                                    </div>
                                                    {formik.touched.name && formik.errors.name && (
                                                        <div className='fv-plugins-message-container'>
                                                            <div className='fv-help-block'>
                                                                <span role='alert' className='text-danger'>{formik.errors.name}</span>
                                                            </div>
                                                        </div>
                                                    )}
                                                </div>
                                                {/* <div className="form-group mb-4 col-lg-6">
                                                    <label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold">Roles</label>
                                                    <select className="form-control form-select" {...formik.getFieldProps('role_id')} name="role_id" id="role_id"
                                                        data-selected="" data-live-search="true" required>
                                                        <option>-- Roles Select -- </option>
                                                        {allRoles.map((rolesValues, i) => {
                                                            return (
                                                                <option selected={i == 0 ? true : false} value={rolesValues.id} key={i}>{rolesValues.name}</option>
                                                            )
                                                        })}
                                                    </select>
                                                    {formik.touched.brand_id && formik.errors.brand_id && (
                                                        <div className='fv-plugins-message-container'>
                                                            <div className='fv-help-block'>
                                                                <span role='alert' className='text-danger mx-2'>{formik.errors.brand_id}</span>
                                                            </div>
                                                        </div>
                                                    )}
                                                </div> */}
                                                 <div className="form-group mb-4 col-lg-6">
                                                    <label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold">Email</label>
                                                    <div className="input-group">
                                                        <input type="text" className="form-control" placeholder="Email" {...formik.getFieldProps('email')} />
                                                    </div>
                                                    {formik.touched.email && formik.errors.email && (
                                                        <div className='fv-plugins-message-container'>
                                                            <div className='fv-help-block'>
                                                                <span role='alert' className='text-danger'>{formik.errors.email}</span>
                                                            </div>
                                                        </div>
                                                    )}
                                                </div>
                                            </div>
                                            <div className="row">
                                                <div className="form-group mb-4 col-lg-6">
                                                    <label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold">Password</label>
                                                    <div className="input-group">
                                                        <input type="password" className="form-control" placeholder="Password" {...formik.getFieldProps('password')} />
                                                    </div>
                                                    {formik.touched.password && formik.errors.password && (
                                                        <div className='fv-plugins-message-container'>
                                                            <div className='fv-help-block'>
                                                                <span role='alert' className='text-danger'>{formik.errors.password}</span>
                                                            </div>
                                                        </div>
                                                    )}
                                                </div>
                                                <div className="form-group mb-4 col-lg-6">
                                                    <label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold">Address</label>
                                                    <div className="input-group">
                                                        <textarea type="text" className="form-control" placeholder="Address" {...formik.getFieldProps('address')} ></textarea>
                                                    </div>
                                                    {formik.touched.address && formik.errors.address && (
                                                        <div className='fv-plugins-message-container'>
                                                            <div className='fv-help-block'>
                                                                <span role='alert' className='text-danger'>{formik.errors.address}</span>
                                                            </div>
                                                        </div>
                                                    )}
                                                </div>
                                            </div>
                                            <div className="row">
                                                
                                                <div className="form-group mb-4 col-lg-6">
                                                    <label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold">State</label>
                                                    <div className="input-group">
                                                        <input type="text" className="form-control" placeholder="State" {...formik.getFieldProps('state')} />
                                                    </div>
                                                    {formik.touched.state && formik.errors.state && (
                                                        <div className='fv-plugins-message-container'>
                                                            <div className='fv-help-block'>
                                                                <span role='alert' className='text-danger'>{formik.errors.state}</span>
                                                            </div>
                                                        </div>
                                                    )}
                                                </div>
                                                <div className="form-group mb-4 col-lg-6">
                                                    <label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold">City</label>
                                                    <div className="input-group">
                                                        <input type="text" className="form-control" placeholder="City" {...formik.getFieldProps('city')} />
                                                    </div>
                                                    {formik.touched.city && formik.errors.city && (
                                                        <div className='fv-plugins-message-container'>
                                                            <div className='fv-help-block'>
                                                                <span role='alert' className='text-danger'>{formik.errors.city}</span>
                                                            </div>
                                                        </div>
                                                    )}
                                                </div>
                                            </div>
                                            <div className="row">
                                               
                                            <div className="form-group mb-4 col-lg-6">
                                                    <label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold">Country</label>
                                                    <div className="input-group">
                                                        <input type="text" className="form-control" placeholder="Country" {...formik.getFieldProps('country')} />
                                                    </div>
                                                    {formik.touched.country && formik.errors.country && (
                                                        <div className='fv-plugins-message-container'>
                                                            <div className='fv-help-block'>
                                                                <span role='alert' className='text-danger'>{formik.errors.country}</span>
                                                            </div>
                                                        </div>
                                                    )}
                                                </div>
                                                <div className="form-group mb-4 col-lg-6">
                                                    <label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold">Phone</label>
                                                    <div className="input-group">
                                                        <input type="number" className="form-control" placeholder="Phone" {...formik.getFieldProps('phone')} min='1' />
                                                    </div>
                                                    {formik.touched.phone && formik.errors.phone && (
                                                        <div className='fv-plugins-message-container'>
                                                            <div className='fv-help-block'>
                                                                <span role='alert' className='text-danger'>{formik.errors.phone}</span>
                                                            </div>
                                                        </div>
                                                    )}
                                                </div>
                                            </div>
                                            
											{/* <div className="form-group mb-4">
												<label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold m-2">Rtl</label>
												<div className="input-group">
													<input type="text" className="form-control" placeholder="Rtl" {...formik.getFieldProps('rtl')} />
												</div>
												{formik.touched.rtl && formik.errors.rtl && (
													<div className='fv-plugins-message-container'>
														<div className='fv-help-block'>
															<span role='alert' className='text-danger'>{formik.errors.rtl}</span>
														</div>
													</div>
												)}
											</div>
											<div className="form-group mb-4">
												<label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold m-2">Status</label>
												<div className="input-group">
													<input type="text" className="form-control" placeholder="Status" {...formik.getFieldProps('status')} />
												</div>
												{formik.touched.status && formik.errors.status && (
													<div className='fv-plugins-message-container'>
														<div className='fv-help-block'>
															<span role='alert' className='text-danger'>{formik.errors.status}</span>
														</div>
													</div>
												)}
											</div> */}
											
															{/* <FormGroup>
													<Label
														htmlFor="recipient-name"
														className="col-form-label"
													>
														Languages Name :
													</Label>
													<Input type="text" className="form-control" />
												</FormGroup> */}

												{/* <FormGroup>
													<Label
														htmlFor="message-text"
														className="col-form-label"
													>
														Category Image :
													</Label>
													<Input
														className="form-control"
														id="validationCustom02"
														type="file"
													/>
												</FormGroup> */}

                                                <div className='card-footer py-5 text-center' id='kt_task_footer'>
													<button
														type='submit'
														id='submit_button'
														className='btn btn-primary text-white mx-2'
														disabled={formik.isSubmitting}
														style={{backgroundColor:'#ffbe57'}}
														// onClick={()=>{toComponentB()}}
														// onClick={() => alert()}
													>
														{!loading && <span className='indicator-label'>Submit
														</span>}
														{loading && (
															<span className='indicator-progress' style={{ display: 'block' }}>
																Please wait...{' '}
																<span className='spinner-border spinner-border-sm align-middle ms-2'></span>
															</span>
														)}
													</button>

													<div className='btn btn-danger text-white' onClick={clearForm} > Cancel</div>
												</div>

											</Form>
										</ModalBody>
										<ModalFooter>
											{/* <Button
												type="button"
												color="primary"
												onClick={() => onCloseModal("VaryingMdo")}
											>
												Save
											</Button>
											<Button
												type="button"
												color="secondary"
												onClick={() => onCloseModal("VaryingMdo")}
											>
												Close
											</Button> */}
										</ModalFooter>
									</Modal>
									{/* Edit Modal */}
									<Modal isOpen={editOpen} toggle={onCloseModal} className='modal-lg'>
										<ModalHeader toggle={onCloseModal}>
											<h5
												className="modal-title f-w-600"
												id="exampleModalLabel2"
											>
												Edit Customer
											</h5>
										</ModalHeader>
										<ModalBody>
                                        <Form noValidate onSubmit={formik.handleSubmit}>
                                            <div className="row">
                                                <div className="form-group mb-4 col-lg-6">
                                                    <label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold">Name</label>
                                                    <div className="input-group">
                                                        <input type="text" className="form-control" placeholder="Name" {...formik.getFieldProps('name')} />
                                                    </div>
                                                    {formik.touched.name && formik.errors.name && (
                                                        <div className='fv-plugins-message-container'>
                                                            <div className='fv-help-block'>
                                                                <span role='alert' className='text-danger'>{formik.errors.name}</span>
                                                            </div>
                                                        </div>
                                                    )}
                                                </div>
                                                {/* <div className="form-group mb-4 col-lg-6">
                                                    <label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold">Roles</label>
                                                    <select className="form-control form-select" {...formik.getFieldProps('user_type')} name="user_type" id="user_type"
                                                        data-selected="" data-live-search="true" required>
                                                        <option>-- Roles Select -- </option>
                                                        {allRoles.map((rolesValues, i) => {
                                                            return (
                                                                <option selected={i == 0 ? true : false} value={rolesValues.id} key={i}>{rolesValues.name}</option>
                                                            )
                                                        })}
                                                    </select>
                                                    {formik.touched.brand_id && formik.errors.brand_id && (
                                                        <div className='fv-plugins-message-container'>
                                                            <div className='fv-help-block'>
                                                                <span role='alert' className='text-danger mx-2'>{formik.errors.brand_id}</span>
                                                            </div>
                                                        </div>
                                                    )}
                                                </div> */}
                                                <div className="form-group mb-4 col-lg-6">
                                                    <label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold">Email</label>
                                                    <div className="input-group">
                                                        <input type="text" className="form-control" placeholder="Email" {...formik.getFieldProps('email')} />
                                                    </div>
                                                    {formik.touched.email && formik.errors.email && (
                                                        <div className='fv-plugins-message-container'>
                                                            <div className='fv-help-block'>
                                                                <span role='alert' className='text-danger'>{formik.errors.email}</span>
                                                            </div>
                                                        </div>
                                                    )}
                                                </div>
                                            </div>
                                            <div className="row">
                                                
                                                <div className="form-group mb-4 col-lg-6">
                                                    <label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold">Address</label>
                                                    <div className="input-group">
                                                        <textarea type="text" className="form-control" placeholder="Address" {...formik.getFieldProps('address')} ></textarea>
                                                    </div>
                                                    {formik.touched.address && formik.errors.address && (
                                                        <div className='fv-plugins-message-container'>
                                                            <div className='fv-help-block'>
                                                                <span role='alert' className='text-danger'>{formik.errors.address}</span>
                                                            </div>
                                                        </div>
                                                    )}
                                                </div>
                                                <div className="form-group mb-4 col-lg-6">
                                                    <label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold">Phone</label>
                                                    <div className="input-group">
                                                        <input type="number" className="form-control" placeholder="Phone" {...formik.getFieldProps('phone')} min='1' />
                                                    </div>
                                                    {formik.touched.phone && formik.errors.phone && (
                                                        <div className='fv-plugins-message-container'>
                                                            <div className='fv-help-block'>
                                                                <span role='alert' className='text-danger'>{formik.errors.phone}</span>
                                                            </div>
                                                        </div>
                                                    )}
                                                </div>
                                            </div>
                                            <div className="row">
                                                
                                                <div className="form-group mb-4 col-lg-6">
                                                    <label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold">State</label>
                                                    <div className="input-group">
                                                        <input type="text" className="form-control" placeholder="State" {...formik.getFieldProps('state')} />
                                                    </div>
                                                    {formik.touched.state && formik.errors.state && (
                                                        <div className='fv-plugins-message-container'>
                                                            <div className='fv-help-block'>
                                                                <span role='alert' className='text-danger'>{formik.errors.state}</span>
                                                            </div>
                                                        </div>
                                                    )}
                                                </div>
                                                <div className="form-group mb-4 col-lg-6">
                                                    <label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold">City</label>
                                                    <div className="input-group">
                                                        <input type="text" className="form-control" placeholder="City" {...formik.getFieldProps('city')} />
                                                    </div>
                                                    {formik.touched.city && formik.errors.city && (
                                                        <div className='fv-plugins-message-container'>
                                                            <div className='fv-help-block'>
                                                                <span role='alert' className='text-danger'>{formik.errors.city}</span>
                                                            </div>
                                                        </div>
                                                    )}
                                                </div>
                                            </div>
                                                <div className='card-footer py-5 text-center' id='kt_task_footer'>
													<button
														type='submit'
														id='submit_button'
														className='btn btn-primary text-white mx-2'
														disabled={formik.isSubmitting}
														style={{backgroundColor:'#ffbe57'}}
														// onClick={()=>{toComponentB()}}
														// onClick={() => alert()}
													>
														{!loading && <span className='indicator-label'>Update
														</span>}
														{loading && (
															<span className='indicator-progress' style={{ display: 'block' }}>
																Please wait...{' '}
																<span className='spinner-border spinner-border-sm align-middle ms-2'></span>
															</span>
														)}
													</button>

													<div className='btn btn-danger text-white' onClick={clearForm} style={{backgroundColor:'#0fb2f7'}}> Cancel</div>
												</div>

											</Form>
										</ModalBody>
									</Modal>

									{/* Delete Modal */}
									<div isOpen={deleteOpen} toggle={oncloseDeleteModal}>
										<div className='modal fade p-6' id={'delete_confirm_popup452222' + selectedId} aria-hidden='true'>
											<div className='modal-dialog modal-dialog-centered'>
												<div className='modal-content'>
													<div className='modal-header'>
														<h3 className="text-dark">Confirmation</h3>
														<div className='btn btn-sm btn-icon btn-active-color-primary' data-bs-dismiss='modal'>
														</div>
													</div>
													<div className='modal-body'>
														<div className='text-center'>
															<h4>Are you sure want to Delete ? </h4>
                                                            <p className='text-danger'>{allCustEdit.name}</p>
															<p className='text-danger'></p>
														</div>
														<div className='d-flex align-items-center justify-content-center'>
															<button className='btn btn-sm btn-outline-danger mx-4 mt-3' data-bs-dismiss='modal' onClick={(e) => onDelete(selectedId)}>
																Yes
															</button>
															<button className='btn btn-sm btn-outline-secondary mt-3 me-3' data-bs-dismiss='modal'>
																No
															</button>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
									{/* Ban Customer Modal */}
									<div isOpen={banOpen} toggle={oncloseBanModal}>
										<div className='modal fade p-6' id={'ban_customer_33333' + selectedId} aria-hidden='true'>
											<div className='modal-dialog modal-dialog-centered'>
												<div className='modal-content'>
													<div className='modal-header'>
														<h3 className="text-dark">Confirmation</h3>
														<div className='btn btn-sm btn-icon btn-active-color-primary' data-bs-dismiss='modal'>
														</div>
													</div>
													<div className='modal-body'>
														<div className='text-center'>
                                                            {/* { (allCustEdit.banned == 0) ? <h4>Are you sure want to Ban ? </h4> :  <h4>Are you sure want to Un-Ban ? </h4>} */}
															<h4>Are you sure want to Ban ? </h4>
                                                            
															<p className='text-danger'></p>
														</div>
														<div className='d-flex align-items-center justify-content-center'>
															<button className='btn btn-sm btn-outline-danger mx-4 mt-3' data-bs-dismiss='modal' onClick={(e) => EditBanUser(selectedId)}>
																Yes
															</button>
															<button className='btn btn-sm btn-outline-secondary mt-3 me-3' data-bs-dismiss='modal'>
																No
															</button>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div className="clearfix"></div>
								<div id="basicScenario" className="product-physical">
									{/* <Datatable
										myData={allLanguages}
										multiSelectOption={false}
										pageSize={10}
										pagination={true}
										class="-striped -highlight"
									/> */}
								<Fragment>
									<DataTable 
										// myData={allBrands}
										data={allCustomers}
										columns={columns}
										multiSelectOption={true}
										pageSize={10}
										pagination={true}
										class="-striped -highlight"
										className="text-center"
									/>
								</Fragment>
								</div>
							</CardBody>
						</Card>
					</Col>
				</Row>
			</Container>
            <ToastContainer/>
		</Fragment>
	);
};

export default CustomerList;
