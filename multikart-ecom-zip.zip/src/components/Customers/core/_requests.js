import axios, {AxiosResponse}  from 'axios'

const API_URL = process.env.REACT_APP_API_URL

// Users 
export const GET_CUSTOMER_LIST = `${API_URL}/get_customer_list `
export const SAVE_CUSTOMER = `${API_URL}/save_customer `
export const GET_CUSTOMER_EDIT = `${API_URL}/get_customer_list_id`
export const UPDATE_CUSTOMER = `${API_URL}/put_customer_id`
export const DELETE_CUSTOMER = `${API_URL}/delete_customer_list`

// Roles
export const GET_ROLES = `${API_URL}/get_roles `
// Ban Users
export const BAN_CUSTOMER = `${API_URL}/ban_customer_id`

export function getCustomers() {
    return axios.get(GET_CUSTOMER_LIST)
    .then((response => response.data))
}

export function saveCustomer(postData, headers) {
    return axios.post(SAVE_CUSTOMER, postData, headers)
    .then((response => response.data))
}

export function getCustomerEdit(id) {
    return axios.get(GET_CUSTOMER_EDIT+'/'+id)
    .then((response => response.data))
}

export function updateCustomer(id ,body) {
    return axios.put(UPDATE_CUSTOMER+'/'+id, body)
    .then((response => response.data))
}

export function deleteCustomer(id) {
    return axios.delete(DELETE_CUSTOMER+'/'+id)
    .then((response => response.data))
}

// Roles
export function getRoles() {
    return axios.get(GET_ROLES)
    .then((response => response.data))
}

// Ban Users
export function banCustomer(id ,body) {
    return axios.put(BAN_CUSTOMER+'/'+id, body)
    .then((response => response.data))
}