export const data = [
    {
        detail: "USASTE-PS6N0",
        schedule: "USASTCITY-6*",
        rate: "10%",
        amount: "15.24",
    },
    {
        detail: "USASTE-PS6N0",
        schedule: "USASTCITY-6*",
        rate: "18%",
        amount: "5.29",
    },
    {
        detail: "USASTE-PS6N0",
        schedule: "USASTCITY-6*",
        rate: "25%",
        amount: "4.78",
    },
    {
        detail: "USASTE-PS6N0",
        schedule: "USASTCITY-6*",
        rate: "40%",
        amount: "3.20",
    },
    {
        detail: "USASTE-PS6N0",
        schedule: "USASTCITY-6*",
        rate: "50%",
        amount: "4.78",
    },
    {
        detail: "USASTE-PS6N0",
        schedule: "USASTCITY-6*",
        rate: "80%",
        amount: "8.4",
    }

]

export default data

  