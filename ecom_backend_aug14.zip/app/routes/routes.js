module.exports = app => {
  // Admin
  const images = require("../controllers/images.controller.js");
  const auth = require("../controllers/auth.controller.js");
  const categories = require("../controllers/categories.controller.js");
  const brand = require("../controllers/brand.controller.js");
  const attributes = require("../controllers/attributes.controller.js");
  const user = require("../controllers/user.controller.js");
  const color = require("../controllers/color.controller.js");
  const product = require("../controllers/product.controller.js");
  const language = require("../controllers/settings.controller.js");
  const currency = require("../controllers/settings.controller.js");
  const taxes = require("../controllers/settings.controller.js");
  const pickpoint = require("../controllers/pickPoint.controller.js");
  const blog = require("../controllers/blogs.controller.js");
  const uploadfiles = require("../controllers/upload.controller.js");
  const flashdeal = require("../controllers/flashDeals.controller.js");
  const businessSettings = require("../controllers/businessSettings.controller.js");
  const staff = require("../controllers/staff.controller.js");
  const customerslist = require("../controllers/customers.controller.js");
  const sales = require("../controllers/sales.controller.js");
  const seller = require("../controllers/seller.controller.js");
  const subscriber = require("../controllers/subscribers.controller.js");
  const coupons = require("../controllers/coupons.controller.js");
  const ticket = require("../controllers/support.controller.js");
  const reports = require("../controllers/reports.controller.js");
  const dashboard = require("../controllers/dashboard.controller.js");
  const translation = require("../controllers/translation.controller.js");
  const shipping = require("../controllers/shipping.controller.js");
  const page = require("../controllers/pages.controller.js");
  const orders = require("../customerControllers/custOrder.controller.js");
  const customerPayment = require("../customerControllers/custPayment.controller.js");
  const custTickets = require("../customerControllers/custTickets.controller.js");
  const master = require("../controllers/masters.controller.js");
  const option = require("../controllers/option.controller.js");
  const services = require("../controllers/servicesProduct.controller.js");
  const branches = require("../controllers/branches.controller.js");
  const nodemailer = require("../controllers/nodemailer.controller.js");

  // Customers
  const custDashboard = require("../customerControllers/custDashboard.controller.js");
  const custWishlists = require("../customerControllers/custWishlist.controller.js"); 
  const carts = require("../customerControllers/carts.controller.js");
  const custUsers = require("../customerControllers/custUser.controller.js");
  const custProducts = require("../customerControllers/custProducts.controller.js");
  const custShipping = require("../customerControllers/custShipping.controllers.js");
  const custReviews = require("../customerControllers/custReviews.controller.js");
  const custConversation = require("../customerControllers/custConversation.controller.js");
  const custNotifications = require("../customerControllers/custNotification.controller.js");
  const custSubscriber = require("../customerControllers/custSubscribers.controller.js");
  const custUploads = require("../customerControllers/custUploads.controller.js");

  // Sellers
  const sellerDashboard = require("../sellerController/sellerDashboard.controller.js");
  const sellerProducts = require("../sellerController/sellerProducts.controller.js");
  const shopDetails = require("../sellerController/shopDetails.controller.js");
  const sellerUsers = require("../sellerController/sellerUser.controller.js");
  const sellers = require("../sellerController/sellers.controller.js");
  const sellerTickets = require("../sellerController/sellerTicket.controller.js");
  const commission = require("../sellerController/sellerCommissionHistory.controller.js");
  const sellerUploads = require("../sellerController/sellerUploads.controller.js");
  const sellerCoupons = require("../sellerController/sellerCoupons.controller.js");
  const sellerPaymentHistory = require("../sellerController/sellerPayment.controller.js");
  const sellerConversation = require("../sellerController/sellerConversations.controller.js");

  const multer = require('multer')
  const upload = multer({
    dest: 'uploads/',
    limits: {
      fileSize: 5242880
    } ,
    fileFilter(req, file, cb) {
      if (!file.originalname.match(/\.(jpg|jpeg|pdf|xlsx|png)$/)) {
        return cb(new Error('Please upload a Image'))
      }
      cb(undefined, true)
    }
  })

  var router = require("express").Router();

  // Auth
  // Login
  router.post("/login" , auth.login)
  // Verify Token
  router.post("/verify_token", auth.verifyToken);
  // Change Password
  router.post("/change_password/:id", auth.changePassword);
  // reset_password
  router.post("/forgot_password", auth.resetPassword);

  // Newsletter Mail
  router.post("/send_newsletter_mail", nodemailer.NewsletterMail);

  // ========================== ADMIN ============================ //
  // Dashboard Keywords
  router.get("/get_admin_dashboard/:keyword", dashboard.getAdminDashboard);

  // Product
  router.get("/get_products", product.getProducts);
  router.get("/get_products_by_added/:role", product.getProductsByAdded);
  router.post("/save_product", upload.fields([
    { name: "pdf", maxCount: 1 },
    { name: "meta_img", maxCount: 1 },
    { name: "photos", maxCount: 10 },
    { name: "thumbnail_img", maxCount: 10 },
  ]), function (req, res, next) {
    product.saveProduct(req, res, next)
  });
  router.put("/put_product/:id", upload.fields([
    { name: "pdf", maxCount: 1 },
    { name: "meta_img", maxCount: 1 },
    { name: "photos", maxCount: 1 },
    { name: "thumbnail_img", maxCount: 1 },
  ]), function (req, res, next) {
    product.putProduct(req, res, next)
  });
  router.get("/get_product_id/:id", product.getProductID);
  router.delete("/delete_product/:id" , product.deleteProduct);

  router.get("/get_seller_products_by_added/:user_id", product.getSellerProductsAddedBy);

  //Digital Product
  router.get("/get_digital_products", product.getDigitalProducts);
  router.get("/get_products_by_added/:role", product.getDigitalProductsByAdded);
  router.post("/save_digital_product", upload.fields([
    { name: "pdf", maxCount: 1 },
    { name: "meta_img", maxCount: 1 },
    { name: "photos", maxCount: 1 },
    { name: "thumbnail_img", maxCount: 1 },
  ]), function (req, res, next) {
    product.saveDigitalProduct(req, res, next)
  });
  router.put("/put_digital_product/:id", upload.fields([
    { name: "pdf", maxCount: 1 },
    { name: "meta_img", maxCount: 1 },
    { name: "photos", maxCount: 1 },
    { name: "thumbnail_img", maxCount: 1 },
  ]), function (req, res, next) {
    product.putDigitalProduct(req, res, next)
  });
  router.get("/get_digital_product_id/:id", product.getDigitalProductID);
  router.delete("/delete_digital_product/:id" , product.deleteDigitalProduct);

  // Category
  router.get("/get_categories" , categories.getCategories);
  router.post("/save_categories", upload.fields([
    { name: "banner", maxCount: 1 },
    { name: "icon", maxCount: 1 },
  ]), function (req, res, next) {
    categories.saveCategories(req, res, next)
  });
  router.put("/put_categories/:id", upload.fields([
    { name: "banner", maxCount: 1 },
    { name: "icon", maxCount: 1 },
  ]), function (req, res, next) {
    categories.putCategories(req, res, next)
  });
  router.get("/get_categories_id/:id", categories.getCategoriesID);
  router.delete("/delete_categories/:id", categories.deleteCategories);

  // Brand 
  router.get("/get_brand" , brand.getBrand);
  router.post("/save_brand", upload.fields([
    { name: "logo", maxCount: 1 },
  ]), function (req, res, next) {
    brand.saveBrand(req, res, next)
  });
  router.put('/put_brand/:id', upload.fields([{
    name: 'logo', maxCount: 1
  }]), function (req, res, next) {
    brand.putBrand(req, res, next)
  });
  router.get("/get_brand_id/:id" , brand.getBrandID);
  router.delete("/delete_brand/:id" , brand.deleteBrand);

  // Options 
  router.get("/get_options" , option.getOptions);
  router.post("/save_option" , option.saveOption);
  router.put("/put_option/:id" , option.putOption);
  router.get("/get_option_edit/:id" , option.getOptionEdit);
  router.delete("/delete_option/:id" , option.deleteOption);

  // Services 
  router.get("/get_services" , services.getServices);
  router.post("/save_service", upload.fields([
    { name: "images", maxCount: 10},
  ]), function (req, res, next) {
    services.saveService(req, res, next)
  });
  router.put('/put_service/:id', upload.fields([{
    name: 'images', maxCount: 10} 
  ]), function (req, res, next) {
    services.putService(req, res, next)
  });

  // Branches 
  router.get("/get_branches" , branches.getBranches);
  router.post("/save_branch" , branches.saveBranch);
  router.put("/put_branch/:id" , branches.putBranch);
  router.get("/get_branch_edit/:id" , branches.getBranchEdit);
  router.get("/get_branch_shopID/:id" , branches.getBranchShopID);
  router.delete("/delete_branch/:id" , branches.deleteBranch);

  router.get("/get_service_edit/:id" , services.getServiceEdit);
  router.delete("/delete_service/:id" , services.deleteService);

  // Attributes 
  router.get("/get_attributes", attributes.getAttributes);
  router.post("/save_attributes" , attributes.saveAttributes);
  router.put("/put_attributes/:id" , attributes.putAttributes);
  router.get("/get_attributes_id/:id" , attributes.getAttributesID);
  router.delete("/delete_attributes/:id" , attributes.deleteAttributes);

  // Attributes Values
  router.get("/get_attributes_values", attributes.getAttributeValues);
  router.put("/put_attribute_value/:attribute_id" , attributes.putAttributeValue);
  router.get("/get_attribute_value_id/:id" , attributes.getAttributeValueID);
  router.delete("/delete_attribute_value/:id" , attributes.deleteAttributeValue);

  // Colors 
  router.get("/get_colors" , color.getColors);
  router.post("/save_color" , color.saveColor);
  router.put("/put_color/:id" , color.putColor);
  router.get("/get_color_id/:id" , color.getColorID);
  router.delete("/delete_color/:id" , color.deleteColor);

  // Reviews Product
  router.get("/get_reviews_products", product.getReviewsProducts);
  router.put("/Update_review_status/:id", product.UpdateReviewStatus);

  // Orders List
  router.get("/get_all_orders_list", sales.getAllOrdersList);
  router.get("/get_all_orders_details/:id", sales.getAllOrderDetailsID);
  router.get("/get_inhouse_orders", sales.getInhouseOrders);
  router.get("/get_seller_orders", sales.getSellerOrders);
  router.get("/get_pickpoint_orders", sales.getPickPointOrders);
  router.get("/get_sales_list_id/:id", sales.getSalesListID);
  router.delete("/delete_sales_list/:id", sales.deleteSalesList);

  router.post("/save_order", sales.saveOrder);
  router.put("/update_order/:id", sales.updateOrder);

  // Customer List
  router.get("/get_customer_list", customerslist.getCustomerList);
  router.post("/save_customer", upload.fields([
    { name: "avatar", maxCount: 1 },
  ]), function (req, res, next) {
    customerslist.saveCustomer(req, res, next)
  });
  router.get("/get_customer_list_id/:id", customerslist.getCustomerListID);
  router.put("/ban_customer_id/:id", customerslist.BanCustomerID);
  // router.put("/put_customer_id/:id", customerslist.putCustomerList);
  router.put("/put_customer_id/:id", upload.fields([
    { name: "avatar", maxCount: 1 },
  ]), function (req, res, next) {
    customerslist.putCustomerList(req, res, next)
  });
  router.delete("/delete_customer_list/:id", customerslist.deleteCustomerList);

  // Seller List
  router.get("/get_seller_list", seller.getSellerList);
  router.get("/get_seller_edit/:id", seller.getSellerEdit);
  router.put("/ban_seller_id/:id", seller.BanSellerID);
  router.put("/put_seller_id/:id", seller.putSellerList);
  router.delete("/delete_seller/:id", seller.deleteSellerList);
  router.get("/get_seller_payouts", seller.getSellerPayouts);
  router.get("/get_seller_payouts_req", seller.getSellerPayoutsREQ);

  // Upload Files 
  router.get("/get_upload_files", uploadfiles.getUploadFiles);
  router.post("/save_upload_file", upload.fields([
    { name: "file_name", maxCount: 1 },
  ]), function (req, res, next) {
    uploadfiles.saveUploadFiles(req, res, next)
  });
  router.put("/put_upload_file/:id", upload.fields([
    { name: "file_name", maxCount: 1 },
  ]), function (req, res, next) {
    uploadfiles.putUploadFile(req, res, next)
  });
  router.get("/edit_upload_file/:id", uploadfiles.editUploadFile);
  router.put("/delete_uploads_file/:id", uploadfiles.deleteUploadFiles);

  // Reports 
  router.get("/get_reports_product_sale", reports.getReportsProductSale); // In-house products
  router.get("/get_reports_seller_sale", reports.getReportsSellerSale);
  router.get("/get_reports_product_stock", reports.getReportsProductStock);
  router.get("/get_reports_product_wishlist", reports.getReportsProductWishlist);
  router.get("/get_reports_user_search", reports.getReportsUserSearch);
  router.get("/get_reports_commission", reports.getReportsCommission);
  router.get("/get_reports_wallet_recharge", reports.getReportsWalletRecharge);

  // Blogs 
  router.get("/get_blogs", blog.getBlogs);
  // router.post("/save_blog", blog.saveBlog);
  router.post("/save_blog", upload.fields([
    { name: "file_name", maxCount: 1 },
  ]), function (req, res, next) {
    blog.saveBlog(req, res, next)
  });
  // router.put("/put_blog/:id" , blog.putBlog);
  router.put("/put_blog/:id", upload.fields([
    { name: "file_name", maxCount: 1 },
  ]), function (req, res, next) {
    blog.putBlog(req, res, next)
  });
  router.get("/get_blog_id/:id" , blog.getBlogID);
  router.delete("/delete_blog/:id" , blog.deleteBlog);

  // Blogs Categories
  router.get("/get_blog_categories", blog.getBlogCategories);
  router.post("/save_blog_category", blog.saveBlogCategory);
  router.put("/put_blog_category/:id", blog.putBlogCategory);
  router.get("/get_blog_category_id/:id", blog.getBlogCategoryID);
  router.delete("/delete_blog_category/:id", blog.deleteBlogCategory);

  // MARKETING
  // Flash Deal
  router.get("/get_flash_deal", flashdeal.getFlashDeal);
  router.post("/save_flash_deal", upload.fields([
    { name: "banner", maxCount: 1 },
  ]), function (req, res, next) {
    flashdeal.saveFlashDeal(req, res, next)
  });
  router.put("/put_flash_deal/:id", upload.fields([
    { name: "banner", maxCount: 1 },
  ]), function (req, res, next) {
    flashdeal.putFlashDeal(req, res, next)
  });
  router.get("/get_flash_deal_id/:id" , flashdeal.getFlashDealID);
  router.delete("/delete_flash_deal/:id" , flashdeal.deleteFlashDeal);

  // Subscribers
  router.get("/get_subscribers", subscriber.getSubscribers);
  router.delete("/delete_subscriber/:id", subscriber.deleteSubscriber);

  // Coupons
  router.get("/get_coupons", coupons.getCoupons);
  router.post("/save_coupons", coupons.saveCoupons);
  router.put("/put_coupons/:id", coupons.putCoupons);
  router.get("/get_coupon_id/:id" , coupons.getCouponsID);
  router.delete("/delete_coupon/:id" , coupons.deleteCoupons);

  // SUPPORTS
  // Tickets
  router.get("/get_tickets_list", ticket.getTicketsList);
  router.get("/get_ticket_id/:id", ticket.getTicketID);
  // Ticket reply
  router.get("/get_tickets_reply_list/:ticket_id", ticket.getTicketReply);
  router.post("/save_ticket_reply", upload.fields([
    { name: "files", maxCount: 1 },
  ]), function (req, res, next) {
    ticket.saveTicketReply(req, res, next)
  });
  router.put("/update_ticket_view/:keyword/:id", ticket.UpdateTicketView);
  
  // Conversation
  router.get("/get_conversation_list", ticket.getConversationList); 
  router.get("/get_conversation_id/:id", ticket.getConversationID);
  // Messages Conversation
  router.get("/get_message_reply_list/:conversation_id", ticket.getMessageReplyList); 
  router.post("/save_message_reply", ticket.saveMessageReply);

  // Business Settings
  router.get("/get_business_settings", businessSettings.getBusinessSettings);
  router.post("/save_business_setting", businessSettings.saveBusinessSetting);
  // router.put("/put_business_setting/:id", businessSettings.putBusinessSetting);
  router.put('/put_business_setting/:type', upload.fields([{
    name: 'value', maxCount: 1
  }]), function (req, res, next) {
    businessSettings.putBusinessSetting(req, res, next)
  });
  router.get("/get_business_setting_id/:type", businessSettings.getBusinessSettingID);
  router.delete("/delete_business_setting/:id", businessSettings.deleteBusinessSetting);

  // SETUP & CONFIGURATION
  // Languages  
  router.get("/get_languages", language.getLanguages);
  router.post("/save_language", language.saveLanguage);
  router.put("/put_language/:id" , language.putLanguage);
  router.put("/update_language_status/:id" , language.UpdateLanguageStatus);
  router.get("/get_language_id/:id" , language.getLanguageID);
  router.delete("/delete_language/:id" , language.deleteLanguage);
  router.post('/bulk_language_import', upload.single("languageimport"), language.languageImport);

  // Translation 
  router.get("/get_translations", translation.getTranslation);
  router.post("/save_translation", translation.saveTranslation);
  router.put("/put_translation/:id", translation.putTranslation);
  router.get("/get_translation_id/:id", translation.getTranslationID);
  router.delete("/delete_translation/:id", translation.deleteTranslation);  

  // Currency 
  router.get("/get_currencies", currency.getCurrency);
  router.post("/save_currency", currency.saveCurrency);
  router.put("/put_currency/:id" , currency.putCurrency);
  router.get("/get_currency_id/:id" , currency.getCurrencyID);
  router.delete("/delete_currency/:id" , currency.deleteCurrency);

  // Taxes 
  router.get("/get_taxes", taxes.getTaxes);
  router.post("/save_taxes", taxes.saveTaxes);
  router.put("/put_taxes/:id" , taxes.putTaxes);
  router.get("/get_taxes_id/:id" , taxes.getTaxesID);
  router.delete("/delete_taxes/:id" , taxes.deleteTaxes);

  // Pickpoint 
  router.get("/get_pickpoint", pickpoint.getPickPoint);
  router.post("/save_pickpoint", pickpoint.savePickPoint);
  router.put("/put_pickpoint/:id" , pickpoint.putPickPoint);
  router.get("/get_pickpoint_id/:id" , pickpoint.getPickPointID);
  router.delete("/delete_pickpoint/:id" , pickpoint.deletePickPoint);

  // Pages
  router.get("/get_pages", page.getPages);
  router.post("/save_page", page.savePage);
  router.put("/put_page/:id", page.putPage);
  router.get("/get_page_id/:id", page.getPageID);
  router.delete("/delete_page/:id", page.deletePage);

  // Shipping Info
  router.get("/get_shipping_info", shipping.getShippingInfo);
  router.post("/save_shipping_info", shipping.saveShippingInfo);
  router.put("/put_shipping_info/:id" , shipping.putShippingInfo);
  router.get("/get_shipping_info_id/:id" , shipping.getShippingInfoID);
  router.delete("/delete_shipping_info/:id" , shipping.deleteShippingInfo);

  // Shipping States
  router.get("/get_states", shipping.getStates);
  router.post("/save_state", shipping.saveState);
  router.get("/get_state_id/:id", shipping.getStateID);
  router.put("/put_state/:id", shipping.putState);
  router.delete("/delete_state/:id", shipping.deleteState);

  // Shipping City
  router.get("/get_cities", shipping.getCities);
  router.post("/save_city", shipping.saveCity);
  router.get("/get_city_id/:id", shipping.getCityID);
  router.put("/put_city/:id", shipping.putCity);
  router.delete("/delete_city/:id", shipping.deleteCity);

  // Shipping Countries
  router.get("/get_countries", shipping.getCountries);
  router.get("/get_country_id/:id", shipping.getCountryID);

  // Shipping Zones
  router.get("/get_zones", shipping.getZones);
  router.post("/save_zone", shipping.saveZone);
  router.get("/get_zone_id/:id", shipping.getZoneID);
  router.put("/put_zone/:id", shipping.putZone);
  router.delete("/delete_zone/:id", shipping.deleteZone);
  
  // Shipping Carriers
  router.get("/get_carriers", shipping.getCarriers);
  router.post("/save_carrier", upload.fields([
    { name: "logo", maxCount: 1 },
  ]), function (req, res, next) {
    shipping.saveCarrier(req, res, next)
  });
  router.get("/get_carrier_id/:id", shipping.getCarrierID);
  router.put("/put_carrier/:id", shipping.putCarrier);
  router.delete("/delete_carrier/:id", shipping.deleteCarrier);

  // Staff
  // All Staff
  router.get("/get_staff", staff.getStaff);
  router.post("/save_staff", staff.saveStaff);
  router.put("/put_staff/:id", staff.putStaff);
  router.get("/get_staff_id/:id" , staff.getStaffID);
  router.delete("/delete_staff/:id" , staff.deleteStaff);

  // Roles
  router.get("/get_roles", staff.getRoles);
  router.post("/save_role", staff.saveRole);
  router.put("/put_role/:id", staff.putRole);
  router.get("/get_role_id/:id", staff.getRoleID);
  router.delete("/delete_role/:id", staff.deleteRole);

  // Role Permission
  router.get("/get_role_permission", staff.getRolePermission);
  router.post("/save_role_permission", staff.saveRolePermission);
  router.get("/get_role_permission_id/:id", staff.getRolePermissionID);
  router.put("/put_role_permission/:role_id", staff.putRolePermission);
  router.delete("/delete_role_permission/:id", staff.deleteRolePermission);

  // Users
  router.get("/get_users", user.getUsers);
  router.post("/save_user", upload.fields([
    { name: "avatar", maxCount: 1 },
  ]), function (req, res, next) {
    user.saveUser(req, res, next)
  });
  router.put("/put_user/:id", upload.fields([
    { name: "avatar", maxCount: 1 },
  ]), function (req, res, next) {
    user.putUser(req, res, next)
  });
  router.get("/get_user_id/:id" , user.getUserID);
  router.delete("/delete_user/:id" , user.deleteUser);

  // Master
  // Delivery Status
  router.get("/get_delivery_status", master.getDeliveryStatus);
  router.put("/put_delivery_status/:id", master.putDeliveryStatus);
  router.post("/save_delivery_status", master.saveDeliveryStatus);
  router.put("/delete_delivery_status/:id", master.deleteDeliveryStatus);

  // Payment Status
  router.get("/get_payment_status", master.getPaymentStatus);
  router.put("/put_payment_status/:id", master.putPaymentStatus);
  router.post("/save_payment_status", master.savePaymentStatus);
  router.put("/delete_payment_status/:id", master.deletePaymentStatus);

  // Shipping Type
  router.get("/get_shipping_type", master.getShippingType);
  router.put("/put_shipping_type/:id", master.putShippingType);
  router.post("/save_shipping_type", master.saveShippingType);
  router.put("/delete_shipping_type/:id", master.deleteShippingType);

  //======================== Customers-Login ==============================//

  // Cust Dashboard
  router.get("/get_cust_dashboard/:keyword/:user_id", custDashboard.getCustDashboard);

  // Product
  router.get("/get_cust_products", custProducts.getCustProducts);
  router.get("/get_cust_product_id/:id", custProducts.getCustProductID);
  router.get("/get_product_price_range", custProducts.getProductsPriceRange);

  // Customers Wishlists
  router.get("/get_cust_wishlists/:user_id", custWishlists.getWishlists);
  router.post("/save_cust_wishlist", custWishlists.saveWishlist);
  router.delete("/delete_cust_wishlist/:id", custWishlists.deleteWishlist);

  // Cust Carts
  router.get("/get_carts", carts.getCarts);
  router.post("/save_cart", carts.saveCart);
  router.put("/put_cart/:id" , carts.putCart);
  router.get("/get_cart_id/:id" , carts.getCartID);
  router.delete("/delete_cart/:id" , carts.deleteCart);

  // Cust Shipping Addresses Info
  router.get("/get_cust_shipping_info/:user_id", custShipping.getCustShipping);
  router.post("/save_cust_shipping_info", custShipping.saveCustShipping);
  router.put("/put_cust_shipping_info/:id" , custShipping.putCustShipping);
  router.get("/get_cust_shipping_info_id/:id" , custShipping.getCustShippingID);
  router.delete("/delete_cust_shipping_info/:id" , custShipping.deleteCustShipping);
  router.put("/update_shipping_default/:keyword/:id" , custShipping.UpdateShippingDefault);

  // Cust State
  router.get("/get_cust_shipping_state", custShipping.getCustShippingStates);
  router.get("/get_cust_shipping_state_id/:id", custShipping.getCustShippingStateID);
  // Cust City
  router.get("/get_cust_shipping_cities", custShipping.getCustShippingCities);
  router.get("/get_cust_shipping_city_id/:id", custShipping.getCustShippingCityID);
  // Cust Country
  router.get("/get_cust_shipping_countries", custShipping.getCustShippingCountries);
  router.get("/get_cust_shipping_country_id/:id", custShipping.getCustShippingCountryID);

  // Cust Orders
  router.get("/get_cust_orders/:user_id", orders.getCustOrders);
  router.post("/save_cust_order", orders.saveCustOrder);
  router.get("/get_cust_order_id/:id" , orders.getCustOrderID);
  router.delete("/delete_cust_order/:id" , orders.deleteCustOrder);
  router.put("/update_cust_orders_view/:keyword/:id" , orders.UpdateCustOrdersView); 

  // Order Tracks
  router.get("/get_cust_order_track", orders.getCustOrdersTrack);

  // Customer Payment
  router.get("/get_customer_payment", customerPayment.getCustomerPayment);
  router.post("/save_customer_payment", customerPayment.saveCustomerPayment);

  // Verify Email
  router.post("/verify_email", custUsers.verifyEmail);

  // Customer reviews
  router.get("/get_cust_reviews", custReviews.getCustReviews);
  router.post("/save_cust_review", custReviews.saveCustReview);
  router.put("/put_cust_review/:id", custReviews.putCustReview);
  router.get("/get_cust_review_id/:id", custReviews.getCustReviewID);
  router.delete("/delete_cust_review/:id", custReviews.deleteCustReview);

  // Upload Files 
  router.get("/get_cust_upload_files/:user_id", custUploads.getCustUploadFiles);

  // Cust Conversation
  router.post("/save_cust_conversation", custConversation.saveCustConversation);
  router.get("/get_cust_conversation/:sender_id", custConversation.getCustConversation); 
  router.get("/get_cust_conversation_id/:id", custConversation.getCustConversationID); 

  // Cust Messages  
  router.get("/get_cust_messages/:conversation_id", custConversation.getCustMessages); 
  router.post("/save_cust_message", custConversation.saveCustMessage); 

  // Cust Notifications
  router.get("/get_cust_notifications/:notifiable_id", custNotifications.getCustNotifications);

  // Cust Tickets
  router.get("/get_cust_ticket_list/:user_id", custTickets.getCustTicketList);
  router.get("/get_cust_ticket_id/:id", custTickets.getCustTicketID);
  router.post("/save_cust_ticket", upload.fields([
    { name: "files", maxCount: 1 },
  ]), function (req, res, next) {
    custTickets.saveCustTicket(req, res, next)
  });
  router.get("/get_cust_ticket_reply/:ticket_id", custTickets.getCustTicketReplyList);
  router.post("/save_cust_ticket_reply", upload.fields([
    { name: "files", maxCount: 1 },
  ]), function (req, res, next) {
    custTickets.saveCustTicketReply(req, res, next)
  });

  // Subscribers
  router.post("/save_cust_subscriber", custSubscriber.saveCustSubscribers); 

  // Cust Users
  router.get("/get_cust_users", custUsers.getCustUsers);
  router.post("/save_cust_user", upload.fields([
    { name: "avatar", maxCount: 1 },
  ]), function (req, res, next) {
    custUsers.saveCustUser (req, res, next)
  });
  // Customer Users Update
  router.put("/put_cust_user/:id", upload.fields([
    { name: "avatar", maxCount: 1 },
  ]), function (req, res, next) {
    custUsers.putCustUser(req, res, next)
  });
  // Customer Profile Update
  router.put("/put_cust_profile/:id", upload.fields([
    { name: "avatar", maxCount: 1 },
  ]), function (req, res, next) {
    custUsers.putCustProfile(req, res, next)
  });
  router.get("/get_cust_user_id/:id" , custUsers.getCustUserID);
  router.delete("/delete_cust_user/:id" , custUsers.deleteCustUser);

  // ============================== SELLER-LOGIN ================================== //
  // Seller Dashboard
  router.get("/get_seller_dashboard/:keyword/:user_id", sellerDashboard.getSellerDashboard);
  
  // Seller Products
  router.get("/get_seller_products_list/:user_id", sellerProducts.getSellerProducts);
  // Seller Digital Products
  router.get("/get_seller_digital_products_list/:user_id", sellerProducts.getSellerDigitalProducts);
  // product_bulk_import
  router.post('/bulk_product_import/:user_id', upload.single("bulkimport"), sellerProducts.bulkImport);
  // Seller Products Reviews
  router.get("/get_seller_product_reviews/:user_id", sellerProducts.getSellerProductReviews);

  // Seller Upload Files 
  router.get("/get_seller_upload_files/:user_id", sellerUploads.getSellerUploadFiles);
  router.post("/save_seller_upload_file", upload.fields([
    { name: "file_name", maxCount: 1 },
  ]), function (req, res, next) {
    sellerUploads.saveSellerUploadFiles(req, res, next)
  });
  router.put("/delete_seller_uploads_file/:id" , sellerUploads.deleteSellerUploadFiles);

  // Seller Coupons
  router.get("/get_seller_coupons_list/:user_id", sellerCoupons.getSellerCoupons);
  router.post("/save_seller_coupon", sellerCoupons.saveSellerCoupon);
  router.put("/put_seller_coupon/:id", sellerCoupons.putSellerCoupon);
  router.get("/get_seller_coupon_id/:id" , sellerCoupons.getSellerCouponID);
  router.delete("/delete_seller_coupon/:id" , sellerCoupons.deleteSellerCoupon);

  // Seller Shop Details
  router.get("/get_shop_details/:user_id", shopDetails.getShopDetails);
  router.post("/save_shop_detail", upload.fields([
    { name: "logo", maxCount: 1 },
    { name: "sliders", maxCount: 1 },
  ]), function (req, res, next) {
    shopDetails.saveShopDetail(req, res, next)
  });
  router.put("/put_shop_detail/:id", upload.fields([
    { name: "logo", maxCount: 1 },
    { name: "sliders", maxCount: 1 },
  ]), function (req, res, next) {
    shopDetails.putShopDetail(req, res, next)
  });
  router.get("/get_shop_detail_id/:id", shopDetails.getShopDetailID);

  // Seller Payments History
  router.get("/get_seller_payment_history/:seller_id", sellerPaymentHistory.getSellerPayment);

  // Seller Money Withdraw Request
  router.get("/get_seller_money_withdraw/:user_id", sellerPaymentHistory.getSellerMoneyWithdraw);
  router.post("/save_seller_money_withdraw", sellerPaymentHistory.saveSellerMoneyWithdraw);

  // Commission History
  router.get("/get_seller_commission_historyID/:seller_id", commission.getSellerCommissionHistoryID);

  // Sellers
  router.get("/get_sellers", sellers.getSellers);
  router.put("/put_seller/:id", sellers.putSeller);

  // Seller Conversation
  router.get("/get_seller_conversation/:sender_id",sellerConversation.getSellerConversation); 
  router.get("/get_seller_conversation_id/:id", sellerConversation.getSellerConversationID); 

  // Seller Messages  
  router.get("/get_seller_messages/:conversation_id", sellerConversation.getSellerMessages); 

  // Seller Tickets
  router.get("/get_seller_ticket_list/:user_id", sellerTickets.getTicketUserID);
  router.get("/get_seller_ticket_id/:id", sellerTickets.getSellerTicketID);
  router.post("/save_seller_ticket", upload.fields([
    { name: "files", maxCount: 1 },
  ]), function (req, res, next) {
    sellerTickets.saveSellerTicket(req, res, next)
  });
  // Ticket reply
  router.get("/get_seller_tickets_reply_list/:ticket_id", sellerTickets.getSellerTicketReply);
  router.post("/save_seller_ticket_reply", upload.fields([
    { name: "files", maxCount: 1 },
  ]), function (req, res, next) {
    sellerTickets.saveSellerTicketReply(req, res, next)
  });

  // Seller Users
  router.get("/get_seller_users", sellerUsers.getSellerUsers);
  router.post("/save_seller_user", upload.fields([
    { name: "avatar", maxCount: 1 },
  ]), function (req, res, next) {
    sellerUsers.saveSellerUser (req, res, next)
  });
  router.put("/put_seller_user/:id", upload.fields([
    { name: "avatar", maxCount: 1 },
  ]), function (req, res, next) {
    sellerUsers.putSellerUser(req, res, next)
  });
  router.put("/put_seller_profile/:id", upload.fields([
    { name: "avatar", maxCount: 1 },
  ]), function (req, res, next) {
    sellerUsers.putSellerProfile(req, res, next)
  });
  router.get("/get_seller_user_id/:id" , sellerUsers.getSellerUserID);
  router.delete("/delete_seller_user/:id" , sellerUsers.deleteSellerUser);

  router.post("/create", upload.array('uploadimages'), images.create);
  router.get("/all-images", images.findAll);
  router.get("/favourite", images.findAllFeatured);
  router.delete("/delete/:id", images.delete);
  router.put("/update/:id", images.update);

  app.use(require('express').static('public'));
  app.use('/uploads', require('express').static('uploads'));
  app.use('/api/module', router);
  
};
