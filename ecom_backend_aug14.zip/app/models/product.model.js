const sql = require("./db.js");
const util = require('util');

// constructor
const Product = function (product) {
   this.id = product.id
   this.name = product.name
   this.added_by = product.added_by
   this.user_id = product.user_id
   this.category_id	 = product.category_id
   this.brand_id = product.brand_id
   this.photos	 = product.photos
   this.thumbnail_img = product.thumbnail_img
   this.video_provider = product.video_provider
   this.video_link = product.video_link
   this.tags = product.tags
   this.description = product.description
   this.unit_price = product.unit_price
   this.purchase_price = product.purchase_price
   this.variant_product = product.variant_product
   this.attributes = product.attributes
   this.choice_options = product.choice_options
   this.colors = product.colors
   this.variations = product.variations
   this.todays_deal = product.todays_deal
   this.published = product.published
   this.approved = product.approved
   this.stock_visibility_state = product.stock_visibility_state
   this.cash_on_delivery = product.cash_on_delivery
   this.featured = product.featured
   this.seller_featured = product.seller_featured
   this.current_stock = product.current_stock
   this.unit = product.unit
   this.weight = product.weight
   this.min_qty = product.min_qty
   this.low_stock_quantity = product.low_stock_quantity
   this.discount = product.discount	
   this.discount_type = product.discount_type
   this.discount_start_date = product.discount_start_date
   this.discount_end_date = product.discount_end_date
   this.tax = product.tax
   this.tax_type = product.tax_type
   this.shipping_type = product.shipping_type
   this.shipping_cost = product.shipping_cost
   this.is_quantity_multiplied = product.is_quantity_multiplied
   this.est_shipping_days = product.est_shipping_days
   this.num_of_sale = product.num_of_sale
   this.meta_title = product.meta_title
   this.meta_description = product.meta_description
   this.meta_img = product.meta_img
   this.pdf = product.pdf
   this.slug = product.slug
   this.rating = product.rating
   this.barcode = product.barcode
   this.digital = product.digital
   this.auction_product = product.auction_product
   this.file_name = product.file_name
   this.file_path = product.file_path
   this.external_link = product.external_link
   this.external_link_btn = product.external_link_btn
   this.wholesale_product = product.wholesale_product
};

Product.getProducts = (result) => {
    let query = "select p.*, cat.name as category_name, br.name as brand_name, us.name as user_name, col.name as color_name, att.name as attributes_name, av.value as attribute_values, up.file_name as image, ps.variant as variant, ps.sku as sku, ps.price as price, ps.qty as qty, fdp.discount as discount_flash, fdp.discount_type as discount_type_flash, sh.name as shop_name, br.logo as brand_logo from products as p "

    query += ` LEFT JOIN categories as cat on (cat.id = p.category_id) `
    query += ` LEFT JOIN brands as br on (br.id = p.brand_id) `
    query += ` LEFT JOIN users as us on (us.id = p.user_id) `
    query += ` LEFT JOIN colors as col on (col.id = p.colors) ` 
    query += ` LEFT JOIN attributes as att on (att.id = p.attributes) `
    query += ` LEFT JOIN attribute_values as av on (att.id = av.attribute_id) `
    query += ` LEFT JOIN uploads as up on (us.id = up.user_id) `
    query += ` LEFT JOIN sellers as sel on (us.id = sel.user_id) `
    query += ` LEFT JOIN shops as sh on (us.id = sh.user_id) `
    query += ` LEFT JOIN product_stocks as ps on (p.id = ps.product_id) `
    query += ` LEFT JOIN flash_deal_products as fdp on (p.id = fdp.product_id) `
    query += ` WHERE p.digital = 0 and us.banned = 0 `
    query += ` GROUP BY p.id `
    query += ` ORDER BY p.id `
    
    sql.query(query, (err, res) => {
      if (err) {
        result(null, err);
        return;
      }
      result(null, res);
    });
};

Product.getProductsByAdded = (queryString, role, result) => {
  let query = "select p.*, cat.name as category_name, br.name as brand_name, us.name as user_name, col.name as color_name, att.name as attributes_name, av.value as attribute_values, up.file_name as image, ps.variant as variant, ps.sku as sku, ps.price as price, ps.qty as qty, fdp.discount as discount_flash, fdp.discount_type as discount_type_flash, sh.name as shop_name, br.logo as brand_logo from products as p "

  query += ` LEFT JOIN categories as cat on (cat.id = p.category_id) `
  query += ` LEFT JOIN brands as br on (br.id = p.brand_id) `
  query += ` LEFT JOIN users as us on (us.id = p.user_id) `
  query += ` LEFT JOIN colors as col on (col.id = p.colors) ` 
  query += ` LEFT JOIN attributes as att on (att.id = p.attributes) `
  query += ` LEFT JOIN attribute_values as av on (att.id = av.attribute_id) `
  query += ` LEFT JOIN uploads as up on (us.id = up.user_id) `
  query += ` LEFT JOIN sellers as sel on (us.id = sel.user_id) `
  query += ` LEFT JOIN shops as sh on (us.id = sh.user_id) `
  query += ` LEFT JOIN product_stocks as ps on (p.id = ps.product_id) `
  query += ` LEFT JOIN flash_deal_products as fdp on (p.id = fdp.product_id) `
  query += ` WHERE p.digital = 0 and us.banned = 0 `

  if (role == 0) {
    query += ` GROUP BY p.id `
  }
  else if (role == 1) {
    query += ` AND p.digital = 0 and us.banned = 0 and us.user_type = 'admin' and p.added_by = 'admin' `
    query += ` GROUP BY p.id `
  }
  else if (role == 2) {
    query += ` AND p.digital = 0 and us.banned = 0 and us.user_type = 'customer' and p.added_by = 'customer'`
    query += ` GROUP BY p.id `
  }
  else if (role == 3) {
    query += ` AND p.digital = 0 and us.banned = 0 and us.user_type = 'seller' and p.added_by = 'seller'`
    query += ` GROUP BY p.id `
  }

  // Sort By
  if (queryString.order_by) {
    let orderByString = queryString.order_by.split('|')
    query += " order by " + `${orderByString[0]} ${orderByString[1]} `
  }
  else {
    query += " order by p.id desc"
  }
  
  sql.query(query, role, (err, res) => {
    if (err) {
      result(null, err);
      return;
    }
    result(null, res);
  });
};

Product.saveProduct = (data, result) => {
    console.log(data);
    let query = "INSERT INTO products SET ?";
    sql.query(query, data, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      result(null, res);
    });
  };

  Product.putProduct = (id, data, result) => {

    // let name = data.name || null;
    // let added_by = data.added_by || null;
    // let user_id = data.user_id || null;
    // let category_id	 = data.category_id || null;
    // let brand_id = data.brand_id || null;
    // let photos	 = data.photos || null;
    // let thumbnail_img = data.thumbnail_img || null;
    // let video_provider = data.video_provider || null;
    // let video_link = data.video_link || null;
    // let tags = data.tags || null;
    // let description = data.description || null;
    // let unit_price = data.unit_price || null;
    // let purchase_price = data.purchase_price || null;
    // let variant_product = data.variant_product || null;
    // let attributes = data.attributes || null;
    // let choice_options = data.choice_options || null;
    // let colors = data.colors || null;
    // let variations = data.variations || null;
    // let todays_deal = data.todays_deal || null;
    // let published = data.published || null; 
    // let approved = data.approved || null;
    // let stock_visibility_state = data.stock_visibility_state || null;
    // let cash_on_delivery = data.cash_on_delivery || null;
    // let featured = data.featured || null;
    // let seller_featured = data.seller_featured || null;
    // let current_stock = data.current_stock || null;
    // let unit = data.unit || null;
    // let weight = data.weight || null;
    // let min_qty = data.min_qty || null;
    // let low_stock_quantity = data.low_stock_quantity || null;
    // let discount = data.discount || null;
    // let discount_type = data.discount_type || null;
    // let discount_start_date = data.discount_start_date || null;
    // let discount_end_date = data.discount_end_date || null;
    // let tax = data.tax || null;
    // let tax_type = data.tax_type || null;
    // let shipping_type = data.shipping_type || null;
    // let shipping_cost = data.shipping_cost || null;
    // let is_quantity_multiplied = data.is_quantity_multiplied || null;
    // let est_shipping_days = data.est_shipping_days || null;
    // let num_of_sale = data.num_of_sale || null;
    // let meta_title = data.meta_title || null;
    // let meta_description = data.meta_description || null;
    // let meta_img = data.meta_img || null;
    // let pdf = data.pdf || null;
    // let slug = data.slug || null;
    // let rating = data.rating || null;
    // let barcode = data.barcode || null;
    // let digital = data.digital || null;
    // let auction_product = data.auction_product || null;
    // let file_name = data.file_name || null;
    // let file_path = data.file_path || null;
    // let external_link = data.external_link || null;
    // let external_link_btn = data.external_link_btn || null;
    // let wholesale_product = data.wholesale_product || null;

    const updates = [];
    if (data.name!='') updates.push(`name = '${data.name}'`);
    if (data.added_by!='') updates.push(`added_by = '${data.added_by}'`);
    if (data.user_id!='') updates.push(`user_id = '${data.user_id}'`);
    if (data.category_id!='') updates.push(`category_id = '${data.category_id}'`);
    if (data.brand_id!='') updates.push(`brand_id = '${data.brand_id}'`);
    if (data.photos!='') updates.push(`photos = '${data.photos}' `);
    if (data.thumbnail_img!='') updates.push(`thumbnail_img = '${data.thumbnail_img}' `);
    if (data.video_provider!='') updates.push(`video_provider = '${data.video_provider}' `);
    if (data.video_link!='') updates.push(`video_link = '${data.video_link}' `);
    if (data.tags!='') updates.push(`tags = '${data.tags}' `);
    if (data.description!='') updates.push(`description = '${data.description}' `);
    if (data.unit_price!='') updates.push(`unit_price = '${data.unit_price}' `);
    if (data.purchase_price!='') updates.push(`purchase_price = '${data.purchase_price}' `);
    if (data.variant_product!='') updates.push(`variant_product = '${data.variant_product}' `);
    if (data.attributes!='') updates.push(`attributes = '${data.attributes}' `);
    if (data.choice_options!='') updates.push(`choice_options = '${data.choice_options}' `);
    if (data.colors!='') updates.push(`colors = '${data.colors}' `);
    if (data.variations!='') updates.push(`variations = '${data.variations}' `);
    if (data.todays_deal!='') updates.push(`todays_deal = '${data.todays_deal}' `);
    if (data.published!='') updates.push(`published = '${data.published}' `);
    if (data.approved!='') updates.push(`approved = '${data.approved}' `);
    if (data.stock_visibility_state!='') updates.push(`stock_visibility_state = '${data.stock_visibility_state}' `);
    if (data.cash_on_delivery!='') updates.push(`cash_on_delivery = '${data.cash_on_delivery}' `);
    if (data.featured!='') updates.push(`featured = '${data.featured}' `);
    if (data.seller_featured!='') updates.push(`seller_featured = '${data.seller_featured}' `);
    if (data.current_stock!='') updates.push(`current_stock = '${data.current_stock}' `);
    if (data.unit!='') updates.push(`unit = '${data.unit}' `);
    if (data.weight!='') updates.push(`weight = '${data.weight}' `);
    if (data.min_qty!='') updates.push(`min_qty = '${data.min_qty}' `);
    if (data.low_stock_quantity!='') updates.push(`low_stock_quantity = '${data.low_stock_quantity}' `);
    if (data.discount!='') updates.push(`discount = '${data.discount}' `);
    if (data.discount_type!='') updates.push(`discount_type = '${data.discount_type}' `);
    if (data.discount_start_date!='') updates.push(`discount_start_date = '${data.discount_start_date}' `);
    if (data.discount_end_date!='') updates.push(`discount_end_date = '${data.discount_end_date}' `);
    if (data.tax!='') updates.push(`tax = '${data.tax}' `);
    if (data.tax_type!='') updates.push(`tax_type = '${data.tax_type}' `);
    if (data.shipping_type!='') updates.push(`shipping_type = '${data.shipping_type}' `);
    if (data.shipping_cost!='') updates.push(`shipping_cost = '${data.shipping_cost}' `);
    if (data.is_quantity_multiplied!='') updates.push(`is_quantity_multiplied = '${data.is_quantity_multiplied}' `);
    if (data.est_shipping_days!='') updates.push(`est_shipping_days = '${data.est_shipping_days}' `);
    if (data.num_of_sale!='') updates.push(`num_of_sale = '${data.num_of_sale}' `);
    if (data.meta_title!='') updates.push(`meta_title = '${data.meta_title}' `);
    if (data.meta_description!='') updates.push(`meta_description = '${data.meta_description}' `);
    if (data.meta_img!='') updates.push(`meta_img = '${data.meta_img}' `);
    if (data.pdf!='') updates.push(`pdf = '${data.pdf}' `);
    if (data.slug!='') updates.push(`slug = '${data.slug}' `);
    if (data.rating!='') updates.push(`rating = '${data.rating}' `);
    if (data.barcode!='') updates.push(`barcode = '${data.barcode}' `);
    if (data.digital!='') updates.push(`digital = '${data.digital}' `);
    if (data.auction_product!='') updates.push(`auction_product = '${data.auction_product}' `);
    if (data.file_name!='') updates.push(`file_name = '${data.file_name}' `);
    if (data.external_link!='') updates.push(`external_link = '${data.external_link}' `);
    if (data.external_link_btn!='') updates.push(`external_link_btn = '${data.external_link_btn}' `);
    if (data.wholesale_product!='') updates.push(`wholesale_product = '${data.wholesale_product}' `);
  
    if (updates.length === 0) {
      res.status(400).json({status: (400), message: "No updates provided" });
      return;
    }
  
    let query = `UPDATE products SET ${updates.join(", ")} WHERE id = ? `
   
   
    // let query = " UPDATE products SET name = '" +name+ "', added_by = '" +added_by+ "',  user_id =  " + user_id + " , category_id =  " + category_id + " , brand_id =  " + brand_id + " ,  photos ='"+photos+"', thumbnail_img = ' " + thumbnail_img + " ' , video_provider = '" +video_provider+ "', video_link = '" +video_link+ "', tags = '" +tags+ "', description = '" +description+ "', unit_price = " + unit_price + ",  purchase_price =  " + purchase_price + " , variant_product =  " + variant_product + " , attributes = '" +attributes+ "', choice_options = '" +choice_options+ "', colors = '" +colors+ "',  variations = '" +variations+ "',  todays_deal =  " + todays_deal + " ,  published =  " + published + " ,  approved =  " + approved + " , stock_visibility_state = '" +stock_visibility_state+ "', cash_on_delivery =  " + cash_on_delivery + " , featured =  " + featured + " , seller_featured =  " + seller_featured + " , current_stock =  " + current_stock + " , unit = '" +unit+ "', weight =  " + weight + " , min_qty =  " + min_qty + " ,  low_stock_quantity =  " + low_stock_quantity + " ,  discount =  " + discount + " , discount_type = '" +discount_type+ "', discount_start_date =  " + discount_start_date + " ,  discount_end_date =  " + discount_end_date + " ,  tax =  " + tax + " ,  tax_type = '" +tax_type+ "',  shipping_type = '" +shipping_type+ "',  shipping_cost =  " + shipping_cost + " , is_quantity_multiplied =  " + is_quantity_multiplied + " , est_shipping_days =  " + est_shipping_days + " , num_of_sale =  " + num_of_sale + " , meta_title = ' " + meta_title + " ' , meta_description = ' " + meta_description + " ' ,  meta_img = '" +meta_img+ "', pdf = '" +pdf+ "', slug = ' " + slug + " ' , rating =  " + rating + " , barcode = '" +barcode+ "', digital =  " + digital + " ,  auction_product =  " + auction_product + " , file_name = '" +file_name+ "',  file_path = '" +file_path+ "',  external_link = '" +external_link+ "',  external_link_btn = '" +external_link_btn+ "',  wholesale_product =  " + wholesale_product + " , updated_at = now() WHERE id = ? "

    
    sql.query(query, id, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      if (res.affectedRows == 0) {
        result({ kind: "not_found" }, null);
        return;
      }
      console.log("updated products : ", { id: id, ...data });
      result(null, data.id);
    });
  };

  Product.getProductID = (id , result) => {
    let query = "select p.*, cat.name as category_name, br.name as brand_name, us.name as user_name, col.name as color_name, att.name as attributes_name, av.value as attribute_values, up.file_name as image, ps.variant as variant, ps.sku as sku, ps.price as price, ps.qty as qty, fdp.discount as discount_flash, fdp.discount_type as discount_type_flash, sh.name as shop_name, br.logo as brand_logo from products as p "

    query += ` LEFT JOIN categories as cat on (cat.id = p.category_id) `
    query += ` LEFT JOIN brands as br on (br.id = p.brand_id) `
    query += ` LEFT JOIN users as us on (us.id = p.user_id) `
    query += ` LEFT JOIN colors as col on (col.id = p.colors) ` 
    query += ` LEFT JOIN attributes as att on (att.id = p.attributes) `
    query += ` LEFT JOIN attribute_values as av on (att.id = av.attribute_id) `
    query += ` LEFT JOIN uploads as up on (us.id = up.user_id) `
    query += ` LEFT JOIN sellers as sel on (us.id = sel.user_id) `
    query += ` LEFT JOIN shops as sh on (us.id = sh.user_id) `
    query += ` LEFT JOIN product_stocks as ps on (p.id = ps.product_id) `
    query += ` LEFT JOIN flash_deal_products as fdp on (p.id = fdp.product_id) `
    query += ` WHERE p.digital = 0 and us.banned = 0 and p.id = ? `
    query += ` GROUP BY p.id `
    query += ` ORDER BY p.id `
  
    sql.query(query, id, (err, res) => {
      if (err) {
        result(null, err);
        return;
      }
      result(null, res[0]);
      console.log(null, res[0]);
    });
    };

  Product.deleteProduct = (id, result) => {
    console.log(id);
    let query = "DELETE FROM products WHERE id = ?";
    sql.query(query, id, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      if (res.affectedRows == 0) {
        // not found Contact with the id
        result({ kind: "not_found" }, null);
        return;
      }
      console.log("deleted Product : ", { id: id });
      result(null, res);
    });
  };

  Product.getSellerProductsAddedBy = (queryString, user_id, result) => {
    let query = "select p.*, cat.name as category_name, br.name as brand_name, us.name as user_name, col.name as color_name, att.name as attributes_name, av.value as attribute_values, up.file_name as image, ps.variant as variant, ps.sku as sku, ps.price as price, ps.qty as qty, fdp.discount as discount_flash, fdp.discount_type as discount_type_flash, sh.name as shop_name, br.logo as brand_logo from products as p "
  
    query += ` LEFT JOIN categories as cat on (cat.id = p.category_id) `
    query += ` LEFT JOIN brands as br on (br.id = p.brand_id) `
    query += ` LEFT JOIN users as us on (us.id = p.user_id) `
    query += ` LEFT JOIN colors as col on (col.id = p.colors) ` 
    query += ` LEFT JOIN attributes as att on (att.id = p.attributes) `
    query += ` LEFT JOIN attribute_values as av on (att.id = av.attribute_id) `
    query += ` LEFT JOIN uploads as up on (us.id = up.user_id) `
    query += ` LEFT JOIN sellers as sel on (us.id = sel.user_id) `
    query += ` LEFT JOIN shops as sh on (us.id = sh.user_id) `
    query += ` LEFT JOIN product_stocks as ps on (p.id = ps.product_id) `
    query += ` LEFT JOIN flash_deal_products as fdp on (p.id = fdp.product_id) `
    query += ` WHERE p.digital = 0 and us.banned = 0 and p.user_id = ${user_id} and us.user_type = 'seller' `
  
    // Sort By
    if (queryString.order_by) {
      let orderByString = queryString.order_by.split('|')
      query += " order by " + `${orderByString[0]} ${orderByString[1]} `
    }
    else {
      query += " order by p.id desc"
    }
    
    sql.query(query, user_id, (err, res) => {
      if (err) {
        result(null, err);
        return;
      }
      result(null, res);
    });
  };

module.exports = Product;
