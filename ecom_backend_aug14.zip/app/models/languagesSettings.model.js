const sql = require("./db.js");
const util = require('util');
const { lang } = require("moment/moment.js");


// constructor
const Languages = function (language) {
   this.id = language.id;
   this.name = language.name;
   this.code = language.code;
   this.app_lang_code = language.app_lang_code;
   this.rtl	= language.rtl;
   this.status = language.status;
};

Languages.getLanguages = (result) => {
    let query = "select * from languages "
    
    sql.query(query, (err, res) => {
      if (err) {
        result(null, err);
        return;
      }
      result(null, res);
    });
};

Languages.saveLanguage = (data, result) => {
    console.log(data);
    let query = "INSERT INTO languages SET ?";
    sql.query(query, data, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      result(null, res);
    });
  };

  Languages.putLanguage = (id, data, result) => {

    // let name = data.name || null;
    // let code = data.code || null;
    // let app_lang_code = data.app_lang_code || null;
    // let rtl	= data.rtl || null;
    // let status = data.status || null;
   
    // let query = "UPDATE languages SET name = '"+name+"', code =  '"+ code +"', app_lang_code = '"+ app_lang_code +"',  rtl = "+rtl+", status = "+status+" , updated_at = now() WHERE id = ? "
         
  const updates = [];
  if (data.name!='') updates.push(`name = '${data.name}'`);
  if (data.code!='') updates.push(`code = '${data.code}'`);
  if (data.app_lang_code!='') updates.push(`app_lang_code = '${data.app_lang_code}'`);
  if (data.rtl!='') updates.push(`rtl = '${data.rtl}'`);
  if (data.status!='') updates.push(`status = '${data.status}'`);

  if (updates.length === 0) {
    res.status(400).json({status: (400), message: "No updates provided" });
    return;
  }

  let query = `UPDATE languages SET ${updates.join(", ")} WHERE id = ? `
  
    sql.query(query, id, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      if (res.affectedRows == 0) {
        result({ kind: "not_found" }, null);
        return;
      }
      console.log("Updated languages : ", { id: id, ...data });
      result(null, data.id);
    });
  };

  Languages.UpdateLanguageStatus = (id, data, result) => {

    let status = data.status || null;
   
    let query = "UPDATE languages SET status ='"+status+"' , updated_at = now() WHERE id = ? "
  
    sql.query(query, id, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      if (res.affectedRows == 0) {
        result({ kind: "not_found" }, null);
        return;
      }
      console.log("updated languages status : ", { id: id, ...data });
      result(null, data.id);
    });
  };

  Languages.getLanguageID = (id , result) => {
    let query = " SELECT * FROM languages WHERE id = ? "
  
    sql.query(query, id, (err, res) => {
      if (err) {
        result(null, err);
        return;
      }
      result(null, res[0]);
      console.log(null, res[0]);
    });
    };

    Languages.deleteLanguage = (id, result) => {
        console.log(id);
        let query = "DELETE FROM languages WHERE id = ?";
        sql.query(query, id, (err, res) => {
          if (err) {
            console.log(err)
            result(err, null);
            return;
          }
          if (res.affectedRows == 0) {
            result({ kind: "not_found" }, null);
            return;
          }
          console.log("deleted Languages : ", { id: id });
          result(null, res);
        });
      };

module.exports = Languages;
