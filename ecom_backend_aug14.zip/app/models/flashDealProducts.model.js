const sql = require("./db.js");

// constructor
const FlashDealProducts = function (flashdealproduct) {
  this.id = flashdealproduct.id;
  this.flash_deal_id = flashdealproduct.flash_deal_id;
  this.product_id = flashdealproduct.product_id;
  this.discount = flashdealproduct.discount;
  this.discount_type = flashdealproduct.discount_type;
};

FlashDealProducts.getFlashDealProducts = (result) => {
  let query = "select * from flash_deal_products "

  sql.query(query, (err, res) => {
    if (err) {
      result(null, err);
      return;
    }
    result(null, res);
  });
};

FlashDealProducts.saveFlashDealProduct = (data, result) => {
  console.log(data);
  let query = "INSERT INTO flash_deal_products SET ?";
  sql.query(query, data, (err, res) => {
    if (err) {
      console.log(err)
      result(err, null);
      return;
    }
    result(null, res);
  });
};

FlashDealProducts.putFlashDealProduct = (id, data, result) => {

  let flash_deal_id = data.flash_deal_id || null;
  let product_id = data.product_id || null;
  let discount = data.discount || null;
  let discount_type = data.discount_type || null;

  let query = "UPDATE flash_deal_products SET flash_deal_id = " + flash_deal_id + " , product_id = " + product_id + " , discount = " + discount + " , discount_type = ' " + discount_type + " ' , updated_at = now()  WHERE id = ? "

  sql.query(query, id, (err, res) => {
    if (err) {
      console.log(err)
      result(err, null);
      return;
    }
    if (res.affectedRows == 0) {
      result({ kind: "not_found" }, null);
      return;
    }
    console.log("updated flash deal product : ", { id: id, ...data });
    result(null, data.id);
  });
};


FlashDealProducts.getFlashDealProductID = (id, result) => {
  let query = " SELECT * FROM flash_deal_products WHERE id = ? "

  sql.query(query, id, (err, res) => {
    if (err) {
      result(null, err);
      return;
    }
    result(null, res);
    console.log(null, res);
  });
};

FlashDealProducts.deleteFlashDealProduct = (id, result) => {
  console.log(id);
  let query = "DELETE FROM flash_deal_products WHERE id = ?";
  sql.query(query, id, (err, res) => {
    if (err) {
      console.log(err)
      result(err, null);
      return;
    }
    if (res.affectedRows == 0) {
      result({ kind: "not_found" }, null);
      return;
    }
    console.log("deleted flash deal product : ", { id: id });
    result(null, res);
  });
};

module.exports = FlashDealProducts;
