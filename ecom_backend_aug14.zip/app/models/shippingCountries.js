const sql = require("./db.js");

// constructor
const ShippingCountries = function (shipping) {
    this.id = shipping.id;
    this.code = shipping.code;
    this.name = shipping.name;
    this.zone_id = shipping.zone_id;
    this.status = shipping.status;
 };

 ShippingCountries.getCountries = (result) => {
    let query  = ` SELECT cou.* from countries as cou `
    
     sql.query(query, (err, res) => {
       if (err) {
         result(null, err);
         return;
       }
       result(null, res);
     });
 };

 ShippingCountries.getCountryID = (id , result) => {
    let query  = ` SELECT cou.* from countries as cou `

        query += ` WHERE cou.id = ? `
  
    sql.query(query, id, (err, res) => {
      if (err) {
        result(null, err);
        return;
      }
      result(null, res[0]);
      console.log(null, res[0]);
    });
    };

 module.exports = ShippingCountries;
