const sql = require("./db.js");


// constructor
const Currency = function (currencies) {
    this.id = currencies.id;
    this.name = currencies.name;
    this.symbol = currencies.symbol;
    this.exchange_rate = currencies.exchange_rate;
    this.status = currencies.status;
    this.code = currencies.code;
 };
 
 
 Currency.getCurrency = (result) => {
     let query = "select * from currencies "
     
     sql.query(query, (err, res) => {
       if (err) {
         result(null, err);
         return;
       }
       result(null, res);
     });
 };
 
 Currency.saveCurrency = (data, result) => {
     console.log(data);
     let query = "INSERT INTO currencies SET ?";
     sql.query(query, data, (err, res) => {
       if (err) {
         console.log(err)
         result(err, null);
         return;
       }
       result(null, res);
     });
   };
 
   Currency.putCurrency = (id, data, result) => {
 
     let name = data.name || null;
     let symbol = data.symbol || null;
     let exchange_rate = data.exchange_rate || null;
     let status = data.status || null;
     let code = data.code || null;
    
     let query = "UPDATE currencies SET name = '"+name+"', symbol = '"+symbol+"', exchange_rate = '"+exchange_rate+"', status = "+status+" , code =  '"+ code +"' , updated_at = now() WHERE id = ? "
   
     sql.query(query, id, (err, res) => {
       if (err) {
         console.log(err)
         result(err, null);
         return;
       }
       if (res.affectedRows == 0) {
         // not found Tutorial with the id
         result({ kind: "not_found" }, null);
         return;
       }
       console.log("updated currencies : ", { id: id, ...data });
       result(null, data.id);
     });
   };
 
   
   Currency.getCurrencyID = (id , result) => {
     let query = " SELECT * FROM currencies WHERE id = ? "
   
     sql.query(query, id, (err, res) => {
       if (err) {
         result(null, err);
         return;
       }
       result(null, res[0]);
       console.log(null, res[0]);
     });
     };
 
     Currency.deleteCurrency = (id, result) => {
         console.log(id);
         let query = "DELETE FROM currencies WHERE id = ?";
         sql.query(query, id, (err, res) => {
           if (err) {
             console.log(err)
             result(err, null);
             return;
           }
           if (res.affectedRows == 0) {
             result({ kind: "not_found" }, null);
             return;
           }
           console.log("deleted currencies : ", { id: id });
           result(null, res);
         });
       };
 
 module.exports = Currency;
 