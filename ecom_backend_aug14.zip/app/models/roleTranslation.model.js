const sql = require("./db.js");


// constructor
const RoleTranslation = function (role) {
  this.id = role.id;
  this.role_id = role.role_id;
  this.name = role.name;
  this.lang = role.lang;
};

RoleTranslation.getRoleTranslation = (result) => {
  let query = "select * from role_translations "

  sql.query(query, (err, res) => {
    if (err) {
      result(null, err);
      return;
    }
    result(null, res);
  });
};

RoleTranslation.saveRoleTranslation = (data, result) => {
    console.log(data);
    let query = "INSERT INTO role_translations SET ?";
    sql.query(query, data, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      result(null, res);
    });
  };

  RoleTranslation.putRoleTranslation = (role_id, data, result) => {

    // let role_id = data.role_id || null;
    let name = data.name|| null;
    let lang = data.lang || null;
   
    let query = "UPDATE role_translations SET name = '"+name+"', lang =  '"+lang+"', updated_at = now()  WHERE role_id = ? "
  
    sql.query(query, role_id, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      if (res.affectedRows == 0) {
        result({ kind: "not_found" }, null);
        return;
      }
      console.log("updated role translations : ", { id: role_id, ...data });
      result(null, data.id);
    });
  };

module.exports = RoleTranslation;
