const sql = require("./db.js");

// constructor
const ShippingCarriers = function (shipping) {
    this.id = shipping.id;
    this.name = shipping.name;
    this.logo = shipping.logo;
    this.transit_time = shipping.transit_time;
    this.free_shipping = shipping.free_shipping;
    this.status = shipping.status;
 };

 ShippingCarriers.getCarriers = (result) => {
    let query  = ` SELECT c.* from carriers as c `

     sql.query(query, (err, res) => {
       if (err) {
         result(null, err);
         return;
       }
       result(null, res);
     });
 };

 ShippingCarriers.saveCarrier = (data, result) => {
    console.log(data);

    let query = "INSERT INTO carriers SET ?";
    
    sql.query(query, data, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      result(null, res);
    });
  };
  
  ShippingCarriers.putCarrier = (id, data, result) => {
  
    let name = data.name || null;
    let logo = data.logo || null;
    let transit_time = data.transit_time || null;
    let free_shipping = data.free_shipping || null;
    let status = data.status|| null;
   
    let query = "UPDATE carriers SET name = '"+name+"' , logo = "+logo+" , transit_time = '"+transit_time+"', free_shipping = "+free_shipping+" , status = "+status+"  WHERE id = ? "
  
    sql.query(query, id, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      if (res.affectedRows == 0) {
        // not found Tutorial with the id
        result({ kind: "not_found" }, null);
        return;
      }
      console.log("updated carriers : ", { id: id, ...data });
      result(null, data.id);
    });
  };
  
  ShippingCarriers.getCarrierID = (id , result) => {
    let query  = ` SELECT c.* , cr.billing_type as billing_type, cr.delimiter1 as delimiter1, cr.delimiter2 as delimiter2, z.name as zone_name, crp.price as price from carriers as c `
        query += ` LEFT JOIN carrier_ranges as cr on (c.id = cr.carrier_id) `
        query += ` LEFT JOIN carrier_range_prices as crp on (c.id = crp.carrier_id) `
        query += ` LEFT JOIN carrier_range_prices as crp1 on (cr.id = crp1.carrier_range_id) `
        query += ` LEFT JOIN zones as z on (z.id = crp.zone_id) `
        query += ` WHERE c.id = ? `
        query += ` GROUP BY c.id `
        query += ` ORDER BY c.id `
  
    sql.query(query, id, (err, res) => {
      if (err) {
        result(null, err);
        return;
      }
      result(null, res[0]);
      console.log(null, res[0]);
    });
    };
  
    ShippingCarriers.deleteCarrier = (id, result) => {
      console.log(id);
      let query = "DELETE FROM carriers WHERE id = ? ";
      sql.query(query, id, (err, res) => {
        if (err) {
          console.log(err)
          result(err, null);
          return;
        }
        if (res.affectedRows == 0) {
          // not found Contact with the id
          result({ kind: "not_found" }, null);
          return;
        }
        console.log("deleted carriers : ", { id: id });
        result(null, res);
      });
    };


 module.exports = ShippingCarriers;
