const sql = require("./db.js");

// constructor
const Brand = function (brand) {
  this.id = brand.id;
  this.name = brand.name;
  this.logo = brand.logo;
  this.top = brand.top;
  this.slug = brand.slug;
  this.meta_title = brand.meta_title;
  this.meta_description = brand.meta_description;
};


Brand.getBrand = (result) => {
  let query = "SELECT * FROM brands "
  sql.query(query, (err, res) => {
    if (err) {
      result(null, err);
      return;
    }
    else {
      result(null, res);
    }
  })
};

Brand.saveBrand = (data, result) => {
  console.log(data);
  let query = "INSERT INTO brands SET ?";
  sql.query(query, data, (err, res) => {
    if (err) {
      console.log(err)
      result(err, null);
      return;
    }
    result(null, res);
  });
};


Brand.putBrand = (id, data, result) => {

  const updates = [];

  if (data.name != '') updates.push(`name = '${data.name}'`);
  if (data.logo != '') updates.push(`logo = '${data.logo}'`);
  if (data.top != '') updates.push(`top = '${data.top}'`);
  if (data.slug != '') updates.push(`slug = '${data.slug}'`);
  if (data.meta_title != '') updates.push(`meta_title = '${data.meta_title}'`);
  if (data.meta_description != '') updates.push(`meta_description = '${data.meta_description}' `);

  if (updates.length === 0) {
    res.status(400).json({ status: (400), message: "No updates provided" });
    return;
  }

  let query = `UPDATE brands SET ${updates.join(", ")} WHERE id = ? `

  sql.query(query, id, (err, res) => {
    if (err) {
      console.log(err)
      result(err, null);
      return;
    }
    if (res.affectedRows == 0) {
      result({ kind: "not_found" }, null);
      return;
    }
    console.log("updated brands : ", { id: id, ...data });
    result(null, data.id);
  });
};

Brand.getBrandID = (id, result) => {
  let query = " SELECT * FROM brands WHERE id = ? "

  sql.query(query, id, (err, res) => {
    if (err) {
      result(null, err);
      return;
    }
    if (res == !id) {
      result({ kind: "not_found" }, null);
      return;
    }
    result(null, res[0]);
    console.log(null, res[0]);
  });
};

Brand.deleteBrand = (id, result) => {
  console.log(id);
  let query = "DELETE FROM brands WHERE id = ?";
  sql.query(query, id, (err, res) => {
    if (err) {
      console.log(err)
      result(err, null);
      return;
    }
    if (res.affectedRows == 0) {
      result({ kind: "not_found" }, null);
      return;
    }
    console.log("deleted brands : ", { id: id });
    result(null, res);
  });
};

module.exports = Brand;
