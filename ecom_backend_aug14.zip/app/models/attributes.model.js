const sql = require("./db.js");

// constructor
const Attributes = function (attributes) {
    this.id = attributes.id;
    this.name = attributes.name;
  };

  Attributes.getAttributes = (result) => {
    let query  = ` SELECT att.* , av.value as value FROM attributes as att ` 
    
        query += ` LEFT JOIN attribute_values as av on (att.id = av.attribute_id) `
        query += ` GROUP BY att.id `
        query += ` ORDER BY att.id `

    sql.query(query, (err, res) => {
      if (err) {
        result(null, err);
        return;
      }
      else {
        result(null, res);
      }
    })
  };

  Attributes.saveAttributes = (data, result) => {
    console.log(data);
    let query = "INSERT INTO attributes SET ?";
    sql.query(query, data, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      result(null, res);
    });
  };


  Attributes.putAttributes = (id, data, result) => {

    let name = data.name || null;
   
    let query = "UPDATE attributes SET name = '"+name+"' , updated_at = now()  WHERE id = ? "
  
    sql.query(query, id, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      if (res.affectedRows == 0) {
        result({ kind: "not_found" }, null);
        return;
      }
      console.log("updated attributes : ", { id: id, ...data });
      result(null, data.id);
    });
  };

  Attributes.getAttributesID = (id , result) => {
    let query  = ` SELECT att.* , av.value as value FROM attributes as att ` 
    
        query += ` LEFT JOIN attribute_values as av on (att.id = av.attribute_id) `
        query += ` WHERE att.id = ? `
  
    sql.query(query, id, (err, res) => {
      if (err) {
        result(null, err);
        return;
      }
      result(null, res[0]);
      console.log(null, res[0]);
    });
    };

    Attributes.deleteAttributes = (id, result) => {
        console.log(id);
        let query = "DELETE FROM attributes WHERE id = ?";
        sql.query(query, id, (err, res) => {
          if (err) {
            console.log(err)
            result(err, null);
            return;
          }
          if (res.affectedRows == 0) {
            result({ kind: "not_found" }, null);
            return;
          }
          console.log("deleted attributes : ", { id: id });
          result(null, res);
        });
      };

module.exports = Attributes;
