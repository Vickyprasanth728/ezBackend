const sql = require("./db.js");

// constructor
const Coupons = function (coupons) {
    this.user_id = coupons.user_id;
    this.type = coupons.type;
    this.code = coupons.code;
    this.details = coupons.details;
    this.discount = coupons.discount;
    this.discount_type = coupons.discount_type;
    this.start_date = coupons.start_date;
    this.end_date = coupons.end_date;
  };

  Coupons.getCoupons = (result) => {

    let query  = ` SELECT cou.*, p.name as product_name, FROM_UNIXTIME(start_date) as start_date, FROM_UNIXTIME(end_date) as end_date FROM coupons as cou `  

        query += ` LEFT JOIN coupon_usages as cu on (cu.coupon_id = cou.id) `
        query += ` LEFT JOIN users as us on (cou.user_id = us.id) `
        query += ` LEFT JOIN products as p on (p.user_id = us.id) `
        query += ` GROUP BY cou.id `
        query += ` ORDER BY cou.id `

    sql.query(query, (err, res) => {
      if (err) {
        result(null, err);
        return;
      }
      else {
        result(null, res);
      }
    })
  };
  
  Coupons.saveCoupons = (data, result) => {
    console.log(data);
    let query = "INSERT INTO coupons SET ?";
    sql.query(query, data, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      result(null, res);
    });
  };

  Coupons.putCoupons= (id, data, result) => {
 
    // let user_id = data.user_id || null;
    // let type = data.type || null;
    // let code = data.code || null;
    // let details = data.details || null;
    // let discount = data.discount || null;
    // let discount_type = data.discount_type || null;
    // let start_date = data.start_date || null;
    // let end_date = data.end_date || null;

    const updates = [];
    if (data.user_id!='') updates.push(`user_id = '${data.user_id}'`);
    if (data.type!='') updates.push(`type = '${data.type}'`);
    if (data.code!='') updates.push(`code = '${data.code}'`);
    if (data.details!='') updates.push(`details = '${data.details}'`);
    if (data.discount!='') updates.push(`discount = '${data.discount}'`);
    if (data.discount_type!='') updates.push(`discount_type = '${data.discount_type}'`);
    if (data.start_date!='') updates.push(`start_date = '${data.start_date}'`);
    if (data.end_date!='') updates.push(`end_date = '${data.end_date}'`);
  
    if (updates.length === 0) {
      res.status(400).json({status: (400), message: "No updates provided" });
      return;
    }
  
    let query = `UPDATE coupons SET ${updates.join(", ")} WHERE id = ? `

    // let query = "UPDATE coupons SET user_id = "+user_id+" , type = '"+type+"', code = ' "+code+" ', details = '"+details+"', discount = "+discount+" , discount_type =  ' "+discount_type+" ' ,  start_date = "+start_date+", end_date = "+end_date+" , updated_at = now()  WHERE id = ? "
  
    sql.query(query, id, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      if (res.affectedRows == 0) {
        result({ kind: "not_found" }, null);
        return;
      }
      console.log("Updated coupons : ", { id: id, ...data });
      result(null, data.id);
    });
   };
  

  Coupons.getCouponsID = (id, result) => {
    let query = " SELECT cou.*, p.name as product_name, FROM_UNIXTIME(start_date) as start_date, FROM_UNIXTIME(end_date) as end_date FROM coupons as cou "

    query += ` LEFT JOIN coupon_usages as cu on (cu.coupon_id = cou.id) `
    query += ` LEFT JOIN users as us on (cou.user_id = us.id) `
    query += ` LEFT JOIN products as p on (p.user_id = us.id) `
    query += ` WHERE cou.id = ? `
    query += ` GROUP BY cou.id `
    query += ` ORDER BY cou.id `

    sql.query(query, id, (err, res) => {
      if (err) {
        result(null, err);
        return;
      }
      if (res == !id) {
        result({ kind: "not_found" });
        return;
      }
      result(null, res[0]);
      console.log(null, res[0]);
    });
  };

  Coupons.deleteCoupons = (id, result) => {
      console.log(id);
      let query = "DELETE FROM coupons WHERE id = ?";
      sql.query(query, id, (err, res) => {
        if (err) {
          console.log(err)
          result(err, null);
          return;
        }
        if (res.affectedRows == 0) {
          result({ kind: "not_found" }, null);
          return;
        }
        console.log("deleted coupons : ", { id: id });
        result(null, res);
      });
    };

module.exports = Coupons;
