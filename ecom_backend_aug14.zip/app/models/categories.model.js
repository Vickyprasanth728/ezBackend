const sql = require("./db.js");

// constructor
const Categories = function (categories) {
    this.id = categories.id;
    this.parent_id = categories.parent_id;
    this.level = categories.level;
    this.name = categories.name;
    this.order_level = categories.order_level;
    this.commision_rate = categories.commision_rate;
    this.banner	 = categories.banner	;
    this.icon = categories.icon;
    this.featured = categories.featured;
    this.top = categories.top;
    this.digital = categories.digital;
    this.slug  = categories.slug ;
    this.meta_title = categories.meta_title;
    this.meta_description = categories.meta_description;
  };

  Categories.getCategories = (result) => {
    
    let query  = ` SELECT cat.* FROM categories as cat `

    sql.query(query, (err, res) => {
      if (err) {
        result(null, err);
        return;
      }
      else {
        result(null, res);
      }
    })
  };

  Categories.saveCategories = (data, result) => {
    console.log(data);
    let query = "INSERT INTO categories SET ?";
    sql.query(query, data, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      result(null, res);
    });
  };

  Categories.putCategories  = (id, data, result) => {

    let parent_id = data.parent_id || null;
    let level = data.level || null;
    let name = data.name || null;
    let order_level = data.order_level|| null;
    let commision_rate = data.commision_rate || null;
    let banner	 = data.banner	 || null;
    let icon = data.icon || null;
    let featured = data.featured || null;
    let top = data.top || null;
    let digital = data.digital || null;
    let slug  = data.slug  || null;
    let meta_title = data.meta_title || null;
    let meta_description = data.meta_description || null;
   
   
    let query = "UPDATE categories SET parent_id = "+parent_id+" , level = "+level+" , name = '"+name+"', order_level =  "+order_level+" , commision_rate =  "+commision_rate+" , banner = '"+banner+"', icon = '"+icon+"', featured =  "+featured+" , top =  "+top+" , digital =  "+digital+" , slug = '"+slug+"' , meta_title = '"+meta_title+"' , meta_description = '"+meta_description+"' , updated_at = now() WHERE id = ? "
  
    sql.query(query, id, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      if (res.affectedRows == 0) {
        result({ kind: "not_found" }, null);
        return;
      }
      console.log("updated categories : ", { id: id, ...data });
      result(null, data.id);
    });
  };

  Categories.getCategoriesID = (id , result) => {
  let query  = ` SELECT cat.*, att.name as attribute_name FROM categories as cat ` 
      query += ` LEFT JOIN products as p on (p.id = cat.parent_id) ` 
      query += ` LEFT JOIN attribute_category as ac on (cat.id = ac.category_id) ` 
      query += ` LEFT JOIN attributes as att on (att.id = ac.attribute_id) ` 
      query += ` WHERE cat.id = ? `
  
    sql.query(query, id, (err, res) => {
      if (err) {
        result(null, err);
        return;
      }
      result(null, res[0]);
      console.log(null, res[0]);
    });
    };

    Categories.deleteCategories = (id, result) => {
      console.log(id);
      let query = "DELETE FROM categories WHERE id = ?";
      sql.query(query, id, (err, res) => {
        if (err) {
          console.log(err)
          result(err, null);
          return;
        }
        if (res.affectedRows == 0) {
          // not found Contact with the id
          result({ kind: "not_found" }, null);
          return;
        }
        console.log("deleted categories : ", { id: id });
        result(null, res);
      });
    };
    
module.exports = Categories;