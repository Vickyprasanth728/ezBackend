const sql = require("./db.js");


// constructor
const CityTranslation = function (City) {
  this.id = City.id;
  this.city_id = City.city_id;
  this.name = City.name;
  this.lang = City.lang;
};

CityTranslation.getCityTranslation = (result) => {
  let query = "select * from city_translations "

  sql.query(query, (err, res) => {
    if (err) {
      result(null, err);
      return;
    }
    result(null, res);
  });
};

CityTranslation.saveCityTranslation = (data, result) => {
    console.log(data);
    let query = "INSERT INTO city_translations SET ?";
    sql.query(query, data, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      result(null, res);
    });
  };

  CityTranslation.putCityTranslation = (city_id, data, result) => {

    // let brand_id = data.brand_id || null;
    let name = data.name|| null;
    let lang = data.lang || null;
   
    let query = "UPDATE city_translations SET name = '"+ name+"', lang =  '"+lang+"', updated_at = now()  WHERE city_id = ? "
  
    sql.query(query, city_id, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      if (res.affectedRows == 0) {
        result({ kind: "not_found" }, null);
        return;
      }
      console.log("updated city translations : ", { id: city_id, ...data });
      result(null, data.id);
    });
  };

module.exports = CityTranslation;