const sql = require("./db.js");

// constructor
const Dashboard = function (dashboard) {
    this.id = dashboard.id;
 };

 
Dashboard.getAdminDashboard = (keyword, result) => {
  let query = `SELECT`
  
  // if (keyword == "total_customers") {
  //   query += ` select COUNT(us.id) as total_customers from users as us `
  //   query += ` where us.user_type = 'customer' and us.banned = 0 `
  // }
  if (keyword == "total_customers") {
    query += ` (SELECT ifnull(COUNT(*),0) from users as us `
    query += ` where us.user_type = 'customer' and us.banned = 0 ) AS total_customers `
  }
  else if (keyword == "total_orders") {
    query += ` (SELECT ifnull(COUNT(*),0) from orders as o ) as total_orders`
  }
  else if (keyword == "total_product_categories") {
    query += ` (SELECT ifnull(COUNT(*),0) from categories as c ) as total_product_categories`
  }
  else if (keyword == "total_product_brands") {
    query += ` (SELECT ifnull(COUNT(*),0) from brands as b) as total_product_brands `
  }
  else if (keyword == "total_admin_products") {
    query += ` (SELECT ifnull(COUNT(*),0) from products as p `
    query += ` left join users as us on (us.id = p.user_id) `
    query += ` where us.user_type = 'admin' ) as total_admin_products `
  }
  else if (keyword == "total_published_products") {
    query += ` (SELECT ifnull(COUNT(*),0)  from products as p `
    query += ` where p.published !=0 ) as total_published_products`
  }
  else if (keyword == "total_seller_products") {
    query += ` (SELECT ifnull(COUNT(*),0) from products as p `
    query += ` left join users as us on (us.id = p.user_id) `
    query += ` where us.user_type = 'seller' ) as total_seller_products `
  }
  else if (keyword == "total_sellers") {
    query += ` (SELECT ifnull(COUNT(*),0)  from sellers as s `
    query += ` left join users as us on (us.id = s.user_id) `
    query += ` left join shops as sh on (us.id = sh.user_id) `
    query += ` where us.user_type = 'seller' ) as total_sellers`
  }
  else if (keyword == "total_approved_sellers") {
    query += ` (SELECT ifnull(COUNT(*),0) from sellers as s `
    query += ` left join users as us on (us.id = s.user_id) `
    query += ` left join shops as sh on (us.id = sh.user_id) `
    query += ` left join products as p on (us.id = p.user_id) `
    query += ` where p.approved = 1 ) as total_approved_sellers `
  }
  else if (keyword == "total_pending_sellers") {
    query += ` (SELECT ifnull(COUNT(*),0) from sellers as s `
    query += ` left join users as us on (us.id = s.user_id) `
    query += ` left join shops as sh on (us.id = sh.user_id) `
    query += ` left join products as p on (us.id = p.user_id) `
    query += ` where p.approved = 0 ) as total_pending_sellers `
  }
  else if (keyword == "number_of_sale") {
    query += ` cat.id as id, cat.name as category_name, COUNT(p.category_id) as number_of_sale from products as p `
    query += ` left join users as us on (us.id = p.user_id) `
    query += ` left join categories as cat on (cat.id = p.category_id) `
    query += ` group by cat.id `
    query += ` order by cat.id `
  }
  else if (keyword == "number_of_stock") {
    query += ` cat.id as id, cat.name as category_name, p.current_stock as number_of_stock from products as p  `
    query += ` left join users as us on (us.id = p.user_id) `
    query += ` left join product_stocks as ps on (p.id = ps.product_id) `
    query += ` left join categories as cat on (cat.id = p.category_id) `
    query += ` group by cat.id `
    query += ` order by cat.id `
  }

  sql.query(query, (err, res) => {
    if (err) {
      console.log(res)
      console.log("error: ", err);
      result(err, null);
      return;
    }
    result(null, res);
  });
};

module.exports = Dashboard;
