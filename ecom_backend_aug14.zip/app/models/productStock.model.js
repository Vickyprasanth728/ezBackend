const sql = require("./db.js");

// constructor
const ProductStock = function (productstock) {
    this.id = productstock.id;
    this.product_id = productstock.product_id;
    this.variant = productstock.variant;
    this.sku = productstock.sku;
    this.price = productstock.price;
    this.qty = productstock.qty;
    this.image = productstock.image;
 };
 
 ProductStock.getProductStock = (result) => {
    let query  = ` SELECT ps.* FROM product_stocks as ps `

        query += ` LEFT JOIN products as p on (p.id = ps.product_id) `
        query += ` GROUP BY ps.id `
        query += ` ORDER BY ps.id `
     
     sql.query(query, (err, res) => {
       if (err) {
         result(null, err);
         return;
       }
       result(null, res);
     });
 };

 ProductStock.saveProductStock = (data, result) => {
    console.log(data);
    let query = "INSERT INTO product_stocks SET ?";
    sql.query(query, data, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      result(null, res);
    });
  };
  
  ProductStock.putProductStock = (product_id, data, result) => {

    // let product_id = data.product_id || null;
    let variant = data.variant || null;
    let sku = data.sku || null;
    let price = data.price || null;
    let qty = data.qty || null;
    let image = data.image || null;

    let query = "UPDATE product_stocks SET variant = '"+variant+"' , sku = '"+sku+"' , price = "+price+" , qty = "+qty+" , image = "+image+" , updated_at = now()  WHERE product_id = ? "
  
    sql.query(query, product_id , (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      if (res.affectedRows == 0) {
        result({ kind: "not_found" }, null);
        return;
      }
      console.log("updated product stock : ", { id: product_id , ...data });
      result(null, data.id);
    });
  };
 module.exports = ProductStock;
