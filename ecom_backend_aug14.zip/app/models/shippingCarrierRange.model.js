const sql = require("./db.js");

// constructor
const ShippingCarrierRange = function (shipping) {
    this.id = shipping.id;
    this.carrier_id = shipping.carrier_id;
    this.billing_type = shipping.billing_type;
    this.delimiter1	 = shipping.delimiter1	;
    this.delimiter2 = shipping.delimiter2;
 };

 ShippingCarrierRange.getCarrierRange = (result) => {
    let query  = ` SELECT cr.* from carrier_ranges as cr `

     sql.query(query, (err, res) => {
       if (err) {
         result(null, err);
         return;
       }
       result(null, res);
     });
 };


 ShippingCarrierRange.saveCarrierRange = (data, result) => {
    console.log(data);

    let query = "INSERT INTO carrier_ranges SET ?";
    
    sql.query(query, data, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      result(null, res);
    });
  };

  ShippingCarrierRange.putCarrierRange = (id, data, result) => {
  
    let carrier_id = data.carrier_id || null;
    let billing_type = data.billing_type || null;
    let delimiter1 = data.delimiter1 || null;
    let delimiter2 = data.delimiter2 || null;
   
    let query = "UPDATE carrier_ranges SET carrier_id = "+carrier_id+" , billing_type = '"+billing_type+"' , delimiter1 = "+delimiter1+" , delimiter2 = "+delimiter2+"  WHERE id = ? "
  
    sql.query(query, id, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      if (res.affectedRows == 0) {
        // not found Tutorial with the id
        result({ kind: "not_found" }, null);
        return;
      }
      console.log("updated carrier range : ", { id: id, ...data });
      result(null, data.id);
    });
  };
  

 module.exports = ShippingCarrierRange;
