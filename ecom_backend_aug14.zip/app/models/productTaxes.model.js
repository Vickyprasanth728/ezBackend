const sql = require("./db.js");

// constructor
const ProductTaxes = function (productTaxes) {
    this.id = productTaxes.id;
    this.product_id = productTaxes.product_id;
    this.tax_id = productTaxes.tax_id;
    this.tax = productTaxes.tax;
    this.tax_type = productTaxes.tax_type;
 };
 
 ProductTaxes.getProductTaxes = (result) => {
    let query  = ` SELECT pt.* FROM product_taxes as pt `

        query += ` LEFT JOIN products as p on (p.id = pt.product_id) `
        query += ` LEFT JOIN taxes as t on (t.id = pt.tax_id) `
        query += ` GROUP BY pt.id `
        query += ` ORDER BY pt.id `
     
     sql.query(query, (err, res) => {
       if (err) {
         result(null, err);
         return;
       }
       result(null, res);
     });
 };

 ProductTaxes.saveProductTaxes = (data, result) => {
    console.log(data);
    let query = "INSERT INTO product_taxes SET ?";
    sql.query(query, data, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      result(null, res);
    });
  };
  
  ProductTaxes.putProductTaxes = (product_id, data, result) => {

    let tax_id = data.tax_id || null;
    let tax = data.tax || null;
    let tax_type = data.tax_type || null;

    let query = "UPDATE product_taxes SET tax_id = "+tax_id+" , tax = "+tax+" , tax_type = '"+tax_type+"' , updated_at = now()  WHERE product_id = ? "
  
    sql.query(query, product_id , (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      if (res.affectedRows == 0) {
        result({ kind: "not_found" }, null);
        return;
      }
      console.log("updated product stock : ", { id: product_id , ...data });
      result(null, data.id);
    });
  };
  
 module.exports = ProductTaxes;
