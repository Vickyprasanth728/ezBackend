const sql = require("./db.js");


// constructor
const Roles = function (roles) {
    this.id = roles.id;
    this.name = roles.name;
    this.guard_name = roles.guard_name;
 };

 Roles.getRoles = (result) => {
    let query  = ` SELECT rol.*, p.name as permission_name, rol.name as role_name from roles as rol `
        
        query += ` LEFT JOIN role_has_permissions as rhp ON (rol.id = rhp.role_id) `
        query += ` LEFT JOIN users as us ON (rol.id = us.user_type) `
        query += ` LEFT JOIN permissions as p ON (p.id = rhp.permission_id) `
        query += ` LEFT JOIN role_has_permissions as rhp1 ON (rol.id = rhp1.role_id) `
        query += ` GROUP BY rol.id `
        query += ` ORDER BY rol.id `
     
     sql.query(query, (err, res) => {
       if (err) {
         result(null, err);
         return;
       }
       result(null, res);
     });
 };

 Roles.saveRole = (data, result) => {
    console.log(data);

    let query = "INSERT INTO roles SET ?";
    
    sql.query(query, data, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      result(null, res);
    });
  };
  
  Roles.putRole = (id, data, result) => {
  
    let name = data.name || null;
    let guard_name = data.guard_name|| null;
   
    let query = "UPDATE roles SET name = '"+name+"', guard_name = '"+guard_name+"', created_at = now() , updated_at = now() WHERE id = ? "
  
    sql.query(query, id, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      if (res.affectedRows == 0) {
        result({ kind: "not_found" }, null);
        return;
      }
      console.log("updated roles : ", { id: id, ...data });
      result(null, data.id);
    });
  };
  
  Roles.getRoleID = (id , result) => {
    let query  = ` SELECT rol.*, p.name as permission_name, rol.name as role_name  from roles as rol `
        
    query += ` LEFT JOIN role_has_permissions as rhp ON (rol.id = rhp.role_id) `
    query += ` LEFT JOIN permissions as p ON (p.id = rhp.permission_id) `
    query += ` LEFT JOIN role_has_permissions as rhp1 ON (rol.id = rhp1.role_id) `
    query += ` WHERE rol.id = ? `
    query += ` GROUP BY rol.id `
    query += ` ORDER BY rol.id `
  
    sql.query(query, id, (err, res) => {
      if (err) {
        result(null, err);
        return;
      }
      result(null, res[0]);
      console.log(null, res[0]);
    });
    };
  
    Roles.deleteRole = (id, result) => {
      console.log(id);
      let query = "DELETE FROM roles WHERE id = ?";
      sql.query(query, id, (err, res) => {
        if (err) {
          console.log(err)
          result(err, null);
          return;
        }
        if (res.affectedRows == 0) {
          // not found Contact with the id
          result({ kind: "not_found" }, null);
          return;
        }
        console.log("deleted roles : ", { id: id });
        result(null, res);
      });
    };


 module.exports = Roles;
