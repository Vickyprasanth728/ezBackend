const sql = require("./db.js");
const util = require('util');

// constructor
const Master = function (master) {
  this.id = master.id,
  this.user_id = master.user_id,
  this.name = master.name
};

Master.getDeliveryStatus = (result) => {
  let query = 'SELECT * FROM delivery_status where deleted_at IS NULL'

  sql.query(query, (err, res) => {
    if (err) {
      result(null, err);
      return;
    }
    result(null, res);
  });
};
Master.putDeliveryStatus = (data, result) => {
  console.log(data);
  let query = "UPDATE delivery_status SET ? WHERE id = " + data.id + "";
  sql.query(query, data, (err, res) => {
    if (err) {
      console.log(err)
      result(err, null);
      return;
    }
    result(null, res);
  });
};
Master.saveDeliveryStatus = (data, result) => {
  console.log(data);
  let query = "INSERT INTO delivery_status SET ?";
  sql.query(query, data, (err, res) => {
    if (err) {
      console.log(err)
      result(err, null);
      return;
    }
    result(null, res);
  });
};
Master.deleteDeliveryStatus = (data, result) => {
  console.log(data);
  let query = "UPDATE delivery_status SET deleted_at = now() WHERE id = " + data.id + "";
  sql.query(query, data, (err, res) => {
    if (err) {
      console.log(err)
      result(err, null);
      return;
    }
    result(null, res);
  });
};


// Payment Status
Master.getPaymentStatus = (result) => {
  let query = 'SELECT * FROM payment_status where deleted_at IS NULL'

  sql.query(query, (err, res) => {
    if (err) {
      result(null, err);
      return;
    }
    result(null, res);
  });
};
Master.putPaymentStatus = (data, result) => {
  console.log(data);
  let query = "UPDATE payment_status SET ? WHERE id = " + data.id + "";
  sql.query(query, data, (err, res) => {
    if (err) {
      console.log(err)
      result(err, null);
      return;
    }
    result(null, res);
  });
};
Master.savePaymentStatus = (data, result) => {
  console.log(data);
  let query = "INSERT INTO payment_status SET ?";
  sql.query(query, data, (err, res) => {
    if (err) {
      console.log(err)
      result(err, null);
      return;
    }
    result(null, res);
  });
};
Master.deletePaymentStatus = (data, result) => {
  console.log(data);
  let query = "UPDATE payment_status SET deleted_at = now() WHERE id = " + data.id + "";
  sql.query(query, data, (err, res) => {
    if (err) {
      console.log(err)
      result(err, null);
      return;
    }
    result(null, res);
  });
};


// Shipping Type
Master.getShippingType = (result) => {
  let query = 'SELECT * FROM shipping_type where deleted_at IS NULL'

  sql.query(query, (err, res) => {
    if (err) {
      result(null, err);
      return;
    }
    result(null, res);
  });
};
Master.putShippingType = (data, result) => {
  console.log(data);
  let query = "UPDATE shipping_type SET ? WHERE id = " + data.id + "";
  sql.query(query, data, (err, res) => {
    if (err) {
      console.log(err)
      result(err, null);
      return;
    }
    result(null, res);
  });
};
Master.saveShippingType = (data, result) => {
  console.log(data);
  let query = "INSERT INTO shipping_type SET ?";
  sql.query(query, data, (err, res) => {
    if (err) {
      console.log(err)
      result(err, null);
      return;
    }
    result(null, res);
  });
};
Master.deleteShippingType = (data, result) => {
  console.log(data);
  let query = "UPDATE shipping_type SET deleted_at = now() WHERE id = " + data.id + "";
  sql.query(query, data, (err, res) => {
    if (err) {
      console.log(err)
      result(err, null);
      return;
    }
    result(null, res);
  });
};

module.exports = Master;
