const sql = require("./db.js");

// constructor
const BusinessSettings = function (settings) {
    this.type = settings.type;
    this.value = settings.value;
    this.lang = settings.lang;
 };
 
 BusinessSettings.getBusinessSettings = (result) => {
    let query = ` select * from business_settings `
     
     sql.query(query, (err, res) => {
       if (err) {
         result(null, err);
         return;
       }
       result(null, res);
     });
 };


 BusinessSettings.saveBusinessSetting = (data, result) => {
  console.log(data);
  let query = "INSERT INTO business_settings SET ?";
  sql.query(query, data, (err, res) => {
    if (err) {
      console.log(err)
      result(err, null);
      return;
    }
    result(null, res);
  });
};

BusinessSettings.putBusinessSetting = (type, data, result) => {

  // let value = data.value;
  // let lang = data.lang;
 
  // let query = "UPDATE business_settings SET value = '"+ value +"', lang =  '"+ lang +"' , updated_at = now() WHERE type = ? "

  const updates = [];
  if (data.value!='') updates.push(`value = '${data.value}'`);
  if (data.lang!='') updates.push(`lang = '${data.lang}'`);

  if (updates.length === 0) {
    res.status(400).json({status: (400), message: "No updates provided" });
    return;
  }

  let query = `UPDATE business_settings SET ${updates.join(", ")} WHERE type = ? `

  sql.query(query, type, (err, res) => {
    if (err) {
      console.log(err)
      result(err, null);
      return;
    }
    if (res.affectedRows == 0) {
      result({ kind: "not_found" }, null);
      return;
    }
    console.log("Updated business settings : ", { type: type, ...data });
    result(null, data.type);
  });
};

BusinessSettings.getBusinessSettingID = (type , result) => {
  let query = " SELECT * FROM business_settings WHERE type = ? "

  sql.query(query, type, (err, res) => {
    if (err) {
      result(null, err);
      return;
    }
    if (res == !type) {
      result({ kind: "not_found" }, null);
      return;
    }
    result(null, res[0]);
    console.log(null, res[0]);
  });
  };

  BusinessSettings.deleteBusinessSetting = (id, result) => {
    console.log(id);
    let query = "DELETE FROM business_settings WHERE id = ?";
    sql.query(query, id, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      if (res.affectedRows == 0) {
        result({ kind: "not_found" }, null);
        return;
      }
      console.log("Deleted business settings : ", { id: id });
      result(null, res);
    });
  };

 module.exports = BusinessSettings;
