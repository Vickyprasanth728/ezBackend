const sql = require("./db.js");


// constructor
const MessageConversation = function (messages) {
  this.id = messages.id;
  this.conversation_id = messages.conversation_id;
  this.user_id = messages.user_id;
  this.message = messages.message;
};

  MessageConversation.getMessageReplyList = (conversation_id, result) => {

  let query  = ` SELECT m.*, us.name as user FROM messages as m `

      query += ` LEFT JOIN conversations as con ON (con.id = m.conversation_id)`
      query += ` LEFT JOIN users as us ON (m.user_id = us.id) `
      query += ` WHERE m.conversation_id = ? `
      query += ` GROUP BY m.id `  
      query += ` ORDER BY m.id `  

  sql.query(query, conversation_id , (err, res) => {
    if (err) {
      result(null, err);
      return;
    }
    result(null, res);
    console.log(null, res);
  });
  };

  MessageConversation.saveMessageReply = (data, result) => {
      console.log(data);
      let query = "INSERT INTO messages SET ?";
      sql.query(query, data, (err, res) => {
        if (err) {
          console.log(err)
          result(err, null);
          return;
        }
        result(null, res);
      });
    };
    
module.exports = MessageConversation;
