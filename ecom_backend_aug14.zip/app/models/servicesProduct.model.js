const sql = require("./db.js");

// constructor
const Services = function (services) {
    this.id = services.id;
    this.category_id = services.category_id;
    this.parent_category_id = services.parent_category_id;
    this.seller_id = services.seller_id;
    this.name = services.name;
    this.price = services.price;
    this.discount_price = services.discount_price;
    this.duration = services.duration;
    this.description = services.description;
    this.images = services.images;
  };


  Services.getServices = (result) => {
    let query =  ` SELECT ser.*, cat.name as category_name, cat1.name as parent_category_name FROM services as ser `
        query += ` LEFT JOIN categories as cat on (cat.id = ser.category_id) `
        query += ` LEFT JOIN categories as cat1 on (cat1.id = ser.parent_category_id) `
        query += ` GROUP BY ser.id `
        query += ` ORDER BY ser.id `
    sql.query(query, (err, res) => {
      if (err) {
        result(null, err);
        return;
      }
      else {
        result(null, res);
      }
    })
  };

  Services.saveService = (data, result) => {
    console.log(data);
    let query = "INSERT INTO services SET ?";
    sql.query(query, data, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      result(null, res);
    });
  };

  Services.putService = (id, data, result) => {

    // let category_id = data.category_id || null;
    // let parent_category_id = data.parent_category_id || null;
    // let seller_id = data.seller_id || null;
    // let name = data.name || null;
    // let price = data.price || null;
    // let discount_price = data.discount_price || null;
    // let duration = data.duration || null;
    // let description = data.description || null;
    // let images = data.images || null;
   
    // let query = "UPDATE services SET category_id = "+category_id+", parent_category_id = "+parent_category_id+" ,seller_id = '"+seller_id+"' ,name = '"+name+"', price = "+price+" , discount_price = "+discount_price+" ,duration = "+duration+" , description = '"+description+"', images = '"+images+"', updated_at = now() WHERE id = ? "
  
    const updates = [];
    if (data.category_id!='') updates.push(`category_id = '${data.category_id}'`);
    if (data.parent_category_id!='') updates.push(`parent_category_id = '${data.parent_category_id}'`);
    if (data.seller_id!='') updates.push(`seller_id = '${data.seller_id}'`);
    if (data.name!='') updates.push(`name = '${data.name}'`);
    if (data.price!='') updates.push(`price = '${data.price}'`);
    if (data.discount_price!='') updates.push(`discount_price = '${data.discount_price}'`);
    if (data.duration!='') updates.push(`duration = '${data.duration}'`);
    if (data.description!='') updates.push(`description = '${data.description}'`);
    if (data.images!='') updates.push(`images = '${data.images}'`);
  
    if (updates.length === 0) {
      res.status(400).json({status: (400), message: "No updates provided" });
      return;
    }
  
    let query = `UPDATE services SET ${updates.join(", ")} WHERE id = ? `
  
      sql.query(query, id, (err, res) => {
        if (err) {
          console.log(err)
          result(err, null);
          return;
        }
        if (res.affectedRows == 0) {
          result({ kind: "not_found" }, null);
          return;
        }
        console.log("Updated services : ", { id: id, ...data });
        result(null, data.id);
      });
  };

  Services.getServiceEdit = (id , result) => {
    let query =  ` SELECT ser.*, cat.name as category_name, cat1.name as parent_category_name FROM services as ser `
        query += ` LEFT JOIN categories as cat on (cat.id = ser.category_id) `
        query += ` LEFT JOIN categories as cat1 on (cat1.id = ser.parent_category_id) `
        query += ` WHERE ser.id = ? `
  
        sql.query(query, id, (err, res) => {
          if (err) {
            result(null, err);
            return;
          }
          if (res == !id) {
            result({ kind: "not_found" }, null);
            return;
          }
          result(null, res[0]);
          console.log(null, res[0]);
        });
    };

    Services.deleteService = (id, result) => {
        console.log(id);
        let query = "DELETE FROM services WHERE id = ?";
        sql.query(query, id, (err, res) => {
          if (err) {
            console.log(err)
            result(err, null);
            return;
          }
          if (res.affectedRows == 0) {
            result({ kind: "not_found" }, null);
            return;
          }
          console.log("deleted services : ", { id: id });
          result(null, res);
        });
      };

module.exports = Services;
