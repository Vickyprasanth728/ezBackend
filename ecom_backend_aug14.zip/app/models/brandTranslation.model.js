const sql = require("./db.js");


// constructor
const BrandTranslation = function (brand) {
  this.id = brand.id;
  this.brand_id = brand.brand_id;
  this.name = brand.name;
  this.lang = brand.lang;
};

BrandTranslation.getBrandTranslation = (result) => {
  let query = "select * from brand_translations "

  sql.query(query, (err, res) => {
    if (err) {
      result(null, err);
      return;
    }
    result(null, res);
  });
};

BrandTranslation.saveBrandTranslation = (data, result) => {
    console.log(data);
    let query = "INSERT INTO brand_translations SET ?";
    sql.query(query, data, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      result(null, res);
    });
  };

  BrandTranslation.putBrandTranslation = (brand_id, data, result) => {

    // let brand_id = data.brand_id || null;
    let name = data.name|| null;
    let lang = data.lang || null;
   
    let query = "UPDATE brand_translations SET name = '"+name+"', lang =  '"+lang+"', updated_at = now()  WHERE brand_id = ? "
  
    sql.query(query, brand_id, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      if (res.affectedRows == 0) {
        result({ kind: "not_found" }, null);
        return;
      }
      console.log("updated brand translations : ", { id: brand_id, ...data });
      result(null, data.id);
    });
  };

module.exports = BrandTranslation;
