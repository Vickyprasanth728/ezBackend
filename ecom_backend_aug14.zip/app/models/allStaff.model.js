const sql = require("./db.js");


// constructor
const AllStaff = function (allstaff) {
    this.id = allstaff.id;
    this.user_id = allstaff.user_id;
    this.role_id = allstaff.role_id;
 };
 
 
 AllStaff.getStaff = (result) => {
    let query = ` select st.*, us.name as name, us.email as email, us.phone as phone, us.password as password, us.user_type as user_type, rol.name as role_name, us.name as user_name from staff as st `

    query += ` left join users as us on (us.id = st.user_id ) `
    query += ` left join roles as rol on (rol.id = st.role_id) `
    // query += ` where us.user_type = "staff" `
    query += ` GROUP BY st.id `
    query += ` ORDER BY st.id asc `
    
     sql.query(query, (err, res) => {
       if (err) {
         result(null, err);
         return;
       }
       result(null, res);
     });
 };

 AllStaff.saveStaff = (data, result) => {
  console.log(data);
  let query = "INSERT INTO staff SET ?";
  sql.query(query, data, (err, res) => {
    if (err) {
      console.log(err)
      result(err, null);
      return;
    }
    result(null, res);
  });
};

// AllStaff.putStaff = (user_id, data, result) => {
 
//   // let user_id = data.user_id || null;
//   let role_id = data.role_id || null;

//   let query = "UPDATE staff SET role_id = "+role_id+" , updated_at = now()  WHERE user_id = ? "

//   sql.query(query, user_id, (err, res) => {
//     if (err) {
//       console.log(err)
//       result(err, null);
//       return;
//     }
//     if (res.affectedRows == 0) {
//       result({ kind: "not_found" }, null);
//       return;
//     }
//     console.log("updated staff : ", { id: user_id, ...data });
//     result(null, data.id);
//   });
// };

AllStaff.putStaff = (id, data, result) => {
 
  let user_id = data.user_id || null;
  let role_id = data.role_id || null;

  let query = "UPDATE staff SET user_id = "+user_id+" , role_id = "+role_id+" , updated_at = now()  WHERE id = ? "

  sql.query(query,id, (err, res) => {
    if (err) {
      console.log(err)
      result(err, null);
      return;
    }
    if (res.affectedRows == 0) {
      result({ kind: "not_found" }, null);
      return;
    }
    console.log("updated staff : ", { id: user_id, ...data });
    result(null, data.id);
  });
};

AllStaff.getStaffID = (id , result) => {

  let query = ` select st.*, us.name as name, us.email as email, us.phone as phone, us.password as password, us.user_type as user_type, rol.name as role_name, us.name as user_name from staff as st `

  query += ` left join users as us on (us.id = st.user_id ) `
  query += ` left join roles as rol on (rol.id = st.role_id) `
  query += ` WHERE st.id = ? `
  query += ` GROUP BY st.id `
  query += ` ORDER BY st.id asc `

  sql.query(query, id, (err, res) => {
    if (err) {
      result(null, err);
      return;
    }
    result(null, res[0]);
    console.log(null, res[0]);
  });
  };

  AllStaff.deleteStaff = (id, result) => {
      console.log(id);

    let query  = ` delete from staff `;
     
        query += ` where id = ? `

      sql.query(query, id, (err, res) => {
        if (err) {
          console.log(err)
          result(err, null);
          return;
        }
        if (res.affectedRows == 0) {
          result({ kind: "not_found" }, null);
          return;
        }
        console.log("deleted staff : ", { id: id });
        result(null, res);
      });
    };
 

 module.exports = AllStaff;
 