const sql = require("./db.js");

// constructor
const ShippingZone = function (shipping) {
    this.id = shipping.id;
    this.name = shipping.name;
    this.status = shipping.status;
 };

 ShippingZone.getZones = (result) => {
    let query  = ` SELECT z.* from zones as z `

     sql.query(query, (err, res) => {
       if (err) {
         result(null, err);
         return;
       }
       result(null, res);
     });
 };

 ShippingZone.saveZone = (data, result) => {
    console.log(data);

    let query = "INSERT INTO zones SET ?";
    
    sql.query(query, data, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      result(null, res);
    });
  };
  
  ShippingZone.putZone = (id, data, result) => {
  
    let name = data.name || null;
    let status = data.status|| null;
   
    let query = "UPDATE zones SET name = ' "+name+" ' , status =   "+ status + "   WHERE id = ? "
  
    sql.query(query, id, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      if (res.affectedRows == 0) {
        // not found Tutorial with the id
        result({ kind: "not_found" }, null);
        return;
      }
      console.log("updated zones : ", { id: id, ...data });
      result(null, data.id);
    });
  };
  
  ShippingZone.getZoneID = (id , result) => {
    let query  = ` SELECT z.* from zones as z `

        query += ` WHERE z.id = ? `
  
    sql.query(query, id, (err, res) => {
      if (err) {
        result(null, err);
        return;
      }
      result(null, res[0]);
      console.log(null, res[0]);
    });
    };
  
    ShippingZone.deleteZone = (id, result) => {
      console.log(id);
      let query = "DELETE FROM zones WHERE id = ? ";
      sql.query(query, id, (err, res) => {
        if (err) {
          console.log(err)
          result(err, null);
          return;
        }
        if (res.affectedRows == 0) {
          // not found Contact with the id
          result({ kind: "not_found" }, null);
          return;
        }
        console.log("deleted zones : ", { id: id });
        result(null, res);
      });
    };


 module.exports = ShippingZone;
