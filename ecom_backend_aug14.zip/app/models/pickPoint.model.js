const sql = require("./db.js");


// constructor
const PickPoint = function (pickpoint) {
    this.id = pickpoint.id;
    this.staff_id = pickpoint.staff_id;
    this.name = pickpoint.name;
    this.address = pickpoint.address;
    this.phone = pickpoint.phone;
    this.pick_up_status = pickpoint.pick_up_status;
    this.cash_on_pickup_status = pickpoint.cash_on_pickup_status;
 };
 
 
 PickPoint.getPickPoint = (result) => {
    let query  = ` SELECT pp.*, us.name as manager, us.name as pick_up_manager FROM pickup_points as pp `

        query += ` LEFT JOIN staff as st on (st.id = pp.staff_id) `
        query += ` LEFT JOIN users as us on (us.id = st.user_id) `
        query += ` LEFT JOIN roles as rol on (rol.id = st.role_id) `
        query += ` WHERE us.user_type = 'staff' `
        query += ` GROUP BY pp.id `
        query += ` ORDER BY pp.id `
     
     sql.query(query, (err, res) => {
       if (err) {
         result(null, err);
         return;
       }
       result(null, res);
     });
 };
 
 PickPoint.savePickPoint = (data, result) => {
     console.log(data);
     let query = "INSERT INTO pickup_points SET ?";
     sql.query(query, data, (err, res) => {
       if (err) {
         console.log(err)
         result(err, null);
         return;
       }
       result(null, res);
     });
   };
 
   PickPoint.putPickPoint = (id, data, result) => {
 
     let staff_id = data.staff_id || null;
     let name = data.name || null;
     let address = data.address || null;
     let phone = data.phone || null;
     let pick_up_status = data.pick_up_status || null;
     let cash_on_pickup_status = data.cash_on_pickup_status || null;

     let query = "UPDATE pickup_points SET staff_id = "+staff_id+" , name = '"+name+"', address = '"+address+"', phone = '"+phone+"',  pick_up_status = "+pick_up_status+" ,  cash_on_pickup_status = "+cash_on_pickup_status+" , updated_at = now()  WHERE id = ? "
   
     sql.query(query, id, (err, res) => {
       if (err) {
         console.log(err)
         result(err, null);
         return;
       }
       if (res.affectedRows == 0) {
         result({ kind: "not_found" }, null);
         return;
       }
       console.log("updated Pick Point : ", { id: id, ...data });
       result(null, data.id);
     });
   };
   
   
   PickPoint.getPickPointID = (id , result) => {
    let query  = ` SELECT pp.*, us.name as manager, us.name as pick_up_manager FROM pickup_points as pp `

        query += ` LEFT JOIN staff as st on (st.id = pp.staff_id) `
        query += ` LEFT JOIN users as us on (us.id = st.user_id) `
        query += ` LEFT JOIN roles as rol on (rol.id = st.role_id) `
        query += ` WHERE us.user_type = 'staff' and pp.id = ? `
        query += ` GROUP BY pp.id `
        query += ` ORDER BY pp.id `
   
     sql.query(query, id, (err, res) => {
       if (err) {
         result(null, err);
         return;
       }
       result(null, res[0]);
       console.log(null, res[0]);
     });
     };
 
     PickPoint.deletePickPoint = (id, result) => {
         console.log(id);
         let query = "DELETE FROM pickup_points WHERE id = ?";
         sql.query(query, id, (err, res) => {
           if (err) {
             console.log(err)
             result(err, null);
             return;
           }
           if (res.affectedRows == 0) {
             result({ kind: "not_found" }, null);
             return;
           }
           console.log("deleted pickup points : ", { id: id });
           result(null, res);
         });
       };
 
 module.exports = PickPoint;
 