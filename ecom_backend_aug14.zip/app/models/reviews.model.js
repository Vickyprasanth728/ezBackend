const sql = require("./db.js");

// constructor
const Reviews = function (reviews) {
    this.id = reviews.id;
}

Reviews.getReviewsProducts = (queryString, result) => {
    let query  = ` SELECT re.*, p.name as product_name, us.name as product_owner, us1.name as user_name, p.published as published from reviews as re `

        query += ` LEFT JOIN products as p on (p.id = re.product_id) `
        query += ` LEFT JOIN users as us on (us.id = p.user_id) `
        query += ` LEFT JOIN users as us1 on (us1.id = re.user_id) `
        query += ` GROUP BY re.id `    

    // Sort By
    if (queryString.order_by) {
      let orderByString = queryString.order_by.split('|')
      query += " order by " + `${orderByString[0]} ${orderByString[1]} `
    }
    else {
      query += " order by re.id DESC"
    }

    sql.query(query, (err, res) => {
      if (err) {
        result(null, err);
        return;
      }
      result(null, res);
    });
};

Reviews.UpdateReviewStatus = (id , result) => {
  let query  = ` UPDATE reviews SET status = '1' `

      query += ` WHERE id = ?  `

  sql.query(query, id, (err, res) => {
    if (err) {
      console.log(err)
      result(err, null);
      return;
    }
    if (res.affectedRows == 0) {
      result({ kind: "not_found" }, null);
      return;
    }
    console.log("Updated Review Successfully :", { id });
    result(null, res);
  });
};


module.exports = Reviews;
