const sql = require("./db.js");


// constructor
const PickPointTranslation = function (pickpoint) {
  this.id = pickpoint.id;
  this.pickup_point_id = pickpoint.pickup_point_id;
  this.name = pickpoint.name;
  this.address = pickpoint.address;
  this.lang = pickpoint.lang;
};

PickPointTranslation.getPickPointTranslation = (result) => {
  let query = "select * from pickup_point_translations "

  sql.query(query, (err, res) => {
    if (err) {
      result(null, err);
      return;
    }
    result(null, res);
  });
};

PickPointTranslation.savePickPointTranslation = (data, result) => {
    console.log(data);
    let query = "INSERT INTO pickup_point_translations SET ?";
    sql.query(query, data, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      result(null, res);
    });
  };

  PickPointTranslation.putPickPointTranslation = (pickup_point_id, data, result) => {

    // let pickup_point_id = data.pickup_point_id || null;
    let name = data.name|| null;
    let address = data.address || null;
    let lang = data.lang || null;
   
    let query = "UPDATE pickup_point_translations SET name = '"+name+"', address = '"+address+"', lang =  '"+lang+"', updated_at = now()  WHERE pickup_point_id = ? "
  
    sql.query(query, pickup_point_id, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      if (res.affectedRows == 0) {
        result({ kind: "not_found" }, null);
        return;
      }
      console.log("updated pickup point translations : ", { id: pickup_point_id, ...data });
      result(null, data.id);
    });
  };

module.exports = PickPointTranslation;
