const sql = require("./db.js");

// constructor
const ProductTranslation = function (productTranslation) {
    this.id = productTranslation.id;
    this.product_id = productTranslation.product_id;
    this.name = productTranslation.name;
    this.unit = productTranslation.unit;
    this.description = productTranslation.description;
    this.lang = productTranslation.lang;
 };
 
 ProductTranslation.getProductTranslation = (result) => {
    let query  = ` SELECT ptr.* FROM product_translations as ptr `

        query += ` LEFT JOIN products as p on (p.id = ptr.product_id) `
        query += ` GROUP BY ptr.id `
        query += ` ORDER BY ptr.id `
     
     sql.query(query, (err, res) => {
       if (err) {
         result(null, err);
         return;
       }
       result(null, res);
     });
 };

 ProductTranslation.saveProductTranslation = (data, result) => {
    console.log(data);
    let query = "INSERT INTO product_translations SET ?";
    sql.query(query, data, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      result(null, res);
    });
  };
  
  ProductTranslation.putProductTranslation = (product_id, data, result) => {

    // let product_id = data.product_id || null;
    let name = data.name|| null;
    let unit = data.unit|| null;
    let description = data.description|| null;
    let lang = data.lang || null;
   
    let query = "UPDATE product_translations SET name = '"+name+"', unit = "+unit+", description = '"+description+"', lang =  '"+lang+"', updated_at = now()  WHERE product_id = ? "
  
    sql.query(query, product_id, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      if (res.affectedRows == 0) {
        result({ kind: "not_found" }, null);
        return;
      }
      console.log("updated product translation : ", { id: product_id, ...data });
      result(null, data.id);
    });
  };

 module.exports = ProductTranslation;
