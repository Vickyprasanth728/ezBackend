const sql = require("./db.js");

// constructor
const Option = function (option) {
    this.id = option.id;
    this.option_name = option.option_name;
    this.added_by = option.added_by;
  };


  Option.getOptions = (result) => {
    let query = "SELECT * FROM options "  
    sql.query(query, (err, res) => {
      if (err) {
        result(null, err);
        return;
      }
      else {
        result(null, res);
      }
    })
  };

  Option.saveOption = (data, result) => {
    console.log(data);
    let query = "INSERT INTO options SET ?";
    sql.query(query, data, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      result(null, res);
    });
  };


  Option.putOption = (id, data, result) => {

    let option_name = data.option_name || null;
    let added_by = data.added_by|| null;
   
    let query = "UPDATE options SET option_name = '"+option_name+"', added_by =  '"+ added_by +"' , updated_at = now() WHERE id = ? "
  
    sql.query(query, id, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      if (res.affectedRows == 0) {
        result({ kind: "not_found" }, null);
        return;
      }
      console.log("updated options : ", { id: id, ...data });
      result(null, data.id);
    });
  };

  Option.getOptionEdit = (id , result) => {
    let query = " SELECT * FROM options WHERE id = ? "
  
    sql.query(query, id, (err, res) => {
      if (err) {
        result(null, err);
        return;
      }
      result(null, res[0]);
      console.log(null, res[0]);
    });
    };

    Option.deleteOption = (id, result) => {
        console.log(id);
        let query = "DELETE FROM options WHERE id = ?";
        sql.query(query, id, (err, res) => {
          if (err) {
            console.log(err)
            result(err, null);
            return;
          }
          if (res.affectedRows == 0) {
            result({ kind: "not_found" }, null);
            return;
          }
          console.log("deleted options : ", { id: id });
          result(null, res);
        });
      };

module.exports = Option;
