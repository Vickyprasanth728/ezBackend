const sql = require("./db.js");


// constructor
const ShippingCity = function (city) {
    this.id = city.id;
    this.name = city.name;
    this.state_id = city.state_id;
    this.cost = city.cost;
    this.status = city.status;
 };

 ShippingCity.getCities = (result) => {
    let query  = ` SELECT c.* , s.name as state_name from cities as c `

        query += ` LEFT JOIN states as s on (c.state_id = s.id) `
    
     sql.query(query, (err, res) => {
       if (err) {
         result(null, err);
         return;
       }
       result(null, res);
     });
 };

 ShippingCity.saveCity = (data, result) => {
    console.log(data);

    let query = "INSERT INTO cities SET ?";
    
    sql.query(query, data, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      result(null, res);
    });
  };
  
  ShippingCity.putCity = (id, data, result) => {
  
    let name = data.name || null;
    let state_id = data.state_id|| null;
    let cost = data.cost|| null;
    let status = data.status|| null;
   
    let query = "UPDATE cities SET name = ' "+name+" ' , state_id =   " + state_id + " ,cost =   " + cost + " , status =   "+ status + "   WHERE id = ? "
  
    sql.query(query, id, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      if (res.affectedRows == 0) {
        result({ kind: "not_found" }, null);
        return;
      }
      console.log("updated city : ", { id: id, ...data });
      result(null, data.id);
    });
  };
  
  ShippingCity.getCityID = (id , result) => {
    let query  = ` SELECT c.* , s.name as state_name from cities as c `

        query += ` LEFT JOIN states as s on (c.state_id = s.id) `
        query += ` WHERE c.id = ? `
  
    sql.query(query, id, (err, res) => {
      if (err) {
        result(null, err);
        return;
      }
      result(null, res[0]);
      console.log(null, res[0]);
    });
    };
  
    ShippingCity.deleteCity = (id, result) => {
      console.log(id);
      let query = "DELETE FROM cities WHERE id = ? ";
      sql.query(query, id, (err, res) => {
        if (err) {
          console.log(err)
          result(err, null);
          return;
        }
        if (res.affectedRows == 0) {
          result({ kind: "not_found" }, null);
          return;
        }
        console.log("deleted city : ", { id: id });
        result(null, res);
      });
    };


 module.exports = ShippingCity;
