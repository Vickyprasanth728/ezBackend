const sql = require("./db.js");

// constructor
const ShippingCarrierRangePrice = function (shipping) {
    this.id = shipping.id;
    this.carrier_id = shipping.carrier_id;
    this.carrier_range_id = shipping.carrier_range_id;
    this.zone_id = shipping.zone_id;
    this.price = shipping.price;
 };

 ShippingCarrierRangePrice.saveCarrierRangePrice = (data, result) => {
    console.log(data);

    let query = "INSERT INTO carrier_range_prices SET ?";
    
    sql.query(query, data, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      result(null, res);
    });
  };

  ShippingCarrierRangePrice.putCarrierRangePrice = (id, data, result) => {
  
    let carrier_id = data.carrier_id || null;
    let carrier_range_id = data.carrier_range_id || null;
    let zone_id = data.zone_id || null;
    let price = data.price || null;
   
    let query = "UPDATE carrier_range_prices SET carrier_id = "+carrier_id+" , carrier_range_id = "+carrier_range_id+" , zone_id = "+zone_id+" , price = "+price+"  WHERE id = ? "
  
    sql.query(query, id, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      if (res.affectedRows == 0) {
        // not found Tutorial with the id
        result({ kind: "not_found" }, null);
        return;
      }
      console.log("updated carrier range price : ", { id: id, ...data });
      result(null, data.id);
    });
  };
  

 module.exports = ShippingCarrierRangePrice;