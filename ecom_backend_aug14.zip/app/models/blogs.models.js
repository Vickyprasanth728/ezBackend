const sql = require("./db.js");


// constructor
const Blogs = function (blogs) {
    this.category_id = blogs.category_id;
    this.title = blogs.title;
    this.slug = blogs.slug;
    this.short_description = blogs.short_description;
    this.description = blogs.description;
    this.banner = blogs.banner;
    this.meta_title = blogs.meta_title;
    this.meta_img = blogs.meta_img;
    this.meta_description = blogs.meta_description;
    this.meta_keywords = blogs.meta_keywords;
    this.status = blogs.status;
 };
 
 
 Blogs.getBlogs = (result) => {
    let query = ` select bl.*, bc.category_name as category_name, up.file_name as banner_name, up.file_original_name as banner_original_name from blogs as bl `

    query += ` left join uploads as up on (up.id = bl.banner) `
    query += ` left join blog_categories as bc on (bc.id = bl.category_id) `
    query += ` GROUP BY bl.id `
    query += ` ORDER BY bl.id `
     
     sql.query(query, (err, res) => {
       if (err) {
         result(null, err);
         return;
       }
       result(null, res);
     });
 };
 
 Blogs.saveBlog = (data, result) => {
     console.log(data);
     let query = "INSERT INTO blogs SET ?";
     sql.query(query, data, (err, res) => {
       if (err) {
         console.log(err)
         result(err, null);
         return;
       }
       result(null, res);
     });
   };
 
  Blogs.putBlog = (id, data, result) => {
     
  const updates = [];
  if (data.category_id!='') updates.push(`category_id = '${data.category_id}'`);
  if (data.title!='') updates.push(`title = '${data.title}'`);
  if (data.slug!='') updates.push(`slug = '${data.slug}'`);
  if (data.short_description!='') updates.push(`short_description = '${data.short_description}'`);
  if (data.description!='') updates.push(`description = '${data.description}'`);
  if (data.banner!='') updates.push(`banner = '${data.banner}'`);
  if (data.meta_title!='') updates.push(`meta_title = '${data.meta_title}'`);
  if (data.meta_img!='') updates.push(`meta_img = '${data.meta_img}'`);
  if (data.meta_description!='') updates.push(`meta_description = '${data.meta_description}'`);
  if (data.meta_keywords!='') updates.push(`meta_keywords = '${data.meta_keywords}'`);
  if (data.status!='') updates.push(`status = '${data.status}'`);

  if (updates.length === 0) {
    res.status(400).json({status: (400), message: "No updates provided" });
    return;
  }

  let query = `UPDATE blogs SET ${updates.join(", ")} WHERE id = ? `

    //  let query = "UPDATE blogs SET category_id = "+category_id+" , title = '"+title+"', slug = ' "+slug+" ', short_description = '"+short_description+"', description = '"+description+"', banner =  "+banner+" ,  meta_title = '"+meta_title+"', meta_img = "+meta_img+" ,  meta_description = ' "+meta_description+" ',  meta_keywords = '"+meta_keywords+"', status = "+status+" , updated_at = now()  WHERE id = ? "
   
    sql.query(query, id, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      if (res.affectedRows == 0) {
        result({ kind: "not_found" }, null);
        return;
      }
      console.log("Updated Blogs : ", { id: id, ...data });
      result(null, data.id);
    });
   };
   
   
   Blogs.getBlogID = (id , result) => {
    let query = ` select bl.*, up.file_original_name as meta_images, up1.file_name as banner_name, bc.category_name as category_name from blogs as bl `

    query += ` left join uploads as up on (up.id = bl.banner) `
    query += ` left join uploads as up1 on (up1.id = bl.meta_img) `
    query += ` left join blog_categories as bc on (bc.id = bl.category_id) `
    query += ` WHERE bl.id = ? `
  
    sql.query(query, id, (err, res) => {
      if (err) {
        result(null, err);
        return;
      }
      if (res == !id) {
        result({ kind: "not_found" });
        return;
      }
      result(null, res[0]);
      console.log(null, res[0]);
    });
  };
 
     Blogs.deleteBlog = (id, result) => {
         console.log(id);
         let query = "DELETE FROM blogs WHERE id = ?";
         sql.query(query, id, (err, res) => {
           if (err) {
             console.log(err)
             result(err, null);
             return;
           }
           if (res.affectedRows == 0) {
             result({ kind: "not_found" }, null);
             return;
           }
           console.log("deleted blog : ", { id: id });
           result(null, res);
         });
       };
 
 module.exports = Blogs;
 