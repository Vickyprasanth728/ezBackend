const sql = require("./db.js");

// constructor
const Color = function (color) {
    this.id = color.id;
    this.name = color.name;
    this.code = color.code;
  };


  Color.getColors = (result) => {
    let query = "SELECT * FROM colors "  
    sql.query(query, (err, res) => {
      if (err) {
        result(null, err);
        return;
      }
      else {
        result(null, res);
      }
    })
  };

  Color.saveColor = (data, result) => {
    console.log(data);
    let query = "INSERT INTO colors SET ?";
    sql.query(query, data, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      result(null, res);
    });
  };


  Color.putColor = (id, data, result) => {

    let name = data.name || null;
    let code = data.code|| null;
   
    let query = "UPDATE colors SET name = '"+name+"', code =  '"+ code +"' , updated_at = now() WHERE id = ? "
  
    sql.query(query, id, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      if (res.affectedRows == 0) {
        // not found Tutorial with the id
        result({ kind: "not_found" }, null);
        return;
      }
      console.log("updated colors : ", { id: id, ...data });
      result(null, data.id);
    });
  };

  Color.getColorID = (id , result) => {
    let query = " SELECT * FROM colors WHERE id = ? "
  
    sql.query(query, id, (err, res) => {
      if (err) {
        result(null, err);
        return;
      }
      result(null, res[0]);
      console.log(null, res[0]);
    });
    };

    Color.deleteColor = (id, result) => {
        console.log(id);
        let query = "DELETE FROM colors WHERE id = ?";
        sql.query(query, id, (err, res) => {
          if (err) {
            console.log(err)
            result(err, null);
            return;
          }
          if (res.affectedRows == 0) {
            result({ kind: "not_found" }, null);
            return;
          }
          console.log("deleted colors : ", { id: id });
          result(null, res);
        });
      };

module.exports = Color;
