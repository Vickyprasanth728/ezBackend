const sql = require("./db.js");


// constructor
const AttributeTranslation = function (attribute) {
  this.id = attribute.id;
  this.attribute_id = attribute.attribute_id;
  this.name = attribute.name;
  this.lang = attribute.lang;
};

AttributeTranslation.getAttributeTranslation = (result) => {
  let query = "select * from attribute_translations "

  sql.query(query, (err, res) => {
    if (err) {
      result(null, err);
      return;
    }
    result(null, res);
  });
};

AttributeTranslation.saveAttributeTranslation = (data, result) => {
    console.log(data);
    let query = "INSERT INTO attribute_translations SET ?";
    sql.query(query, data, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      result(null, res);
    });
  };

  AttributeTranslation.putAttributeTranslation = (attribute_id, data, result) => {

    // let attribute_id = data.attribute_id || null;
    let name = data.name|| null;
    let lang = data.lang || null;
   
    let query = "UPDATE attribute_translations SET name = '"+name+"', lang =  '"+lang+"', updated_at = now()  WHERE attribute_id = ? "
  
    sql.query(query, attribute_id, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      if (res.affectedRows == 0) {
        // not found Tutorial with the id
        result({ kind: "not_found" }, null);
        return;
      }
      console.log("updated attributes translations : ", { id: attribute_id, ...data });
      result(null, data.id);
    });
  };

module.exports = AttributeTranslation;
