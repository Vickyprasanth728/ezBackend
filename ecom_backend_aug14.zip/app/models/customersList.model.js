const sql = require("./db.js");

// Constructor
const CustomerList = function (user) {
  this.referred_by = user.referred_by;
  this.provider_id = user.provider_id;
  this.user_type = user.user_type;
  this.name = user.name;
  this.email = user.email;
  this.email_verified_at = user.email_verified_at;
  this.verification_code = user.verification_code;
  this.new_email_verificiation_code = user.new_email_verificiation_code;
  this.password = user.password;
  this.remember_token = user.remember_token;
  this.device_token = user.device_token;
  this.avatar = user.avatar;
  this.avatar_original = user.avatar_original	;
  this.address = user.address;
  this.country = user.country;
  this.state = user.state	;
  this.city = user.city;
  this.postal_code = user.postal_code;
  this.phone = user.phone;
  this.balance = user.balance;
  this.banned = user.banned;
  this.referral_code = user.referral_code;
  this.customer_package_id = user.customer_package_id;
  this.remaining_uploads = user.remaining_uploads;
 };
 
 
 CustomerList.getCustomerList = (result) => {
    let query  = ` select us.*, cp.name as package, w.amount as wallet_amount, w.payment_method as payment_method, w.payment_details as payment_details from users as us `

        query += ` LEFT JOIN customer_packages as cp on (cp.id =  us.customer_package_id) `
        query += ` LEFT JOIN wallets as w on (us.id = w.user_id) `
        query += ` where us.user_type = "customer" `
        query += ` GROUP BY us.id `
        query += ` ORDER BY us.id asc `
    
     sql.query(query, (err, res) => {
       if (err) {
         result(null, err);
         return;
       }
       result(null, res);
     });
 };

 CustomerList.getCustomerListID = (id , result) => {
  let query  = ` SELECT * FROM users as us `
      query += ` WHERE us.user_type = "customer" and  us.id = ? `

      sql.query(query, id, (err, res) => {
        if (err) {
          result(null, err);
          return;
        }
        if (res == !id) {
          result({ kind: "not_found" }, null);
          return;
        }
        result(null, res[0]);
        console.log(null, res[0]);
      });
  };
   
//  CustomerList.BanCustomerID = (id , result) => {
//     let query  = ` UPDATE users SET banned = '2' `

//         query += ` WHERE user_type = 'customer' `
//         query += ` and id = ?  `

//     sql.query(query, id, (err, res) => {
//       if (err) {
//         console.log(err)
//         result(err, null);
//         return;
//       }
//       if (res.affectedRows == 0) {
//         result({ kind: "not_found" }, null);
//         return;
//       }
//       console.log("Banned Customer Successfully :", { id });
//       result(null, res);
//     });
// };

CustomerList.BanCustomerID = (id, data, result) => {

  let banned = data.banned;
 
  let query = "UPDATE users SET banned ='"+banned+"' , updated_at = now() WHERE id = ? "

  sql.query(query, id, (err, res) => {
    if (err) {
      console.log(err)
      result(err, null);
      return;
    }
    if (res.affectedRows == 0) {
      result({ kind: "not_found" }, null);
      return;
    }
    console.log("Banned Customer Successfully : ", { id: id, ...data });
    result(null, data.id);
  });
};

CustomerList.saveCustomer = (data, result) => {
  console.log(data);
  let query = "INSERT INTO users SET ?";
  sql.query(query, data, (err, res) => {
      if (err) {
          console.log(err)
          result(err, null);
          return;
      }
      result(null, res);
  });
};

// CustomerList.putCustomerList = (id, data, result) => {
  
//   let name  = data.name  || null;
//   let email = data.email || null;
//   let phone = data.phone || null;
//   let balance = data.balance || null;
  
//   let query = " UPDATE users SET name ='"+name+"' , email = ' "+email+" ' , phone = '"+phone+"', balance = "+balance+", updated_at = now()  WHERE id = ? "
//   // let query = ` UPDATE users SET name = '${name}' , email = '${email}', phone = '${phone}' , balance = "+balance+" , updated_at = now()  WHERE id = ? `

//   sql.query(query, id, (err, res) => {
//     if (err) {
//       console.log(err)
//       result(err, null);
//       return;
//     }
//     if (res.affectedRows == 0) {
//       result({ kind: "not_found" }, null);
//       return;
//     }
//     console.log("updated customer : ", { id: id, ...data });
//     result(null, data);
//   });
// };

CustomerList.putCustomerList = (id, data, result) => {

  const updates = [];
  if (data.referred_by!='') updates.push(`referred_by = '${data.referred_by}'`);
  if (data.provider_id!='') updates.push(`provider_id = '${data.provider_id}'`);
  if (data.user_type!='') updates.push(`user_type = '${data.user_type}'`);
  if (data.name!='') updates.push(`name = '${data.name}'`);
  if (data.email!='') updates.push(`email = '${data.email}'`);
  if (data.email_verified_at!='') updates.push(`email_verified_at = '${data.email_verified_at}'`);
  if (data.verification_code!='') updates.push(`verification_code = '${data.verification_code}'`);
  if (data.new_email_verificiation_code!='') updates.push(`new_email_verificiation_code = '${data.new_email_verificiation_code}'`);
  if (data.remember_token!='') updates.push(`remember_token = '${data.remember_token}'`);
  if (data.device_token!='') updates.push(`device_token = '${data.device_token}'`);
  if (data.avatar!='') updates.push(`avatar = '${data.avatar}'`);
  if (data.address!='') updates.push(`address = '${data.address}'`);
  if (data.country!='') updates.push(`country = '${data.country}'`);
  if (data.state!='') updates.push(`state = '${data.state}'`);
  if (data.city!='') updates.push(`city = '${data.city}'`);
  if (data.postal_code!='') updates.push(`postal_code = '${data.postal_code}'`);
  if (data.phone!='') updates.push(`phone = '${data.phone}'`);
  if (data.balance!='') updates.push(`balance = '${data.balance}'`);
  if (data.banned!='') updates.push(`banned = '${data.banned}'`);
  if (data.referral_code!='') updates.push(`referral_code = '${data.referral_code}'`);
  if (data.customer_package_id!='') updates.push(`customer_package_id = '${data.customer_package_id}'`);
  if (data.remaining_uploads!='') updates.push(`remaining_uploads = '${data.remaining_uploads}'`);

  if (updates.length === 0) {
    res.status(400).json({status: (400), message: "No updates provided" });
    return;
  }

  let query = `UPDATE users SET ${updates.join(", ")} WHERE id = ? `


  // let query = "UPDATE users SET referred_by = "+ referred_by+" , provider_id = '"+provider_id+"' , user_type = '"+user_type+"' , name = '"+name+"' , email = '"+email+"' , email_verified_at = "+email_verified_at+" , verification_code = '"+verification_code+"', new_email_verificiation_code = '"+new_email_verificiation_code+"', remember_token = '"+remember_token+"', device_token = '"+device_token+"' , avatar = '"+avatar+"', address = '"+address+"', country = '"+country+"', state = '"+ state+"', city = '"+city+"', postal_code = '"+postal_code+"', phone = '"+phone+"',  balance = "+balance+" ,  banned = "+banned+" , referral_code = '"+referral_code+"', customer_package_id = "+customer_package_id+" ,remaining_uploads = "+remaining_uploads+" , updated_at = now()  WHERE id = ? "

  sql.query(query, id, (err, res) => {
    if (err) {
      console.log(err)
      result(err, null);
      return;
    }
    if (res.affectedRows == 0) {
      // not found Tutorial with the id
      result({ kind: "not_found" }, null);
      return;
    }
    console.log("Updated Customer : ", { id: id, ...data });
    result(null, data.id);
  });
};

  CustomerList.deleteCustomerList = (id, result) => {
      console.log(id);
      let query = ` DELETE FROM users `;

      query += ` WHERE user_type = 'customer' `
      query += ` and id = ?  `

      sql.query(query, id, (err, res) => {
        if (err) {
          console.log(err)
          result(err, null);
          return;
        }
        if (res.affectedRows == 0) {
          result({ kind: "not_found" }, null);
          return;
        }
        console.log("deleted customer : ", { id: id });
        result(null, res);
      });
    };

 module.exports = CustomerList;
