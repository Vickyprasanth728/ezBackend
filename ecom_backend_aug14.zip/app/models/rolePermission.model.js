const sql = require("./db.js");


// constructor
const RolePermission = function (rolePermission) {
    this.permission_id = rolePermission.permission_id;
    this.role_id = rolePermission.role_id;
 };

 RolePermission.getRolePermission = (result) => {
    let query  = ` SELECT rol.id as id, p.* , p.name as permission_name, rol.name as role_name from role_has_permissions as rhp `
        
        query += ` LEFT JOIN permissions as p ON (p.id = rhp.permission_id) `
        query += ` LEFT JOIN roles as rol ON (rol.id = rhp.role_id) `
        query += ` GROUP BY p.id `
        query += ` ORDER BY p.id `
     
     sql.query(query, (err, res) => {
       if (err) {
         result(null, err);
         return;
       }
       result(null, res);
     });
 };

 RolePermission.saveRolePermission = (data, result) => {
    console.log(data);
    let query = "INSERT INTO role_has_permissions SET ?";
    sql.query(query, data, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      result(null, res);
    });
  };
  
  RolePermission.putRolePermission = (role_id, data, result) => {
  
    let permission_id = data.permission_id || null;
   
    let query = "UPDATE role_has_permissions SET permission_id = "+permission_id+"  WHERE role_id = ? "
  
    sql.query(query, role_id , (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      if (res.affectedRows == 0) {
        result({ kind: "not_found" }, null);
        return;
      }
      console.log("updated role permission : ", { id: role_id, ...data });
      result(null, data.role_id);
    });
  };
  
  RolePermission.getRolePermissionID = (id , result) => {
    let query = " SELECT * FROM role_has_permissions WHERE id = ? "
  
    sql.query(query, id, (err, res) => {
      if (err) {
        result(null, err);
        return;
      }
      result(null, res[0]);
      console.log(null, res[0]);
    });
    };
  
    RolePermission.deleteRolePermission = (id, result) => {
      console.log(id);
      let query = "DELETE FROM role_has_permissions WHERE id = ?";
      sql.query(query, id, (err, res) => {
        if (err) {
          console.log(err)
          result(err, null);
          return;
        }
        if (res.affectedRows == 0) {
          // not found Contact with the id
          result({ kind: "not_found" }, null);
          return;
        }
        console.log("deleted role permission : ", { id: id });
        result(null, res);
      });
    };


 module.exports = RolePermission;
