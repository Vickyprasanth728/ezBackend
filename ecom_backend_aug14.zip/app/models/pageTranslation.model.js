const sql = require("./db.js");


// constructor
const PageTranslation = function (page) {
  this.id = page.id;
  this.page_id = page.page_id;
  this.title = page.title;
  this.content = page.content;
  this.lang = page.lang;
};

PageTranslation.getPageTranslation = (result) => {
  let query = "select * from page_translations "

  sql.query(query, (err, res) => {
    if (err) {
      result(null, err);
      return;
    }
    result(null, res);
  });
};

PageTranslation.savePageTranslation = (data, result) => {
    console.log(data);
    let query = "INSERT INTO page_translations SET ?";
    sql.query(query, data, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      result(null, res);
    });
  };

  PageTranslation.putPageTranslation = (page_id, data, result) => {

    // let page_id = data.page_id || null;
    let title = data.title|| null;
    let content = data.content|| null;
    let lang = data.lang || null;
   
    let query = "UPDATE page_translations SET title = '"+title+"', content =  '"+content+"', lang =  '"+lang+"', updated_at = now()  WHERE page_id = ? "
  
    sql.query(query, page_id, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      if (res.affectedRows == 0) {
        result({ kind: "not_found" }, null);
        return;
      }
      console.log("updated page translations : ", { id: page_id, ...data });
      result(null, data.id);
    });
  };

module.exports = PageTranslation;
