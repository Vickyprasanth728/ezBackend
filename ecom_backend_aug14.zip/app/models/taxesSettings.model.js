const sql = require("./db.js");


// constructor
const Taxes = function (taxes) {
    this.id = taxes.id;
    this.name = taxes.name;
    this.tax_status = taxes.tax_status;
 };
 
 
 Taxes.getTaxes = (result) => {
     let query = "select * from taxes "
     
     sql.query(query, (err, res) => {
       if (err) {
         result(null, err);
         return;
       }
       result(null, res);
     });
 };
 
 Taxes.saveTaxes = (data, result) => {
     console.log(data);
     let query = "INSERT INTO taxes SET ?";
     sql.query(query, data, (err, res) => {
       if (err) {
         console.log(err)
         result(err, null);
         return;
       }
       result(null, res);
     });
   };
 
   Taxes.putTaxes = (id, data, result) => {
 
     let name = data.name || null;
     let tax_status = data.status || null;

     let query = "UPDATE taxes SET name = '"+name+"', tax_status = "+tax_status+" , updated_at = now()  WHERE id = ? "
   
     sql.query(query, id, (err, res) => {
       if (err) {
         console.log(err)
         result(err, null);
         return;
       }
       if (res.affectedRows == 0) {
         // not found Tutorial with the id
         result({ kind: "not_found" }, null);
         return;
       }
       console.log("updated taxes : ", { id: id, ...data });
       result(null, data.id);
     });
   };
   
   
   Taxes.getTaxesID = (id , result) => {
     let query = " SELECT * FROM taxes WHERE id = ? "
   
     sql.query(query, id, (err, res) => {
       if (err) {
         result(null, err);
         return;
       }
       result(null, res[0]);
       console.log(null, res[0]);
     });
     };
 
     Taxes.deleteTaxes = (id, result) => {
         console.log(id);
         let query = "DELETE FROM taxes WHERE id = ?";
         sql.query(query, id, (err, res) => {
           if (err) {
             console.log(err)
             result(err, null);
             return;
           }
           if (res.affectedRows == 0) {
             result({ kind: "not_found" }, null);
             return;
           }
           console.log("deleted taxes : ", { id: id });
           result(null, res);
         });
       };
 
 module.exports = Taxes;
 