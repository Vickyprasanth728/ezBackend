const sql = require("./db.js");

// constructor
const CustomerPackage = function (brand) {
    this.id = brand.id;
    this.name = brand.name;
    this.amount = brand.amount;
    this.product_upload = brand.product_upload;
    this.logo = brand.logo;
  };

  CustomerPackage.putCustomerPackage = (id, data, result) => {

    let name = data.name || null;
    let amount = data.amount|| null;
    let product_upload = data.product_upload || null;
    let logo  = data.logo  || null;
   
    let query = "UPDATE customer_packages SET name = ' " + name + " ', amount = " + amount + " , product_upload =  " + product_upload + " , logo = ' " + logo + " ' , updated_at = now()  WHERE id = ? "
  
    sql.query(query, id, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      if (res.affectedRows == 0) {
        // not found Tutorial with the id
        result({ kind: "not_found" }, null);
        return;
      }
      console.log("updated customer package : ", { id: id, ...data });
      result(null, data.id);
    });
  };

 module.exports = CustomerPackage;
