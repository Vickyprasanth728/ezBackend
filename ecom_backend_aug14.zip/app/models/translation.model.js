const sql = require("./db.js");


// constructor
const Translation = function (translation) {
    this.id = translation.id;
    this.lang = translation.lang;
    this.lang_key = translation.lang_key;
    this.lang_value = translation.lang_value;
 };

 Translation.getTranslation = (result) => {
    let query  = ` SELECT * from translations as t `
        query += ` GROUP BY t.id `
        query += ` ORDER BY t.id `
     
     sql.query(query, (err, res) => {
       if (err) {
         result(null, err);
         return;
       }
       result(null, res);
     });
 };
  
 Translation.saveTranslation = (data, result) => {
  console.log(data);
  let query = "INSERT INTO translations SET ?";
  sql.query(query, data, (err, res) => {
    if (err) {
      console.log(err)
      result(err, null);
      return;
    }
    result(null, res);
  });
};

 Translation.putTranslation = (id, data, result) => {
 
    // let lang = data.lang || null;
    // let lang_key = data.lang_key || null;
    // let lang_value = data.lang_value || null;

    // let query = "UPDATE translations SET lang = '"+lang+"' , lang_key = '"+lang_key+"', lang_value = '"+lang_value+"', updated_at = now()  WHERE id = ? "

    const updates = [];
    if (data.lang!='') updates.push(`lang = '${data.lang}'`);
    if (data.lang_key!='') updates.push(`lang_key = '${data.lang_key}'`);
    if (data.lang_value!='') updates.push(`lang_value = '${data.lang_value}'`);
  
    if (updates.length === 0) {
      res.status(400).json({status: (400), message: "No updates provided" });
      return;
    }
  
    let query = `UPDATE translations SET ${updates.join(", ")} WHERE id = ? `
  
    sql.query(query, id, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      if (res.affectedRows == 0) {
        result({ kind: "not_found" }, null);
        return;
      }
      console.log("Updated translations : ", { id: id, ...data });
      result(null, data.id);
    });
  };
  
  Translation.getTranslationID = (id , result) => {
   let query = " SELECT * FROM translations as t"
       query += ` WHERE t.id = ?  `

       sql.query(query, id, (err, res) => {
        if (err) {
          result(null, err);
          return;
        }
        if (res == !id) {
          result({ kind: "not_found" }, null);
          return;
        }
        result(null, res[0]);
        console.log(null, res[0]);
      });
    };

    Translation.deleteTranslation = (id, result) => {
      console.log(id);
      let query = "DELETE FROM translations WHERE id = ?";
      sql.query(query, id, (err, res) => {
        if (err) {
          console.log(err)
          result(err, null);
          return;
        }
        if (res.affectedRows == 0) {
          result({ kind: "not_found" }, null);
          return;
        }
        console.log("deleted translation : ", { id: id });
        result(null, res);
      });
    };

module.exports = Translation;

