const sql = require("./db.js");

// constructor
const TicketSupports = function (tickets) {
    this.id = tickets.id;
    this.code = tickets.code || null,
    this.user_id = tickets.user_id || null,
    this.subject = tickets.subject || null,
    this.details = tickets.details || null,
    this.files = tickets.files || null,
    this.status = tickets.status || null,
    this.viewed = tickets.viewed || null,
    this.client_viewed = tickets.client_viewed || null
  };

// Ticket Supports List
TicketSupports.getTicketsList = (result) => {

    let query  = ` SELECT tic.* , tic.created_at as sending_date, tic.subject as subject, us.name as user, tic.status as status, tr.reply as reply, tr.created_at as last_reply FROM tickets as tic `

        query += ` LEFT JOIN ticket_replies as tr on (tr.ticket_id = tic.id) `
        query += ` LEFT JOIN users as us on (us.id = tic.user_id) `
        query += ` GROUP BY tic.id `  
        query += ` ORDER BY tic.id `  

    sql.query(query, (err, res) => {
        if (err) {    
        result(null, err);
        return;
        } 
        else {
        result(null, res);
        }
    })  
};

TicketSupports.getTicketID = (id , result) => {
  let query  = ` SELECT tic.* , tic.created_at as sending_date, tic.subject as subject, us.name as user, us.user_type as user_type, tic.status as status, tr.reply as reply, tr.created_at as last_reply FROM tickets as tic `

  query += ` LEFT JOIN ticket_replies as tr on (tr.ticket_id = tic.id) `
  query += ` LEFT JOIN users as us on (us.id = tic.user_id) `
  query += ` WHERE tic.id = ? `
  query += ` GROUP BY tic.id `  
  query += ` ORDER BY tic.id `

  sql.query(query, id, (err, res) => {
    if (err) {
      result(null, err);
      return;
    }
    result(null, res);
    console.log(null, res);
  });
  };


TicketSupports.saveTicket = (data, result) => {
    console.log(data);
    let query = "INSERT INTO tickets SET ?";
    sql.query(query, data, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      result(null, res);
    });
  };

  TicketSupports.UpdateTicketView = (keyword, id, result) => {
    // let query  = ` UPDATE tickets SET viewed = '1' `

    //     query += ` WHERE id = ?  `

    let query = ``

    if (keyword == "viewed") {
      query += ` UPDATE tickets SET viewed = '1' `
      query += ` WHERE id = ?  `
    }
    else if (keyword == "client_viewed") {
      query += ` UPDATE tickets SET client_viewed = '1' `
      query += ` WHERE id = ?  `
    }

    sql.query(query, id, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      if (res.affectedRows == 0) {
        result({ kind: "not_found" }, null);
        return;
      }
      console.log("Viewed Ticket Successfully :", { id });
      result(null, res);
    });
};

module.exports = TicketSupports;
