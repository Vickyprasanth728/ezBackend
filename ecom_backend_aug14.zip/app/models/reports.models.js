const sql = require("./db.js");


// constructor
const Reports = function (reports) {
    this.id = reports.id;
 };

 Reports.getReportsProductSale = (result) => {
    let query  = ` SELECT p.id as id, p.name as product_name, p.num_of_sale as no_of_sale from products as p `
        
        query += ` GROUP BY p.id `
        query += ` ORDER BY p.id `
     
     sql.query(query, (err, res) => {
       if (err) {
         result(null, err);
         return;
       }
       result(null, res);
     });
 };
 Reports.getReportsSellerSale = (result) => {
    let query  = ` SELECT p.id as id, us.name as seller_name, sh.name as shop_name, p.num_of_sale as no_of_sale , o.grand_total as order_amount from products as p `
        
        query += ` LEFT JOIN users as us on (us.id = p.user_id) `
        query += ` LEFT JOIN orders as o on (us.id = o.user_id) `
        query += ` LEFT JOIN shops as sh on (us.id = sh.user_id) `
        query += ` GROUP BY p.id `
        query += ` ORDER BY p.id `
     
     sql.query(query, (err, res) => {
       if (err) {
         result(null, err);
         return;
       }
       result(null, res);
     });
 };

 Reports.getReportsProductStock = (result) => {
    let query  = ` SELECT p.id as id, p.name as product_name, ps.price as stock from products as p `
        
        query += ` LEFT JOIN product_stocks as ps on (p.id = ps.product_id) `
        query += ` GROUP BY p.id `
        query += ` ORDER BY p.id `
     
     sql.query(query, (err, res) => {
       if (err) {
         result(null, err);
         return;
       }
       result(null, res);
     });
 };

 Reports.getReportsProductWishlist = (result) => {
    let query  = ` SELECT p.name as product_name, COUNT(wi.product_id) as num_of_wish from wishlists as wi `
        
        query += ` LEFT JOIN users as us on (us.id = wi.user_id) `
        query += ` LEFT JOIN products as p on (p.id = wi.product_id) `
        query += ` GROUP BY p.id `
        query += ` ORDER BY p.id `
     
     sql.query(query, (err, res) => {
       if (err) {
         result(null, err);
         return;
       }
       result(null, res);
     });
 };
 Reports.getReportsUserSearch = (result) => {
    let query  = ` SELECT * from searches as sea `
        
        query += ` GROUP BY sea.id `
        query += ` ORDER BY sea.id `
     
     sql.query(query, (err, res) => {
       if (err) {
         result(null, err);
         return;
       }
       result(null, res);
     });
 };

 Reports.getReportsCommission = (result) => {

   let query =  ` SELECT ch.id as id, o.code as code, ch.admin_commission as admin_commission, ch.seller_earning as seller_earning, ch.created_at as created_at from commission_histories as ch `
      
      query += ` LEFT JOIN orders as o on (o.id = ch.order_id) `
      query += ` LEFT JOIN sellers as s on (s.id = ch.seller_id) `
      query += ` LEFT JOIN order_details as od on (od.id = ch.order_detail_id) `
      query += ` GROUP BY ch.id `
      query += ` ORDER BY ch.id `
   
   sql.query(query, (err, res) => {
     if (err) {
       result(null, err);
       return;
     }
     result(null, res);
   });
};

 Reports.getReportsWalletRecharge = (result) => {
    // let query  = ` SELECT p.id as id, us.name as customer, w.created_at as date, w.amount as amount, w.payment_method as payment_method, p.approved as approval from products as p `

    //     query += ` LEFT JOIN users as us ON (us.id = p.user_id) `
    //     query += ` LEFT JOIN wallets as w ON (us.id = w.user_id) `
    //     query += ` Where us.user_type = 'customer' `
    //     query += ` GROUP BY p.id `
    //     query += ` ORDER BY p.id `

    let query  = ` SELECT w.*, us.name as customer_name from wallets as w `

        query += ` LEFT JOIN users as us ON (us.id = w.user_id) `
        query += ` Where us.user_type = 'customer' `
        query += ` GROUP BY w.id `
        query += ` ORDER BY w.id `
     
     sql.query(query, (err, res) => {
       if (err) {
         result(null, err);
         return;
       }
       result(null, res);
     });
 };


module.exports = Reports;
