const sql = require("./db.js");


// constructor
const AttributeCategory = function (attribute) {
  this.id = attribute.id;
  this.category_id = attribute.category_id;
  this.attribute_id = attribute.attribute_id;
};

AttributeCategory.getAttributeCategory = (result) => {
  let query = "select * from attribute_category "

  sql.query(query, (err, res) => {
    if (err) {
      result(null, err);
      return;
    }
    result(null, res);
  });
};

AttributeCategory.saveAttributeCategory = (data, result) => {
    console.log(data);
    let query = "INSERT INTO attribute_category SET ?";
    sql.query(query, data, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      result(null, res);
    });
  };

  AttributeCategory.putAttributeCategory = (attribute_id, data, result) => {

    let category_id = data.category_id|| null;
   
    let query = "UPDATE attribute_category SET category_id = "+category_id+" , updated_at = now()  WHERE attribute_id = ? "
  
    sql.query(query, attribute_id, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      if (res.affectedRows == 0) {
        result({ kind: "not_found" }, null);
        return;
      }
      console.log("updated attributes category : ", { id: attribute_id, ...data });
      result(null, data.id);
    });
  };

module.exports = AttributeCategory;