const sql = require("./db.js");
var md5 = require('md5');

// constructor
const Seller = function (seller) {
  this.id = seller.id;
  this.referred_by = seller.referred_by;
  this.provider_id = seller.provider_id;
  this.seller_type = seller.seller_type;
  this.name = seller.name;
  this.email = seller.email;
  this.email_verified_at = seller.email_verified_at;
  this.verification_code = seller.verification_code;
  this.new_email_verificiation_code = seller.new_email_verificiation_code;
  this.password = seller.password;
  this.remember_token = seller.remember_token;
  this.device_token = seller.device_token;
  this.avatar = seller.avatar;
  this.avatar_original = seller.avatar_original;
  this.address = seller.address;
  this.country = seller.country;
  this.state = seller.state;
  this.city = seller.city;
  this.postal_code = seller.postal_code;
  this.phone = seller.phone;
  this.balance = seller.balance;
  this.banned = seller.banned;
  this.referral_code = seller.referral_code;
  this.customer_package_id = seller.customer_package_id;
  this.remaining_uploads = seller.remaining_uploads;
};

// Seller List
Seller.getSellerList = (result) => {

  let query  = ` SELECT us.*, sh.name as shop_name, sh.verification_info as verification_info, p.approved as approval, us.user_type as users_type, pay.amount as due_to_seller, pay.payment_details as payment_details, pay.payment_method as payment_method FROM users as us `

      query += ` LEFT JOIN products as p on (p.user_id = us.id) `
      query += ` LEFT JOIN sellers as se on (se.user_id = us.id) `
      query += ` LEFT JOIN shops as sh on (sh.user_id = us.id) `
      query += ` LEFT JOIN payments as pay on (pay.seller_id = se.id) `
      query += ` WHERE us.user_type = 'seller' and us.banned = 0 `
      query += ` GROUP BY us.id `
      query += ` ORDER BY us.id `

  sql.query(query, (err, res) => {
    if (err) {
      result(null, err);
      return;
    }
    else {
      result(null, res);
    }
  })
};
// Seller Edit List
Seller.getSellerEdit = (id, result) => {

  let query  = ` SELECT us.name as name , us.email as email, us.password as password FROM users as us `

      query += ` LEFT JOIN products as p on (p.user_id = us.id) `
      query += ` LEFT JOIN sellers as se on (se.user_id = us.id) `
      query += ` LEFT JOIN shops as sh on (sh.user_id = us.id) `
      query += ` LEFT JOIN payments as pay on (pay.seller_id = se.id) `
      query += ` WHERE us.user_type = 'seller' and us.banned = 0 and us.id = ? `
      query += ` GROUP BY us.id `
      query += ` ORDER BY us.id `

  sql.query(query, id, (err, res) => {
    if (err) {
      console.log(err)
      result(err, null);
      return;
    }
    if (res.affectedRows == 0) {
      result({ kind: "not_found" }, null);
      return;
    }
    console.log("Successfully  :", { id });
    result(null, res);
  })
};

Seller.getSellerPayouts = (result) => {

  let query = ` SELECT pay.id as id , pay.created_at as date, sh.name as seller, us.name as user_name, pay.amount as amount, pay.payment_details as payment_details FROM payments as pay `

  query += ` LEFT JOIN sellers as se on (se.id = pay.seller_id) `
  query += ` LEFT JOIN users as us on (us.id = se.user_id) `
  query += ` LEFT JOIN shops as sh on (sh.user_id = us.id) `
  query += ` GROUP BY pay.id `
  query += ` ORDER BY pay.id `

  sql.query(query, (err, res) => {
    if (err) {
      result(null, err);
      return;
    }
    else {
      result(null, res);
    }
  })
};

Seller.getSellerPayoutsREQ = (result) => {

  let query = ` SELECT swr.id as id , swr.created_at as date, sh.name as shop_name, us.name as seller_name, pay.amount as total_amount, swr.amount as request_amount, swr.message as message, swr.status as status FROM seller_withdraw_requests as swr  `

  query += ` LEFT JOIN payments as pay on (pay.id = pay.seller_id) `
  query += ` LEFT JOIN sellers as se on (se.id = pay.seller_id) `
  query += ` LEFT JOIN users as us on (us.id = se.user_id) `
  query += ` LEFT JOIN shops as sh on (sh.user_id = us.id) `
  query += ` GROUP BY swr.id `
  query += ` ORDER BY swr.id `

  sql.query(query, (err, res) => {
    if (err) {
      result(null, err);
      return;
    }
    else {
      result(null, res);
    }
  })
};

// Banner Seller 
Seller.BanSellerID = (id, result) => {
  let query = ` UPDATE users SET banned = '2' `

  query += ` WHERE user_type = 'seller' `
  query += ` and id = ?  `

  sql.query(query, id, (err, res) => {
    if (err) {
      console.log(err)
      result(err, null);
      return;
    }
    if (res.affectedRows == 0) {
      result({ kind: "not_found" }, null);
      return;
    }
    console.log("Successfully Banned Seller  :", { id });
    result(null, res);
  });
};

Seller.putSellerList = (id, data, result) => {

  const hashedPassword = md5(data.password)

  let name = data.name || null;
  let email = data.email || null;
  let password = hashedPassword || null;

  let query = ` UPDATE users SET name = '${name}' , email = '${email}', password = '${password}', updated_at = now()  WHERE id = ? `

  sql.query(query, id, (err, res) => {
    if (err) {
      console.log(err)
      result(err, null);
      return;
    }
    if (res.affectedRows == 0) {
      result({ kind: "not_found" }, null);
      return;
    }
    console.log("updated seller : ", { id: id, ...data });
    result(null, data.id);
  });
};

Seller.deleteSellerList = (id, result) => {
  console.log(id);

  let query = ` DELETE FROM users `;

  query += ` WHERE user_type = 'seller' `
  query += ` and id = ?  `

  sql.query(query, id, (err, res) => {
    if (err) {
      console.log(err)
      result(err, null);
      return;
    }
    if (res.affectedRows == 0) {
      result({ kind: "not_found" }, null);
      return;
    }
    console.log("deleted Seller : ", { id: id });
    result(null, res);
  });
};


module.exports = Seller;
