const sql = require("./db.js");


// constructor
const AttributeValues = function (attribute) {
  this.id = attribute.id;
  this.attribute_id = attribute.attribute_id;
  this.value = attribute.value;
  this.color_code = attribute.color_code;
};

AttributeValues.getAttributeValues = (result) => {
  let query  = ` SELECT av.* , att.name as name FROM attribute_values as av` 
    
      query += ` LEFT JOIN attributes as att on (att.id = av.attribute_id) `
      query += ` GROUP BY av.id `
      query += ` ORDER BY av.id `

  sql.query(query, (err, res) => {
    if (err) {
      result(null, err);
      return;
    }
    result(null, res);
  });
};

AttributeValues.saveAttributeValue = (data, result) => {
    console.log(data);
    let query = "INSERT INTO attribute_values SET ?";
    sql.query(query, data, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      result(null, res);
    });
  };

  AttributeValues.putAttributeValue = (attribute_id, data, result) => {

    // let attribute_id = data.attribute_id || null;
    let value = data.value|| null;
    let color_code = data.color_code|| null;
   
    let query = "UPDATE attribute_values SET attribute_id =  '"+attribute_id+"' , value =  '"+value+"' , color_code =  '"+color_code+"' , updated_at = now() WHERE attribute_id = ? "
  
    sql.query(query, attribute_id, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      if (res.affectedRows == 0) {
        result({ kind: "not_found" }, null);
        return;
      }
      console.log("updated attribute values : ", { attribute_id: attribute_id, ...data });
      result(null, data.id);
    });
  };

  AttributeValues.getAttributeValueID = (id , result) => {
    let query = " SELECT * FROM attribute_values WHERE id = ? "
  
    sql.query(query, id, (err, res) => {
      if (err) {
        result(null, err);
        return;
      }
      result(null, res[0]);
      console.log(null, res[0]);
    });
    };

    AttributeValues.deleteAttributeValue = (id, result) => {
        console.log(id);
        let query = "DELETE FROM attribute_values WHERE id = ?";
        sql.query(query, id, (err, res) => {
          if (err) {
            console.log(err)
            result(err, null);
            return;
          }
          if (res.affectedRows == 0) {
            result({ kind: "not_found" }, null);
            return;
          }
          console.log("deleted attribute values : ", { id: id });
          result(null, res);
        });
      };
module.exports = AttributeValues;