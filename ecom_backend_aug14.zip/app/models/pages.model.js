const sql = require("./db.js");

// constructor
const Pages = function (pages) {
    this.type = pages.type;
    this.title = pages.title;
    this.slug = pages.slug;
    this.content = pages.content;
    this.meta_title = pages.meta_title;
    this.meta_description = pages.meta_description;
    this.keywords = pages.keywords;
    this.meta_image = pages.meta_image;
 };
 
 
 Pages.getPages = (result) => {
    let query = ` select * from pages `
     
     sql.query(query, (err, res) => {
       if (err) {
         result(null, err);
         return;
       }
       result(null, res);
     });
 };


 Pages.savePage = (data, result) => {
  console.log(data);
  let query = "INSERT INTO pages SET ?";
  sql.query(query, data, (err, res) => {
    if (err) {
      console.log(err)
      result(err, null);
      return;
    }
    result(null, res);
  });
};

Pages.putPage = (id, data, result) => {

  // let  type = data.type || null;
  // let  title = data.title || null;
  // let  slug = data.slug || null;
  // let  content = data.content || null;
  // let  meta_title = data.meta_title || null;
  // let  meta_description = data.meta_description || null;
  // let  keywords = data.keywords || null;
  // let  meta_image = data.meta_image || null;

  const updates = [];
  if (data.type!='') updates.push(`type = '${data.type}'`);
  if (data.title!='') updates.push(`title = '${data.title}'`);
  if (data.slug!='') updates.push(`slug = '${data.slug}'`);
  if (data.content!='') updates.push(`content = '${data.content}'`);
  if (data.meta_title!='') updates.push(`meta_title = '${data.meta_title}'`);
  if (data.meta_description!='') updates.push(`meta_description = '${data.meta_description}'`);
  if (data.keywords!='') updates.push(`keywords = '${data.keywords}'`);
  if (data.meta_image!='') updates.push(`meta_image = '${data.meta_image}'`);

  if (updates.length === 0) {
    res.status(400).json({status: (400), message: "No updates provided" });
    return;
  }

  let query = `UPDATE pages SET ${updates.join(", ")} WHERE id = ? `
 
  // let query = "UPDATE pages SET type = '"+type+"', title =  '"+title+"' , slug =  '"+slug+"' , content =  '"+content+"', meta_title =  '"+meta_title+"' , meta_description =  '"+meta_description+"' , keywords =  '"+keywords+"', meta_image =  '"+meta_image+"' , updated_at = now() WHERE id = ? "

  sql.query(query, id, (err, res) => {
    if (err) {
      console.log(err)
      result(err, null);
      return;
    }
    if (res.affectedRows == 0) {
      result({ kind: "not_found" }, null);
      return;
    }
    console.log("Updated Page : ", { id: id, ...data });
    result(null, data.id);
  });
};

Pages.getPageID = (id , result) => {
  let query = " SELECT * FROM pages WHERE id = ? "

  sql.query(query, id, (err, res) => {
    if (err) {
      result(null, err);
      return;
    }
    if (res == !id) {
      result({ kind: "not_found" }, null);
      return;
    }
    result(null, res[0]);
    console.log(null, res[0]);
  });
  };

  Pages.deletePage = (id, result) => {
    console.log(id);
    let query = "DELETE FROM pages WHERE id = ?";
    sql.query(query, id, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      if (res.affectedRows == 0) {
        result({ kind: "not_found" }, null);
        return;
      }
      console.log("deleted pages : ", { id: id });
      result(null, res);
    });
  };

 module.exports = Pages;
