const sql = require("./db.js");

// Constructor
const SalesList = function (sale) {
    this.combined_order_id = sale.combined_order_id,
    this.user_id = sale.user_id,
    this.guest_id = sale.guest_id,
    this.seller_id = sale.seller_id,
    this.shipping_address = sale.shipping_address,
    this.additional_info = sale.additional_info,
    this.shipping_type = sale.shipping_type,
    this.pickup_point_id = sale.pickup_point_id,
    this.carrier_id = sale.carrier_id,
    this.delivery_status = sale.delivery_status,
    this.payment_type = sale.payment_type,
    this.payment_status = sale.payment_status,
    this.payment_details = sale.payment_details,
    this.grand_total = sale.grand_total,
    this.coupon_discount = sale.coupon_discount,
    this.code = sale.code,
    this.tracking_code = sale.tracking_code,
    this.date = sale.date,
    this.viewed = sale.viewed,
    this.delivery_viewed = sale.delivery_viewed,
    this.payment_status_viewed = sale.payment_status_viewed,
    this.commission_calculated = sale.commission_calculated
 };

 SalesList.getAllOrdersList = (result) => {
  let query  = ` select o.*, o.code as order_code, us.name as customer_name, us1.name as seller, sh.name as shop_name, o.grand_total as amount, o.delivery_status as delivery_status, o.delivery_status as payment_method, o.payment_status as payment_status, us.user_type as user_type, car.name as carrier_name, ps.name as status_payment, ds.name as status_delivery, st.name as type_shipping, COUNT(p.id) as num_of_products from orders as o `

      query += ` LEFT JOIN users as us on (us.id = o.user_id) `
      query += ` LEFT JOIN users as us1 on (us1.id = o.seller_id) `
      query += ` LEFT JOIN products as p on (us.id = p.user_id) `
      query += ` LEFT JOIN shops as s on (s.user_id = us.id) `
      query += ` LEFT JOIN shops as sh on (sh.id = o.seller_id) `
      query += ` LEFT JOIN payments as pay on (us.id = o.user_id) `
      query += ` LEFT JOIN carriers as car on (car.id = o.carrier_id) `
      query += ` LEFT JOIN delivery_status as ds on (ds.id = o.delivery_status) `
      query += ` LEFT JOIN payment_status as ps on (ps.id = o.payment_status) `
      query += ` LEFT JOIN shipping_type as st on (st.id = o.shipping_type) `
      query += ` GROUP BY o.id `
      query += ` ORDER BY o.id DESC  `
  
   sql.query(query, (err, res) => {
     if (err) {
       result(null, err);
       return;
     }
     result(null, res);
   });
};

SalesList.getAllOrderDetailsID = (id , result) => {

  let query  = ` select od.*, us.name as name, us.email as email, us.phone as phone, us.address as address, us.country as country, o.code as order_code, sh.name as shop_name , us.name as customer_name, o.grand_total as amount, o.delivery_status as delivery_status, o.delivery_status as payment_method, o.payment_status as payment_status, o.additional_info as addi_info, us.user_type as user_type, pro.id as prod_id, pro.thumbnail_img as photo, pro.description as description, COUNT(pro.id) as num_of_products from order_details as od `

  query += ` LEFT JOIN orders as o on (o.id = od.order_id) `
  query += ` LEFT JOIN sellers as s on (s.id = od.seller_id) `
  query += ` LEFT JOIN users as us on (us.id = o.user_id) `
  query += ` LEFT JOIN shops as sh on (us.id = sh.user_id) `
  query += ` LEFT JOIN products as pro on (pro.id = od.product_id) `
  query += ` LEFT JOIN pickup_points as pp on (pp.id = od.pickup_point_id) `
  query += ` WHERE od.id = ? `
  query += ` GROUP BY od.id `
  query += ` ORDER BY od.id DESC  `

  sql.query(query, id, (err, res) => {
    if (err) {
      result(null, err);
      return;
    }
    if (res == !id) {
      result({ kind: "not_found" });
      return;
    }
    result(null, res[0]);
    console.log(null, res[0]);
  });
  };

 SalesList.getInhouseOrders = (result) => {
    let query  = ` select o.id as id , o.code as order_code, s.name as seller, us.name as customer_name, o.grand_total as amount, o.delivery_status as delivery_status, o.delivery_status as payment_method, o.payment_status as payment_status, us.user_type as user_type, COUNT(p.id) as num_of_products from orders as o `

        query += ` LEFT JOIN users as us on (us.id = o.user_id) `
        query += ` LEFT JOIN products as p on (us.id = p.user_id) `
        query += ` LEFT JOIN shops as s on (s.user_id = us.id) `
        query += ` LEFT JOIN payments as pay on (us.id = o.user_id) `
        query += ` WHERE us.user_type = 'customer' `
        query += ` GROUP BY o.id `
        query += ` ORDER BY o.id DESC  `
    
     sql.query(query, (err, res) => {
       if (err) {
         result(null, err);
         return;
       }
       result(null, res);
     });
 };

 SalesList.getSellerOrders = (result) => {
  let query  = ` select o.id as id , o.code as order_code, s.name as seller, us.name as seller_name, o.grand_total as amount, o.delivery_status as delivery_status, o.payment_type as payment_method, o.payment_status as payment_status, us.user_type as user_type, COUNT(p.id) as num_of_products from orders as o `

      query += ` LEFT JOIN users as us on (us.id = o.user_id) `
      query += ` LEFT JOIN products as p on (us.id = p.user_id) `
      query += ` LEFT JOIN payments as pay on (us.id = o.user_id) `
      query += ` LEFT JOIN sellers as se on (se.id = o.seller_id) `
      query += ` LEFT JOIN shops as s on (s.user_id = us.id) `
      query += ` WHERE us.user_type = 'seller' `
      query += ` GROUP BY o.id `
      query += ` ORDER BY o.id DESC  `
  
   sql.query(query, (err, res) => {
     if (err) {
       result(null, err);
       return;
     }
     result(null, res);
   });
};

SalesList.getPickPointOrders = (result) => {
  let query  = ` select o.id , o.code as order_code, s.name as seller, us.name as customer_name, o.grand_total as amount, o.delivery_status as delivery_status, o.payment_type as payment_method, o.payment_status as payment_status, pp.name as pickpoint_name , us.user_type as user_type, COUNT(p.id) as num_of_products from orders as o `

      query += ` LEFT JOIN users as us on (us.id = o.user_id) `
      query += ` LEFT JOIN products as p on (us.id = p.user_id) `
      query += ` LEFT JOIN shops as s on (s.user_id = us.id) `
      query += ` LEFT JOIN payments as pay on (us.id = o.user_id) `
      query += ` LEFT JOIN pickup_points as pp on (pp.id = o.pickup_point_id) `
      query += ` WHERE o.pickup_point_id = '1' `
      query += ` GROUP BY o.id `
      query += ` ORDER BY o.id DESC  `
  
   sql.query(query, (err, res) => {
     if (err) {
       result(null, err);
       return;
     }
     result(null, res);
   });
};

 SalesList.getSalesListID = (id , result) => {

  let query  = ` select o.*, o.code as order_code, us.name as customer_name, us1.name as seller, sh.name as shop_name, o.grand_total as amount, o.delivery_status as delivery_status, o.delivery_status as payment_method, o.payment_status as payment_status, us.user_type as user_type, car.name as carrier_name, ps.name as status_payment, ds.name as status_delivery, st.name as type_shipping, COUNT(p.id) as num_of_products from orders as o `

      query += ` LEFT JOIN users as us on (us.id = o.user_id) `
      query += ` LEFT JOIN users as us1 on (us1.id = o.seller_id) `
      query += ` LEFT JOIN products as p on (us.id = p.user_id) `
      query += ` LEFT JOIN shops as s on (s.user_id = us.id) `
      query += ` LEFT JOIN shops as sh on (sh.id = o.seller_id) `
      query += ` LEFT JOIN payments as pay on (us.id = o.user_id) `
      query += ` LEFT JOIN carriers as car on (car.id = o.carrier_id) `
      query += ` LEFT JOIN delivery_status as ds on (ds.id = o.delivery_status) `
      query += ` LEFT JOIN payment_status as ps on (ps.id = o.payment_status) `
      query += ` LEFT JOIN shipping_type as st on (st.id = o.shipping_type) `
      query += ` WHERE o.id = ? `

  sql.query(query, id, (err, res) => {
    if (err) {
      result(null, err);
      return;
    }
    if (res == !id) {
      result({ kind: "not_found" });
      return;
    }
    result(null, res[0]);
    console.log(null, res[0]);
  });
  };

  SalesList.deleteSalesList = (id, result) => {
    console.log(id);
    let query = "DELETE FROM orders WHERE id = ?";
    sql.query(query, id, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      if (res.affectedRows == 0) {
        result({ kind: "not_found" }, null);
        return;
      }
      console.log("Deleted order : ", { id: id });
      result(null, res);
    });
  };

  SalesList.saveOrder = (data, result) => {
    console.log(data);
    let query = "INSERT INTO orders SET ?";
    sql.query(query, data, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      result(null, res);
    });
  };


  SalesList.updateOrder = (id, data, result) => {

    const updates = [];
    if (data.combined_order_id!='') updates.push(`combined_order_id = '${data.combined_order_id}'`);
    if (data.user_id!='') updates.push(`user_id = '${data.user_id}'`);
    if (data.guest_id!='') updates.push(`guest_id = '${data.guest_id}'`);
    if (data.seller_id!='') updates.push(`seller_id = '${data.seller_id}'`);
    if (data.shipping_address!='') updates.push(`shipping_address = '${data.shipping_address}'`);
    if (data.additional_info!='') updates.push(`additional_info = '${data.additional_info}'`);
    if (data.shipping_type!='') updates.push(`shipping_type = '${data.shipping_type}'`);
    if (data.pickup_point_id!='') updates.push(`pickup_point_id = '${data.pickup_point_id}'`);
    if (data.carrier_id!='') updates.push(`carrier_id = '${data.carrier_id}'`);
    if (data.delivery_status!='') updates.push(`delivery_status = '${data.delivery_status}'`);
    if (data.payment_type!='') updates.push(`payment_type = '${data.payment_type}'`);
    if (data.payment_status!='') updates.push(`payment_status = '${data.payment_status}'`);
    if (data.payment_details!='') updates.push(`payment_details = '${data.payment_details}'`);
    if (data.grand_total!='') updates.push(`grand_total = '${data.grand_total}'`);
    if (data.coupon_discount!='') updates.push(`coupon_discount = '${data.coupon_discount}'`);
    if (data.code!='') updates.push(`code = '${data.code}'`);
    if (data.tracking_code!='') updates.push(`tracking_code = '${data.tracking_code}'`);
    if (data.date!='') updates.push(`date = '${data.date}'`);
    if (data.viewed!='') updates.push(`viewed = '${data.viewed}'`);
    if (data.delivery_viewed!='') updates.push(`delivery_viewed = '${data.delivery_viewed}'`);
    if (data.payment_status_viewed!='') updates.push(`payment_status_viewed = '${data.payment_status_viewed}'`);
    if (data.commission_calculated!='') updates.push(`commission_calculated = '${data.commission_calculated}'`);
  
    if (updates.length === 0) {
      res.status(400).json({status: (400), message: "No updates provided" });
      return;
    }
  
    let query = `UPDATE orders SET ${updates.join(", ")} WHERE id = ? `
  
      sql.query(query, id, (err, res) => {
        if (err) {
          console.log(err)
          result(err, null);
          return;
        }
        if (res.affectedRows == 0) {
          result({ kind: "not_found" }, null);
          return;
        }
        console.log("Updated Order : ", { id: id, ...data });
        result(null, data.id);
      });
     };
 module.exports = SalesList;
