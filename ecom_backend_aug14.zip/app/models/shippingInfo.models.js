const sql = require("./db.js");

// constructor
const ShippingInfo = function (addresses) {
    this.id = addresses.id;
    this.user_id = addresses.user_id || null,
    this.address = addresses.address || null,
    this.country_id = addresses.country_id || null,
    this.state_id = addresses.state_id	 || null,
    this.city_id = addresses.city_id || null,
    this.longitude = addresses.longitude || null,
    this.latitude = addresses.latitude || null,
    this.postal_code = addresses.postal_code || null,
    this.phone = addresses.phone || null,
    this.set_default = addresses.set_default || null
  };


  ShippingInfo.getShippingInfo = (result) => {
    
    let query  = ` SELECT ad.*, st.name as state, cou.name as country, c.name as city, us.name as users from addresses as ad `

        query += ` LEFT JOIN states as st ON (ad.state_id = st.id) `
        query += ` LEFT JOIN countries as cou ON (ad.country_id = cou.id) `
        query += ` LEFT JOIN cities as c ON (ad.city_id = c.id) `
        query += ` LEFT JOIN users as us ON (ad.user_id = us.id) `
        query += ` GROUP BY ad.id `
        query += ` ORDER BY ad.id `

    sql.query(query, (err, res) => {
      if (err) {
        result(null, err);
        return;
      }
      else {
        result(null, res);
      }
    })
  };

  ShippingInfo.saveShippingInfo = (data, result) => {
    console.log(data);
    let query = "INSERT INTO addresses SET ?";
    sql.query(query, data, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      result(null, res);
    });
  };

  ShippingInfo.putShippingInfo = (id, data, result) => {

    let user_id = data.user_id || null
    let address = data.address || null
    let country_id = data.country_id || null
    let state_id = data.state_id || null
    let city_id = data.city_id || null
    let longitude = data.longitude || null
    let latitude = data.latitude || null
    let postal_code = data.postal_code || null
    let phone = data.phone || null
    let set_default = data.set_default || null
   
    let query = "UPDATE addresses SET user_id = "+user_id+" , address = '"+address+"' , country_id =  "+country_id+" , country_id = "+country_id+" , state_id = "+state_id+",  city_id = "+city_id+" , longitude = "+longitude+" , latitude = "+latitude+" , postal_code = '"+postal_code+"' , phone = '"+phone+"' , set_default = "+set_default+" ,   updated_at = now()  WHERE id = ? "
  
    sql.query(query, id, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      if (res.affectedRows == 0) {
        // not found Tutorial with the id
        result({ kind: "not_found" }, null);
        return;
      }
      console.log("Updated Shipping Info : ", { id: id, ...data });
      result(null, data.id);
    });
  };

  ShippingInfo.getShippingInfoID = (id , result) => {

    let query  = ` SELECT ad.*, st.name as state, cou.name as country, c.name as city, us.name as users from addresses as ad `

        query += ` LEFT JOIN states as st ON (ad.state_id = st.id) `
        query += ` LEFT JOIN countries as cou ON (ad.country_id = cou.id) `
        query += ` LEFT JOIN cities as c ON (ad.city_id = c.id) `
        query += ` LEFT JOIN users as us ON (ad.user_id = us.id) `
        query += ` WHERE ad.id = ? `
        query += ` GROUP BY ad.id `
        query += ` ORDER BY ad.id `
  
    sql.query(query, id, (err, res) => {
      if (err) {
        result(null, err);
        return;
      }
      result(null, res[0]);
      console.log(null, res[0]);
    });
    };

    ShippingInfo.deleteShippingInfo = (id, result) => {
        console.log(id);
        let query = "DELETE FROM addresses WHERE id = ?";
        sql.query(query, id, (err, res) => {
          if (err) {
            console.log(err)
            result(err, null);
            return;
          }
          if (res.affectedRows == 0) {
            // not found Contact with the id
            result({ kind: "not_found" }, null);
            return;
          }
          console.log("Deleted Shipping Info : ", { id: id });
          result(null, res);
        });
      };

module.exports = ShippingInfo;
