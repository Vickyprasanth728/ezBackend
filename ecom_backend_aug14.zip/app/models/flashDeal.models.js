const sql = require("./db.js");


// constructor
const FlashDeal = function (flashdeal) {
  this.id = flashdeal.id;
  this.title = flashdeal.title;
  this.start_date = flashdeal.start_date;
  this.end_date = flashdeal.end_date;
  this.status = flashdeal.status;
  this.featured = flashdeal.featured;
  this.background_color = flashdeal.background_color;
  this.text_color = flashdeal.text_color;
  this.banner = flashdeal.banner;
  this.slug = flashdeal.slug;
};


FlashDeal.getFlashDeal = (result) => {
  let query = " SELECT fd.*, p.name as product_name, p.unit_price as base_price, p.thumbnail_img as photo, fdp.discount as discount, fdp.discount_type as discount_type FROM flash_deals as fd "

  query += ` LEFT JOIN flash_deal_products as fdp on (fd.id = fdp.flash_deal_id) `
  query += ` LEFT JOIN products as p on (p.id = fdp.product_id) `
  query += ` GROUP BY fd.id  `
  query += ` ORDER BY fd.id  `

  sql.query(query, (err, res) => {
    if (err) {
      result(null, err);
      return;
    }
    result(null, res);
  });
};

FlashDeal.saveFlashDeal = (data, result) => {
  console.log(data);
  let query = "INSERT INTO flash_deals SET ?";
  sql.query(query, data, (err, res) => {
    if (err) {
      console.log(err)
      result(err, null);
      return;
    }
    result(null, res);
  });
};

FlashDeal.putFlashDeal = (id, data, result) => {

  let title = data.title || null;
  let start_date = data.start_date || null;
  let end_date = data.end_date || null;
  let status = data.status || null;
  let featured = data.featured || null;
  let background_color = data.background_color || null;
  let text_color = data.text_color || null;
  let banner = data.banner || null;
  let slug = data.slug || null;

  let query = " UPDATE flash_deals SET title = '" + title + "', start_date = " + start_date + " , end_date = " + end_date + " , status = " + status + ", featured =  " + featured + " ,  background_color = '" + background_color + "', text_color = ' " + text_color + " ',  banner = ' " + banner + " ',  slug = '" + slug + "', updated_at = now()  WHERE id = ? "

  sql.query(query, id, (err, res) => {
    if (err) {
      console.log(err)
      result(err, null);
      return;
    }
    if (res.affectedRows == 0) {
      // not found Tutorial with the id
      result({ kind: "not_found" }, null);
      return;
    }
    console.log("updated flash deal : ", { id: id, ...data });
    result(null, data.id);
  });
};


FlashDeal.getFlashDealID = (id, result) => {
  let query = " SELECT fd.*, p.name as product_name, p.unit_price as base_price, p.thumbnail_img as photo, fdp.discount as discount, fdp.discount_type as discount_type FROM flash_deals as fd "

      query += ` LEFT JOIN flash_deal_products as fdp on (fd.id = fdp.flash_deal_id) `
      query += ` LEFT JOIN products as p on (p.id = fdp.product_id) `
      query += ` WHERE fd.id = ?  `
      query += ` GROUP BY fd.id  `
      query += ` ORDER BY fd.id  `


      sql.query(query, id, (err, res) => {
        if (err) {
          result(null, err);
          return;
        }
        result(null, res[0]);
        console.log(null, res[0]);
      });
};

FlashDeal.deleteFlashDeal = (id, result) => {
  console.log(id);
  let query = "DELETE FROM flash_deals WHERE id = ?";
  sql.query(query, id, (err, res) => {
    if (err) {
      console.log(err)
      result(err, null);
      return;
    }
    if (res.affectedRows == 0) {
      result({ kind: "not_found" }, null);
      return;
    }
    console.log("deleted flash deal : ", { id: id });
    result(null, res);
  });
};

module.exports = FlashDeal;
