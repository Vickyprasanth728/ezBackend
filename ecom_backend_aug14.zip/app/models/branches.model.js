const sql = require("./db.js");

// constructor
const Branches = function (branch) {
    this.id = branch.id;
    this.shop_id = branch.shop_id;
    this.city = branch.city;
    this.shop_open_time = branch.shop_open_time;
    this.shop_close_time = branch.shop_close_time;
    this.address = branch.address;
    this.phone_number = branch.phone_number;
    this.payment_type = branch.payment_type;
  };

  Branches.getBranches = (result) => {

    let query  =  `SELECT br.*, sh.name as shop_name FROM branches as br `
        query +=  `LEFT JOIN shops as sh on (sh.id = br.shop_id) `  
        query += ` GROUP BY br.id `
        query += ` ORDER BY br.id `

    sql.query(query, (err, res) => {
      if (err) {
        result(null, err);
        return;
      }
      else {
        result(null, res);
      }
    })
  };

  Branches.saveBranch = (data, result) => {
    console.log(data);
    let query = "INSERT INTO branches SET ?";
    sql.query(query, data, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      result(null, res);
    });
  };


  Branches.putBranch = (id, data, result) => {

    let shop_id = data.shop_id || null;
    let city = data.city || null;
    let shop_open_time = data.shop_open_time || null;
    let shop_close_time = data.shop_close_time || null;
    let address = data.address || null;
    let phone_number = data.phone_number || null;
    let payment_type = data.payment_type || null;
   
    let query = "UPDATE branches SET  shop_id = "+shop_id+", city = '"+ city+"', shop_open_time =  '"+shop_open_time+"' , shop_close_time =  '"+shop_close_time+"' , address = ' "+address+" ' , phone_number = "+phone_number+" , payment_type = "+ payment_type+" , updated_at = now()  WHERE id = ? "
  
    sql.query(query, id, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      if (res.affectedRows == 0) {
        result({ kind: "not_found" }, null);
        return;
      }
      console.log("updated branches : ", {id: id, ...data });
      result(null, data.id);
    });
  };

  Branches.getBranchEdit = (id , result) => {
    let query  =  `SELECT br.*, sh.name as shop_name FROM branches as br `
        query +=  `LEFT JOIN shops as sh on (sh.id = br.shop_id) `
        query +=  `WHERE br.id = ? `
  
    sql.query(query, id, (err, res) => {
        if (err) {
            result(null, err);
            return;
        }
        if (res == !id) {
            result({ kind: "not_found" }, null);
            return;
        }
        result(null, res[0]);
        console.log(null, res[0]);
        });
    };
  Branches.getBranchShopID = (shop_id , result) => {
    let query  =  `SELECT br.*, sh.name as shop_name FROM branches as br `
        query +=  `LEFT JOIN shops as sh on (sh.id = br.shop_id) `
        query +=  `WHERE br.shop_id = ? `
  
    sql.query(query, shop_id, (err, res) => {
        if (err) {
            result(null, err);
            return;
        }
        if (res == !id) {
            result({ kind: "not_found" }, null);
            return;
        }
        result(null, res[0]);
        console.log(null, res[0]);
        });
    };

    Branches.deleteBranch = (id, result) => {
        console.log(id);
        let query = "DELETE FROM branches WHERE id = ?";
        sql.query(query, id, (err, res) => {
          if (err) {
            console.log(err)
            result(err, null);
            return;
          }
          if (res.affectedRows == 0) {
            result({ kind: "not_found" }, null);
            return;
          }
          console.log("deleted branches : ", { id: id });
          result(null, res);
        });
      };

module.exports = Branches;
