const sql = require("./db.js");


// constructor
const FlashTranslation = function (flash) {
  this.id = flash.id;
  this.flash_deal_id = flash.flash_deal_id;
  this.title = flash.title;
  this.lang = flash.lang;
};

FlashTranslation.getBrandTranslation = (result) => {
  let query = "select * from flash_deal_translations "

  sql.query(query, (err, res) => {
    if (err) {
      result(null, err);
      return;
    }
    result(null, res);
  });
};

FlashTranslation.saveFlashTranslation = (data, result) => {
    console.log(data);
    let query = "INSERT INTO flash_deal_translations SET ?";
    sql.query(query, data, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      result(null, res);
    });
  };

  FlashTranslation.putFlashTranslation = (flash_deal_id, data, result) => {

    // let flash_deal_id = data.flash_deal_id || null;
    let title = data.title|| null;
    let lang = data.lang || null;
   
    let query = "UPDATE flash_deal_translations SET title = '"+title+"', lang =  '"+lang+"', updated_at = now()  WHERE flash_deal_id = ? "
  
    sql.query(query, flash_deal_id, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      if (res.affectedRows == 0) {
        result({ kind: "not_found" }, null);
        return;
      }
      console.log("updated flash translations : ", { id: flash_deal_id, ...data });
      result(null, data.id);
    });
  };

module.exports = FlashTranslation;
