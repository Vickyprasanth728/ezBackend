const sql = require("./db.js");
var md5 = require('md5');

// constructor
const Auth = function (auth) {
    this.id = auth.id;
    this.name = auth.name;
    this.email = auth.email;
    this.user_type = auth.user_type;
  };
  
Auth.login = (data, result) => {
  const hashedPassword = md5(data.password)
  sql.query(`select * from users WHERE email = '${data.email}' and password = '${hashedPassword}' `, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }
    if (res.length) {
      result(null, res[0]);
      return;
    }
    result({ kind: "not_found" }, null);
  });
};

Auth.verifyToken = (data, result) => {
  sql.query(` SELECT * FROM users WHERE remember_token = '${data.remember_token}' ` , (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }

    if (res.length) {
      result(null, res[0]);
      return;
    }

    result({ kind: "not_found" }, null);
  });
};

Auth.changePassword = (id, data, result) => {

  const encryptedpassword = md5(data.password);
  console.log(encryptedpassword);  

  let query = "UPDATE users SET password = '" + encryptedpassword + "' WHERE id = ? ";

  sql.query(query, id, (err, res) => {
    if (err) {
      console.log(err)
      result(err, null);
      return;
    }
    if (res.affectedRows == 0) {
      result({ kind: "not_found" }, null);
      return;
    }
    console.log("Password Changed Successfully : ", { id: id, ...data });
    result(null, data.id);
  });
};

module.exports = Auth;
