const sql = require("./db.js");


// constructor
const UploadFiles = function (uploadfiles) {
    this.file_original_name = uploadfiles.file_original_name;
    this.file_name = uploadfiles.file_name;
    this.user_id = uploadfiles.user_id;
    this.file_size = uploadfiles.file_size;
    this.extension = uploadfiles.extension;
    this.type = uploadfiles.type;
    this.external_link = uploadfiles.external_link;
 };
 
 
 UploadFiles.getUploadFiles = (result) => {
     let query  = ` SELECT up.*, us.name as user_name FROM uploads as up `
         query += ` LEFT JOIN users as us ON (up.user_id = us.id) `
         query += ` where up.deleted_at IS NULL `
     
     sql.query(query, (err, res) => {
       if (err) {
         result(null, err);
         return;
       }
       result(null, res);
     });
 };

 UploadFiles.saveUploadFiles = (data, result) => {
  console.log(data);
  let query = "INSERT INTO uploads SET ?";
  sql.query(query, data, (err, res) => {
    if (err) {
      console.log(err)
      result(err, null);
      return;
    }
    result(null, res);
  });
};

UploadFiles.putUploadFile = (id, data, result) => {

  let file_original_name = data.file_original_name;
  let file_name = data.file_name;
  let user_id = data.user_id;
  let file_size = data.file_size;
  let extension = data.extension;
  let type = data.type;
  let external_link = data.external_link;
 
  let query = "UPDATE uploads SET file_original_name = '"+file_original_name+"', file_name = '"+file_name+"' , user_id =  "+ user_id +" ,file_size =  "+ file_size +" ,extension =  '"+ extension +"' , type =  '"+ type +"' , external_link =  '"+ external_link +"' , updated_at = now() WHERE id = ? "

  sql.query(query, id, (err, res) => {
    if (err) {
      console.log(err)
      result(err, null);
      return;
    }
    if (res.affectedRows == 0) {
      result({ kind: "not_found" }, null);
      return;
    }
    console.log("updated upload file : ", { id: id, ...data });
    result(null, data.id);
  });
};


UploadFiles.editUploadFile = (id , result) => {
  let query = " SELECT * FROM uploads WHERE id = ? "

  sql.query(query, id, (err, res) => {
    if (err) {
      result(null, err);
      return;
    }
    if (res == !id) {
      result({ kind: "not_found" }, null);
      return;
    }
    result(null, res[0]);
    console.log(null, res[0]);
  });
  };

UploadFiles.deleteUploadFiles = (id, result) => {
  console.log(id);
  let query = "UPDATE uploads SET deleted_at = now() WHERE id = ?";
  sql.query(query, id, (err, res) => {
    if (err) {
      console.log(err)
      result(err, null);
      return;
    }
    if (res.affectedRows == 0) {
      result({ kind: "not_found" }, null);
      return;
    }
    console.log("deleted uploads : ", { id: id });
    result(null, res);
  });
};

 module.exports = UploadFiles;
