const sql = require("./db.js");

// constructor
const ConversationSupports = function (messages) {
    this.id = messages.id;
    this.sender_id = messages.sender_id;
    this.receiver_id = messages.receiver_id;
    this.title = messages.title;
    this.sender_viewed = messages.sender_viewed;
    this.receiver_viewed = messages.receiver_viewed;
  };

// Ticket Supports List
ConversationSupports.getConversationList = (result) => {

    let query  = ` SELECT con.*, m.message as messages, us1.name as sender, us2.name as receiver FROM conversations as con `

        query += ` LEFT JOIN messages as m ON (m.conversation_id = con.id)`
        query += ` LEFT JOIN users as us ON (m.user_id = us.id) `
        query += ` LEFT JOIN users as us1 ON (con.sender_id = us1.id) `
        query += ` LEFT JOIN users as us2 ON (con.receiver_id = us2.id) `
        query += ` GROUP BY con.id `  
        query += ` ORDER BY con.id `  

    sql.query(query, (err, res) => {
        if (err) {    
        result(null, err);
        return;
        } 
        else {
        result(null, res);  
        }
    })  
};

ConversationSupports.getConversationID = (id , result) => {
    let query  = ` SELECT con.*, m.message as messages, us1.name as sender, us2.name as receiver FROM conversations as con `

        query += ` LEFT JOIN messages as m ON (m.conversation_id = con.id)`
        query += ` LEFT JOIN users as us ON (m.user_id = us.id) `
        query += ` LEFT JOIN users as us1 ON (con.sender_id = us1.id) `
        query += ` LEFT JOIN users as us2 ON (con.receiver_id = us2.id) `
        query += ` WHERE CON.id = ?  `
        query += ` GROUP BY con.id `  
        query += ` ORDER BY con.id ` 
  
    sql.query(query, id, (err, res) => {
      if (err) {
        result(null, err);
        return;
      }
      result(null, res[0]);
      console.log(null, res[0]);
    });
    };

module.exports = ConversationSupports;
