const sql = require("./db.js");

// constructor
const CategoryTranslation = function (category) {
  this.id = category.id;
  this.category_id = category.category_id;
  this.name = category.name;
  this.lang = category.lang;
};

CategoryTranslation.getCategoryTranslation = (result) => {
  let query = "select * from category_translations "

  sql.query(query, (err, res) => {
    if (err) {
      result(null, err);
      return;
    }
    result(null, res);
  });
};

CategoryTranslation.saveCategoryTranslation = (data, result) => {
    console.log(data);
    let query = "INSERT INTO category_translations SET ?";
    sql.query(query, data, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      result(null, res);
    });
  };

  CategoryTranslation.putCategoryTranslation = (category_id, data, result) => {

    let name = data.name|| null;
    let lang = data.lang || null;
   
    let query = "UPDATE category_translations SET name = '"+name+"', lang =  '"+lang+"', updated_at = now()  WHERE category_id = ? "
  
    sql.query(query, category_id , (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      if (res.affectedRows == 0) {
        result({ kind: "not_found" }, null);
        return;
      }
      console.log("updated category translations : ", { id: category_id, ...data });
      result(null, data.id);
    });
  };

module.exports = CategoryTranslation;