const sql = require("./db.js");

// Constructor
const Subscribers = function (subs) {
    this.id = subs.id;
    this.email = subs.email;
   };

Subscribers.getSubscribers = (result) => {
    let query  = ` select sub.id as id, sub.email as email, sub.created_at as date from subscribers as sub `
    
     sql.query(query, (err, res) => {
       if (err) {
         result(null, err);
         return;
       }
       result(null, res);
     });
 };

 Subscribers.deleteSubscriber = (id, result) => {
  console.log(id);
  let query = "DELETE FROM subscribers WHERE id = ?";
  sql.query(query, id, (err, res) => {
    if (err) {
      console.log(err)
      result(err, null);
      return;
    }
    if (res.affectedRows == 0) {
      // not found Contact with the id
      result({ kind: "not_found" }, null);
      return;
    }
    console.log("deleted subscribers : ", { id: id });
    result(null, res);
  });
};

 module.exports = Subscribers;
