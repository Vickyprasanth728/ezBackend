const sql = require("./db.js");


// constructor
const BlogCategories = function (blogCategories) {
    this.category_name = blogCategories.category_name;
    this.slug = blogCategories.slug;
 };
 
 BlogCategories.getBlogCategories = (result) => {
     let query = "select * from blog_categories "
     
     sql.query(query, (err, res) => {
       if (err) {
         result(null, err);
         return;
       }
       result(null, res);
     });
 };
 
 BlogCategories.saveBlogCategory = (data, result) => {
     console.log(data);
     let query = "INSERT INTO blog_categories SET ?";
     sql.query(query, data, (err, res) => {
       if (err) {
         console.log(err)
         result(err, null);
         return;
       }
       result(null, res);
     });
   };
 
   BlogCategories.putBlogCategory = (id, data, result) => {
 
     const updates = [];
     if (data.category_name!='') updates.push(`category_name = '${data.category_name}'`);
     if (data.slug!='') updates.push(`slug = '${data.slug}'`);
   
     if (updates.length === 0) {
       res.status(400).json({status: (400), message: "No updates provided" });
       return;
     }
   
     let query = `UPDATE blog_categories SET ${updates.join(", ")} WHERE id = ? `

      //  let query = "UPDATE blog_categories SET category_name =  '"+category_name+"' , slug = '"+slug+"', updated_at = now()  WHERE id = ? "
    
      sql.query(query, id, (err, res) => {
        if (err) {
          console.log(err)
          result(err, null);
          return;
        }
        if (res.affectedRows == 0) {
          result({ kind: "not_found" }, null);
          return;
        }
        console.log("Updated Blog Category : ", { id: id, ...data });
        result(null, data.id);
      });
   };
   
   
   BlogCategories.getBlogCategoryID = (id , result) => {
     let query = " SELECT * FROM blog_categories WHERE id = ? "
   
     sql.query(query, id, (err, res) => {
      if (err) {
        result(null, err);
        return;
      }
      if (res == !id) {
        result({ kind: "not_found" }, null);
        return;
      }
      result(null, res[0]);
      console.log(null, res[0]);
    });
     };
 
     BlogCategories.deleteBlogCategory = (id, result) => {
         console.log(id);
         let query = "DELETE FROM blog_categories WHERE id = ?";
         sql.query(query, id, (err, res) => {
           if (err) {
             console.log(err)
             result(err, null);
             return;
           }
           if (res.affectedRows == 0) {
             result({ kind: "not_found" }, null);
             return;
           }
           console.log("deleted blog categories : ", { id: id });
           result(null, res);
         });
       };
 
 module.exports = BlogCategories;
 