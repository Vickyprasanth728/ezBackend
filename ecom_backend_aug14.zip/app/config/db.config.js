// // Load the mysql package
// var mysql_package = require('mysql');
// var connection_data = mysql_package.createConnection({
//   host: "192.168.1.24",
//   user: "root",
//   password: "",
//   db:"wabisabi_db"
// });

module.exports = {
  // HOST: "localhost",
  host: "192.168.1.24",
  USER: "root",
  PASSWORD: "",
  DB: "vts_admin",
  // DB: "th_ecom",

  smtpUserName: "134a7d7fee3891",
  smtpPassword: "f549d5fc6cae82",
  smtpHost: "smtp.mailtrap.io",
  smtpPort: "587",
};