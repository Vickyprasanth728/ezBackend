const BusinessSettings = require("../models/businessSettings.model.js");
const path = require("path");
const fs = require("fs");

// Business Settings
exports.getBusinessSettings = (req, res) => {
  BusinessSettings.getBusinessSettings((err, data) => {
    if (err)
      res.status(401).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
    else 
    res.status(200).send({
      status:(200),
      message:"Success",
      Data:data
    })
  });
};

exports.saveBusinessSetting = (req, res) => {
  
  const settings = new BusinessSettings({
    id: req.body.id,
    type: req.body.type,
    value: req.body.value || null,
    lang: req.body.lang || null,  
  });

  BusinessSettings.saveBusinessSetting ( settings, (err, data) => {
    if (err) {
      console.log(err)
      res.status(401).send({
        message:
          err.message || "Some error occurred while posting business settings ."
      });
    }
    else {
      console.log("Posted Successfully");
      res.status(200).send({
        message: "Posted Successfully",
        output: settings
      })
    }
  });
};


exports.putBusinessSetting = (req, res) => {

  let value = "";
    
  if (req.files.value) {
    const extension = req.files.value[0]["mimetype"].split('/')[1]
    value = req.files.value[0]["filename"] + '.' + extension
    value = req.files.value[0]["originalname"]
  }

  const settings = new BusinessSettings({
       type : req.body.type,
       value : value || req.body.value,
       lang : req.body.lang,
  });

  let BSid = req.params.type

  BusinessSettings.putBusinessSetting (req.params.type, settings , (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(401).send({
          message: `Not found business settings with type ${req.params.type}.`
        });
      }
    }
    else {
  
      if (req.files.value) {
        const currentPath = path.join(process.cwd(), "uploads", req.files.value[0]["filename"]);
        const destinationPath = path.join(process.cwd(), "/uploads/setting/values/" + `${BSid}`, value);
        const baseUrl = process.cwd() + '/uploads/setting/values/' + `${BSid}`
        fs.mkdirSync(baseUrl, { recursive: true })
        fs.rename(currentPath, destinationPath, function (err) {
          if (err) {
            throw err
          } else {
            console.log("Successfully moved the value images !")
          }
        });
      }

      res.status(200).send({
        status:(200),
        message:"Success",
        Data: settings
      })
    }
});
};

exports.getBusinessSettingID = (req, res) => {
  BusinessSettings.getBusinessSettingID(req.params.type, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(401).send({
          status:(401),
          message: `Not found setting with type ${req.params.type}.`
        });
      }
    }
    else {
      res.status(200).send({
        status:(200),
        message:"Success",
        Data:data
      })
    }
});
};

exports.deleteBusinessSetting = (req, res) => {
  BusinessSettings.deleteBusinessSetting ( req.params.id, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(401).send({
          message: `Not found business settings with id ${req.params.id}.`
        });
      }
    }
    else {
      res.status(200).send({
        status:(200),
        message:"Success",
      })
    }
});
};