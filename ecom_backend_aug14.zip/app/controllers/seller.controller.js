const Seller = require("../models/seller.model.js");

// Seller List
exports.getSellerList = (req, res) => {
    Seller.getSellerList((err, data) => {
      if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
      else res.send(data);
    });
  };
// Seller Edit List
exports.getSellerEdit = (req, res) => {
    Seller.getSellerEdit(req.params.id,(err, data) => {
      if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
    else res.send(data);
    });
  };  

// Seller Payouts
exports.getSellerPayouts = (req, res) => {
  Seller.getSellerPayouts((err, data) => {
    if (err)
    res.status(500).send({
      message:
        err.message || "Some error occurred while retrieving data."
    });
    else res.send(data);
  });
};

// Seller Payouts Request
exports.getSellerPayoutsREQ = (req, res) => {
  Seller.getSellerPayoutsREQ((err, data) => {
    if (err)
    res.status(500).send({
      message:
        err.message || "Some error occurred while retrieving data."
    });
    else res.send(data);
  });
};

  // Seller Ban List
exports.BanSellerID = (req, res) => {
  Seller.BanSellerID(req.params.id, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found seller with id ${req.params.id}.`
        });
      }
    }
  else 
  {
    res.statusCode = 200;
    res.send("Seller banned Succesfully");
  }
});
};

// Seller Update
exports.putSellerList = (req, res) => {

  const seller = new Seller({
    id: req.body.id || null ,
    name : req.body.name || null ,
    email : req.body.email || null ,
    password : req.body.password || null ,
  });

  Seller.putSellerList (req.params.id, seller, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found seller with id ${req.params.id}.`
        });
      }
    }
    else {
      res.statusCode = 200;
      res.send("Seller updated Succesfully");
    }
});
};

// Seller Delete 
exports.deleteSellerList = (req, res) => {
  Seller.deleteSellerList( req.params.id, (err, data) => {
  if (err) {
    if (err.kind === "not_found") {
      res.status(404).send({
        message: `Not found seller with id ${req.params.id}.`
      });
    }
  }
  else {
    res.statusCode = 200;
    res.send("Seller deleted Succesfully");
  }
});
};
