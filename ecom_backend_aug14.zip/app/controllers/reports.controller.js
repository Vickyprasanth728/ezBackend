const Reports = require("../models/reports.models.js");


// Reports 
exports.getReportsProductSale = (req, res) => {
    Reports.getReportsProductSale((err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
    else res.send(data);
  });
};
exports.getReportsSellerSale = (req, res) => {
    Reports.getReportsSellerSale((err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
    else res.send(data);
  });
};
exports.getReportsProductStock = (req, res) => {
    Reports.getReportsProductStock((err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
    else res.send(data);
  });
};
exports.getReportsProductWishlist = (req, res) => {
    Reports.getReportsProductWishlist((err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
    else res.send(data);
  });
};
exports.getReportsUserSearch = (req, res) => {
    Reports.getReportsUserSearch((err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
    else res.send(data);
  });
};
exports.getReportsCommission = (req, res) => {
    Reports.getReportsCommission((err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
    else res.send(data);
  });
};
exports.getReportsWalletRecharge = (req, res) => {
    Reports.getReportsWalletRecharge((err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
    else res.send(data);
  });
};