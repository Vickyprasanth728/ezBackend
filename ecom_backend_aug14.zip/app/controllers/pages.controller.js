const Pages = require("../models/pages.model.js");
const PageTranslation = require("../models/pageTranslation.model.js");

function keyGen(keyLength) {
  var i, key = "", characters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

  var charactersLength = characters.length;

  for (i = 0; i < keyLength; i++) {
    key += characters.substr(Math.floor((Math.random() * charactersLength) + 1), 1);
  }

  return key;
}

// Pages
exports.getPages = (req, res) => {
  Pages.getPages((err, data) => {
    if (err)
      res.status(401).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
    else 
    res.status(200).send({
      status:(200),
      message:"Success",
      Data:data
    })
  });
};

exports.savePage = (req, res) => {

  let x = req.body.title.toLowerCase().replace(/ /g, '-').replace(/[^\w-]+/g);
  let y = req.body.title.toLowerCase().replace(/ /g, '_').replace(/[^\w-]+/g);
  // slug = title.toLowerCase();
  
  const pages = new Pages({
    id: req.body.id || null,
    type : y ,
    title : req.body.title || null,
    slug : x ,
    content : req.body.content || null,
    meta_title : req.body.meta_title || null,
    meta_description : req.body.meta_description || null,
    keywords : req.body.keywords || null,
    meta_image : req.body.meta_image || null,
  });

  Pages.savePage ( pages, (err, data) => {
    if (err) {
      console.log(err)
      res.status(401).send({
        message:
          err.message || "Some error occurred while posting page translation  ."
      });
    }
    else {

        // let pageId = data.insertId

        // const pageTranslation = new PageTranslation({
        //     page_id :  pageId,
        //     title :  req.body.title,
        //     content :  req.body.content,
        //     lang :  req.body.lang,
        //   });
    
        //   PageTranslation.savePageTranslation(pageTranslation, (err, data) => {
        //     if (err) {
        //       console.log(err)
        //       console.log("Page Translation posted");
        //       console.log("Posted Successfully");
        //       res.statusCode = 200;
        //     }
        //   });

      console.log("Posted Successfully");
      res.status(200).send({
        message: "Posted Successfully",
        output: pages
      })
    }
  });
};


exports.putPage = (async(req, res) => {

  const pages = new Pages({
       type : req.body.type || null,
       title : req.body.title || null,
       slug : req.body.slug || null,
       content : req.body.content || null,
       meta_title : req.body.meta_title || null,
       meta_description : req.body.meta_description || null,
       keywords : req.body.keywords || null,
       meta_image : req.body.meta_image || null,
  });

  let pageId = req.params.id

  Pages.putPage (req.params.id, pages , (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(401).send({
          message: `Not found page translation with id ${req.params.id}.`
        });
      }
    }
    else {
        // const pageTranslation = new PageTranslation({
        //     page_id :  pageId ,
        //     title :  req.body.title || null ,
        //     content :  req.body.content || null,
        //     lang :  req.body.lang || null,
        //   });
  
        //   PageTranslation.putPageTranslation (pageId , pageTranslation, (err, data) => {
        //     if (err) {
        //       if (err.kind === "not_found") {
        //         res.status(401).send({
        //           message: `Not found with page id ${pageId}.`
        //         });
        //       }
        //     }
        //   })

        res.status(200).send({
          status:(200),
          message:"Success",
          Data:pages
        })
    }
});
});

exports.getPageID = (req, res) => {
  Pages.getPageID(req.params.id, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(401).send({
          status:(401),
          message: `Not found page with id ${req.params.id}.`
        });
      }
    }
    else {
      res.status(200).send({
        status:(200),
        message:"Success",
        Data:data
      })
    }
});
};

exports.deletePage = (req, res) => {
  Pages.deletePage ( req.params.id, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(401).send({
          message: `Not found page translation with id ${req.params.id}.`
        });
      }
    }
    else {
      res.status(200).send({
        status:(200),
        message:"Success",
      })
    }
});
};