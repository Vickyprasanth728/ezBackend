const UploadFiles = require("../models/upload.models.js");
const path = require("path");
const fs = require("fs");

// Upload Files
exports.getUploadFiles = (req, res) => {
  UploadFiles.getUploadFiles((err, data) => {
      if (err)
        res.status(401).send({
          message:
            err.message || "Some error occurred while retrieving data."
        });
      else 
        res.status(200).send({
        status:(200),
        message:"Success",
        Data:data
      })
    });
  };
  
exports.saveUploadFiles = (req, res) => { 

  let file_name = "";
  if (req.files.file_name) {
    const ext = req.files.file_name[0]["mimetype"].split('/')[1]
    file_name = req.files.file_name[0]["filename"] + '.' + ext
    file_original_name = req.files.file_name[0]["originalname"]
    file_size = req.files.file_name[0]["size"]
    extension = req.files.file_name[0]["mimetype"].split('/')[1]
    type = req.files.file_name[0]["mimetype"].split('/')[0]
  }

  const uploadfiles = new UploadFiles({
    id : req.body.id,
    file_original_name : file_original_name || null,
    file_name : file_name || null,
    user_id : req.body.user_id || null,
    file_size : file_size || null,
    extension : extension || null,
    type : type || null,
    external_link : req.body.external_link || null,
  });

  UploadFiles.saveUploadFiles( uploadfiles, (err, data) => {
    if (err) {
      console.log(err)
      res.status(401).send({
        message:
          err.message || "Some error occurred while posting upload files ."
      });
    }
    else {

      let uploadId = data.insertId

      if (req.files.file_name) {

        const currentPath = path.join(process.cwd(), "uploads", req.files.file_name[0]["filename"]);
        const destinationPath = path.join(process.cwd(), "/uploads/all_uploads/file_name/" + `${uploadId}`, file_name);
        const baseUrl = process.cwd() + '/uploads/all_uploads/file_name/' + `${uploadId}`
        fs.mkdirSync(baseUrl, { recursive: true })
        fs.rename(currentPath, destinationPath, function (err) {
          if (err) {
            throw err
          } else {
            console.log("Successfully images file uploaded !")
          }
        });
      }
      console.log("Posted Successfully");
      res.status(200).send({
        message: "Posted Successfully",
        output: uploadfiles
      })
    }
  });
};

exports.putUploadFile = (req, res) => {

  let file_name = "";

  if (req.files.file_name) {
    const ext = req.files.file_name[0]["mimetype"].split('/')[1]
    file_name = req.files.file_name[0]["filename"] + '.' + ext
    file_original_name = req.files.file_name[0]["originalname"]
    file_size = req.files.file_name[0]["size"]
    extension = req.files.file_name[0]["mimetype"].split('/')[1]
    type = req.files.file_name[0]["mimetype"].split('/')[0]
  }

    const uploadfiles = new UploadFiles({
      id : req.body.id,
      file_original_name : file_original_name,
      file_name : file_name,
      user_id : req.body.user_id,
      file_size : file_size,
      extension : extension,
      type : type,
      external_link : req.body.external_link || null,
    });

  let uploadId = req.params.id
  
  UploadFiles.putUploadFile (req.params.id, uploadfiles, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(401).send({
          message: `Not found Upload file with id ${req.params.id}.`
        });
      }
    }
    else {

      if (req.files.file_name) {
        const currentPath = path.join(process.cwd(), "uploads", req.files.file_name[0]["filename"]);
        const destinationPath = path.join(process.cwd(), "/uploads/all_uploads/file_name/" + `${uploadId}`, file_name);
        const baseUrl = process.cwd() + '/uploads/all_uploads/file_name/' + `${uploadId}`
        fs.mkdirSync(baseUrl, { recursive: true })
        fs.rename(currentPath, destinationPath, function (err) {
          if (err) {
            throw err
          } else {
            console.log("Successfully moved the upload images !")
          }
        });
      }

    res.status(200).send({
      status:(200),
      message:"Success",
      Data:uploadfiles
    })
    }
});
};

exports.editUploadFile = (req, res) => {
  UploadFiles.editUploadFile(req.params.id, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(401).send({
          status:(401),
          message: `Not found Upload Files with id ${req.params.id}.`
        });
      }
    }
    else {
      res.status(200).send({
        status:(200),
        message:"Success",
        Data:data
      })
    }
});
};

exports.deleteUploadFiles = (req, res) => {
  UploadFiles.deleteUploadFiles( req.params.id, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found upload files with id ${req.params.id}.`
        });
      }
    }
    else {
      res.status(200).send({
        status:(200),
        message:"Success",
      })
    }
});
};