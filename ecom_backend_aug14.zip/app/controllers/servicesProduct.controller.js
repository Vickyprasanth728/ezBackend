const Services = require("../models/servicesProduct.model.js");
const { Validator } = require('node-input-validator');
const path = require("path");
const fs = require("fs");

exports.getServices = (req, res) => {
    Services.getServices((err, data) => {
      if (err)
      res.status(401).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
      else 
      res.status(200).send({
        status:(200),
        message:"Success",
        Data:data
      })
    });
  };

  exports.saveService = (async (req, res) => {

    let images = "";
    
    if (req.files.images) {
      const extension = req.files.images[0]["mimetype"].split('/')[1]
      images = req.files.images[0]["filename"] + '.' + extension
      images = req.files.images[0]["originalname"]
    }

    const VALID = new Validator(req.body, {
        name: 'required|minLength:1|maxLength:50',
        category_id: 'required|integer|minLength:1|maxLength:8',
        price: 'required|decimal|minLength:1|maxLength:10',
        discount_price: 'required|decimal|minLength:1|maxLength:8',
      });

      VALID.check().then(async (matched) => {
        if (!matched) {
          // res.status(422).send(VALID.errors);
          res.status(422).send({
            status:(422),
            message:"Errors",
            errors: (VALID.errors)
          })
        }
        else {
            const Service = new Services({
            id: req.body.id,
            category_id: req.body.category_id,
            parent_category_id: req.body.parent_category_id,
            seller_id: req.body.seller_id,
            name: req.body.name,
            price: req.body.price,
            discount_price: req.body.discount_price,
            duration: req.body.duration,
            description: req.body.description || null,
            images: images,
            });

    Services.saveService( Service, (err, data) => {
      if (err) {
        console.log(err)
        res.status(401).send({
          message:
            err.message || "Some error occurred while posting Service  ."
        });
      }
      else {

        let serviceId = data.insertId

        if (req.files.images) {
          const currentPath = path.join(process.cwd(), "uploads", req.files.images[0]["filename"]);
          const destinationPath = path.join(process.cwd(), "/uploads/service/images/" + `${serviceId}`, images);
  
          const baseUrl = process.cwd() + '/uploads/service/images/' + `${serviceId}`
          fs.mkdirSync(baseUrl, { recursive: true })
          fs.rename(currentPath, destinationPath, function (err) {
            if (err) {
              throw err
            } else {
              console.log("Successfully moved the Images !")
            }
          });
        }

        console.log("Posted Successfully");
        res.status(200).send({
          message: "Posted Successfully",
          output: data
        })
      }
    });
    }
   })
  });

  exports.putService = (async  (req, res) => {

    let images = "";
    
    if (req.files.images) {
      const extension = req.files.images[0]["mimetype"].split('/')[1]
      images = req.files.images[0]["filename"] + '.' + extension
      images = req.files.images[0]["originalname"]
    }

    const VALID = new Validator(req.body, {
        name: 'required|minLength:1|maxLength:50',
        category_id: 'required|integer|minLength:1|maxLength:8',
        price: 'required|decimal|minLength:1|maxLength:10',
        discount_price: 'required|decimal|minLength:1|maxLength:8',
      });

      VALID.check().then(async (matched) => {
        if (!matched) {
          // res.status(422).send(VALID.errors);
          res.status(422).send({
            status:(422),
            message:"Errors",
            errors: (VALID.errors)
          })
        }

        else {
        const Service = new Services({
            category_id: req.body.category_id,
            parent_category_id: req.body.parent_category_id,
            seller_id: req.body.seller_id,
            name: req.body.name,
            price: req.body.price,
            discount_price: req.body.discount_price,
            duration: req.body.duration,
            description: req.body.description,
            images: images,
        });
  
    let serviceId = req.params.id
    Services.putService (req.params.id, Service, (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(401).send({
            message: `Not found Service with id ${req.params.id}.`
          });
        }
      }
      else {

        if (req.files.images) {
          const currentPath = path.join(process.cwd(), "uploads", req.files.images[0]["filename"]);
          const destinationPath = path.join(process.cwd(), "/uploads/service/images/" + `${serviceId}`, images);
  
          const baseUrl = process.cwd() + '/uploads/service/images/' + `${serviceId}`
          fs.mkdirSync(baseUrl, { recursive: true })
          fs.rename(currentPath, destinationPath, function (err) {
            if (err) {
              throw err
            } else {
              console.log("Successfully moved the Images !")
            }
          });
        }

        res.status(200).send({
            status:(200),
            message:"Success",
            Data:data
          })
      }
  });
}
})
  });

//   exports.saveService = (req, res) => {

//     let images = "";
    
//     if (req.files.images) {
//       const extension = req.files.images[0]["mimetype"].split('/')[1]
//       images = req.files.images[0]["filename"] + '.' + extension
//       images = req.files.images[0]["originalname"]
//     }
  
//     const Service = new Services({
//       id: req.body.id,
//       category_id: req.body.category_id,
//       parent_category_id: req.body.parent_category_id,
//       seller_id: req.body.seller_id,
//       name: req.body.name,
//       price: req.body.price,
//       discount_price: req.body.discount_price,
//       duration: req.body.duration,
//       description: req.body.description,
//       images: images,
//     });

//     Services.saveService( Service, (err, data) => {
//       if (err) {
//         console.log(err)
//         res.status(401).send({
//           message:
//             err.message || "Some error occurred while posting Service  ."
//         });
//       }
//       else {

//         let serviceId = data.insertId

//         if (req.files.images) {
//           const currentPath = path.join(process.cwd(), "uploads", req.files.images[0]["filename"]);
//           const destinationPath = path.join(process.cwd(), "uploads/services/images/" + `${serviceId}`, images);
  
//           const baseUrl = process.cwd() + '/uploads/services/images/' + `${serviceId}`
//           fs.mkdirSync(baseUrl, { recursive: true })
//           fs.rename(currentPath, destinationPath, function (err) {
//             if (err) {
//               throw err
//             } else {
//               console.log("Successfully moved the Images !")
//             }
//           });
//         }

//         console.log("Posted Successfully");
//         res.status(200).send({
//           message: "Posted Successfully",
//           output: data
//         })
//       }
//     });
//   };

//   exports.putService = (req, res) => {

//     let images = "";
    
//     if (req.files.images) {
//       const extension = req.files.images[0]["mimetype"].split('/')[1]
//       images = req.files.images[0]["filename"] + '.' + extension
//       images = req.files.images[0]["originalname"]
//     }

//     const Service = new Services({
//         category_id: req.body.category_id || null,
//         parent_category_id: req.body.parent_category_id || null,
//         seller_id: req.body.seller_id || null,
//         name: req.body.name || null,
//         price: req.body.price || null,
//         discount_price: req.body.discount_price || null,
//         duration: req.body.duration || null,
//         description: req.body.description || null,
//         images: images || null,
//     });
  
//     let serviceId = req.params.id
//     Services.putService (req.params.id, Service, (err, data) => {
//       if (err) {
//         if (err.kind === "not_found") {
//           res.status(401).send({
//             message: `Not found Service with id ${req.params.id}.`
//           });
//         }
//       }
//       else {

//         if (req.files.logo) {
//           const currentPath = path.join(process.cwd(), "uploads", req.files.logo[0]["filename"]);
//           const destinationPath = path.join(process.cwd(), "uploads/services/images/" + `${serviceId}`, logo);
  
//           const baseUrl = process.cwd() + '/uploads/services/images/' + `${serviceId}`
//           fs.mkdirSync(baseUrl, { recursive: true })
//           fs.rename(currentPath, destinationPath, function (err) {
//             if (err) {
//               throw err
//             } else {
//               console.log("Successfully moved the Images !")
//             }
//           });
//         }

//         res.status(200).send({
//             status:(200),
//             message:"Success",
//             Data:data
//           })
//       }
//   });
//   };

  exports.getServiceEdit = (req, res) => {
    Services.getServiceEdit (req.params.id, (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
            res.status(401).send({
            status:(401),
            message: `Not found service with id ${req.params.id}.`
            });
        }
        }
        else {
        res.status(200).send({
            status:(200),
            message:"Success",
            Data:data
        })
        }
    });
    };

  exports.deleteService = (req, res) => {
    Services.deleteService (req.params.id, (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(401).send({
            message: `Not found Service with id ${req.params.id}.`
          });
        }
      }
      else {
        res.status(200).send({
            status:(200),
            message:"Success",
          })
      }
  });
};



// const Organization = require("../models/organization.model");
// const path = require("path");
// const fs = require("fs");
// const { Validator } = require('node-input-validator');
// const util = require('util');
// const sql = require("../models/db");
// const User = require("../models/user.model");
// const UserPackageDetails = require("../models/userPackageDetails.model.js");
// const UserOtherDetails = require("../models/userOtherDetails.model.js");
// const UserProfessional = require("../models/userProfessional.model.js");
// const UserPerformance = require("../models/userPerformance.model.js")
// // const jwt = require('jsonwebtoken');
// // const auth = require("../middleware/auth.js")

// var md5 = require('md5');
// function keyGen(keyLength) {
//   var i, key = "", characters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

//   var charactersLength = characters.length;

//   for (i = 0; i < keyLength; i++) {
//     key += characters.substr(Math.floor((Math.random() * charactersLength) + 1), 1);
//   }

//   return key;
// }
// // organization save company
// exports.saveOrganization = (async (req, res) => {
//   if (!req.body) {
//     res.status(400).send({
//       message: "User Cannot be Empty"
//     });
//   }
//   let upload = "";
//   let upload_original_name = "";
//   let upload_logo = "";
//   let upload_logo_original_name = "";

//   if (req.files.upload_logo) {
//     const extension = req.files.upload_logo[0]["mimetype"].split('/')[1]
//     upload_logo = req.files.upload_logo[0]["filename"] + '.' + extension
//     upload_logo_original_name = req.files.upload_logo[0]["originalname"]
//   }
//   if (req.files.upload) {
//     const extension = req.files.upload[0]["mimetype"].split('/')[1]
//     upload = req.files.upload[0]["filename"] + '.' + extension
//     upload_original_name = req.files.upload[0]["originalname"]
//   }
//   const v = new Validator(req.body, {
//     organization_name: 'required|minLength:1|maxLength:50',
//     phone_number: 'required|integer|minLength:7|maxLength:15',
//     gst_number: 'alphaNumeric|minLength:15|maxLength:15',
//     cin_number: 'alphaNumeric|minLength:21|maxLength:21',
//     tan_number: 'alphaNumeric|minLength:10|maxLength:10',
//     pan_number: 'alphaNumeric|minLength:10|maxLength:10',
//     branch_details: 'string|alpha|minLength:1|maxLength:50',
//     registered_address: 'string|minLength:1|maxLength:200',
//     city: 'integer|minLength:1|maxLength:8',
//     state: 'integer|minLength:1|maxLength:8',
//     country: 'integer|minLength:1|maxLength:8',
//     currency: 'integer|minLength:1|maxLength:8',
//     website: 'url|minLength:1|maxLength:50',
//     facebook_url: 'url|minLength:1|maxLength:50',
//     linkindin_url: 'url|minLength:1|maxLength:50',
//     twitter_url: 'url|minLength:1|maxLength:50',
//     instagram_url: 'url|minLength:1|maxLength:50',
//     youtube_url: 'url|minLength:1|maxLength:50',
//     approval: 'integer|minLength:1|maxLength:50',
//     // upload_logo: 'mime',
//     // upload_logo_original_name: 'mime',
//     // upload: 'mime',
//     // upload_original_name: 'mime',
//     first_name: 'required|minLength:1|maxLength:50',
//     last_name: 'minLength:1|maxLength:30',
//     email: 'required|email',
//     password: 'required|minLength:7,maxLength:15',
//     created_by: 'required|integer'
//   });

//   v.check().then(async (matched) => {
//     if (!matched) {
//       res.status(422).send(v.errors);
//     }
//     else {
//       const query1 = util.promisify(sql.query).bind(sql);
//       const executivesFetch = await query1(`select email from users where email='${req.body.email}' limit 1`);
//       const executives = executivesFetch[0] ? executivesFetch[0]["email"] : 0
//       if (executives != 0) {
//         res.status(402).send({
//           message:
//             "Primary Email Already Exists"
//         });
//       }
//       else {
//         const organization = new Organization({
//           organization_name: req.body.organization_name,
//           phone_number: req.body.phone_number,
//           gst_number: req.body.gst_number,
//           cin_number: req.body.cin_number,
//           tan_number: req.body.tan_number,
//           pan_number: req.body.pan_number,
//           branch_details: req.body.branch_details,
//           registered_address: req.body.registered_address,
//           city: req.body.city,
//           state: req.body.state,
//           country: req.body.country,
//           currency: req.body.currency,
//           website: req.body.website,
//           facebook_url: req.body.facebook_url,
//           linkindin_url: req.body.linkindin_url,
//           twitter_url: req.body.twitter_url,
//           instagram_url: req.body.instagram_url,
//           youtube_url: req.body.youtube_url,
//           approval: req.body.approval || 0,
//           upload_logo: upload_logo,
//           upload_logo_original_name: upload_logo_original_name,
//           upload: upload,
//           upload_original_name: upload_original_name
//         });
//         Organization.saveOrganization(organization, async (err, data) => {
//           if (err) {
//             console.log(err)
//             res.status(500).send({
//               message:
//                 err.message || "Some error occurred while posting."
//             });
//           }
//           else {
//             let orgId = data.insertId
//             const hashedPassword = md5(req.body.password)
//             const AssignToData = new User({
//               first_name: req.body.first_name,
//               last_name: req.body.last_name,
//               designation: 1,
//               email: req.body.email,
//               password: hashedPassword,
//               api_token: keyGen(30),
//               created_by: req.body.created_by
//             });
//             User.saveUserOrg(AssignToData, (err, data) => {
//               if (err) {
//                 console.log(err)
//               }
//               else {
//                 let userId = data.insertId
//                 // const OtherDetails = new UserOtherDetails({
//                 //   user_id: userId,
//                 // });
//                 // const Packagedetails = new UserPackageDetails({
//                 //   user_id: userId,
//                 // });
//                 // const Histories = new UserProfessional({
//                 //   user_id: userId,
//                 // });
//                 // const user = new UserPerformance({
//                 //   user_id: userId,
//                 // });
//                 // UserOtherDetails.saveUserOtherDetails(OtherDetails, (err, data) => { if (err) { console.log(err); result(err, null); return; } })
//                 // UserPackageDetails.saveUserPackageDetails(Packagedetails, (err, data) => { if (err) { console.log(err); result(err, null); return; } })
//                 // UserProfessional.saveUserProfDetails(Histories, (err, data) => { if (err) { console.log(err); result(err, null); return; } })
//                 // UserPerformance.savePerformanceGoals(user, (err, data) => { if (err) { console.log(err); result(err, null); return; } })
//                 Organization.putOrganization_pri_id(orgId, userId, (err, data) => { if (err) { console.log(err); result(err, null); return; } })
//               }
//             })

//             if (req.files.upload) {
//               const currentPath = path.join(process.cwd(), "uploads", req.files.upload[0]["filename"]);
//               const destinationPath = path.join(process.cwd(), "/uploads/organization/upload/" + `${orgId}`, upload);
//               const baseUrl = process.cwd() + '/uploads/organization/upload/' + `${orgId}`
//               fs.mkdirSync(baseUrl, { recursive: true })
//               fs.rename(currentPath, destinationPath, function (err) {
//                 if (err) {
//                   throw err
//                 } else {
//                   console.log("Successfully moved the upload image!")
//                 }
//               });
//             }
//             if (req.files.upload_logo) {
//               const currentPath = path.join(process.cwd(), "uploads", req.files.upload_logo[0]["filename"]);
//               const destinationPath = path.join(process.cwd(), "/uploads/organization/upload_logo/" + `${orgId}`, upload_logo);

//               const baseUrl = process.cwd() + '/uploads/organization/upload_logo/' + `${orgId}`
//               fs.mkdirSync(baseUrl, { recursive: true })
//               fs.rename(currentPath, destinationPath, function (err) {
//                 if (err) {
//                   throw err
//                 } else {
//                   console.log("Successfully moved the upload_logo image!")
//                 }
//               });
//             }
//             res.status(200).send({
//               message: "Posted Successfully",
//               output: data
//             })
//           }
//         });
//       }
//     }
//   });
// });
// // organization put UPDATE
// exports.putOrganization = (req, res) => {

//   // let upload = "";
//   // let upload_original_name = "";
//   // let upload_logo = "";
//   // let upload_logo_original_name = "";

//   // if (req.files.upload) {
//   //   const extension = req.files.upload[0]["mimetype"].split('/')[1]
//   //   upload = req.files.upload[0]["filename"] + '.' + extension
//   //   upload_original_name = req.files.upload[0]["originalname"]
//   // }

//   // if (req.files.upload_logo) {
//   //   const extension = req.files.upload_logo[0]["mimetype"].split('/')[1]
//   //   upload_logo = req.files.upload_logo[0]["filename"] + '.' + extension
//   //   upload_logo_original_name = req.files.upload_logo[0]["originalname"]
//   // }
//   const v = new Validator(req.body, {
//     organization_name: 'required|minLength:1|maxLength:50',
//     phone_number: 'required|integer|minLength:7|maxLength:15',
//     gst_number: 'alphaNumeric|minLength:15|maxLength:15',
//     cin_number: 'alphaNumeric|minLength:21|maxLength:21',
//     tan_number: 'alphaNumeric|minLength:10|maxLength:10',
//     pan_number: 'alphaNumeric|minLength:10|maxLength:10',
//     branch_details: 'string|alpha|minLength:1|maxLength:50',
//     registered_address: 'string|minLength:1|maxLength:200',
//     city: 'integer|minLength:1|maxLength:8',
//     state: 'integer|minLength:1|maxLength:8',
//     country: 'integer|minLength:1|maxLength:8',
//     currency: 'integer|minLength:1|maxLength:8',
//     website: 'url|minLength:1|maxLength:50',
//     facebook_url: 'url|minLength:1|maxLength:50',
//     linkindin_url: 'url|minLength:1|maxLength:50',
//     twitter_url: 'url|minLength:1|maxLength:50',
//     instagram_url: 'url|minLength:1|maxLength:50',
//     youtube_url: 'url|minLength:1|maxLength:50',
//     approval: 'integer|minLength:1|maxLength:50',
//     // upload_logo: 'mime',
//     // upload_logo_original_name: 'mime',
//     // upload: 'mime',
//     // upload_original_name: 'mime',
//     first_name: 'required|minLength:1|maxLength:50',
//     last_name: 'minLength:1|maxLength:30',
//     email: 'required|email',
//     created_by: 'required|integer'
//   });
//   v.check().then(async (matched) => {
//     if (!matched) {
//       res.status(422).send(v.errors);
//     }
//     else {
//       // adminid fetch from organization
//       const query1 = util.promisify(sql.query).bind(sql);
//       const adminFetch = await query1(`select pri_admin_id from organization where id = ${req.params.org_id} and deleted_status=0 limit 1`);
//       const adminId = adminFetch[0] ? adminFetch[0]["pri_admin_id"] : 0
//       if (adminId == 0) {
//         res.status(402).send({
//           message:
//             "organization doesnot exist"
//         });
//       }
//       else {
//         // admin id valid or not
//         const adminExistsFetch = await query1(`select first_name from users where id = ${adminId} and deleted_status=0 limit 1`);
//         const adminIdExists = adminExistsFetch[0] ? adminExistsFetch[0]["first_name"] : 0
//         if (adminIdExists == 0) {
//           res.status(402).send({
//             message:
//               "Organization is valid & admin Id is invalid"
//           });
//         }
//         else {
//           // email id exists check
//           const emailIdExistsFetch = await query1(`select id from users where email='${req.body.email}' and id != ${adminId} and deleted_status=0 limit 1`);
//           const emailIdExists = emailIdExistsFetch[0] ? emailIdExistsFetch[0]["id"] : 0

//           if (emailIdExists != 0) {
//             res.status(402).send({
//               message:
//                 "Primary Email Already Exists"
//             });
//           }
//           else {
//             const organization = new Organization({
//               id: req.params.org_id,
//               organization_name: req.body.organization_name,
//               phone_number: req.body.phone_number,
//               gst_number: req.body.gst_number,
//               cin_number: req.body.cin_number,
//               tan_number: req.body.tan_number,
//               pan_number: req.body.pan_number,
//               branch_details: req.body.branch_details,
//               registered_address: req.body.registered_address,
//               city: req.body.city,
//               state: req.body.state,
//               country: req.body.country,
//               currency: req.body.currency,
//               website: req.body.website,
//               facebook_url: req.body.facebook_url,
//               linkindin_url: req.body.linkindin_url,
//               twitter_url: req.body.twitter_url,
//               instagram_url: req.body.instagram_url,
//               youtube_url: req.body.youtube_url,
//               approval: req.body.approval || 1,
//               // upload_logo: upload_logo,
//               // upload_logo_original_name: upload_logo_original_name,
//               // upload: upload,
//               // upload_original_name: upload_original_name
//             });
//             Organization.putOrganization(req.params.org_id, organization, async (err, data) => {
//               if (err) {
//                 if (err.kind === "not_found") {
//                   res.status(404).send({
//                     message: `Not found organization with id ${req.params.org_id}.`
//                   });
//                 }
//               }
//               else {
//                 const AssignToData = new User({
//                   first_name: req.body.first_name || null,
//                   last_name: req.body.last_name || null,
//                   email: req.body.email || null,
//                   created_by: req.body.created_by
//                 });
//                 User.putUserOrg(adminIdExists, AssignToData, (err, data) => { if (err) { console.log(err); result(err, null); return; } })

//                 // if (req.files.upload) {
//                 //   const currentPath = path.join(process.cwd(), "uploads", req.files.upload[0]["filename"]);
//                 //   const destinationPath = path.join(process.cwd(), "/uploads/company/upload/" + `${adminIdExists}`, upload);
//                 //   const baseUrl = process.cwd() + '/uploads/company/upload/' + `${adminIdExists}`
//                 //   fs.mkdirSync(baseUrl, { recursive: true })
//                 //   fs.rename(currentPath, destinationPath, function (err) {
//                 //     if (err) {
//                 //       throw err
//                 //     } else {
//                 //       console.log("Successfully moved the upload image!")
//                 //     }
//                 //   });
//                 // }
//                 // if (req.files.upload_logo) {
//                 //   const currentPath = path.join(process.cwd(), "uploads", req.files.upload_logo[0]["filename"]);
//                 //   const destinationPath = path.join(process.cwd(), "/uploads/company/upload_logo/" + `${adminIdExists}`, upload_logo);

//                 //   const baseUrl = process.cwd() + '/uploads/company/upload_logo/' + `${adminIdExists}`
//                 //   fs.mkdirSync(baseUrl, { recursive: true })
//                 //   fs.rename(currentPath, destinationPath, function (err) {
//                 //     if (err) {
//                 //       throw err
//                 //     } else {
//                 //       console.log("Successfully moved the upload_logo image!")
//                 //     }
//                 //   });
//                 // }
//                 res.status(200).send("organization details updated Succesfully");
//               }
//             });
//           }
//         }
//       }
//     }
//   })
// };
// // organization get all company
// exports.getOrganization = (req, res) => {
//   if(
//     !req.headers.authorization ||
//     !req.headers.authorization.startsWith('Bearer') ||
//     !req.headers.authorization.split(' ')[1]
//     ){
//     return res.status(422).json({
//     message: "Please provide the token",
//     });
//     }
//     try {
//       const theToken = req.headers.authorization.split(' ')[1];
//       const decoded = jwt.verify(theToken, 'the-super-strong-secrect');
//       console.log(decoded);
//     } catch (err) {
//       return res.status(401).send("Invalid Token");
//     }
//   var newArray = []
//   Organization.getOrganization(async (err, data) => {
//     const query = util.promisify(sql.query).bind(sql);
//     if (err)
//       res.status(500).send({
//         message:
//           err.message || "Some error occurred while retrieving data."
//       });
//     else {
//       for (i = 0; i < data.length; i++) {
//         const rows = await query(`select us.first_name,us.last_name,us.designation,us.email from users as us where us.deleted_at IS NULL and us.id = ${data[i]["pri_admin_id"]} and us.deleted_at IS NULL `);
//         data[i]["admin_details"] = rows
//         newArray.push(data[i])
//       }
//       res.send(newArray)
//     }
//   });
// };
// // organization get company ID
// exports.getOrganizationId = (req, res) => {
//   var newArray = []
//   Organization.getOrganizationId(req.params.org_id, async (err, data) => {
//     const query = util.promisify(sql.query).bind(sql);
//     if (err)
//       res.status(500).send({
//         message:
//           err.message || "Some error occurred while retrieving data."
//       });
//     else {
//       const rows = await query(`select us.first_name,us.last_name,us.designation,us.email from users as us where us.deleted_at IS NULL and us.id = ${data["pri_admin_id"]} and us.deleted_at IS NULL `);
//       data["admin_details"] = rows
//       newArray.push(data)
//       res.send(newArray)
//     }
//   });
// };
// // upload logo update
// exports.uploadImageUpdate = (req, res) => {
//   // save images and move to folder
//   let upload = "";
//   let upload_original_name = "";
//   let upload_logo = "";
//   let upload_logo_original_name = "";
//   if (req.files.upload_logo) {
//     const extension = req.files.upload_logo[0]["mimetype"].split('/')[1]
//     upload_logo = req.files.upload_logo[0]["filename"] + '.' + extension
//     upload_logo_original_name = req.files.upload_logo[0]["originalname"]
//   }
//   if (req.files.upload) {
//     const extension = req.files.upload[0]["mimetype"].split('/')[1]
//     upload = req.files.upload[0]["filename"] + '.' + extension
//     upload_original_name = req.files.upload[0]["originalname"]
//   }
//   const orgImagesData = new Organization({
//     upload: upload || null,
//     upload_original_name: upload_original_name || null,
//     upload_logo: upload_logo,
//     upload_logo_original_name: upload_logo_original_name
//   });

//   Organization.putProfileImage(req.params.org_id, orgImagesData, (err, data) => { if (err) { console.log(err); result(err, null); return; } })
//   let orgId = req.params.org_id
//   if (req.files.upload) {
//     const currentPath = path.join(process.cwd(), "uploads", req.files.upload[0]["filename"]);
//     const destinationPath = path.join(process.cwd(), "/uploads/organization/upload/" + `${orgId}`, upload);
//     const baseUrl = process.cwd() + '/uploads/organization/upload/' + `${orgId}`
//     fs.mkdirSync(baseUrl, { recursive: true })
//     fs.rename(currentPath, destinationPath, function (err) {
//       if (err) {
//         throw err
//       } else {
//         console.log("Successfully moved the upload image!")
//       }
//     });
//   }
//   if (req.files.upload_logo) {
//     const currentPath = path.join(process.cwd(), "uploads", req.files.upload_logo[0]["filename"]);
//     const destinationPath = path.join(process.cwd(), "/uploads/organization/upload_logo/" + `${orgId}`, upload_logo);

//     const baseUrl = process.cwd() + '/uploads/organization/upload_logo/' + `${orgId}`
//     fs.mkdirSync(baseUrl, { recursive: true })
//     fs.rename(currentPath, destinationPath, function (err) {
//       if (err) {
//         throw err
//       } else {
//         console.log("Successfully moved the upload_logo image!")
//       }
//     });
//   }
//   res.statusCode = 200;
//   res.send("Profile Image Updated Succesfully");
// }
// // organization DELETE
// exports.deleteOrganization = async (req, res) => {
//   // adminid fetch from organization
//   const query1 = util.promisify(sql.query).bind(sql);
//   const adminFetch = await query1(`select pri_admin_id from organization where id = ${req.params.org_id} and deleted_status=0 limit 1`);
//   const adminId = adminFetch[0] ? adminFetch[0]["pri_admin_id"] : 0
//   if (adminId == 0) {
//     res.status(402).send({
//       message:
//         "organization doesnot exist"
//     });
//   }
//   else {
//     // admin id valid or not
//     const adminExistsFetch = await query1(`select id from users where id = ${adminId} and deleted_status=0 limit 1`);
//     const adminIdExists = adminExistsFetch[0] ? adminExistsFetch[0]["id"] : 0
//     if (adminIdExists == 0) {
//       res.status(402).send({
//         message:
//           "Organization is valid & admin Id is invalid"
//       });
//     }
//     else {
//       Organization.deleteOrganization(req.params.org_id, async (err, data) => {
//         if (err) {
//           if (err.kind === "not_found") {
//             res.status(404).send({
//               message: `Not found organization with id ${req.params.org_id}.`
//             });
//           }
//         }
//         else {
//           User.deleteUser(adminIdExists,(err, data) => { if (err) { console.log(err); result(err, null); return; } })
//           res.status(200).send("organization details updated Succesfully");
//         }
//       });
//     }
//   }
// };
