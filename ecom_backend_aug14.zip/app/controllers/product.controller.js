const Product = require("../models/product.model.js");
const ProductStock = require("../models/productStock.model.js");
const ProductTaxes = require("../models/productTaxes.model.js");
const ProductTranslation = require("../models/productTranslation.model.js");
const DigitalProduct = require("../models/digitalProduct.model.js");
const Reviews = require("../models/reviews.model.js");
const fs = require("fs")
const dayjs = require('dayjs');
const path = require("path");


// Products
exports.getProducts = (req, res) => {
    Product.getProducts((err, data) => {
      if (err)
        res.status(401).send({
          message:
            err.message || "Some error occurred while retrieving data."
        });
      else 
      res.status(200).send({
        status:(200),
        message:"Success",
        Data:data
      })
    });
  };

  exports.getProductsByAdded = (req, res) => {
    Product.getProductsByAdded(req.query, req.params.role, (err, data) => {
      if (err)
        res.status(401).send({
          message:
            err.message || "Some error occurred while retrieving data."
        });
      else 
      res.status(200).send({
        status:(200),
        message:"Success",
        Data:data
      })
    });
  };

  exports.saveProduct = (req, res) => {

    let pdf = "";
    let meta_img = "";
    let photos = "";
    let thumbnail_img = "";

    if (req.files.pdf) {
      const extension = req.files.pdf[0]["mimetype"].split('/')[1]
      pdf = req.files.pdf[0]["filename"] + '.' + extension
      pdf = req.files.pdf[0]["originalname"]
    }
    if (req.files.meta_img) {
        const extension = req.files.meta_img[0]["mimetype"].split('/')[1]
        meta_img = req.files.meta_img[0]["filename"] + '.' + extension
        meta_img = req.files.meta_img[0]["originalname"]
    }
    if (req.files.photos) {
        const extension = req.files.photos[0]["mimetype"].split('/')[1]
        photos = req.files.photos[0]["filename"] + '.' + extension
        photos = req.files.photos[0]["originalname"]
    }
    if (req.files.thumbnail_img) {
        const extension = req.files.thumbnail_img[0]["mimetype"].split('/')[1]
        thumbnail_img = req.files.thumbnail_img[0]["filename"] + '.' + extension
        thumbnail_img = req.files.thumbnail_img[0]["originalname"]
    }

    const discount_start_date = req.body.discount_start_date
    let discountStartDateMerge = ""
    if (discount_start_date) {
      let start = dayjs(req.body.discount_start_date);
      discountStartDateMerge = start.format("YYYY-MM-DD h:mm:ss")
    } else {
      discountStartDateMerge = ""
    }

    const discount_end_date = req.body.discount_end_date
    let discountEndDateMerge = ""
    if (discount_end_date) {
      let end = dayjs(req.body.discount_end);
      discountEndDateMerge = end.format("YYYY-MM-DD h:mm:ss")
    } else {
      discountEndDateMerge = " "
    }

    const products = new Product({
        id :req.body.id || null, 
        name :req.body.name|| null,
        added_by : "admin" || null,
        user_id :req.body.user_id|| null,
        category_id	 :req.body.category_id|| null,
        brand_id :req.body.brand_id|| null,
        photos : photos || null,
        thumbnail_img : thumbnail_img|| null,
        video_provider :req.body.video_provider|| null,
        video_link :req.body.video_link|| null,
        tags :req.body.tags|| null,
        description :req.body.description|| null,
        unit_price :req.body.unit_price|| null,
        purchase_price :req.body.purchase_price|| null,
        variant_product :req.body.variant_product|| "0" || null,
        attributes :req.body.attributes|| null,
        choice_options :req.body.choice_options|| null,
        colors :req.body.colors|| null,
        variations :req.body.variations|| null,
        todays_deal :req.body.todays_deal|| "0" || null,
        published :req.body.published|| "0" || null,
        approved :req.body.approved|| "0" || null,
        stock_visibility_state :req.body.stock_visibility_state|| null,
        cash_on_delivery :req.body.cash_on_delivery|| "0" ||  null,
        featured :req.body.featured|| "0" ||  null,
        seller_featured :req.body.seller_featured|| "0" ||  null,
        current_stock :req.body.current_stock|| "0" ||  null,
        unit :req.body.unit|| null,
        weight :req.body.weight|| "0.00" ||  null,
        min_qty :req.body.min_qty|| "0" ||  null,
        low_stock_quantity :req.body.low_stock_quantity|| null,
        discount :req.body.discount	|| null,
        discount_type :req.body.discount_type|| null,
        discount_start_date : discountStartDateMerge|| null,
        discount_end_date : discountEndDateMerge|| null,
        tax :req.body.tax|| null,
        tax_type :req.body.tax_type|| null,
        shipping_type :req.body.shipping_type|| "flat_rate" || null,
        shipping_cost :req.body.shipping_cost||  "0.00" || null,
        is_quantity_multiplied :req.body.is_quantity_multiplied|| "0" || null,
        est_shipping_days :req.body.est_shipping_days|| null,
        num_of_sale :req.body.num_of_sale|| "0" ||  null,
        meta_title :req.body.meta_title|| null,
        meta_description :req.body.meta_description|| null,
        meta_img : meta_img|| null,
        pdf : pdf|| null,
        slug : req.body.slug|| null,
        rating :req.body.rating|| "0.00" ||  null,
        barcode :req.body.barcode|| null,
        digital : "0" || null,
        auction_product :req.body.auction_product|| "0" || null,
        file_name :req.body.file_name|| null,
        file_path :req.body.file_path|| null,
        external_link :req.body.external_link|| null,
        external_link_btn :req.body.external_link_btn|| "buy_now" || null,
        wholesale_product :req.body.wholesale_product|| "0" || null,
    });
  
    Product.saveProduct( products, (err, data) => {
      if (err) {
        console.log(err)
        res.status(401).send({
          message:
            err.message || "Some error occurred while posting new products  ."
        });
      }
      else {

     let productId = data.insertId

      if (req.files.pdf) {
        
        const currentPath = path.join(process.cwd(), "uploads", req.files.pdf[0]["filename"]);
        const destinationPath = path.join(process.cwd(), "/uploads/products/pdf/" + `${productId}`, pdf);
        const baseUrl = process.cwd() + '/uploads/products/pdf/' + `${productId}`
        fs.mkdirSync(baseUrl, { recursive: true })
        fs.rename(currentPath, destinationPath, function (err) {
          if (err) {
            throw err
          } else {
            console.log("Successfully moved the pdf files !")
          }
        });
      }

      if (req.files.meta_img) {
        
        const currentPath = path.join(process.cwd(), "uploads", req.files.meta_img[0]["filename"]);
        const destinationPath = path.join(process.cwd(), "/uploads/products/meta_img/" + `${productId}`, meta_img);
        const baseUrl = process.cwd() + '/uploads/products/meta_img/' + `${productId}`
        fs.mkdirSync(baseUrl, { recursive: true })
        fs.rename(currentPath, destinationPath, function (err) {
          if (err) {
            throw err
          } else {
            console.log("Successfully moved the meta images !")
          }
        });
      }

      if (req.files.photos) {
        
        const currentPath = path.join(process.cwd(), "uploads", req.files.photos[0]["filename"]);
        const destinationPath = path.join(process.cwd(), "/uploads/products/photos/" + `${productId}`, photos);
        const baseUrl = process.cwd() + '/uploads/products/photos/' + `${productId}`
        fs.mkdirSync(baseUrl, { recursive: true })
        fs.rename(currentPath, destinationPath, function (err) {
          if (err) {
            throw err
          } else {
            console.log("Successfully moved the meta images !")
          }
        });
      }

      if (req.files.thumbnail_img) {
        
        const currentPath = path.join(process.cwd(), "uploads", req.files.thumbnail_img[0]["filename"]);
        const destinationPath = path.join(process.cwd(), "/uploads/products/thumbnail_img/" + `${productId}`, thumbnail_img);
        const baseUrl = process.cwd() + '/uploads/products/thumbnail_img/' + `${productId}`
        fs.mkdirSync(baseUrl, { recursive: true })
        fs.rename(currentPath, destinationPath, function (err) {
          if (err) {
            throw err
          } else {
            console.log("Successfully moved the meta images !")
          }
        });
      }

    // const productstock = new ProductStock({
    //   id: req.body.id,
    //   product_id: productId,
    //   variant: req.body.variant,
    //   sku: req.body.sku,
    //   price: req.body.price,
    //   qty: req.body.qty,
    //   image: req.body.image,
    // });

    // const productTaxes = new ProductTaxes({
    //   id : req.body.id,
    //   product_id : productId,
    //   tax_id : req.body.tax_id,
    //   tax : req.body.tax,
    //   tax_type : req.body.tax_type,
    // });

    // const productTranslation = new ProductTranslation({
    //   id : req.body.id,
    //   product_id : productId,
    //   name : req.body.name,
    //   unit : req.body.unit,
    //   description : req.body.description,
    //   lang : req.body.lang,
    // });


    // ProductStock.saveProductStock(productstock, (err, data) => {
    //   if (err) {
    //     console.log(err)
    //     console.log("Product Stock");
    //     console.log("Posted Successfully");
    //     res.statusCode = 200;
    //   }
    // });

    // ProductTaxes.saveProductTaxes(productTaxes, (err, data) => {
    //   if (err) {
    //     console.log(err)
    //     console.log("Product Taxes");
    //     console.log("Posted Successfully");
    //     res.statusCode = 200;
    //   }
    // });

    // ProductTranslation.saveProductTranslation(productTranslation, (err, data) => {
    //   if (err) {
    //     console.log(err)
    //     console.log("Product Translation");
    //     console.log("Posted Successfully");
    //     res.statusCode = 200;
    //   }
    // });
        console.log("Posted Successfully");
        res.status(200).send({
        message: "Posted Successfully",
        output: products
        })
      }
    });
  };

  // exports.putProduct =(async (req, res) => {

  //   let pdf = "" ;
  //   let meta_img = "";
  //   let photos = "";
  //   let thumbnail_img = "";

  //   if (req.files.pdf) {
  //     const extension = req.files.pdf[0]["mimetype"].split('/')[1]
  //     pdf = req.files.pdf[0]["filename"] + '.' + extension
  //     pdf = req.files.pdf[0]["originalname"]
  //   }

  //   if (req.files.meta_img) {
  //       const extension = req.files.meta_img[0]["mimetype"].split('/')[1]
  //       meta_img = req.files.meta_img[0]["filename"] + '.' + extension
  //       meta_img = req.files.meta_img[0]["originalname"]
  //   }
  //   if (req.files.photos) {
  //       const extension = req.files.photos[0]["mimetype"].split('/')[1]
  //       photos = req.files.photos[0]["filename"] + '.' + extension
  //       photos = req.files.photos[0]["originalname"]
  //   }
  //   if (req.files.thumbnail_img) {
  //       const extension = req.files.thumbnail_img[0]["mimetype"].split('/')[1]
  //       thumbnail_img = req.files.thumbnail_img[0]["filename"] + '.' + extension
  //       thumbnail_img = req.files.thumbnail_img[0]["originalname"]
  //   }

  //   const products = new Product({
  //       id :req.body.id,
  //       name :req.body.name,
  //       added_by :req.body.added_by,
  //       user_id :req.body.user_id,
  //       category_id	 :req.body.category_id,
  //       brand_id :req.body.brand_id,
  //       photos: photos,
  //       thumbnail_img : thumbnail_img,
  //       conditon :req.body.conditon,
  //       location :req.body.location,
  //       video_provider :req.body.video_provider,
  //       video_link :req.body.video_link,
  //       tags :req.body.tags,
  //       description :req.body.description,
  //       unit_price :req.body.unit_price,
  //       purchase_price :req.body.purchase_price,
  //       variant_product :req.body.variant_product,
  //       attributes :req.body.attributes,
  //       choice_options :req.body.choice_options,
  //       colors :req.body.colors,
  //       variations :req.body.variations,
  //       todays_deal :req.body.todays_deal,
  //       published :req.body.published,
  //       approved :req.body.approved,
  //       stock_visibility_state :req.body.stock_visibility_state,
  //       cash_on_delivery :req.body.cash_on_delivery,
  //       featured :req.body.featured,
  //       seller_featured :req.body.seller_featured,
  //       current_stock :req.body.current_stock,
  //       unit :req.body.unit,
  //       weight :req.body.weight,
  //       min_qty :req.body.min_qty,
  //       low_stock_quantity :req.body.low_stock_quantity,
  //       discount :req.body.discount	,
  //       discount_type :req.body.discount_type,
  //       discount_start_date :req.body.discount_start_date,
  //       discount_end_date :req.body.discount_end_date,
  //       tax :req.body.tax,
  //       tax_type :req.body.tax_type,
  //       shipping_type :req.body.shipping_type,
  //       shipping_cost :req.body.shipping_cost,
  //       is_quantity_multiplied :req.body.is_quantity_multiplied,
  //       est_shipping_days :req.body.est_shipping_days,
  //       num_of_sale :req.body.num_of_sale,
  //       meta_title :req.body.meta_title,
  //       meta_description :req.body.meta_description,
  //       meta_img : meta_img,
  //       pdf : req.body.pdf,
  //       slug :req.body.slug,
  //       rating :req.body.rating,
  //       barcode :req.body.barcode,
  //       digital : "0",
  //       auction_product :req.body.auction_product,
  //       file_name :req.body.file_name,
  //       file_path :req.body.file_path,
  //       external_link :req.body.external_link,
  //       external_link_btn :req.body.external_link_btn,
  //       wholesale_product :req.body.wholesale_product,
  //   });
  
  //   let productId = req.params.id
    
  //   Product.putProduct (req.params.id, products, (err, data) => {
  //     if (err) {
  //       if (err.kind === "not_found") {
  //         res.status(401).send({
  //           message: `Not found products with id ${req.params.id}.`
  //         });
  //       }
  //     }
  //     else {

  //       if (req.files.pdf) {
        
  //         const currentPath = path.join(process.cwd(), "uploads", req.files.pdf[0]["filename"]);
  //         const destinationPath = path.join(process.cwd(), "/uploads/products/pdf/" + `${productId}`, pdf);
  //         const baseUrl = process.cwd() + '/uploads/products/pdf/' + `${productId}`
  //         fs.mkdirSync(baseUrl, { recursive: true })
  //         fs.rename(currentPath, destinationPath, function (err) {
  //           if (err) {
  //             throw err
  //           } else {
  //             console.log("Successfully moved the pdf files !")
  //           }
  //         });
  //       }
  
  //       if (req.files.meta_img) {
          
  //         const currentPath = path.join(process.cwd(), "uploads", req.files.meta_img[0]["filename"]);
  //         const destinationPath = path.join(process.cwd(), "/uploads/products/meta_img/" + `${productId}`, meta_img);
  //         const baseUrl = process.cwd() + '/uploads/products/meta_img/' + `${productId}`
  //         fs.mkdirSync(baseUrl, { recursive: true })
  //         fs.rename(currentPath, destinationPath, function (err) {
  //           if (err) {
  //             throw err
  //           } else {
  //             console.log("Successfully moved the meta images !")
  //           }
  //         });
  //       }
  
  //       if (req.files.photos) {
          
  //         const currentPath = path.join(process.cwd(), "uploads", req.files.photos[0]["filename"]);
  //         const destinationPath = path.join(process.cwd(), "/uploads/products/photos/" + `${productId}`, photos);
  //         const baseUrl = process.cwd() + '/uploads/products/photos/' + `${productId}`
  //         fs.mkdirSync(baseUrl, { recursive: true })
  //         fs.rename(currentPath, destinationPath, function (err) {
  //           if (err) {
  //             throw err
  //           } else {
  //             console.log("Successfully moved the meta images !")
  //           }
  //         });
  //       }
  
  //       if (req.files.thumbnail_img) {
          
  //         const currentPath = path.join(process.cwd(), "uploads", req.files.thumbnail_img[0]["filename"]);
  //         const destinationPath = path.join(process.cwd(), "/uploads/products/thumbnail_img/" + `${productId}`, thumbnail_img);
  //         const baseUrl = process.cwd() + '/uploads/products/thumbnail_img/' + `${productId}`
  //         fs.mkdirSync(baseUrl, { recursive: true })
  //         fs.rename(currentPath, destinationPath, function (err) {
  //           if (err) {
  //             throw err
  //           } else {
  //             console.log("Successfully moved the meta images !")
  //           }
  //         });
  //       }
        
  //     //   const productstock = new ProductStock({
  //     //     product_id :  productId || null,
  //     //     variant :  req.body.variant || null,
  //     //     sku :  req.body.sku || null,
  //     //     price :  req.body.price || null,
  //     //     qty :  req.body.qty || null,
  //     //     image :  req.body.image || null,
  //     //   });

  //     //   const productTaxes = new ProductTaxes({
  //     //     id : req.body.id,
  //     //     product_id : productId,
  //     //     tax_id : req.body.tax_id,
  //     //     tax : req.body.tax,
  //     //     tax_type : req.body.tax_type,
  //     //   });
  
  //     //   const productTranslation = new ProductTranslation({
  //     //     product_id : productId || null ,
  //     //     name : req.body.name || null ,
  //     //     unit : req.body.unit || null ,
  //     //     description : req.body.description || null ,
  //     //     lang : req.body.lang || null ,
  //     //   });

  //       // ProductStock.putProductStock (req.params.id, productstock, (err, data) => {
  //       //   if (err) {
  //       //     if (err.kind === "not_found") {
  //       //       res.status(401).send({
  //       //         message: `Not found Product Stock with id ${req.params.id}.`
  //       //       });
  //       //     }
  //       //   }
  //       // });

  //     //   ProductTaxes.putProductTaxes (req.params.id, productTaxes, (err, data) => {
  //     //     if (err) {
  //     //       if (err.kind === "not_found") {
  //     //         res.status(401).send({
  //     //           message: `Not found Product Stock with id ${req.params.id}.`
  //     //         });
  //     //       }
  //     //     }
  //     //   });
        
  //     // ProductTranslation.putProductTranslation (productId , productTranslation, (err, data) => {
  //     //   if (err) {
  //     //     if (err.kind === "not_found") {
  //     //       res.status(401).send({
  //     //         message: `Not found with product id ${productId}.`
  //     //       });
  //     //     }
  //     //   }
  //     // })

  //     res.status(200).send({
  //       status:(200),
  //       message:"Success",
  //       Data:products
  //     })
  //     }
  // });
  // });

  exports.putProduct = (async (req, res) => {

    let pdf = "";
    let meta_img = "";
    let photos = "";
    let thumbnail_img = "";

    if (req.files.pdf) {
      const extension = req.files.pdf[0]["mimetype"].split('/')[1]
      pdf = req.files.pdf[0]["filename"] + '.' + extension
      pdf = req.files.pdf[0]["originalname"]
    }

    if (req.files.meta_img) {
        const extension = req.files.meta_img[0]["mimetype"].split('/')[1]
        meta_img = req.files.meta_img[0]["filename"] + '.' + extension
        meta_img = req.files.meta_img[0]["originalname"]
    }
    if (req.files.photos) {
        const extension = req.files.photos[0]["mimetype"].split('/')[1]
        photos = req.files.photos[0]["filename"] + '.' + extension
        photos = req.files.photos[0]["originalname"]
    }
    if (req.files.thumbnail_img) {
        const extension = req.files.thumbnail_img[0]["mimetype"].split('/')[1]
        thumbnail_img = req.files.thumbnail_img[0]["filename"] + '.' + extension
        thumbnail_img = req.files.thumbnail_img[0]["originalname"]
    }

    const products = new Product({
      id :req.body.id,
      name :req.body.name,
      added_by :req.body.added_by,
      user_id :req.body.user_id,
      category_id	 :req.body.category_id,
      brand_id :req.body.brand_id,
      photos: photos,
      thumbnail_img : thumbnail_img,
      conditon :req.body.conditon,
      location :req.body.location,
      video_provider :req.body.video_provider,
      video_link :req.body.video_link,
      tags :req.body.tags,
      description :req.body.description,
      unit_price :req.body.unit_price,
      purchase_price :req.body.purchase_price,
      variant_product :req.body.variant_product,
      attributes :req.body.attributes,
      choice_options :req.body.choice_options,
      colors :req.body.colors,
      variations :req.body.variations,
      todays_deal :req.body.todays_deal,
      published :req.body.published,
      approved :req.body.approved,
      stock_visibility_state :req.body.stock_visibility_state,
      cash_on_delivery :req.body.cash_on_delivery,
      featured :req.body.featured,
      seller_featured :req.body.seller_featured,
      current_stock :req.body.current_stock,
      unit :req.body.unit,
      weight :req.body.weight,
      min_qty :req.body.min_qty,
      low_stock_quantity :req.body.low_stock_quantity,
      discount :req.body.discount	,
      discount_type :req.body.discount_type,
      discount_start_date :req.body.discount_start_date,
      discount_end_date :req.body.discount_end_date,
      tax :req.body.tax,
      tax_type :req.body.tax_type,
      shipping_type :req.body.shipping_type,
      shipping_cost :req.body.shipping_cost,
      is_quantity_multiplied :req.body.is_quantity_multiplied,
      est_shipping_days :req.body.est_shipping_days,
      num_of_sale :req.body.num_of_sale,
      meta_title :req.body.meta_title,
      meta_description :req.body.meta_description,
      meta_img : meta_img,
      pdf : req.body.pdf,
      slug :req.body.slug,
      rating :req.body.rating,
      barcode :req.body.barcode,
      digital : "0",
      auction_product :req.body.auction_product,
      file_name :req.body.file_name,
      file_path :req.body.file_path,
      external_link :req.body.external_link,
      external_link_btn :req.body.external_link_btn,
      wholesale_product :req.body.wholesale_product,
  });

    let productId = req.params.id
    
    Product.putProduct (req.params.id, products, (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(401).send({
            message: `Not found products with id ${req.params.id}.`
          });
        }
      }
      else {

        if (req.files.pdf) {
        
          const currentPath = path.join(process.cwd(), "uploads", req.files.pdf[0]["filename"]);
          const destinationPath = path.join(process.cwd(), "/uploads/products/pdf/" + `${productId}`, pdf);
          const baseUrl = process.cwd() + '/uploads/products/pdf/' + `${productId}`
          fs.mkdirSync(baseUrl, { recursive: true })
          fs.rename(currentPath, destinationPath, function (err) {
            if (err) {
              throw err
            } else {
              console.log("Successfully moved the pdf files !")
            }
          });
        }
  
        if (req.files.meta_img) {
          
          const currentPath = path.join(process.cwd(), "uploads", req.files.meta_img[0]["filename"]);
          const destinationPath = path.join(process.cwd(), "/uploads/products/meta_img/" + `${productId}`, meta_img);
          const baseUrl = process.cwd() + '/uploads/products/meta_img/' + `${productId}`
          fs.mkdirSync(baseUrl, { recursive: true })
          fs.rename(currentPath, destinationPath, function (err) {
            if (err) {
              throw err
            } else {
              console.log("Successfully moved the meta images !")
            }
          });
        }
  
        if (req.files.photos) {
          
          const currentPath = path.join(process.cwd(), "uploads", req.files.photos[0]["filename"]);
          const destinationPath = path.join(process.cwd(), "/uploads/products/photos/" + `${productId}`, photos);
          const baseUrl = process.cwd() + '/uploads/products/photos/' + `${productId}`
          fs.mkdirSync(baseUrl, { recursive: true })
          fs.rename(currentPath, destinationPath, function (err) {
            if (err) {
              throw err
            } else {
              console.log("Successfully moved the meta images !")
            }
          });
        }
  
        if (req.files.thumbnail_img) {
          
          const currentPath = path.join(process.cwd(), "uploads", req.files.thumbnail_img[0]["filename"]);
          const destinationPath = path.join(process.cwd(), "/uploads/products/thumbnail_img/" + `${productId}`, thumbnail_img);
          const baseUrl = process.cwd() + '/uploads/products/thumbnail_img/' + `${productId}`
          fs.mkdirSync(baseUrl, { recursive: true })
          fs.rename(currentPath, destinationPath, function (err) {
            if (err) {
              throw err
            } else {
              console.log("Successfully moved the meta images !")
            }
          });
        }
        res.status(200).send({
          status:(200),
          message:"Success",
          Data:products
        })
      }
    }
    ) 
  });


  exports.getProductID = (req, res) => {
    Product.getProductID(req.params.id, (err, data) => {
    if (err)
      res.status(401).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
    else 
    res.status(200).send({
      status:(200),
      message:"Success",
      Data:data
    })
  });
};

  exports.deleteProduct = (req, res) => {
    Product.deleteProduct ( req.params.id, (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(401).send({
            message: `Not found product with id ${req.params.id}.`
          });
        }
      }
      else {
        res.statusCode = 200;
        res.send("Product deleted Succesfully");
      }
  });
};

exports.getSellerProductsAddedBy = (req, res) => {
  Product.getSellerProductsAddedBy(req.query, req.params.user_id, (err, data) => {
    if (err)
      res.status(401).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
    else
    res.status(200).send({
      status:(200),
      message:"Success",
      Data:data
    })
  });
};

// Digital Products
exports.getDigitalProducts = (req, res) => {
  DigitalProduct.getDigitalProducts((err, data) => {
    if (err)
      res.status(401).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
    else 
    res.status(200).send({
      status:(200),
      message:"Success",
      Data:data
    })
  });
};


exports.getDigitalProductsByAdded = (req, res) => {
  DigitalProduct.getDigitalProductsByAdded(req.query, req.params.role, (err, data) => {
    if (err)
      res.status(401).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
    else     
      res.status(200).send({
      status:(200),
      message:"Success",
      Data:data
    })
  });
};

exports.saveDigitalProduct = (req, res) => {

  let pdf = "";
  let meta_img = "";
  let photos = "";
  let thumbnail_img = "";

  if (req.files.pdf) {
    const extension = req.files.pdf[0]["mimetype"].split('/')[1]
    pdf = req.files.pdf[0]["filename"] + '.' + extension
    pdf = req.files.pdf[0]["originalname"]
  }

  if (req.files.meta_img) {
      const extension = req.files.meta_img[0]["mimetype"].split('/')[1]
      meta_img = req.files.meta_img[0]["filename"] + '.' + extension
      meta_img = req.files.meta_img[0]["originalname"]
  }
  if (req.files.photos) {
      const extension = req.files.photos[0]["mimetype"].split('/')[1]
      photos = req.files.photos[0]["filename"] + '.' + extension
      photos = req.files.photos[0]["originalname"]
  }
  if (req.files.thumbnail_img) {
      const extension = req.files.thumbnail_img[0]["mimetype"].split('/')[1]
      thumbnail_img = req.files.thumbnail_img[0]["filename"] + '.' + extension
      thumbnail_img = req.files.thumbnail_img[0]["originalname"]
  }

  const discount_start_date = req.body.discount_start_date
  let discountStartDateMerge = ""
  if (discount_start_date) {
    let start = dayjs(req.body.discount_start_date);
    discountStartDateMerge = start.format("YYYY-MM-DD h:mm:ss")
  } else {
    discountStartDateMerge = ""
  }

  const discount_end_date = req.body.discount_end_date
  let discountEndDateMerge = ""
  if (discount_end_date) {
    let end = dayjs(req.body.discount_end);
    discountEndDateMerge = end.format("YYYY-MM-DD h:mm:ss")
  } else {
    discountEndDateMerge = " "
  }

  const products = new DigitalProduct({
      id :req.body.id ,
      name :req.body.name,
      added_by :req.body.added_by,
      user_id :req.body.user_id,
      category_id	 :req.body.category_id,
      brand_id :req.body.brand_id,
      photos : photos,
      thumbnail_img : thumbnail_img,
      video_provider :req.body.video_provider,
      video_link :req.body.video_link,
      tags :req.body.tags,
      description :req.body.description,
      unit_price :req.body.unit_price,
      purchase_price :req.body.purchase_price,
      variant_product :req.body.variant_product,
      attributes :req.body.attributes,
      choice_options :req.body.choice_options,
      colors :req.body.colors,
      variations :req.body.variations,
      todays_deal :req.body.todays_deal,
      published :req.body.published,
      approved :req.body.approved,
      stock_visibility_state :req.body.stock_visibility_state,
      cash_on_delivery :req.body.cash_on_delivery,
      featured :req.body.featured,
      seller_featured :req.body.seller_featured,
      current_stock :req.body.current_stock,
      unit :req.body.unit,
      weight :req.body.weight,
      min_qty :req.body.min_qty,
      low_stock_quantity :req.body.low_stock_quantity,
      discount :req.body.discount	,
      discount_type :req.body.discount_type,
      discount_start_date : discountStartDateMerge,
      discount_end_date : discountEndDateMerge,
      tax :req.body.tax,
      tax_type :req.body.tax_type,
      shipping_type :req.body.shipping_type,
      shipping_cost :req.body.shipping_cost,
      is_quantity_multiplied :req.body.is_quantity_multiplied,
      est_shipping_days :req.body.est_shipping_days,
      num_of_sale :req.body.num_of_sale,
      meta_title :req.body.meta_title,
      meta_description :req.body.meta_description,
      meta_img : meta_img,
      pdf : pdf,
      slug :req.body.slug,
      rating :req.body.rating,
      barcode :req.body.barcode,
      digital : "2",
      auction_product :req.body.auction_product,
      file_name :req.body.file_name,
      file_path :req.body.file_path,
      external_link :req.body.external_link,
      external_link_btn :req.body.external_link_btn,
      wholesale_product :req.body.wholesale_product,
      
  });

  DigitalProduct.saveDigitalProduct( products, (err, data) => {
    if (err) {
      console.log(err)
      res.status(401).send({
        message:
          err.message || "Some error occurred while posting new products  ."
      });
    }
    else {

   let productId = data.insertId

    if (req.files.pdf) {
      
      const currentPath = path.join(process.cwd(), "uploads", req.files.pdf[0]["filename"]);
      const destinationPath = path.join(process.cwd(), "/uploads/products/pdf/" + `${productId}`, pdf);
      const baseUrl = process.cwd() + '/uploads/products/pdf/' + `${productId}`
      fs.mkdirSync(baseUrl, { recursive: true })
      fs.rename(currentPath, destinationPath, function (err) {
        if (err) {
          throw err
        } else {
          console.log("Successfully moved the pdf files !")
        }
      });
    }

    if (req.files.meta_img) {
      
      const currentPath = path.join(process.cwd(), "uploads", req.files.meta_img[0]["filename"]);
      const destinationPath = path.join(process.cwd(), "/uploads/products/meta_img/" + `${productId}`, meta_img);
      const baseUrl = process.cwd() + '/uploads/products/meta_img/' + `${productId}`
      fs.mkdirSync(baseUrl, { recursive: true })
      fs.rename(currentPath, destinationPath, function (err) {
        if (err) {
          throw err
        } else {
          console.log("Successfully moved the meta images !")
        }
      });
    }

    if (req.files.photos) {
      
      const currentPath = path.join(process.cwd(), "uploads", req.files.photos[0]["filename"]);
      const destinationPath = path.join(process.cwd(), "/uploads/products/photos/" + `${productId}`, photos);
      const baseUrl = process.cwd() + '/uploads/products/photos/' + `${productId}`
      fs.mkdirSync(baseUrl, { recursive: true })
      fs.rename(currentPath, destinationPath, function (err) {
        if (err) {
          throw err
        } else {
          console.log("Successfully moved the meta images !")
        }
      });
    }

    if (req.files.thumbnail_img) {
      
      const currentPath = path.join(process.cwd(), "uploads", req.files.thumbnail_img[0]["filename"]);
      const destinationPath = path.join(process.cwd(), "/uploads/products/thumbnail_img/" + `${productId}`, thumbnail_img);
      const baseUrl = process.cwd() + '/uploads/products/thumbnail_img/' + `${productId}`
      fs.mkdirSync(baseUrl, { recursive: true })
      fs.rename(currentPath, destinationPath, function (err) {
        if (err) {
          throw err
        } else {
          console.log("Successfully moved the meta images !")
        }
      });
    }

    const productstock = new ProductStock({
      id: req.body.id,
      product_id: productId,
      variant: req.body.variant,
      sku: req.body.sku,
      price: req.body.price,
      qty: req.body.qty,
      image: req.body.image,
    });

    const productTaxes = new ProductTaxes({
      id : req.body.id,
      product_id : productId,
      tax_id : req.body.tax_id,
      tax : req.body.tax,
      tax_type : req.body.tax_type,
    });

    const productTranslation = new ProductTranslation({
      id : req.body.id,
      product_id : productId,
      name : req.body.name,
      unit : req.body.unit,
      description : req.body.description,
      lang : req.body.lang,
    });

    ProductStock.saveProductStock(productstock, (err, data) => {
      if (err) {
        console.log(err)
        console.log("Product Stock");
        console.log("Posted Successfully");
        res.statusCode = 200;
      }
    });

    ProductTaxes.saveProductTaxes(productTaxes, (err, data) => {
      if (err) {
        console.log(err)
        console.log("Product Taxes");
        console.log("Posted Successfully");
        res.statusCode = 200;
      }
    });

    ProductTranslation.saveProductTranslation(productTranslation, (err, data) => {
      if (err) {
        console.log(err)
        console.log("Product Translation");
        console.log("Posted Successfully");
        res.statusCode = 200;
      }
    });

      console.log("Posted Successfully");
      res.status(200).send({
        message: "Posted Successfully",
        output: data
      })
    }
  });
};

exports.putDigitalProduct = (req, res) => {

  let pdf = "" ;
  let meta_img = "";
  let photos = "";
  let thumbnail_img = "";

  if (req.files.pdf) {
    const extension = req.files.pdf[0]["mimetype"].split('/')[1]
    pdf = req.files.pdf[0]["filename"] + '.' + extension
    pdf = req.files.pdf[0]["originalname"]
  }

  if (req.files.meta_img) {
      const extension = req.files.meta_img[0]["mimetype"].split('/')[1]
      meta_img = req.files.meta_img[0]["filename"] + '.' + extension
      meta_img = req.files.meta_img[0]["originalname"]
  }
  if (req.files.photos) {
      const extension = req.files.photos[0]["mimetype"].split('/')[1]
      photos = req.files.photos[0]["filename"] + '.' + extension
      photos = req.files.photos[0]["originalname"]
  }
  if (req.files.thumbnail_img) {
      const extension = req.files.thumbnail_img[0]["mimetype"].split('/')[1]
      thumbnail_img = req.files.thumbnail_img[0]["filename"] + '.' + extension
      thumbnail_img = req.files.thumbnail_img[0]["originalname"]
  }

  const products = new DigitalProduct({
      id :req.body.id || null ,
      name :req.body.name || null ,
      added_by :req.body.added_by || null ,
      user_id :req.body.user_id || null ,
      category_id	 :req.body.category_id || null ,
      brand_id :req.body.brand_id || null ,
      photos: photos || null ,
      thumbnail_img : thumbnail_img || null ,
      conditon :req.body.conditon || null ,
      location :req.body.location || null ,
      video_provider :req.body.video_provider || null ,
      video_link :req.body.video_link || null ,
      tags :req.body.tags || null ,
      description :req.body.description || null ,
      unit_price :req.body.unit_price || null ,
      purchase_price :req.body.purchase_price || null ,
      variant_product :req.body.variant_product || null ,
      attributes :req.body.attributes || null ,
      choice_options :req.body.choice_options || null ,
      colors :req.body.colors || null ,
      variations :req.body.variations || null ,
      todays_deal :req.body.todays_deal || null ,
      published :req.body.published || null ,
      approved :req.body.approved || null ,
      stock_visibility_state :req.body.stock_visibility_state || null ,
      cash_on_delivery :req.body.cash_on_delivery || null ,
      featured :req.body.featured || null ,
      seller_featured :req.body.seller_featured || null ,
      current_stock :req.body.current_stock || null ,
      unit :req.body.unit || null ,
      weight :req.body.weight || null ,
      min_qty :req.body.min_qty || null ,
      low_stock_quantity :req.body.low_stock_quantity || null ,
      discount :req.body.discount	 || null ,
      discount_type :req.body.discount_type || null ,
      discount_start_date :req.body.discount_start_date || null ,
      discount_end_date :req.body.discount_end_date || null ,
      tax :req.body.tax || null ,
      tax_type :req.body.tax_type || null ,
      shipping_type :req.body.shipping_type || null ,
      shipping_cost :req.body.shipping_cost || null ,
      is_quantity_multiplied :req.body.is_quantity_multiplied || null ,
      est_shipping_days :req.body.est_shipping_days || null ,
      num_of_sale :req.body.num_of_sale || null ,
      meta_title :req.body.meta_title || null ,
      meta_description :req.body.meta_description || null ,
      meta_img : meta_img || null ,
      pdf : pdf || null ,
      slug :req.body.slug || null ,
      rating :req.body.rating || null ,
      barcode :req.body.barcode || null ,
      digital :"2" || null ,
      auction_product : req.body.auction_product || null ,
      file_name :req.body.file_name || null ,
      file_path :req.body.file_path || null ,
      external_link :req.body.external_link || null ,
      external_link_btn :req.body.external_link_btn || null ,
      wholesale_product :req.body.wholesale_product || null ,
  });

  let productId = req.params.id

  DigitalProduct.putDigitalProduct (req.params.id, products, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(401).send({
          message: `Not found digital product with id ${req.params.id}.`
        });
      }
    }
    else {


      if (req.files.pdf) {
        
        const currentPath = path.join(process.cwd(), "uploads", req.files.pdf[0]["filename"]);
        const destinationPath = path.join(process.cwd(), "/uploads/products/pdf/" + `${productId}`, pdf);
        const baseUrl = process.cwd() + '/uploads/products/pdf/' + `${productId}`
        fs.mkdirSync(baseUrl, { recursive: true })
        fs.rename(currentPath, destinationPath, function (err) {
          if (err) {
            throw err
          } else {
            console.log("Successfully moved the pdf files !")
          }
        });
      }

      if (req.files.meta_img) {
        
        const currentPath = path.join(process.cwd(), "uploads", req.files.meta_img[0]["filename"]);
        const destinationPath = path.join(process.cwd(), "/uploads/products/meta_img/" + `${productId}`, meta_img);
        const baseUrl = process.cwd() + '/uploads/products/meta_img/' + `${productId}`
        fs.mkdirSync(baseUrl, { recursive: true })
        fs.rename(currentPath, destinationPath, function (err) {
          if (err) {
            throw err
          } else {
            console.log("Successfully moved the meta images !")
          }
        });
      }

      if (req.files.photos) {
        
        const currentPath = path.join(process.cwd(), "uploads", req.files.photos[0]["filename"]);
        const destinationPath = path.join(process.cwd(), "/uploads/products/photos/" + `${productId}`, photos);
        const baseUrl = process.cwd() + '/uploads/products/photos/' + `${productId}`
        fs.mkdirSync(baseUrl, { recursive: true })
        fs.rename(currentPath, destinationPath, function (err) {
          if (err) {
            throw err
          } else {
            console.log("Successfully moved the meta images !")
          }
        });
      }

      if (req.files.thumbnail_img) {
        
        const currentPath = path.join(process.cwd(), "uploads", req.files.thumbnail_img[0]["filename"]);
        const destinationPath = path.join(process.cwd(), "/uploads/products/thumbnail_img/" + `${productId}`, thumbnail_img);
        const baseUrl = process.cwd() + '/uploads/products/thumbnail_img/' + `${productId}`
        fs.mkdirSync(baseUrl, { recursive: true })
        fs.rename(currentPath, destinationPath, function (err) {
          if (err) {
            throw err
          } else {
            console.log("Successfully moved the meta images !")
          }
        });
      }

      // const productstock = new ProductStock({
      //   product_id :  productId || null,
      //   variant :  req.body.variant || null,
      //   sku :  req.body.sku || null,
      //   price :  req.body.price || null,
      //   qty :  req.body.qty || null,
      //   image :  req.body.image || null,
      // });

      // const productTaxes = new ProductTaxes({
      //   id : req.body.id,
      //   product_id : productId,
      //   tax_id : req.body.tax_id,
      //   tax : req.body.tax,
      //   tax_type : req.body.tax_type,
      // });

      // const productTranslation = new ProductTranslation({
      //   product_id : productId || null ,
      //   name : req.body.name || null ,
      //   unit : req.body.unit || null ,
      //   description : req.body.description || null ,
      //   lang : req.body.lang || null ,
      // });

      // ProductStock.putProductStock (req.params.id, productstock, (err, data) => {
      //   if (err) {
      //     if (err.kind === "not_found") {
      //       res.status(401).send({
      //         message: `Not found Product Stock with id ${req.params.id}.`
      //       });
      //     }
      //   }
      // });

      // ProductTaxes.putProductTaxes (req.params.id, productTaxes, (err, data) => {
      //   if (err) {
      //     if (err.kind === "not_found") {
      //       res.status(401).send({
      //         message: `Not found Product Stock with id ${req.params.id}.`
      //       });
      //     }
      //   }
      // });

      // ProductTranslation.putProductTranslation (productId , productTranslation, (err, data) => {
      //   if (err) {
      //     if (err.kind === "not_found") {
      //       res.status(401).send({
      //         message: `Not found with product id ${productId}.`
      //       });
      //     }
      //   }
      // })
      res.status(200).send({
        status:(200),
        message:"Success",
        Data:data
      })
    }
});
};

exports.getDigitalProductID = (req, res) => {
  DigitalProduct.getDigitalProductID(req.params.id, (err, data) => {
  if (err)
    res.status(401).send({
      message:
        err.message || "Some error occurred while retrieving data."
    });
  else 
  res.status(200).send({
    status:(200),
    message:"Success",
    Data:data
  })
});
};

exports.deleteDigitalProduct = (req, res) => {
  DigitalProduct.deleteDigitalProduct( req.params.id, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(401).send({
          message: `Not found digital product with id ${req.params.id}.`
        });
      }
    }
    else {
      res.status(200).send({
        status:(200),
        message:"Success",
        Data:data
      })
    }
});
};


// Reviews 
exports.getReviewsProducts = (req, res) => {
  Reviews.getReviewsProducts(req.query, (err, data) => {
    if (err)
      res.status(401).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
    else 
    res.status(200).send({
      status:(200),
      message:"Success",
      Data:data
    })
  });
};

exports.UpdateReviewStatus = (req, res) => {
  Reviews.UpdateReviewStatus(req.params.id, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found customer with id ${req.params.id}.`
        });
      }
    }
  else 
  {
    res.status(200).send({
      status:(200),
      message:"Success",
      Data:data
    })
  }
});
};