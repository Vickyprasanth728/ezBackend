const Color = require("../models/color.model.js");
const path = require("path");
const fs = require("fs");

exports.getColors = (req, res) => {
    Color.getColors((err, data) => {
      if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
      else res.send(data);
    });
  };

  exports.saveColor = (req, res) => {
  
    const colors = new Color({
      id: req.body.id,
      name: req.body.name,
      code: req.body.code,
    });
  
    Color.saveColor( colors, (err, data) => {
      if (err) {
        console.log(err)
        res.status(500).send({
          message:
            err.message || "Some error occurred while posting colors  ."
        });
      }
      else {
        console.log("Posted Successfully");
        res.status(200).send({
          message: "Posted Successfully",
          output: data
        })
      }
    });
  };


  exports.putColor = (req, res) => {

    const colors = new Color({
         name : req.body.name || null,
         code : req.body.code || null,
    });
  
    Color.putColor (req.params.id, colors, (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(404).send({
            message: `Not found colors with id ${req.params.id}.`
          });
        }
      }
      else {
        res.statusCode = 200;
        res.send("Colors updated Succesfully");
      }
  });
  };

  exports.getColorID = (req, res) => {
    Color.getColorID(req.params.id, (err, data) => {
      if (err)
        res.status(500).send({
          message:
            err.message || "Some error occurred while retrieving data."
        });
      else res.send(data);
    });
  };

  exports.deleteColor= (req, res) => {
    Color.deleteColor( req.params.id, (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(404).send({
            message: `Not found colors with id ${req.params.id}.`
          });
        }
      }
      else {
        res.statusCode = 200;
        res.send("Colors deleted Succesfully");
      }
  });
};