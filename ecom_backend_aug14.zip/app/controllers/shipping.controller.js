const ShippingInfo = require("../models/shippingInfo.models.js");
const ShippingCity = require("../models/shippingCities.model.js");
const ShippingState = require("../models/shippingState.model.js");
const ShippingCountries = require("../models/shippingCountries.js");
const ShippingZone = require("../models/shippingZones.model.js");
const ShippingCarriers = require("../models/shipppingCarriers.model.js");
const ShippingCarrierRange = require("../models/shippingCarrierRange.model.js");
const ShippingCarrierRangePrice = require("../models/shippingCarrierRangePrice.model.js");
const CityTranslation = require("../models/citytranslation.model.js");
const path = require("path");
const fs = require("fs");


// Shipping Address
exports.getShippingInfo = (req, res) => {
  ShippingInfo.getShippingInfo((err, data) => {
    if (err)
    res.status(500).send({
      message:
        err.message || "Some error occurred while retrieving data."
    });
    else res.send(data);
  });
};

exports.saveShippingInfo = (req, res) => {

  const shippingInfo = new ShippingInfo({
      id : req.body.id,
      user_id : req.body.user_id,
      address : req.body.address,
      country_id : req.body.country_id,
      state_id : req.body.state_id,
      city_id : req.body.city_id,
      longitude : req.body.longitude,
      latitude : req.body.latitude,
      postal_code : req.body.postal_code,
      phone : req.body.phone,
      set_default : req.body.set_default
 });

  ShippingInfo.saveShippingInfo ( shippingInfo, (err, data) => {
    if (err) {
      console.log(err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while posting Shipping Info  ."
      });
    }
    else {
      console.log("Posted Successfully");
      res.status(200).send({
        message: "Posted Successfully",
        output: data
      })
    }
  });
};

exports.putShippingInfo = (req, res) => {

  const shippingInfo = new ShippingInfo({
      id : req.body.id || null, 
      user_id : req.body.user_id || null, 
      address : req.body.address || null, 
      country_id : req.body.country_id || null, 
      state_id : req.body.state_id || null, 
      city_id : req.body.city_id || null, 
      longitude : req.body.longitude || null, 
      latitude : req.body.latitude || null, 
      postal_code : req.body.postal_code || null, 
      phone : req.body.phone || null, 
      set_default : req.body.set_default || null,
 });

  ShippingInfo.putShippingInfo (req.params.id, shippingInfo, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found shipping Info with id ${req.params.id}.`
        });
      }
    }
    else {
      res.statusCode = 200;
      res.send("Shipping Info updated Succesfully");
    }
});
};

exports.getShippingInfoID = (req, res) => {
  ShippingInfo.getShippingInfoID(req.params.id, (err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
    else res.send(data);
  });
};

exports.deleteShippingInfo = (req, res) => {
  ShippingInfo.deleteShippingInfo ( req.params.id, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found Shipping Info with id ${req.params.id}.`
        });
      }
    }
    else {
      res.statusCode = 200;
      res.send("Shipping Info deleted Succesfully");
    }
});
};

// Shipping State
exports.getStates = (req, res) => {
    ShippingState.getStates ((err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
    else res.send(data);
  });
  };
  
  exports.saveState = (req, res) => {
    
    const shippingstate = new ShippingState ({
      id: req.body.id,
      name: req.body.name,
      country_id: req.body.country_id,
      status: req.body.status,
    });
  
    ShippingState.saveState ( shippingstate , (err, data) => {
      if (err) {
        console.log(err)
        res.status(500).send({
          message:
            err.message || "Some error occurred while posting states  ."
        });
      }
      else {
        console.log("Posted Successfully");
        res.status(200).send({
          message: "Posted Successfully",
          output: data
        })
      }
    });
  };
  
  
  exports.putState = (req, res) => {
  
    const shippingstate = new ShippingState({
      name : req.body.name || null,
      country_id: req.body.country_id  || null,
      status: req.body.status  || null,
    });
  
    ShippingState.putState (req.params.id, shippingstate , (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(404).send({
            message: `Not found shipping state with id ${req.params.id}.`
          });
        }
      }
      else {
        res.statusCode = 200;
        res.send("Shipping State updated Succesfully");
      }
  });
  };
  
  exports.getStateID = (req, res) => {
    ShippingState.getStateID(req.params.id, (err, data) => {
      if (err)
        res.status(500).send({
          message:
            err.message || "Some error occurred while retrieving data."
        });
      else res.send(data);
    });
  };
  
  exports.deleteState = (req, res) => {
    ShippingState.deleteState ( req.params.id, (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(404).send({
            message: `Not found States with id ${req.params.id}.`
          });
        }
      }
      else {
        res.statusCode = 200;
        res.send("States Deleted Succesfully");
      }
  });
  };


  // Shipping City
exports.getCities = (req, res) => {
    ShippingCity.getCities ((err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
    else res.send(data);
  });
  };
  
  exports.saveCity = (req, res) => {
    
    const shippingcity = new ShippingCity ({
      id: req.body.id,
      name: req.body.name,
      state_id: req.body.state_id,
      cost: req.body.cost,
      status: req.body.status,
    });
  
    ShippingCity.saveCity ( shippingcity , (err, data) => {
      if (err) {
        console.log(err)
        res.status(500).send({
          message:
            err.message || "Some error occurred while posting city  ."
        });
      }
      else {

        let cityId = data.insertId

        const cityTranslation = new CityTranslation({
          city_id : cityId || null ,
          name : req.body.name || null ,
          lang : req.body.lang || null ,
        });

        CityTranslation.saveCityTranslation( cityTranslation, (err, data) => {
          if (err) {
            console.log(err)
            console.log("Brand Translation posted");
            console.log("Posted Successfully");
            res.statusCode = 200;
          }
        });
        
        console.log("Posted Successfully");
        res.status(200).send({
          message: "Posted Successfully",
          output: data
        })
      }
    });
  };
  
  exports.putCity = (req, res) => {
  
    const shippingcity = new ShippingCity({
      name : req.body.name || null,
      state_id: req.body.state_id || null,
      cost: req.body.cost || null,
      status: req.body.status || null,
    });
  
    let cityId = req.params.id

    ShippingCity.putCity (req.params.id, shippingcity , (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(404).send({
            message: `Not found shipping city with id ${req.params.id}.`
          });
        }
      }
      else {

        const cityTranslation = new CityTranslation({
          city_id : cityId || null ,
          name : req.body.name || null ,
          lang : req.body.lang || null ,
        });

        CityTranslation.putCityTranslation (cityId , cityTranslation, (err, data) => {
          if (err) {
            if (err.kind === "not_found") {
              res.status(404).send({
                message: `Not found with city Id ${cityId}.`
              });
            }
          }
        })

        res.statusCode = 200;
        res.send("Shipping City updated Succesfully");
      }
  });
  };
  
  exports.getCityID = (req, res) => {
    ShippingCity.getCityID(req.params.id, (err, data) => {
      if (err)
        res.status(500).send({
          message:
            err.message || "Some error occurred while retrieving data."
        });
      else res.send(data);
    });
  };
  
  exports.deleteCity = (req, res) => {
    ShippingCity.deleteCity ( req.params.id, (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(404).send({
            message: `Not found city with id ${req.params.id}.`
          });
        }
      }
      else {
        res.statusCode = 200;
        res.send("City Deleted Succesfully");
      }
  });
  };


// Shipping Countries
exports.getCountries = (req, res) => {
  ShippingCountries.getCountries ((err, data) => {
  if (err)
    res.status(500).send({
      message:
        err.message || "Some error occurred while retrieving data."
    });
  else res.send(data);
});
};

exports.getCountryID = (req, res) => {
  ShippingCountries.getCountryID(req.params.id, (err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
    else res.send(data);
  });
};


// Shipping Zones
exports.getZones = (req, res) => {
  ShippingZone.getZones ((err, data) => {
  if (err)
    res.status(500).send({
      message:
        err.message || "Some error occurred while retrieving data."
    });
  else res.send(data);
});
};

exports.saveZone = (req, res) => {
  
  const shippingzones = new ShippingZone ({
    id: req.body.id,
    name: req.body.name,
    status: req.body.status,
  });

  ShippingZone.saveZone ( shippingzones , (err, data) => {
    if (err) {
      console.log(err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while posting zone  ."
      });
    }
    else {
      console.log("Posted Successfully");
      res.status(200).send({
        message: "Posted Successfully",
        output: data
      })
    }
  });
};

exports.putZone = (req, res) => {

  const shippingzones = new ShippingZone({
    name : req.body.name || null,
    status: req.body.status  || null,
  });

  ShippingZone.putZone (req.params.id, shippingzones , (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found shipping zone with id ${req.params.id}.`
        });
      }
    }
    else {
      res.statusCode = 200;
      res.send("Shipping Zone updated Succesfully");
    }
});
};

exports.getZoneID = (req, res) => {
  ShippingZone.getZoneID(req.params.id, (err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
    else res.send(data);
  });
};

exports.deleteZone = (req, res) => {
  ShippingZone.deleteZone ( req.params.id, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found zone with id ${req.params.id}.`
        });
      }
    }
    else {
      res.statusCode = 200;
      res.send("Zone Deleted Succesfully");
    }
});
};


// Shipping Carriers
exports.getCarriers = (req, res) => {
  ShippingCarriers.getCarriers ((err, data) => {
  if (err)
    res.status(500).send({
      message:
        err.message || "Some error occurred while retrieving data."
    });
  else res.send(data);
});
};

exports.saveCarrier = (req, res) => {
  
  const shippingcarriers = new ShippingCarriers ({
    id: req.body.id,
    name: req.body.name,
    logo : req.body.logo,
    transit_time : req.body.transit_time,
    free_shipping : req.body.free_shipping,
    status: req.body.status,
  });

  ShippingCarriers.saveCarrier ( shippingcarriers , (err, data) => {
    if (err) {
      console.log(err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while posting carrier  ."
      });
    }
    else {

      let carrierId = data.insertId
        
      const carrierranges = new ShippingCarrierRange({
        id : req.body.id,
        carrier_id : carrierId ,
        billing_type : req.body.billing_type,
        delimiter1 : req.body.delimiter1,
        delimiter2 : req.body.delimiter2,
      });

      ShippingCarrierRange.saveCarrierRange(carrierranges, (err, data) => {
        if (err) {
          console.log(err)
          console.log("carrier range posted");
          console.log("Posted Successfully");
          res.statusCode = 200;
        }

      let carrierRangeId = data.insertId

      const carrierrangeprice = new ShippingCarrierRangePrice({
        carrier_id : carrierId ,
        carrier_range_id : carrierRangeId ,
        zone_id : req.body.zone_id,
        price : req.body.price,
      });

    
      ShippingCarrierRangePrice.saveCarrierRangePrice(carrierrangeprice, (err, data) => {
          if (err) {
            console.log(err)
            console.log("carrier range price posted");
            console.log("Posted Successfully");
            res.statusCode = 200;
          }
        });
      });

      console.log("Posted Successfully");
      res.status(200).send({
        message: "Posted Successfully",
        output: data
      })
    }
  });
};

exports.putCarrier = (req, res) => {

  const shippingcarriers = new ShippingCarriers({
    name : req.body.name || null,
    logo : req.body.logo || null,
    transit_time : req.body.transit_time || null,
    free_shipping : req.body.free_shipping || null,
    status: req.body.status  || null,
  });

  let carrierId = req.params.id

  ShippingCarriers.putCarrier (req.params.id, shippingcarriers , (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found shipping carrier with id ${req.params.id}.`
        });
      }
    }
    else {

      const carrierranges = new ShippingCarrierRange({
        id :req.body.id,
        carrier_id : carrierId ,
        billing_type : req.body.billing_type || null,
        delimiter1 : req.body.delimiter1 || null,
        delimiter2 : req.body.delimiter2 || null,
      });

      let carrierRangeId = req.params.id

      ShippingCarrierRange.putCarrierRange (req.params.id , carrierranges , (err, data) => {
        if (err) {
          if (err.kind === "not_found") {
            res.status(404).send({
              message: `Not found carrier range with id ${req.params.id}.`
            });
          }
        }
      })

      const carrierrangeprice = new ShippingCarrierRangePrice({
        carrier_id : carrierId ,
        carrier_range_id : carrierRangeId,
        zone_id : req.body.zone_id,
        price : req.body.price,
      });

      ShippingCarrierRangePrice.putCarrierRangePrice (req.params.id , carrierrangeprice , (err, data) => {
        if (err) {
          if (err.kind === "not_found") {
            res.status(404).send({
              message: `Not found carrier range price with id ${req.params.id}.`
            });
          }
        }
      })

      res.statusCode = 200;
      res.send("Shipping carrier updated Succesfully");
    }
});
};

exports.getCarrierID = (req, res) => {
  ShippingCarriers.getCarrierID(req.params.id, (err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
    else res.send(data);
  });
};

exports.deleteCarrier = (req, res) => {
  ShippingCarriers.deleteCarrier ( req.params.id, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found carrier with id ${req.params.id}.`
        });
      }
    }
    else {
      res.statusCode = 200;
      res.send("Carrier Deleted Succesfully");
    }
});
};