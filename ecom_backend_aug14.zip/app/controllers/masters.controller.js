const Master = require("../models/master.models.js");

//Delivery status 
exports.getDeliveryStatus = (req, res) => {
  Master.getDeliveryStatus((err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving tutorials."
      });
    else 
    res.status(200).send({
      status:(200),
      message:"Success",
      Data:data
    })
  });
};
exports.putDeliveryStatus = (req, res) => {
  const Masters = new Master({
    id: req.params.id,
    user_id: req.body.user_id,
    name: req.body.name
  });
  Master.putDeliveryStatus(Masters, (err, data) => {
    if (err) {
      console.log(err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while updating delivery status."
      });
    }
    else {
      // console.log(req.files)
      res.status(200).send({
        status:(200),
        message:"Success",
        Data: Masters
      })
    }
  });
};
exports.saveDeliveryStatus = (req, res) => {
  const Masters = new Master({
    user_id: req.body.user_id,
    name: req.body.name
  });
  Master.saveDeliveryStatus(Masters, (err, data) => {
    if (err) {
      console.log(err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while posting delivery status."
      });
    }
    else {
      console.log("Posted Successfully");
      res.status(200).send({
        message: "Posted Successfully",
        output: Masters
      })
    }
  });
};
exports.deleteDeliveryStatus = (req, res) => {
  const Masters = new Master({
    id: req.params.id,
  });
  Master.deleteDeliveryStatus(Masters, (err, data) => {
    if (err) {
      console.log(err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while deleting delivery status."
      });
    }
    else {
      // console.log(req.files)
      res.status(200).send({
        status:(200),
        message:"Success",
      })
    }
  });
};



//Payment status 
exports.getPaymentStatus = (req, res) => {
  Master.getPaymentStatus((err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving tutorials."
      });
    else   
    res.status(200).send({
      status:(200),
      message:"Success",
      Data:data
    })
  });
};
exports.putPaymentStatus = (req, res) => {
  const Masters = new Master({
    id: req.params.id,
    user_id: req.body.user_id,
    name: req.body.name
  });
  Master.putPaymentStatus(Masters, (err, data) => {
    if (err) {
      console.log(err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while updating payment status."
      });
    }
    else {
      // console.log(req.files)
      res.status(200).send({
        status:(200),
        message:"Success",
        Data:Masters
      })
    }
  });
};
exports.savePaymentStatus = (req, res) => {
  const Masters = new Master({
    user_id: req.body.user_id,
    name: req.body.name
  });
  Master.savePaymentStatus(Masters, (err, data) => {
    if (err) {
      console.log(err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while posting payment status."
      });
    }
    else {
      // console.log(req.files)
      console.log("Posted Successfully");
      res.status(200).send({
        message: "Posted Successfully",
        output: Masters
      })
    }
  });
};
exports.deletePaymentStatus = (req, res) => {
  const Masters = new Master({
    id: req.params.id,
  });
  Master.deletePaymentStatus(Masters, (err, data) => {
    if (err) {
      console.log(err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while deleting payment status."
      });
    }
    else {
      // console.log(req.files)
      res.status(200).send({
        status:(200),
        message:"Success",
      })
    }
  });
};



// Shipping Type  
exports.getShippingType = (req, res) => {
  Master.getShippingType((err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving tutorials."
      });
    else 
    res.status(200).send({
      status:(200),
      message:"Success",
      Data:data
    })
  });
};
exports.putShippingType = (req, res) => {
  const Masters = new Master({
    id: req.params.id,
    user_id: req.body.user_id,
    name: req.body.name
  });
  Master.putShippingType(Masters, (err, data) => {
    if (err) {
      console.log(err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while updating shipping type."
      });
    }
    else {
      // console.log(req.files)
      res.status(200).send({
        status:(200),
        message:"Success",
        Data: Masters
      })
    }
  });
};
exports.saveShippingType = (req, res) => {
  const Masters = new Master({
    user_id: req.body.user_id,
    name: req.body.name
  });
  Master.saveShippingType(Masters, (err, data) => {
    if (err) {
      console.log(err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while posting shipping type."
      });
    }
    else {
      // console.log(req.files)
      console.log("Posted Successfully");
      res.status(200).send({
        message: "Posted Successfully",
        output: Masters
      })
    }
  });
};
exports.deleteShippingType = (req, res) => {
  const Masters = new Master({
    id: req.params.id,
  });
  Master.deleteShippingType(Masters, (err, data) => {
    if (err) {
      console.log(err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while deleting shipping type."
      });
    }
    else {
      // console.log(req.files)
      res.status(200).send({
        status:(200),
        message:"Success",
        Data: Masters
      })
    }
  });
};
