const Translation = require("../models/translation.model.js");
const { Validator } = require('node-input-validator');

exports.getTranslation = (req, res) => {
    Translation.getTranslation((err, data) => {
    if (err)
      res.status(401).send({
        message: "Some error occurred while retrieving data."
      });
    else 
    res.status(200).send({
      status:(200),
      message:"Success",
      Data:data
    })
  });
};

exports.saveTranslation = (async (req, res) => {

  const validate = new Validator(req.body, {
    lang: 'required|minLength:2|maxLength:5',
    lang_key: 'required|minLength:1|maxLength:50',
    lang_value: 'required|minLength:1|maxLength:50',
  });

  validate.check().then(async (matched) => {
    if (!matched) {
      // res.status(422).send(validate.errors);
      res.status(422).send({
        status: (422),
        message: "Errors",
        errors: (validate.errors)
      })
    }

    else {
      const translation = new Translation({
        id: req.body.id,
        lang: req.body.lang,
        lang_key: req.body.lang_key,
        lang_value: req.body.lang_value,
      });

      Translation.saveTranslation(translation, (err, data) => {
        if (err) {
          console.log(err)
          res.status(401).send({
            message:
              err.message || "Some error occurred while posting translation  ."
          });
        }
        else {
          console.log("Posted Successfully");
          res.status(200).send({
            message: "Posted Successfully",
            output: data
          })
        }
      });
    }
  })
});

exports.putTranslation = (async (req, res) => {

  const validate = new Validator(req.body, {
    lang: 'required|minLength:2|maxLength:5',
    lang_key: 'required|minLength:1|maxLength:50',
    lang_value: 'required|minLength:1|maxLength:50',
  });

  validate.check().then(async (matched) => {
    if (!matched) {
      // res.status(422).send(validate.errors);
      res.status(422).send({
        status: (422),
        message: "Errors",
        errors: (validate.errors)
      })
    }

    else {
      const translation = new Translation({
        id: req.body.id || null,
        lang: req.body.lang || null,
        lang_key: req.body.lang_key || null,
        lang_value: req.body.lang_value || null,
      });

      Translation.putTranslation(req.params.id, translation, (err, data) => {
        if (err) {
          if (err.kind === "not_found") {
            res.status(401).send({
              message: `Not found translation with id ${req.params.id}.`
            });
          }
        }
        else {
          res.status(200).send({
            status: (200),
            message: "Updated Succesfully",
          })
        }
      });
    }
  })
});

exports.getTranslationID = (req, res) => {
Translation.getTranslationID(req.params.id, (err, data) => {
  if (err) {
    if (err.kind === "not_found") {
      res.status(401).send({
        status:(401),
        message: `Not found translation with id ${req.params.id}.`
      });
    }
  }
  else {
    res.status(200).send({
      status:(200),
      message:"Success",
      data:data
    })
  }
});
};

exports.deleteTranslation = (req, res) => {
  Translation.deleteTranslation( req.params.id, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(401).send({
          message: `Not found translation with id ${req.params.id}.`
        });
      }
    }
    else {
      res.status(200).send({
        status:(200),
        message:"Deleted Succesfully",
        Data:data
      })
    }
});
};