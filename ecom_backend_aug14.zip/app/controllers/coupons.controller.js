const Coupons = require("../models/coupons.models");
const CouponUsage = require("../models/couponUsage.model.js");
const moment = require('moment');
const dayjs = require('dayjs');
const path = require("path");
const fs = require("fs");

exports.getCoupons = (req, res) => {
    Coupons.getCoupons((err, data) => {
      if (err)
      res.status(401).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
      else
      res.status(200).send({
        status:(200),
        message:"Success",
        Data:data
      })
    });
  };

  exports.saveCoupons = (req, res) => {
    
    const d1 = new Date(req.body.start_date);
    console.log(d1);
    const startDate = d1.getTime();
    console.log(startDate);

    const d2 = new Date(req.body.end_date);
    console.log(d2);
    const startEnd = d2.getTime();
    console.log(startEnd);

    const coupons = new Coupons({
      id : req.body.id,
      user_id : req.body.user_id || null,
      type : req.body.type || null,
      code : req.body.code || null,
      details : req.body.details,
      discount : req.body.discount || null,
      discount_type : req.body.discount_type || null,
      start_date : req.body.start_date || null,
      end_date : req.body.end_date || null,
    });
  
    Coupons.saveCoupons( coupons, (err, data) => {
      if (err) {
        console.log(err)
        res.status(401).send({
          message:
            err.message || "Some error occurred while posting Coupons ."
        });
      }
      else {

        let couponId = data.insertId
        let userId = req.body.user_id

        const couponUsage = new CouponUsage({
          user_id : userId,
          coupon_id : couponId,
        });
  
        CouponUsage.saveCouponUsage(couponUsage, (err, data) => {
          if (err) {
            console.log(err)
            console.log("Coupon Usage posted successfully");
            console.log("Posted Successfully");
            res.statusCode = 200;
          }
        });

        console.log("Posted Successfully");
        res.status(200).send({
          message: "Posted Successfully",
          output: coupons
        })
      }
    });
  };

  exports.putCoupons = (req, res) => {

    const d1 = new Date(req.body.start_date);
    console.log(d1);
    const startDate = d1.getTime();
    console.log(startDate);

    const d2 = new Date(req.body.end_date);
    console.log(d2);
    const startEnd = d2.getTime();
    console.log(startEnd);

    const coupons = new Coupons({
      id: req.body.id || null ,
      user_id : req.body.user_id,
      type : req.body.type,
      code : req.body.code,
      details : req.body.details,
      discount : req.body.discount,
      discount_type : req.body.discount_type,
      start_date : startDate,
      end_date : startEnd,
    });
  
    let couponId = req.params.id
    let userId = req.body.user_id

    Coupons.putCoupons (req.params.id, coupons, (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(401).send({
            message: `Not found coupons with id ${req.params.id}.`
          });
        }
      }
      else {

        const couponUsage = new CouponUsage({
          user_id : userId || null,
          coupon_id : couponId || null,
        });

        CouponUsage.putCouponUsage (couponId , couponUsage, (err, data) => {
          if (err) {
            if (err.kind === "not_found") {
              res.status(401).send({
                message: `Not found with coupon id ${couponId}.`
              });
            }
          }
        })
        res.status(200).send({
          status:(200),
          message:"Success",
          Data: coupons
        })
      }
  });
  };
  

  exports.getCouponsID = (req, res) => {
    Coupons.getCouponsID(req.params.id, (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(401).send({
            status:(401),
            message: `Not found coupon with id ${req.params.id}.`
          });
        }
      }
      else {
        res.status(200).send({
          status:(200),
          message:"Success",
          Data:data
        })
      }
  });
  };

  exports.deleteCoupons = (req, res) => {
    Coupons.deleteCoupons( req.params.id, (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(401).send({
            message: `Not found couponId with id ${req.params.id}.`
          });
        }
      }
      else {
        res.status(200).send({
          status:(200),
          message:"Success",
        })
      }
  });
};