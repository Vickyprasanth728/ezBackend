const User = require("../models/user.model.js");
const fs = require("fs")
const path = require("path");
const util = require('util');
const sql = require("../models/db");
const dayjs = require('dayjs');
var md5 = require('md5');


function keyGen(keyLength) {
  var i, key = "", characters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

  var charactersLength = characters.length;

  for (i = 0; i < keyLength; i++) {
    key += characters.substr(Math.floor((Math.random() * charactersLength) + 1), 1);
  }

  return key;
}

exports.getUsers = (req, res) => {
    User.getUsers((err, data) => {
      if (err)
        res.status(500).send({
          message:
            err.message || "Some error occurred while retrieving data."
        });
      else 
      res.status(200).send({
        status:(200),
        message:"Success",
        Data:data
      })
    });
  };

  exports.saveUser = (async(req, res) => {

    const email_verify_time = req.body.email_verified_at
    let emailVerifyTime = ""
    if (email_verify_time) {
      let start = dayjs(req.body.email_verified_at);
      emailVerifyTime = start.format("YYYY-MM-DD h:mm:ss")
    } else {
      emailVerifyTime = ""
    }

    if (!req.body) {
      res.status(400).send({
        message: "User Cannot be Empty"
      });
    }
  
    const query1 = util.promisify(sql.query).bind(sql);
    const executivesFetch = await query1(`select email from users where email='${req.body.email}' limit 1`);
    const executives = executivesFetch[0] ? executivesFetch[0]["exec"] : 0
    
    if(executives != 0){
      res.send("Email already exists");
    }
    else {

      let avatar = "";

      if (req.files.avatar) {
        const extension = req.files.avatar[0]["mimetype"].split('/')[1]
        avatar = req.files.avatar[0]["filename"] + '.' + extension
        avatar_original = req.files.avatar[0]["originalname"]
      }

    const hashedPassword = md5(req.body.password);

    const users = new User({
      id: req.body.id || null,
      referred_by : req.body.referred_by || null,
      provider_id : req.body.provider_id || null,
      user_type : 'admin' || null,
      name : req.body.name || null,
      email : req.body.email  || null,
      email_verified_at : emailVerifyTime || null,
      verification_code : req.body.verification_code || null,
      new_email_verificiation_code : req.body.new_email_verificiation_code || null,
      password : hashedPassword || null,
      remember_token : keyGen(30) ,
      device_token : req.body.device_token || null,
      avatar : avatar || null,
      avatar_original : req.body.avatar_original || null,
      address : req.body.address || null,
      country : req.body.country || null,
      state	 : req.body.state || null,
      city : req.body.city || null,
      postal_code : req.body.postal_code || null,
      phone : req.body.phone || null,
      balance : "0"|| null,
      banned : "0" || null,
      referral_code : req.body.referral_code || null,
      customer_package_id : req.body.customer_package_id || null,
      remaining_uploads : req.body.remaining_uploads || null,
    });
  
    User.saveUser( users, (err, data) => {
      if (err) {
        console.log(err)
        res.status(500).send({
          message:
            err.message || "Some error occurred while posting users  ."
        });
      }
      else {

        let userId = data.insertId

        if (req.files.avatar) {
          
          const currentPath = path.join(process.cwd(), "uploads", req.files.avatar[0]["filename"]);
          const destinationPath = path.join(process.cwd(), "/uploads/users/avatar/" + `${userId}`, avatar);
          const baseUrl = process.cwd() + '/uploads/users/avatar/' + `${userId}`
          fs.mkdirSync(baseUrl, { recursive: true })
          fs.rename(currentPath, destinationPath, function (err) {
            if (err) {
              throw err
            } else {
              console.log("Successfully moved the avatar users files !")
            }
          });
        }

        console.log("Posted Successfully");
        res.status(200).send({
          message: "Posted Successfully",
          output: users
        })
      }
    });
  }
  });

  exports.putUser = (async(req, res) => {

    const email_verify_time = req.body.email_verified_at
    let emailVerifyTime = ""
    if (email_verify_time) {
      let start = dayjs(req.body.email_verified_at);
      emailVerifyTime = start.format("YYYY-MM-DD")
    } else {
      emailVerifyTime = " "
    }

    if (!req.body) {
      res.status(400).send({
        message: "User Cannot be Empty"
      });
    }
  
    // const query1 = util.promisify(sql.query).bind(sql);
    // const executivesFetch = await query1(`select email from users where email='${req.body.email}' limit 1`);
    // const executives = executivesFetch[0] ? executivesFetch[0]["exec"] : 0
    
    // if(executives != 0){
    //   res.send("Email already exists");
    // }
    // else {
    let avatar = "";

    if (req.files.avatar) {
      const extension = req.files.avatar[0]["mimetype"].split('/')[1]
      avatar = req.files.avatar[0]["filename"] + '.' + extension
      avatar_original = req.files.avatar[0]["originalname"]
    }

    const hashedPassword = md5(req.body.password);

    const users = new User({
      id: req.body.id,
      referred_by : req.body.referred_by,
      provider_id : req.body.provider_id,
      user_type : req.body.user_type,
      name : req.body.name,
      email : req.body.email ,
      email_verified_at : req.body.emailVerifyTime,
      verification_code : req.body.verification_code,
      new_email_verificiation_code : req.body.new_email_verificiation_code,
      password : hashedPassword,
      remember_token :  keyGen(30),
      device_token : req.body.device_token,
      avatar : avatar,
      avatar_original : req.body.avatar_original,
      address : req.body.address,
      country : req.body.country,
      state	 : req.body.state,
      city : req.body.city,
      postal_code : req.body.postal_code,
      phone : req.body.phone,
      balance : req.body.balance,
      banned : req.body.banned,
      referral_code : req.body.referral_code,
      customer_package_id : req.body.customer_package_id,
      remaining_uploads : req.body.remaining_uploads,
    });
  
    let userId = req.params.id

    User.putUser (req.params.id, users, (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(404).send({
            message: `Not found user with id ${req.params.id}.`
          });
        }
      }
      else {

        if (req.files.avatar) {
          
          const currentPath = path.join(process.cwd(), "uploads", req.files.avatar[0]["filename"]);
          const destinationPath = path.join(process.cwd(), "/uploads/users/avatar/" + `${userId}`, avatar);
          const baseUrl = process.cwd() + '/uploads/users/avatar/' + `${userId}`
          fs.mkdirSync(baseUrl, { recursive: true })
          fs.rename(currentPath, destinationPath, function (err) {
            if (err) {
              throw err
            } else {
              console.log("Successfully moved the avatar users files !")
            }
          });
        }

        res.status(200).send({
          status:(200),
          message:"Success",
          Data: users
        })
      }
  });
 }
// }
);

  exports.getUserID = (req, res) => {
    User.getUserID(req.params.id, (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(401).send({
            status:(401),
            message: `Not found user with id ${req.params.id}.`
          });
        }
      }
      else {
        res.status(200).send({
          status:(200),
          message:"Success",
          Data:data
        })
      }
  });
};

exports.deleteUser= (req, res) => {
    User.deleteUser( req.params.id, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found user with id ${req.params.id}.`
        });
      }
    }
    else {
      res.statusCode = 200;
      res.send("User deleted Succesfully");
    }
});
};