const TicketSupports = require("../models/supportTickets.model.js");
const TicketReply = require("../models/supportTicketReply.models.js");
const ConversationSupports = require("../models/supportConversation.model.js");
const MessageConversation = require("../models/supportMessages.models.js");
const path = require("path");
const fs = require("fs");

// Tickets List
exports.getTicketsList = (req, res) => {
  TicketSupports.getTicketsList((err, data) => {
      if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
      else res.send(data);
    });
  };

  exports.getTicketID = (req, res) => {
    TicketSupports.getTicketID(req.params.id, (err, data) => {
      if (err)
        res.status(500).send({
          message:
            err.message || "Some error occurred while retrieving data."
        });
      else res.send(data);
    });
  };

// Ticket Reply
exports.getTicketReply = (req, res) => {
  TicketReply.getTicketReply(req.params.ticket_id, (err, data) => {
      if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
      else res.send(data);
    });
  };

  // Ticket Reply
  exports.saveTicketReply = (req, res) => {

    let files = "";

    if (req.files.files) {
      const extension = req.files.files[0]["mimetype"].split('/')[1]
      files = req.files.files[0]["filename"] + '.' + extension
      files = req.files.files[0]["originalname"]
    }
    const tickets = new TicketReply({
      id: req.body.id ,
      ticket_id: req.body.ticket_id || null,
      user_id: req.body.user_id || null,
      reply: req.body.reply || null,
      files: files || null,
    });
  
    TicketReply.saveTicketReply ( tickets, (err, data) => {
      if (err) {
        console.log(err)
        res.status(500).send({
          message:
            err.message || "Some error occurred while posting tickets  ."
        });
      }
      else {

        let ticketId = data.insertId
        if (req.files.files) {

          const currentPath = path.join(process.cwd(), "uploads", req.files.files[0]["filename"]);
          const destinationPath = path.join(process.cwd(), "/uploads/tickets/files/" + `${ticketId}`, files);
          const baseUrl = process.cwd() + '/uploads/tickets/files/' + `${ticketId}`
          fs.mkdirSync(baseUrl, { recursive: true })
          fs.rename(currentPath, destinationPath, function (err) {
            if (err) {
              throw err
            } else {
              console.log("Successfully moved the files images !")
            }
          });
        }
        console.log("Posted Successfully");
        res.status(200).send({
          message: "Posted Successfully",
          output: data
        })
      }
    });
  };

// Ticket View
exports.UpdateTicketView = (req, res) => {
  TicketSupports.UpdateTicketView(req.params.keyword, req.params.id,  (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found ticket View with id ${req.params.id}.`
        });
      }
    }
  else 
  {
    res.statusCode = 200;
    res.send("Viewed Ticket Succesfully");
  }
});
};

// Conversation List
exports.getConversationList = (req, res) => {
  ConversationSupports.getConversationList((err, data) => {
      if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
      else res.send(data);
    });
  };

exports.getConversationID = (req, res) => {
  ConversationSupports.getConversationID(req.params.id, (err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
    else res.send(data);
  });
};

// Message Conversations
exports.getMessageReplyList = (req, res) => {
  MessageConversation.getMessageReplyList(req.params.conversation_id, (err, data) => {
      if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
      else res.send(data);
    });
  };

  exports.saveMessageReply = (req, res) => {

    const messages = new MessageConversation({
      id : req.body.id  || null,
      conversation_id : req.body.conversation_id || null,
      user_id : req.body.user_id || null,
      message : req.body.message || null
    });
  
    MessageConversation.saveMessageReply( messages, (err, data) => {
      if (err) {
        console.log(err) 
        res.status(500).send({
          message:
            err.message || "Some error occurred while posting user ."
        });
      }
      else {
          console.log("Posted Successfully");
          res.status(200).send({
          message: "Posted Successfully",
          output: data
        })
      }
    });
  };