const AllStaff = require("../models/allStaff.model.js");
const RolePermission = require("../models/rolePermission.model.js");
const RoleTranslation = require("../models/roleTranslation.model.js");
const Roles = require("../models/roles.model.js");
const User = require("../models/user.model");
var md5 = require('md5');

function keyGen(keyLength) {
  var i, key = "", characters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

  var charactersLength = characters.length;

  for (i = 0; i < keyLength; i++) {
    key += characters.substr(Math.floor((Math.random() * charactersLength) + 1), 1);
  }

  return key;
}

// Staff
exports.getStaff = (req, res) => {
    AllStaff.getStaff((err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
    else res.send(data);
  });
};

exports.saveStaff = (req, res) => {


  const hashedPassword = md5(req.body.password);

    const users = new User({
      referred_by : req.body.referred_by || null,
      provider_id : req.body.provider_id || null,
      user_type : "staff" || null,
      name : req.body.name || null,
      email : req.body.email  || null,
      email_verified_at : req.body.email_verified_at || null,
      verification_code : req.body.verification_code || null,
      new_email_verificiation_code : req.body.new_email_verificiation_code || null,
      password : hashedPassword || null,
      remember_token : keyGen(30),
      device_token : req.body.device_token || null,
      avatar : req.body.avatar || null,
      avatar_original : req.body.avatar_original || null,
      address : req.body.address || null,
      country : req.body.country || null,
      state : req.body.state || null,
      city : req.body.city || null,
      postal_code : req.body.postal_code || null,
      phone : req.body.phone || null,
      balance : req.body.balance || "0",
      banned : req.body.banned || "0",
      referral_code : req.body.referral_code || null,
      customer_package_id : req.body.customer_package_id || null,
      remaining_uploads : req.body.remaining_uploads || null,
    });
  
    User.saveUser( users, (err, data) => {
      if (err) {
        console.log(err) 
        res.status(500).send({
          message:
            err.message || "Some error occurred while posting user ."
        });
      }
      else {

        let userId = data.insertId

        const allStaff = new AllStaff({
          user_id: userId,
          role_id: req.body.role_id,
        });

        AllStaff.saveStaff(allStaff, (err, data) => {
          if (err) {
            console.log(err)
            console.log("user posted");
            console.log("Posted Successfully");
            res.statusCode = 200;
          }
        });

        console.log("Posted Successfully");
        res.status(200).send({
          message: "Posted Successfully",
          output: data
        })
      }
    });
  };


  exports.putStaff = (req, res) => {

    const hashedPassword = md5(req.body.password);

    const users = new User({
      referred_by : req.body.referred_by || null,
      provider_id : req.body.provider_id || null,
      user_type : "staff" || null,
      name : req.body.name || null,
      email : req.body.email  || null,
      email_verified_at : req.body.email_verified_at || null,
      verification_code : req.body.verification_code || null,
      new_email_verificiation_code : req.body.new_email_verificiation_code || null,
      password : hashedPassword || null,
      remember_token : req.body.remember_token || null,
      device_token : req.body.device_token || null,
      avatar : req.body.avatar || null,
      avatar_original : req.body.avatar_original || null,
      address : req.body.address || null,
      country : req.body.country || null,
      state : req.body.state || null,
      city : req.body.city || null,
      postal_code : req.body.postal_code || null,
      phone : req.body.phone || null,
      balance : req.body.balance || null,
      banned : req.body.banned || null,
      referral_code : req.body.referral_code || null,
      customer_package_id : req.body.customer_package_id || null,
      remaining_uploads : req.body.remaining_uploads || null,
    });

    let userId = req.params.id

    User.putUser (req.params.id, users, (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(404).send({
            message: `Not found user with id ${req.params.id}.`
          });
        }
      }
      else {

        const allstaff = new AllStaff({
          user_id : userId || null ,
          role_id : req.body.role_id || null ,
        });

        AllStaff.putStaff (userId, allstaff, (err, data) => {
          if (err) {
            if (err.kind === "not_found") {
              res.status(404).send({
                message: `Not found staff with id ${userId}.`
              });
            }
          }
        })
        res.statusCode = 200;
        res.send("Staff updated Succesfully");
      }
  });
  };
  
  exports.putStaff = (req, res) => {

    const users = new User({
      referred_by : req.body.referred_by || null,
      provider_id : req.body.provider_id || null,
      user_type : req.body.user_type || null,
      name : req.body.name || null,
      email : req.body.email  || null,
      email_verified_at : req.body.email_verified_at || null,
      verification_code : req.body.verification_code || null,
      new_email_verificiation_code : req.body.new_email_verificiation_code || null,
      password : req.body.password || null,
      remember_token : req.body.remember_token || null,
      device_token : req.body.device_token || null,
      avatar : req.body.avatar || null,
      avatar_original : req.body.avatar_original || null,
      address : req.body.address || null,
      country : req.body.country || null,
      state : req.body.state || null,
      city : req.body.city || null,
      postal_code : req.body.postal_code || null,
      phone : req.body.phone || null,
      balance : req.body.balance || null,
      banned : req.body.banned || null,
      referral_code : req.body.referral_code || null,
      customer_package_id : req.body.customer_package_id || null,
      remaining_uploads : req.body.remaining_uploads || null,
    });

    let userId = req.params.id

    User.putUser (req.params.id, users, (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(404).send({
            message: `Not found user with id ${req.params.id}.`
          });
        }
      }
      else {

        const allstaff = new AllStaff({
          user_id : userId || null ,
          role_id : req.body.role_id || null ,
        });

        AllStaff.putStaff (userId, allstaff, (err, data) => {
          if (err) {
            if (err.kind === "not_found") {
              res.status(404).send({
                message: `Not found staff with id ${userId}.`
              });
            }
          }
        })
        res.statusCode = 200;
        res.send("Staff updated Succesfully");
      }
  });
  };
  exports.getStaffID = (req, res) => {
    AllStaff.getStaffID(req.params.id, (err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
    else res.send(data);
  });
};

exports.deleteStaff = (req, res) => {
    AllStaff.deleteStaff( req.params.id, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found staff with id ${req.params.id}.`
        });
      }
    }
    else {
      res.statusCode = 200;
      res.send("Staff deleted Succesfully");
    }
});
};
  
// Role Permission
exports.getRolePermission = (req, res) => {
  RolePermission.getRolePermission((err, data) => {
  if (err)
    res.status(500).send({
      message:
        err.message || "Some error occurred while retrieving data."
    });
  else res.send(data);
});
};

exports.saveRolePermission = (req, res) => {
  
  const rolepermission = new RolePermission({
    permission_id: req.body.permission_id,
    role_id: req.body.role_id,
  });

  RolePermission.saveRolePermission( rolepermission, (err, data) => {
    if (err) {
      console.log(err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while posting Role Permission  ."
      });
    }
    else {
      console.log("Posted Successfully");
      res.status(200).send({
        message: "Posted Successfully",
        output: data
      })
    }
  });
};


exports.putRolePermission = (req, res) => {

  const rolepermission = new RolePermission({
    permission_id : req.body.permission_id || null,
  });

  RolePermission.putRolePermission (req.params.role_id, rolepermission , (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found role permission with id ${req.params.role_id}.`
        });
      }
    }
    else {
      res.statusCode = 200;
      res.send("Role permission updated Succesfully");
    }
});
};

exports.getRolePermissionID = (req, res) => {
  RolePermission.getRolePermissionID(req.params.id, (err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
    else res.send(data);
  });
};

exports.deleteRolePermission= (req, res) => {
  RolePermission.deleteRolePermission( req.params.id, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found Role permission with id ${req.params.id}.`
        });
      }
    }
    else {
      res.statusCode = 200;
      res.send("Role Permission Deleted Succesfully");
    }
});
};


// Roles
exports.getRoles = (req, res) => {
  Roles.getRoles ((err, data) => {
  if (err)
    res.status(500).send({
      message:
        err.message || "Some error occurred while retrieving data."
    });
  else res.send(data);
});
};

exports.saveRole = (req, res) => {
  
  const roles = new Roles({
    id: req.body.id,
    name: req.body.name,
    guard_name: req.body.guard_name,
  });

  Roles.saveRole ( roles, (err, data) => {
    if (err) {
      console.log(err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while posting Roles  ."
      });
    }
    else {
      let roleId = data.insertId

      // role_has_permissions
      const rolepermission = new RolePermission({
        permission_id: req.body.permission_id,
        role_id: roleId ,
      });

      // role_translations
      const roleTranslation = new RoleTranslation({
        role_id : roleId ,
        name : req.body.name, 
        lang : req.body.lang,
      });

      RolePermission.saveRolePermission(rolepermission, (err, data) => { if (err) { console.log(err); console.log("Role Permission "); result(err, null); return; } });

      RoleTranslation.saveRoleTranslation(roleTranslation, (err, data) => {
        if (err) {
          console.log(err)
          console.log("Role Translation posted");
          console.log("Posted Successfully");
          res.statusCode = 200;
        }
      });

      console.log("Roles & Permissions posted Successfully");
      res.status(200).send({
        message: "Roles & Permissions posted Successfully",
        output: data
      })
    }
  });
};

exports.putRole = (req, res) => {

  const roles = new Roles({
    id : req.params.id ,
    name : req.body.name || null,
    guard_name : req.body.guard_name || null,
  });

  let roleId = req.params.id

  Roles.putRole (req.params.id, roles , (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found roles with id ${req.params.id}.`
        });
      }
    }
    else {

      const rolepermission = new RolePermission({
        permission_id: req.body.permission_id,
        role_id: roleId ,
      });

      const roleTranslation = new RoleTranslation({
        role_id : roleId || null ,
        name : req.body.name || null ,
        lang : req.body.lang || null ,
      });

      RolePermission.putRolePermission (roleId, rolepermission , (err, data) => {
        if (err) {
          if (err.kind === "not_found") {
            res.status(404).send({
              message: `Not found role permission with id ${roleId}.`
            });
          }
        }
      })
  
      RoleTranslation.putRoleTranslation (roleId , roleTranslation, (err, data) => {
        if (err) {
          if (err.kind === "not_found") {
            res.status(404).send({
              message: `Not found with role id ${roleId}.`
            });
          }
        }
      })

      res.statusCode = 200;
      res.send("Roles & Permissions updated Succesfully");
    }
});
};

exports.getRoleID = (req, res) => {
  Roles.getRoleID(req.params.id, (err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
    else res.send(data);
  });
};

exports.deleteRole = (req, res) => {
  Roles.deleteRole ( req.params.id, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found Roles with id ${req.params.id}.`
        });
      }
    }
    else {
      res.statusCode = 200;
      res.send("Roles Deleted Succesfully");
    }
});
};