const Auth = require("../models/auth.model.js");
const sql = require("../models/db");
const mailer = require("../customerModels/mailer.models.js");
const util = require('util');
const { Validator } = require('node-input-validator');

//login api

// exports.login = (req, res) => {
//   if (!req.body) {
//     res.status(400).send({
//       message: "Email Id and Password Should Not Be Empty"
//     });
//   }
  
//   Auth.login(req.body, (err, data) => {
//     if (err) {
//       if (err.kind === "not_found") {
//         res.status(404).send({
//           message: `Not found User with Email ${req.body.email}.`
//         });
//       } else {
//         res.status(500).send({
//           message: "Error retrieving User with Email " + req.body.email
//         });
//       }
//     }
//     else {
//       res.send(data);
//       console.log(data);
//     };
//   });
// };

exports.login = (async (req, res) => {

  if (!req.body) {
    res.status(401).send({
      message: "Email Id and Password Should Not Be Empty"
    });
  }

  const validate = new Validator(req.body, {
    email: 'required|minLength:10|maxLength:50',
    password: 'required|minLength:8|maxLength:50',
  });

  validate.check().then(async (matched) => {
    if (!matched) {
      // res.status(422).send(validate.errors);
      res.status(422).send({
        status:(422),
        message:"Errors",
        errors: (validate.errors)
      })
    }
    else {
  
  Auth.login(req.body, (err, data) => {

    var email = req.body.email;
    var password = req.body.password;

    if (err) {

      if (email == "" || email == null || email == undefined || email == !req.body.email) {
          console.log("Invalid email");
          res.status(401).send({
            status:(401) ,
            message: "Invaild Email ID"
          })
        }

      else if (password == "" || password == null || password == undefined || password == !req.body.password) {
          console.log("Invalid password");
          res.status(401).send({
            status:(401) ,
            message: "Invaild password"
          })
        } 

       else {
          res.status(401).send({
            message: "Invalid Email Id and Password"
          });
        }
      }

    else {
      // res.send(data);
      // console.log(data);
      res.status(200).send({
        status:(200),
        message:"Success",
        Data:data
      })
    };
  });
}
})
});

  exports.verifyToken = (req, res) => {
    if (!req.body) {
      res.status(400).send({
        message: "remember_token Should Not Be Empty"
      });
    }
    Auth.verifyToken(req.body, (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(404).send({
            message: `Not found User with remember_token ${req.body.remember_token}.`
          });
        } else {
          res.status(500).send({
            message: "Error retrieving User with remember_token " + req.body.remember_token
          });
        }
      } else {
        res.send(data);
      };
    });
  };

  exports.changePassword = (req, res) => {

    if (!req.body) {
      res.status(400).send({
        message: "Password Cannot be Empty"
      });
    }
    
    Auth.changePassword(req.params.id, req.body, (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(404).send({
            message: `Not found user with id ${req.params.id}.`
          });
        }
      }
      else {  
        res.statusCode = 200;
        res.send("User Password updated Succesfully");
      }
    });
  };

  exports.resetPassword = (async (req, res) => {
    const query = util.promisify(sql.query).bind(sql);
    const userIdFetch = await query(`select id, email, remember_token from users where email='${req.body.email}' limit 1`);
    const user_email = userIdFetch[0] ? userIdFetch[0]["email"] : 0
    const user_remembertoken = userIdFetch[0] ? userIdFetch[0]["remember_token"] : 0
    x = userIdFetch.length
    if (!req.body) {
      res.status(400).send({
        message: "Email Cannot be Empty"
      });
    }
    if (x == 0) {
      res.send({ message: "User does not exists" })
    }
    else {
      console.log(user_email)
      console.log(user_remembertoken)
      let url = {
        from: "dev.vrikshatech@gmail.com",
        to: user_email,
        subject: "Reset Password Link E-com",
        html: ''
        // '<p>You requested for reset password, kindly use this <a href="http://localhost:4000/reset-password?token=' + user_remembertoken + '">link</a> to reset your password</p>'
      };
      mailer.sendMail(url,(err, user_email, user_remembertoken) => {
        if (err) {
          console.log(0)
          res.statusCode = 200;
          res.send({message: "password link sent to the email", email: user_email, remember_token:user_remembertoken});
        }
      });
    }
  });
