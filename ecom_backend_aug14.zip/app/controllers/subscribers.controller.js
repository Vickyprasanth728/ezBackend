const Subscribers = require("../models/subscribers.model.js");

// subscribers List
exports.getSubscribers = (req, res) => {
    Subscribers.getSubscribers((err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
    else res.send(data);
  });
};

exports.deleteSubscriber = (req, res) => {
  Subscribers.deleteSubscriber ( req.params.id, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found subscribers with id ${req.params.id}.`
        });
      }
    }
    else {
      res.statusCode = 200;
      res.send("Subscribers deleted Succesfully");
    }
});
};