const Languages = require("../models/languagesSettings.model.js");
const Currency = require("../models/currencySettings.js");
const Taxes = require("../models/taxesSettings.model.js");
const { Validator } = require('node-input-validator');
const fs = require("fs")
const util = require('util');
const sql = require("../models/db");
const readXlsxFile = require('read-excel-file/node');


exports.getLanguages = (req, res) => {
    Languages.getLanguages((err, data) => {
      if (err)
        res.status(401).send({
          message:
            err.message || "Some error occurred while retrieving data."
        });
      else 
      res.status(200).send({
        status:(200),
        message:"Success",
        Data:data
      })
    });
  };

  exports.saveLanguage = (async(req, res) => {

    const query1 = util.promisify(sql.query).bind(sql);
    const executivesFetch = await query1(`select app_lang_code from languages where app_lang_code='${req.body.app_lang_code}' limit 1`);
    const executives = executivesFetch[0] ? executivesFetch[0]["exec"] : 0

    const query2 = util.promisify(sql.query).bind(sql);
    const executivesFetch2 = await query2(`select code from languages where code='${req.body.code}' limit 1`);
    const executives2 = executivesFetch2[0] ? executivesFetch2[0]["exec"] : 0
    
    if(executives != 0){
      // res.send("App Language code already exists");
      res.status(401).send({
        status:(401),
        message: "App Language code already exists",
      })
    } 
    else if(executives2 != 0){
      // res.send("App Language code already exists");
      res.status(401).send({
        status:(401),
        message: "Code already exists",
      })
    }
    else {
    const validate = new Validator(req.body, {
      name: 'required|minLength:3|maxLength:50',
      code: 'required|minLength:2|maxLength:5',
    });

    validate.check().then(async (matched) => {
      if (!matched) {
        // res.status(422).send(validate.errors);
        res.status(422).send({
          status:(422),
          message:"Errors",
          errors: (validate.errors)
        })
      }

      else {
        const languages = new Languages({
          id: req.body.id,
          name: req.body.name,
          code: req.body.code,
          app_lang_code: req.body.app_lang_code,
          rtl: req.body.rtl || "0",
          status: req.body.status || "0",
        });
  
    Languages.saveLanguage( languages , (err, data) => {
      if (err) {
        console.log(err)
        res.status(401).send({
          message:
            err.message || "Some error occurred while posting languages  ."
        });
      }
      else {
        console.log("Posted Successfully");
        res.status(200).send({
          message: "Posted Successfully",
          output: data
        })
      }
    });
    
     }
    })
  }
  });

  // exports.saveLanguage = (req, res) => {
  //   const languages = new Languages({
  //     id: req.body.id,
  //     name: req.body.name,
  //     code: req.body.code,
  //     app_lang_code: req.body.app_lang_code,
  //     rtl: req.body.rtl,
  //     status: req.body.status,
  //   });
  
  //   Languages.saveLanguage( languages , (err, data) => {
  //     if (err) {
  //       console.log(err)
  //       res.status(401).send({
  //         message:
  //           err.message || "Some error occurred while posting languages  ."
  //       });
  //     }
  //     else {
  //       console.log("Posted Successfully");
  //       res.status(200).send({
  //         message: "Posted Successfully",
  //         output: data
  //       })
  //     }
  //   });
  // };

  exports.putLanguage = (async(req, res) => {

    const query1 = util.promisify(sql.query).bind(sql);
    const executivesFetch = await query1(`select app_lang_code from languages where app_lang_code='${req.body.app_lang_code}' limit 1`);
    const executives = executivesFetch[0] ? executivesFetch[0]["exec"] : 0

    const query2 = util.promisify(sql.query).bind(sql);
    const executivesFetch2 = await query2(`select code from languages where code='${req.body.code}' limit 1`);
    const executives2 = executivesFetch2[0] ? executivesFetch2[0]["exec"] : 0
    
    if(executives != 0){
      // res.send("App Language code already exists");
      res.status(401).send({
        status:(401),
        message: "App Language code already exists",
      })
    } 

    // else if(executives2 != 0){
    //   // res.send("App Language code already exists");
    //   res.status(401).send({
    //     status:(401),
    //     message: "Code already exists",
    //   })
    // }
    
    else {

    const validate = new Validator(req.body, {
      name: 'required|minLength:3|maxLength:50',
      code: 'required|minLength:2|maxLength:5',
    });

    validate.check().then(async (matched) => {
      if (!matched) {
        // res.status(422).send(validate.errors);
        res.status(422).send({
          status:(422),
          message:"Errors",
          errors: (validate.errors)
        })
      }

      else {
        const languages = new Languages({
            name: req.body.name || null,
            code: req.body.code|| null,
            app_lang_code: req.body.app_lang_code || null,
            rtl: req.body.rtl || null,
            status: req.body.status || null,
        });
  
    Languages.putLanguage (req.params.id, languages, (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(401).send({
            message: `Not found languages with id ${req.params.id}.`
          });
        }
      }
      else {
        res.status(200).send({
          status:(200),
          message:"Success",
          Data:data
        })
      }
  });
  
   }
    })
  }
  });

  exports.UpdateLanguageStatus = (req, res) => {

    const colors = new Languages({
         status : req.body.status || null,
    });
  
    Languages.UpdateLanguageStatus (req.params.id, colors, (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(404).send({
            message: `Not found lang status with id ${req.params.id}.`
          });
        }
      }
      else {
        res.statusCode = 200;
        res.send("Lang Status updated Succesfully");
      }
  });
  };

  exports.getLanguageID = (req, res) => {
    Languages.getLanguageID(req.params.id, (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
            res.status(401).send({
            status:(401),
            message: `Not found language with id ${req.params.id}.`
            });
        }
        }
        else {
        res.status(200).send({
            status:(200),
            message:"Success",
            data:data
        })
        }
    });
    };

  exports.deleteLanguage = (req, res) => {
    Languages.deleteLanguage( req.params.id, (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(401).send({
            message: `Not found languages with id ${req.params.id}.`
          });
        }
      }
      else {
        res.status(200).send({
          status:(200),
          message:"Success",
        })
      }
  });
};

exports.languageImport = (async (req, res) => {
  const query = util.promisify(sql.query).bind(sql);

  readXlsxFile('./uploads/' + req.file.filename).then((rows) => {

    rows.shift();
    rows.forEach(async (row) => {

    let languagesData = new (Languages)({
      name: row[0] || null,
      code: row[1] || null,
      app_lang_code:row[2] || null,
      rtl: row[3] || null,
      status: row[4] || null,
    });
    console.log(languagesData)
    Languages.saveLanguage(languagesData, (err, data) => {
      if (err) {
        res.status(401).send({
          message:
            err.message || "Some error occurred while retrieving languages."
        });
      }
      else {
        res.statusCode = 200;
      }
    })
  });
  res.send("Languages Saved Succesfully");
});
});


// Currencies
exports.getCurrency = (req, res) => {
  Currency.getCurrency((err, data) => {
    if (err)
      res.status(401).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
    else 
    res.status(200).send({
      status:(200),
      message:"Success",
      Data:data
    })
  });
};

exports.saveCurrency = (req, res) => {
  const currencies = new Currency({
    id: req.body.id,
    name: req.body.name,
    symbol: req.body.symbol,
    exchange_rate: req.body.exchange_rate,
    status: req.body.status,
    code: req.body.code,
  });

  Currency.saveCurrency( currencies , (err, data) => {
    if (err) {
      console.log(err)
      res.status(401).send({
        message:
          err.message || "Some error occurred while posting currencies  ."
      });
    }
    else {
      console.log("Posted Successfully");
      res.status(200).send({
        message: "Posted Successfully",
        output: data
      })
    }
  });
};

exports.putCurrency = (req, res) => {

  const currencies = new Currency({
      name: req.body.name || null,
      symbol: req.body.symbol || null,
      exchange_rate: req.body.exchange_rate || null,
      status: req.body.status || null,
      code: req.body.code|| null,

  });

  Currency.putCurrency (req.params.id, currencies, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(401).send({
          message: `Not found currencies with id ${req.params.id}.`
        });
      }
    }
    else {
      res.status(200).send({
        status:(200),
        message:"Success",
        Data:data
      })
    }
});
};

exports.getCurrencyID = (req, res) => {
  Currency.getCurrencyID(req.params.id, (err, data) => {
    if (err)
      res.status(401).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
    else 
    res.status(200).send({
      status:(200),
      message:"Success",
      Data:data
    })
  });
};

exports.deleteCurrency = (req, res) => {
  Currency.deleteCurrency( req.params.id, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(401).send({
          message: `Not found currencies with id ${req.params.id}.`
        });
      }
    }
    else {
      res.status(200).send({
        status:(200),
        message:"Success",
      })
    }
});
};


// Taxes
exports.getTaxes = (req, res) => {
  Taxes.getTaxes((err, data) => {
    if (err)
      res.status(401).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
    else 
    res.status(200).send({
      status:(200),
      message:"Success",
      Data:data
    })
  });
};

exports.saveTaxes = (req, res) => {
  const taxes = new Taxes({
    id: req.body.id,
    name: req.body.name,
    tax_status: req.body.tax_status,
  });

  Taxes.saveTaxes( taxes , (err, data) => {
    if (err) {
      console.log(err)
      res.status(401).send({
        message:
          err.message || "Some error occurred while posting taxes  ."
      });
    }
    else {
      console.log("Posted Successfully");
      res.status(200).send({
        message: "Posted Successfully",
        output: data
      })
    }
  });
};

exports.putTaxes = (req, res) => {

  const taxes = new Taxes({
      name: req.body.name || null,
      tax_status: req.body.tax_status || null,
  });

  Taxes.putTaxes (req.params.id, taxes, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(401).send({
          message: `Not found taxes with id ${req.params.id}.`
        });
      }
    }
    else {
      res.status(200).send({
        status:(200),
        message:"Success",
        Data:data
      })
    }
});
};

exports.getTaxesID = (req, res) => {
  Taxes.getTaxesID(req.params.id, (err, data) => {
    if (err)
      res.status(401).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
    else       
      res.status(200).send({
      status:(200),
      message:"Success",
      Data:data
    })
  });
};

exports.deleteTaxes = (req, res) => {
  Taxes.deleteTaxes( req.params.id, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(401).send({
          message: `Not found taxes with id ${req.params.id}.`
        });
      }
    }
    else {
      res.status(200).send({
        status:(200),
        message:"Success",
      })
    }
});
};