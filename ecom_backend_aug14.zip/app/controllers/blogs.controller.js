const Blogs = require("../models/blogs.models.js");
const BlogCategories = require("../models/blogsCategories.models.js");
const UploadFiles = require("../models/upload.models.js");
const path = require("path");
const fs = require("fs");

function keyGen(keyLength) {
  var i, key = "", characters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

  var charactersLength = characters.length;

  for (i = 0; i < keyLength; i++) {
    key += characters.substr(Math.floor((Math.random() * charactersLength) + 1), 1);
  }

  return key;
}

// Blogs
exports.getBlogs = (req, res) => {
  Blogs.getBlogs((err, data) => {
  if (err)
    res.status(401).send({
      message:
        err.message || "Some error occurred while retrieving data."
    });
  else 
  res.status(200).send({
    status:(200),
    message:"Success",
    Data:data
  })
});
};

// exports.saveBlog = (async(req, res) => {

//   let x = req.body.title.toLowerCase().replace(/ /g, '-').replace(/[^\w-]+/g, '');

//   const blogs = new Blogs({
//     id : req.body.id || null,
//     category_id : req.body.category_id || null,
//     title : req.body.title || null,
//     slug : x ,
//     short_description : req.body.short_description || null,
//     description : req.body.description || null,
//     banner : req.body.banner || null,
//     meta_title : req.body.meta_title || null,
//     meta_img : req.body.meta_img || null,
//     meta_description : req.body.meta_description || null,
//     meta_keywords : req.body.meta_keywords || null,
//     status : req.body.status || "0",
//   });

//   Blogs.saveBlog( blogs, (err, data) => {
//     if (err) {
//       console.log(err)
//       res.status(401).send({
//         message:
//           err.message || "Some error occurred while posting blog ."
//       });
//     }
//     else {

//       let file_name = "";
//       if (req.files.file_name) {
//         const ext = req.files.file_name[0]["mimetype"].split('/')[1]
//         file_name = req.files.file_name[0]["filename"] + '.' + ext
//         file_original_name = req.files.file_name[0]["originalname"]
//         file_size = req.files.file_name[0]["size"]
//         extension = req.files.file_name[0]["mimetype"].split('/')[1]
//         type = req.files.file_name[0]["mimetype"].split('/')[0]
//       }
    
//       const uploadfiles = new UploadFiles({
//         id :  req.body.banner ,
//         file_original_name : file_original_name,
//         file_name : file_name,
//         user_id : req.body.user_id,
//         file_size : file_size,
//         extension : extension,
//         type: type,
//         external_link : req.body.external_link,
//       });
//       UploadFiles.saveUploadFiles( uploadfiles, (err, data) => {
//         if (err) {
//           console.log(err)
//           res.status(401).send({
//             message:
//               err.message || "Some error occurred while posting upload files ."
//           });
//         }
//         else {
    
//           let uploadId = data.insertId
    
//           if (req.files.file_name) {
    
//             const currentPath = path.join(process.cwd(), "uploads", req.files.file_name[0]["filename"]);
//             const destinationPath = path.join(process.cwd(), "/uploads/all_uploads/file_name/" + `${uploadId}`, file_name);
//             const baseUrl = process.cwd() + '/uploads/all_uploads/file_name/' + `${uploadId}`
//             fs.mkdirSync(baseUrl, { recursive: true })
//             fs.rename(currentPath, destinationPath, function (err) {
//               if (err) {
//                 throw err
//               } else {
//                 console.log("Successfully images file uploaded !")
//               }
//             });
//           }
//         }
//       });

//       console.log("Posted Successfully");
//       res.status(200).send({
//         message: "Posted Successfully",
//         output: blogs
//       })
//     }
//   });
// });


exports.saveBlog = (async (req, res) => {

  let file_name = "";
  if (req.files.file_name) {
    const ext = req.files.file_name[0]["mimetype"].split('/')[1]
    file_name = req.files.file_name[0]["filename"] + '.' + ext
    file_original_name = req.files.file_name[0]["originalname"]
    file_size = req.files.file_name[0]["size"]
    extension = req.files.file_name[0]["mimetype"].split('/')[1]
    type = req.files.file_name[0]["mimetype"].split('/')[0]
  }

  const uploadfiles = new UploadFiles({
    id: req.body.id,
    file_original_name: file_original_name || null,
    file_name: file_name || null,
    user_id: req.body.user_id || null,
    file_size: file_size || null,
    extension: extension || null,
    type: type || null,
    external_link: req.body.external_link || null,
  });
  
  UploadFiles.saveUploadFiles(uploadfiles, (err, data) => {
    if (err) {
      console.log(err)
      res.status(401).send({
        message:
          err.message || "Some error occurred while posting upload files ."
      });
    }
    else {

      let uploadId = data.insertId

      if (req.files.file_name) {

        const currentPath = path.join(process.cwd(), "uploads", req.files.file_name[0]["filename"]);
        const destinationPath = path.join(process.cwd(), "/uploads/all_uploads/file_name/" + `${uploadId}`, file_name);
        const baseUrl = process.cwd() + '/uploads/all_uploads/file_name/' + `${uploadId}`
        fs.mkdirSync(baseUrl, { recursive: true })
        fs.rename(currentPath, destinationPath, function (err) {
          if (err) {
            throw err
          } else {
            console.log("Successfully images file uploaded !")
          }
        });
      }

      let x = req.body.title.toLowerCase().replace(/ /g, '-').replace(/[^\w-]+/g, '');

      const blogs = new Blogs({
        id: req.body.id || null,
        category_id: req.body.category_id || null,
        title: req.body.title || null,
        slug: x ,
        short_description: req.body.short_description || null,
        description: req.body.description || null,
        banner: uploadId,
        meta_title: req.body.meta_title || null,
        meta_img: req.body.meta_img || null,
        meta_description: req.body.meta_description || null,
        meta_keywords: req.body.meta_keywords || null,
        status: req.body.status || "0",
      });

      Blogs.saveBlog(blogs, (err, data) => {
        if (err) {
          console.log(err)
          res.status(401).send({
            message:
              err.message || "Some error occurred while posting blog ."
          });
        }
        else {
        }
      });
      console.log("Posted Successfully");
      res.status(200).send({
        message: "Posted Successfully",
        output: blogs
      })
    }
  });
});


exports.putBlog = (async(req, res) => {

  let x = req.body.title.toLowerCase().replace(/ /g, '-').replace(/[^\w-]+/g, '');

  const blogs = new Blogs({
    id: req.body.id,
    category_id : req.body.category_id,
    title : req.body.title,
    slug : x ,
    short_description : req.body.short_description,
    description : req.body.description,
    banner : req.body.banner,
    meta_title : req.body.meta_title,
    meta_img : req.body.meta_img,
    meta_description : req.body.meta_description,
    meta_keywords : req.body.meta_keywords,
    status : req.body.status,
  });

  Blogs.putBlog (req.params.id, blogs, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found blog with id ${req.params.id}.`
        });
      }
    }
    else {

      // let file_name = "";

      if (req.files.file_name) {
        const ext = req.files.file_name[0]["mimetype"].split('/')[1]
        file_name = req.files.file_name[0]["filename"] + '.' + ext
        file_original_name = req.files.file_name[0]["originalname"]
        file_size = req.files.file_name[0]["size"]
        extension = req.files.file_name[0]["mimetype"].split('/')[1]
        type = req.files.file_name[0]["mimetype"].split('/')[0]
      }
    
        const uploadfiles = new UploadFiles({
          id : req.body.banner,
          file_original_name : file_original_name || null,
          file_name : file_name || null,
          user_id : req.body.user_id || null,
          file_size : file_size || null,
          extension : extension || null,
          type : type || null,
          external_link : req.body.external_link || null,
        });
    
      
      UploadFiles.putUploadFile (req.body.banner, uploadfiles, (err, data) => {
        if (err) {
          if (err.kind === "not_found") {
            res.status(401).send({
              message: `Not found Upload file with id ${req.params.id}.`
            });
          }
        }
        else {  
         let uploadId = req.body.banner


          if (req.files.file_name) {
            const currentPath = path.join(process.cwd(), "uploads", req.files.file_name[0]["filename"]);
            const destinationPath = path.join(process.cwd(), "/uploads/all_uploads/file_name/" + `${uploadId}`, file_name);
            const baseUrl = process.cwd() + '/uploads/all_uploads/file_name/' + `${uploadId}`
            fs.mkdirSync(baseUrl, { recursive: true })
            fs.rename(currentPath, destinationPath, function (err) {
              if (err) {
                throw err
              } else {
                console.log("Successfully moved the upload images !")
              }
            });
          }
          
      res.status(200).send({
        status:(200),
        message:"Success",
        Data:blogs,
        Data2:uploadfiles
      })
    }
  })}
});
});


// exports.putBlog = (async(req, res) => {

//   let x = req.body.title.toLowerCase().replace(/ /g, '-').replace(/[^\w-]+/g, '');

//   const blogs = new Blogs({
//     id: req.body.id,
//     category_id : req.body.category_id,
//     title : req.body.title,
//     slug : x ,
//     short_description : req.body.short_description,
//     description : req.body.description,
//     banner : req.body.banner,
//     meta_title : req.body.meta_title,
//     meta_img : req.body.meta_img,
//     meta_description : req.body.meta_description,
//     meta_keywords : req.body.meta_keywords,
//     status : req.body.status,
//   });

//   Blogs.putBlog (req.params.id, blogs, (err, data) => {
//     if (err) {
//       if (err.kind === "not_found") {
//         res.status(404).send({
//           message: `Not found blog with id ${req.params.id}.`
//         });
//       }
//     }
//     else {
//       res.status(200).send({
//         status:(200),
//         message:"Success",
//         Data:blogs
//       })
//     }
// });
// });

// exports.putBlog = (req, res) => {

//   let file_name = "";
//   let file_original_name = "";
//   let file_size = "";
//   let extension = "";
//   let type = "";
//   let external_link = "";

//   if (req.files.file_name) {
//     const ext = req.files.file_name[0]["mimetype"].split('/')[1]
//     file_name = req.files.file_name[0]["filename"] + '.' + ext
//     file_original_name = req.files.file_name[0]["originalname"]
//     file_size = req.files.file_name[0]["size"]
//     extension = req.files.file_name[0]["mimetype"].split('/')[1]
//     type = req.files.file_name[0]["mimetype"].split('/')[0]
//   }

//     const uploadfiles = new UploadFiles({
//       id : req.body.id,
//       file_original_name : file_original_name || null,
//       file_name : file_name || null,
//       user_id : req.body.user_id || null,
//       file_size : file_size || null,
//       extension : extension || null,
//       type : type || null,
//       external_link : req.body.external_link || null,
//     });

//   // let uploadUpdateId = req.params.id
  
//   UploadFiles.saveUploadFiles(uploadfiles, (err, data) => {
//     if (err) {
//       console.log(err)
//       res.status(401).send({
//         message:
//           err.message || "Some error occurred while posting upload files ."
//       });
//     }
//     else {

//       let uploadId = data.insertId

//       if (req.files.file_name) {
//         const currentPath = path.join(process.cwd(), "uploads", req.files.file_name[0]["filename"]);
//         const destinationPath = path.join(process.cwd(), "/uploads/all_uploads/file_name/" + `${uploadId}`, file_name);
//         const baseUrl = process.cwd() + '/uploads/all_uploads/file_name/' + `${uploadId}`
//         fs.mkdirSync(baseUrl, { recursive: true })
//         fs.rename(currentPath, destinationPath, function (err) {
//           if (err) {
//             throw err
//           } else {
//             console.log("Successfully moved the upload images !")
//           }
//         });
//       }

//       const blogs = new Blogs({
//         id: req.body.id,
//         category_id : req.body.category_id,
//         title : req.body.title,
//         slug : '' ,
//         short_description : req.body.short_description,
//         description : req.body.description,
//         banner : uploadId,
//         meta_title : req.body.meta_title,
//         meta_img : req.body.meta_img,
//         meta_description : req.body.meta_description,
//         meta_keywords : req.body.meta_keywords,
//         status : req.body.status,
//       });

//       Blogs.putBlog (req.params.id, blogs, (err, data) => {
//         if (err) {
//           if (err.kind === "not_found") {
//             res.status(404).send({
//               message: `Not found blog with id ${req.params.id}.`
//             });
//           }
//         }
//       })
//     res.status(200).send({
//       status:(200),
//       message:"Success",
//       Data:uploadfiles,
//       Data1: blogs,
//     })
//     }
// });
// };


// exports.putBlog = (async(req, res) => {

//   let x = req.body.title.toLowerCase().replace(/ /g, '-').replace(/[^\w-]+/g, '');

//   const blogs = new Blogs({
//     id: req.body.id,
//     category_id : req.body.category_id,
//     title : req.body.title,
//     slug : x ,
//     short_description : req.body.short_description,
//     description : req.body.description,
//     banner : req.body.banner,
//     meta_title : req.body.meta_title,
//     meta_img : req.body.meta_img,
//     meta_description : req.body.meta_description,
//     meta_keywords : req.body.meta_keywords,
//     status : req.body.status,
//   });

//   bannerId = req.body.banner

//   Blogs.putBlog (req.params.id, blogs, (err, data) => {
//     if (err) {
//       if (err.kind === "not_found") {
//         res.status(404).send({
//           message: `Not found blog with id ${req.params.id}.`
//         });
//       }
//     }
//     else {

//       let file_name = "";

//       if (req.files.file_name) {
//         const ext = req.files.file_name[0]["mimetype"].split('/')[1]
//         file_name = req.files.file_name[0]["filename"] + '.' + ext
//         file_original_name = req.files.file_name[0]["originalname"]
//         file_size = req.files.file_name[0]["size"]
//         extension = req.files.file_name[0]["mimetype"].split('/')[1]
//         type = req.files.file_name[0]["mimetype"].split('/')[0]
//       }
    
//         const uploadfiles = new UploadFiles({
//           id : bannerId,
//           file_original_name : file_original_name,
//           file_name : file_name,
//           user_id : req.body.user_id,
//           file_size : file_size,
//           extension : extension,
//           type : type,
//           external_link : req.body.external_link,
//         });
    
//       // let uploadId = req.params.id

//       UploadFiles.saveUploadFiles(uploadfiles, (err, data) => {
//         if (err) {
//           console.log(err)
//           res.status(401).send({
//             message:
//               err.message || "Some error occurred while posting upload files ."
//           });
//         }
//         else {
//           let uploadId = bannerId
    
//           if (req.files.file_name) {
//             const currentPath = path.join(process.cwd(), "uploads", req.files.file_name[0]["filename"]);
//             const destinationPath = path.join(process.cwd(), "/uploads/all_uploads/file_name/" + `${uploadId}`, file_name);
//             const baseUrl = process.cwd() + '/uploads/all_uploads/file_name/' + `${uploadId}`
//             fs.mkdirSync(baseUrl, { recursive: true })
//             fs.rename(currentPath, destinationPath, function (err) {
//               if (err) {
//                 throw err
//               } else {
//                 console.log("Successfully moved the upload images !")
//               }
//             });
//           }
//         }})

//       res.status(200).send({
//         status:(200),
//         message:"Success",
//         Data:blogs,
//         Data2:uploadfiles,
//       })
//     }
// });
// });

exports.getBlogID = (req, res) => {
  Blogs.getBlogID(req.params.id, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(401).send({
          status:(401),
          message: `Not found blog with id ${req.params.id}.`
        });
      }
    }
    else {
      res.status(200).send({
        status:(200),
        message:"Success",
        Data:data
      })
    }
});
};
exports.deleteBlog = (req, res) => {
    Blogs.deleteBlog( req.params.id, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found blog with id ${req.params.id}.`
        });
      }
    }
    else {
      res.status(200).send({
        status:(200),
        message:"Success",
      })
    }
});
};


// Blogs Categories

exports.getBlogCategories = (req, res) => {
    BlogCategories.getBlogCategories((err, data) => {
    if (err)
      res.status(401).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
    else 
    res.status(200).send({
      status:(200),
      message:"Success",
      Data:data
    })
  });
};

exports.saveBlogCategory = (req, res) => {
  const blogCategories = new BlogCategories({

    id : req.body.id || null,
    category_name : req.body.category_name || null,
    slug : req.body.slug || '0',
  });

  BlogCategories.saveBlogCategory( blogCategories, (err, data) => {
    if (err) {
      console.log(err)
      res.status(401).send({
        message:
          err.message || "Some error occurred while posting blog categories ."
      });
    }
    else {
      console.log("Posted Successfully");
      res.status(200).send({
        message: "Posted Successfully",
        output: data
      })
    }
  });
};

exports.putBlogCategory = (req, res) => {

  const blogCategories = new BlogCategories({
    id: req.body.id,
    category_name : req.body.category_name,
    slug : req.body.slug,
  });

  BlogCategories.putBlogCategory (req.params.id, blogCategories, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found blog categories with id ${req.params.id}.`
        });
      }
    }
    else {
      res.status(200).send({
        status:(200),
        message:"Success",
        Data:blogCategories
      })
    }
});
};

exports.getBlogCategoryID = (req, res) => {
    BlogCategories.getBlogCategoryID(req.params.id, (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(401).send({
            status:(401),
            message: `Not found customer with id ${req.params.id}.`
          });
        }
      }
      else {
        res.status(200).send({
          status:(200),
          message:"Success",
          Data:data
        })
      }
  });
  };

exports.deleteBlogCategory = (req, res) => {
    BlogCategories.deleteBlogCategory( req.params.id, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found blog categories with id ${req.params.id}.`
        });
      }
    }
    else {
      res.status(200).send({
        status:(200),
        message:"Success",
      })
    }
});
};