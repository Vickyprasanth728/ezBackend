const Categories = require("../models/categories.model.js");
const CategoryTranslation = require("../models/categoriesTranslation.model.js");
const path = require("path");
const fs = require("fs");

exports.getCategories = (req, res) => {
    Categories.getCategories((err, data) => {
      if (err)
      res.status(401).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
      else 
      res.status(200).send({
        status:(200),
        message:"Success",
        Data:data
      })
    });
  };

  exports.saveCategories = (req, res) => {

    let banner = "";
    let icon = "";

    if (req.files.banner) {
      const extension = req.files.banner[0]["mimetype"].split('/')[1]
      banner = req.files.banner[0]["filename"] + '.' + extension
      banner = req.files.banner[0]["originalname"]
    }

    if (req.files.icon) {
      const extension = req.files.icon[0]["mimetype"].split('/')[1]
      icon = req.files.icon[0]["filename"] + '.' + extension
      icon = req.files.icon[0]["originalname"]
    }
  
    const categories = new Categories({
      id: req.body.id|| null,
      parent_id: req.body.parent_id|| null,
      level: req.body.level || "0"|| null,
      name: req.body.name|| null,
      order_level: req.body.order_level|| "0",
      commision_rate:req.body.commision_rate || "0.00"|| null,
      banner: banner|| null,
      icon: icon|| null,
      featured:req.body.featured || "0"|| null,
      top:req.body.top || "0"|| null,
      digital: "0"|| null,
      slug: req.body.slug|| null,
      meta_title: req.body.meta_title|| null,
      meta_description: req.body.meta_description|| null,
    });
  
    Categories.saveCategories(categories, (err, data) => {
      if (err) {
        console.log(err)
        res.status(200).send({
          message:
            err.message || "Some error occurred while posting categories ."
        });
      }
      else {

        let categoryId = data.insertId

      if (req.files.banner) {
        //move banner
        const currentPath = path.join(process.cwd(), "uploads", req.files.banner[0]["filename"]);
        const destinationPath = path.join(process.cwd(), "/uploads/category/banner/" + `${categoryId}`, banner);
        const baseUrl = process.cwd() + '/uploads/category/banner/' + `${categoryId}`
        fs.mkdirSync(baseUrl, { recursive: true })
        fs.rename(currentPath, destinationPath, function (err) {
          if (err) {
            throw err
          } else {
            console.log("Successfully moved the banner images !")
          }
        });
      }

      if (req.files.icon) {
        //move icon
        const currentPath = path.join(process.cwd(), "uploads", req.files.icon[0]["filename"]);
        const destinationPath = path.join(process.cwd(), "/uploads/category/icon/" + `${categoryId}`, icon);
        const baseUrl = process.cwd() + '/uploads/category/icon/' + `${categoryId}`
        fs.mkdirSync(baseUrl, { recursive: true })
        fs.rename(currentPath, destinationPath, function (err) {
          if (err) {
            throw err
          } else {
            console.log("Successfully moved the icon images !")
          }
        });
      }

      // const categoryTranslation = new CategoryTranslation({
      //   category_id : categoryId,
      //   name : req.body.name,
      //   lang : req.body.lang || "EN",
      // });

      // CategoryTranslation.saveCategoryTranslation(categoryTranslation, (err, data) => {
      //   if (err) {
      //     console.log(err)
      //     console.log("Category Translation posted Successfully");
      //     console.log("Posted Successfully");
      //     res.statusCode = 200;
      //   }
      // });

        console.log("Posted Successfully");
        res.status(200).send({
          message: "Posted Successfully",
          output: data
        })
      }
    });
  };

  exports.putCategories = (req, res) => {

    if (!req.body) {
      res.status(401).send({
        message: "Empty"
      });
    }

    let banner = "";
    let icon = "";

    if (req.files.banner) {
      const extension = req.files.banner[0]["mimetype"].split('/')[1]
      banner = req.files.banner[0]["filename"] + '.' + extension
      banner = req.files.banner[0]["originalname"]
    }

    if (req.files.icon) {
      const extension = req.files.icon[0]["mimetype"].split('/')[1]
      icon = req.files.icon[0]["filename"] + '.' + extension
      icon = req.files.icon[0]["originalname"]
    }

    const categories = new Categories({
         parent_id : req.body.parent_id || null,
         level : req.body.level || null,
         name : req.body.name || null,
         order_level : req.body.order_level|| null,
         commision_rate : req.body.commision_rate || null,
         banner	 : banner	|| null,
         icon : icon || null,
         featured : req.body.featured || null,
         top : req.body.top || null,
         digital : req.body.digital || null,
         slug  : req.body.slug  || null,
         meta_title : req.body.meta_title || null,
         meta_description : req.body.meta_description || null,
    });
  
    let categoryId = req.params.id
    Categories.putCategories (req.params.id, categories, (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(404).send({
            message: `Not found categories with id ${req.params.id}.`
          });
        }
      }
      else {

        if (req.files.banner) {
          //move banner
          const currentPath = path.join(process.cwd(), "uploads", req.files.banner[0]["filename"]);
          const destinationPath = path.join(process.cwd(), "/uploads/category/banner/" + `${categoryId}`, banner);
          const baseUrl = process.cwd() + '/uploads/category/banner/' + `${categoryId}`
          fs.mkdirSync(baseUrl, { recursive: true })
          fs.rename(currentPath, destinationPath, function (err) {
            if (err) {
              throw err
            } else {
              console.log("Successfully moved the banner images !")
            }
          });
        }
  
        if (req.files.icon) {
          //move icon
          const currentPath = path.join(process.cwd(), "uploads", req.files.icon[0]["filename"]);
          const destinationPath = path.join(process.cwd(), "/uploads/category/icon/" + `${categoryId}`, icon);
          const baseUrl = process.cwd() + '/uploads/category/icon/' + `${categoryId}`
          fs.mkdirSync(baseUrl, { recursive: true })
          fs.rename(currentPath, destinationPath, function (err) {
            if (err) {
              throw err
            } else {
              console.log("Successfully moved the icon images !")
            }
          });
        }
          res.status(200).send({
          status:(200),
          message:"Categories Updated Succesfully",
          output: data
        })
      }
  });
  };

  exports.getCategoriesID = (req, res) => {
    Categories.getCategoriesID(req.params.id, (err, data) => {
    if (err)
      res.status(401).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
    else    
      res.status(200).send({
      status:(200),
      message:"Success",
      Data:data
    })
  });
  };

  exports.deleteCategories = (req, res) => {
    Categories.deleteCategories( req.params.id, (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(404).send({
            message: `Not found Categories with id ${req.params.id}.`
          });
        }
      }
      else {
          res.status(200).send({
          status:(200),
          message:"Categories deleted Succesfully",
          Data:data
        })
      }
  });
};