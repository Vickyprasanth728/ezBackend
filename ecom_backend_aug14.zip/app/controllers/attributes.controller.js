const Attributes = require("../models/attributes.model.js");
const AttributeTranslation = require("../models/attributeTranslations.model.js");
const AttributeValues = require("../models/attributeValues.model.js");
const AttributeCategory = require("../models/attributeCategory.model.js");


exports.getAttributes = (req, res) => {
    Attributes.getAttributes((err, data) => {
      if (err)
      res.status(401).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
      else 
      res.status(200).send({
        status:(200),
        message:"Success",
        Data:data
      })
    });
  };

  exports.saveAttributes = (req, res) => {
  
    const attributes = new Attributes({
      id: req.body.id,
      name: req.body.name,
    });
  
    Attributes.saveAttributes( attributes, (err, data) => {
      if (err) {
        console.log(err)
        res.status(401).send({
          message:
            err.message || "Some error occurred while posting attributes  ."
        });
      }
      else {

        let attributeId = data.insertId

        const attributeValues = new AttributeValues({
          attribute_id : attributeId,
          value : req.body.value,
          color_code : req.body.color_code,
        });

        const attributeTranslation = new AttributeTranslation({
          attribute_id : attributeId,
          name : req.body.name,
          lang : req.body.lang,
        });

        const attributeCategory = new AttributeCategory({
          category_id : req.body.category_id,
          attribute_id : attributeId,
        });
  
        AttributeValues.saveAttributeValue(attributeValues, (err, data) => {
          if (err) {
            console.log(err)
            console.log("Attribute Values posted Successfully");
            console.log("Posted Successfully");
            res.statusCode = 200;
          }
        });

        AttributeTranslation.saveAttributeTranslation(attributeTranslation, (err, data) => {
          if (err) {
            console.log(err)
            console.log("Attribute Translation posted Successfully");
            console.log("Posted Successfully");
            res.statusCode = 200;
          }
        });

        AttributeCategory.saveAttributeCategory(attributeCategory, (err, data) => {
          if (err) {
            console.log(err)
            console.log("Attribute Category posted Successfully");
            console.log("Posted Successfully");
            res.statusCode = 200;
          }
        });

        res.status(200).send({
          status:(200),
          message:"Success",
          Data:data
        })
      }
    });
  };


  exports.putAttributes = (req, res) => {

    const attributes = new Attributes({
         name : req.body.name || null,
    });
  
    // let attributeId = req.params.id

    Attributes.putAttributes (req.params.id, attributes, (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(401).send({
            message: `Not found attributes with id ${req.params.id}.`
          });
        }
      }
      else {

        // const attributeTranslation = new AttributeTranslation ({
        //   attribute_id : attributeId || null ,
        //   name : req.body.name || null ,
        //   lang : req.body.lang || null ,
        // });
        // const attributevalues = new AttributeValues ({
        //   attribute_id : attributeId || null,
        //   value : req.body.value || null,
        //   color_code : req.body.color_code || null,
        // });

        // AttributeValues.putAttributeValue ( req.params.id , attributevalues, (err, data) => {
        //   if (err) {
        //     if (err.kind === "not_found") {
        //       res.status(401).send({
        //         message: `Not found attribute values with attribute Id ${req.params.id}.`
        //       });
        //     }
        //   }
        // })

        // const attributeCategory = new AttributeCategory ({
        //   category_id : req.body.category_id  || null ,
        //   attribute_id : attributeId || null ,
        // });

        // AttributeTranslation.putAttributeTranslation (attributeId , attributeTranslation, (err, data) => {
        //   if (err) {
        //     if (err.kind === "not_found") {
        //       res.status(401).send({
        //         message: `Not found attribute Translation with attribute Id ${attributeId}.`
        //       });
        //     }
        //   }
        // })

        // AttributeCategory.putAttributeCategory (attributeId , attributeCategory, (err, data) => {
        //   if (err) {
        //     if (err.kind === "not_found") {
        //       res.status(401).send({
        //         message: `Not found attribute category with attribute Id ${attributeId}.`
        //       });
        //     }
        //   }
        // })

        res.status(200).send({
          status:(200),
          message:"Success",
          Data:data
        })
      }
  });
  };

  exports.getAttributesID = (req, res) => {
    Attributes.getAttributesID(req.params.id, (err, data) => {
      if (err)
        res.status(401).send({
          message:
            err.message || "Some error occurred while retrieving data."
        });
      else 
      res.status(200).send({
        status:(200),
        message:"Success",
        Data:data
      })
    });
  };

  exports.deleteAttributes = (req, res) => {
    Attributes.deleteAttributes( req.params.id, (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(401).send({
            message: `Not found attributes with id ${req.params.id}.`
          });
        }
      }
      else {
        res.status(200).send({
          status:(200),
          message:"Success",
          Data:data
        })
      }
  });
};


// Attributes Values 
exports.getAttributeValues = (req, res) => {
  AttributeValues.getAttributeValues((err, data) => {
    if (err)
    res.status(401).send({
      message:
        err.message || "Some error occurred while retrieving data."
    });
    else       
    res.status(200).send({
      status:(200),
      message:"Success",
      Data:data
    })
  });
};

exports.putAttributeValue = (req, res) => {

  const attributeValues = new AttributeValues({
      //  attribute_id : req.body.attribute_id || null,
       value : req.body.value || null,
       color_code : req.body.color_code || null,
  });

  AttributeValues.putAttributeValue (req.params.attribute_id, attributeValues, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(401).send({
          message: `Not found Attribute Values with id ${req.params.id}.`
        });
      }
    }
    else {
      res.status(200).send({
        status:(200),
        message:"Success",
        Data:attributeValues
      })
    }
});
};

exports.getAttributeValueID = (req, res) => {
  AttributeValues.getAttributeValueID(req.params.id, (err, data) => {
    if (err)
      res.status(401).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
    else 
    res.status(200).send({
      status:(200),
      message:"Success",
      Data:data
    })
  });
};

exports.deleteAttributeValue = (req, res) => {
  AttributeValues.deleteAttributeValue( req.params.id, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(401).send({
          message: `Not found Attribute Values with id ${req.params.id}.`
        });
      }
    }
    else {
      res.status(200).send({
        status:(200),
        message:"Success",
        Data:data
      })
    }
});
};