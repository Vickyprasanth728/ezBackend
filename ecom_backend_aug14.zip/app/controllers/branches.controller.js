const Branches = require("../models/branches.model.js");
const { Validator } = require('node-input-validator');
const path = require("path");
const fs = require("fs");

exports.getBranches = (req, res) => {
    Branches.getBranches ((err, data) => {
      if (err)
      res.status(401).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
      else 
      res.status(200).send({
        status:(200),
        message:"Success",
        Data:data
      })
    });
  };

  exports.saveBranch = (async (req, res) => {

    const VALID = new Validator(req.body, {
      shop_id: 'required|integer|minLength:1|maxLength:5',
      city: 'required|minLength:3|maxLength:50',
      phone_number: 'required|integer|minLength:10|maxLength:10',
      payment_type: 'required|integer|minLength:1|maxLength:5',
    });

    VALID.check().then(async (matched) => {
      if (!matched) {
        // res.status(422).send(VALID.errors);
        res.status(422).send({
          status:(422),
          message:"Errors",
          errors: (VALID.errors)
        })
      }

      else {
        const branch = new Branches({
          id: req.body.id || null,
          shop_id: req.body.shop_id || null,
          city: req.body.city || null,
          shop_open_time: req.body.shop_open_time || null,
          shop_close_time: req.body.shop_close_time || null,
          address: req.body.address || null,
          phone_number: req.body.phone_number || null,
          payment_type: req.body.payment_type || null,
        });

        Branches.saveBranch( branch, (err, data) => {
          if (err) {
            console.log(err)
            res.status(401).send({
              message:
                err.message || "Some error occurred while posting Branches  ."
            });
          }
          else {
            res.status(200).send({
              status:(200),
              message:"Success",
              Data:data
            })
          }
        });
      }
    })
  });

  exports.putBranch =(async (req, res) => {

    const VALID = new Validator(req.body, {
        shop_id: 'required|integer|minLength:1|maxLength:5',
        city: 'required|minLength:3|maxLength:50',
        phone_number: 'required|integer|minLength:10|maxLength:10',
        payment_type: 'required|integer|minLength:1|maxLength:5',
    });

    VALID.check().then(async (matched) => {
      if (!matched) {
        // res.status(422).send(VALID.errors);
        res.status(422).send({
          status:(422),
          message:"Errors",
          errors: (VALID.errors)
        })
      }
      else {
        
        const branch = new Branches ({
            id: req.body.id || null,
            shop_id: req.body.shop_id || null,
            city: req.body.city || null,
            shop_open_time: req.body.shop_open_time || null,
            shop_close_time: req.body.shop_close_time || null,
            address: req.body.address || null,
            phone_number: req.body.phone_number || null,
            payment_type: req.body.payment_type || null,
        });

    Branches.putBranch (req.params.id, branch, (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(401).send({
            message: `Not found branch with id ${req.params.id}.`
          });
        }
      }
      else {
        res.status(200).send({
          status:(200),
          message:"Success",
          Data:data
        })
      }
    }
    ) }
  });
  });

exports.getBranchEdit = (req, res) => {
    Branches.getBranchEdit(req.params.id, (err, data) => {
        if (err) {
            if (err.kind === "not_found") {
                res.status(401).send({
                    status: (401),
                    message: `Not found branches with id ${req.params.id}.`
                });
            }
        }
        else {
            res.status(200).send({
                status: (200),
                message: "Success",
                data: data
            })
        }
    });
};

exports.getBranchShopID = (req, res) => {
    Branches.getBranchShopID(req.params.shop_id, (err, data) => {
        if (err) {
            if (err.kind === "not_found") {
                res.status(401).send({
                    status: (401),
                    message: `Not found branches with id ${req.params.id}.`
                });
            }
        }
        else {
            res.status(200).send({
                status: (200),
                message: "Success",
                data: data
            })
        }
    });
};

  exports.deleteBranch = (req, res) => {
    Branches.deleteBranch( req.params.id, (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(401).send({
            message: `Not found branch with id ${req.params.id}.`
          });
        }
      }
      else {
        res.status(200).send({
          status:(200),
          message:"Success",
        })
      }
  });
};