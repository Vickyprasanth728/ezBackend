const PickPoint = require("../models/pickPoint.model.js");
const PickPointTranslation = require("../models/pickPointTranslation.model.js");


// pick point
exports.getPickPoint = (req, res) => {
  PickPoint.getPickPoint((err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
    else res.send(data);
  });
};

exports.savePickPoint = (req, res) => {
  const pickpoint = new PickPoint({
    id: req.body.id,
    staff_id : req.body.staff_id,
    name : req.body.name,
    address : req.body.address,
    phone : req.body.phone,
    pick_up_status : req.body.pick_up_status,
    cash_on_pickup_status : req.body.cash_on_pickup_status,
  });

  PickPoint.savePickPoint( pickpoint , (err, data) => {
    if (err) {
      console.log(err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while posting Pick Point  ."
      });
    }
    else {

      let pickPointId = data.insertId

      const pickpointTranslation = new PickPointTranslation({
        pickup_point_id : pickPointId,
        name : req.body.name,
        address : req.body.address,
        lang : req.body.lang,
      });

      PickPointTranslation.savePickPointTranslation ( pickpointTranslation, (err, data) => {
        if (err) {
          console.log(err)
          console.log("Pick Point Translation posted");
          console.log("Posted Successfully");
          res.statusCode = 200;
        }
      });

      console.log("Posted Successfully");
      res.status(200).send({
        message: "Posted Successfully",
        output: data
      })
    }
  });
};

exports.putPickPoint = (req, res) => {

  const pickpoint = new PickPoint({
    id: req.body.id || null ,
    staff_id : req.body.staff_id || null ,
    name : req.body.name || null ,
    address : req.body.address || null ,
    phone : req.body.phone || null ,
    pick_up_status : req.body.pick_up_status || null ,
    cash_on_pickup_status : req.body.cash_on_pickup_status || null ,
  });

  let pickPointId = req.params.id

  PickPoint.putPickPoint (req.params.id, pickpoint, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found Pick Point with id ${req.params.id}.`
        });
      }
    }
    else {

      const pickpointTranslation = new PickPointTranslation({
        pickup_point_id : pickPointId || null ,
        name : req.body.name || null ,
        address : req.body.address || null ,
        lang : req.body.lang || null ,
      });

      PickPointTranslation.putPickPointTranslation (pickPointId , pickpointTranslation, (err, data) => {
        if (err) {
          if (err.kind === "not_found") {
            res.status(404).send({
              message: `Not found with Pick-Point translation id ${pickPointId}.`
            });
          }
        }
      })

      res.statusCode = 200;
      res.send("Pick Point updated Succesfully");
    }
});
};

exports.getPickPointID = (req, res) => {
    PickPoint.getPickPointID(req.params.id, (err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
    else res.send(data);
  });
};

exports.deletePickPoint = (req, res) => {
    PickPoint.deletePickPoint( req.params.id, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found Pick Point with id ${req.params.id}.`
        });
      }
    }
    else {
      res.statusCode = 200;
      res.send("Pick Point deleted Succesfully");
    }
});
};