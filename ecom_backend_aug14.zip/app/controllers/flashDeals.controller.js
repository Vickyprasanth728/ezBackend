const FlashDeal = require("../models/flashDeal.models.js");
const FlashDealProducts = require("../models/flashDealProducts.model.js");
const FlashTranslation = require("../models/flashDealTransaction.model.js");
const path = require("path");
const fs = require("fs");

// FlashDeal
exports.getFlashDeal = (req, res) => {
  FlashDeal.getFlashDeal((err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
    else res.send(data);
  });
};

exports.saveFlashDeal = (req, res) => {

  let banner = "";

  if (req.files.banner) {
    const extension = req.files.banner[0]["mimetype"].split('/')[1]
    banner = req.files.banner[0]["filename"] + '.' + extension
    banner = req.files.banner[0]["originalname"]
  }

  const flashDeal = new FlashDeal({
    id : req.body.id,
    title :  req.body.title ,
    start_date :  req.body.start_date ,
    end_date :  req.body.end_date ,
    status :  req.body.status ,
    featured :  req.body.featured ,
    background_color :  req.body.background_color ,
    text_color : req.body.text_color ,
    banner : banner ,
    slug : req.body.slug ,
  });

  FlashDeal.saveFlashDeal( flashDeal, (err, data) => {
    if (err) {
      console.log(err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while posting flash deal ."
      });
    }
    else {

      let flashdealID = data.insertId

      if (req.files.banner) {

        const currentPath = path.join(process.cwd(), "uploads", req.files.banner[0]["filename"]);
        const destinationPath = path.join(process.cwd(), "/uploads/flashdeal/banner/" + `${flashdealID}`, banner);
        const baseUrl = process.cwd() + '/uploads/flashdeal/banner/' + `${flashdealID}`
        fs.mkdirSync(baseUrl, { recursive: true })
        fs.rename(currentPath, destinationPath, function (err) {
          if (err) {
            throw err
          } else {
            console.log("Successfully moved the flashdeal banner images !")
          }
        });
      }

      const flashDealproduct = new FlashDealProducts({
        flash_deal_id :  flashdealID ,
        product_id :  req.body.product_id,
        discount :  req.body.discount,
        discount_type :  req.body.discount_type,
      });

      const flashTranslation = new FlashTranslation({
        flash_deal_id : flashdealID,
        title :  req.body.title,
        lang :  req.body.lang,
      });

      FlashDealProducts.saveFlashDealProduct(flashDealproduct, (err, data) => { if (err) { console.log(err); console.log("Flash Deal Products"); result(err, null); return; } });

      FlashTranslation.saveFlashTranslation(flashTranslation, (err, data) => {
        if (err) {
          console.log(err)
          console.log("Flash Deal Translation posted");
          console.log("Posted Successfully");
          res.statusCode = 200;
        }
      });

      console.log("Posted Successfully");
      res.status(200).send({
        message: "Posted Successfully",
        output: data
      })
    }
  });
};

// exports.putFlashDeal = (req, res) => {

//   const flashDeal = new FlashDeal({
//      title :  req.body.title || null,
//      start_date :  req.body.start_date || null,
//      end_date :  req.body.end_date || null,
//      status :  req.body.status || null,
//      featured :  req.body.featured || null,
//      background_color :  req.body.background_color || null,
//      text_color :  req.body.text_color || null,
//      banner :  req.body.banner || null,
//      slug :  req.body.slug || null,
//   });

//   FlashDeal.putFlashDeal (req.params.id, flashDeal, (err, data) => {
//     if (err) {
//       if (err.kind === "not_found") {
//         res.status(404).send({
//           message: `Not found flash deal with id ${req.params.id}.`
//         });
//       }
//     }
//     else {
//       res.statusCode = 200;
//       res.send("Flash deal updated Succesfully");
//     }
// });
// };

exports.putFlashDeal = (req, res) => {

  let banner = "";

  if (req.files.banner) {
    const extension = req.files.banner[0]["mimetype"].split('/')[1]
    banner = req.files.banner[0]["filename"] + '.' + extension
    banner = req.files.banner[0]["originalname"]
  }

  const flashDeal = new FlashDeal({
     title :  req.body.title || null,
     start_date :  req.body.start_date || null,
     end_date :  req.body.end_date || null,
     status :  req.body.status || null,
     featured :  req.body.featured || null,
     background_color :  req.body.background_color || null,
     text_color :  req.body.text_color || null,
     banner : banner || null,
     slug :  req.body.slug || null,
  });

  let flashdealID = req.params.id

  FlashDeal.putFlashDeal (req.params.id, flashDeal, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found flash deal with id ${req.params.id}.`
        });
      }
    }
    else {

      if (req.files.banner) {

        const currentPath = path.join(process.cwd(), "uploads", req.files.banner[0]["filename"]);
        const destinationPath = path.join(process.cwd(), "/uploads/flashdeal/banner/" + `${flashdealID}`, banner);
        const baseUrl = process.cwd() + '/uploads/flashdeal/banner/' + `${flashdealID}`
        fs.mkdirSync(baseUrl, { recursive: true })
        fs.rename(currentPath, destinationPath, function (err) {
          if (err) {
            throw err
          } else {
            console.log("Successfully moved the flashdeal banner images !")
          }
        });
      }

      // let flashID = data

      const flashDealproduct = new FlashDealProducts({
        flash_deal_id : flashdealID || null,
        product_id :  req.body.product_id || null,
        discount :  req.body.discount || null,
        discount_type :  req.body.discount_type || null,
      });

      FlashDealProducts.putFlashDealProduct (req.params.id, flashDealproduct, (err, data) => {
        if (err) {
          if (err.kind === "not_found") {
            res.status(404).send({
              message: `Not found flash deal with id ${req.params.id}.`
            });
          }
        }
      });

      const flashTranslation = new FlashTranslation({
        flash_deal_id : flashdealID || null ,
        title : req.body.title || null ,
        lang : req.body.lang || null ,
      });

      FlashTranslation.putFlashTranslation (flashdealID , flashTranslation, (err, data) => {
        if (err) {
          if (err.kind === "not_found") {
            res.status(404).send({
              message: `Not found with flashdeal id ${flashdealID}.`
            });
          }
        }
      })

      res.statusCode = 200;
      res.send("Flash deal updated Succesfully");
    }
});
};

exports.getFlashDealID = (req, res) => {
  FlashDeal.getFlashDealID(req.params.id, (err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
    else res.send(data);
  });
};

exports.deleteFlashDeal = (req, res) => {
  FlashDeal.deleteFlashDeal( req.params.id, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found flash deal with id ${req.params.id}.`
        });
      }
    }
    else {
      res.statusCode = 200;
      res.send("Flash deal deleted Succesfully");
    }
});
};


// Flash Deal Products
exports.getFlashDealProducts = (req, res) => {
  FlashDealProducts.getFlashDealProducts ((err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
    else res.send(data);
  });
};

exports.saveFlashDealProduct = (req, res) => {

  const flashDealproduct = new FlashDealProducts({
    id : req.body.id,
    flash_deal_id :  req.body.flash_deal_id,
    product_id :  req.body.product_id,
    discount :  req.body.discount,
    discount_type :  req.body.discount_type,
  });

  FlashDealProducts.saveFlashDealProduct( flashDealproduct, (err, data) => {
    if (err) {
      console.log(err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while posting flash deal ."
      });
    }
    else {
      console.log("Posted Successfully");
      res.status(200).send({
        message: "Posted Successfully",
        output: data
      })
    }
  });
};

exports.putFlashDealProduct = (req, res) => {

  const flashDealproduct = new FlashDealProducts({
    flash_deal_id :  req.body.flash_deal_id || null,
    product_id :  req.body.product_id || null,
    discount :  req.body.discount || null,
    discount_type :  req.body.discount_type || null,
  });

  FlashDealProducts.putFlashDealProduct (req.params.id, flashDealproduct, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found flash deal with id ${req.params.id}.`
        });
      }
    }
    else {
      res.statusCode = 200;
      res.send("Flash deal updated Succesfully");
    }
});
};

exports.getFlashDealProductID = (req, res) => {
  FlashDealProducts.getFlashDealProductID(req.params.id, (err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
    else res.send(data);
  });
};

exports.deleteFlashDealProduct = (req, res) => {
  FlashDealProducts.deleteFlashDealProduct( req.params.id, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found flash deal with id ${req.params.id}.`
        });
      }
    }
    else {
      res.statusCode = 200;
      res.send("Flash deal deleted Succesfully");
    }
});
};