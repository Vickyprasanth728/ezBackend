const Option = require("../models/option.model.js");
const path = require("path");
const fs = require("fs");

exports.getOptions = (req, res) => {
    Option.getOptions((err, data) => {
      if (err)
      res.status(401).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
      else 
      res.status(200).send({
        status:(200),
        message:"Success",
        Data:data
      })
    });
  };

  exports.saveOption = (req, res) => {
  
    const Options = new Option({
      id: req.body.id,
      option_name: req.body.option_name,
      added_by: req.body.added_by,
    });
  
    Option.saveOption( Options, (err, data) => {
      if (err) {
        console.log(err)
        res.status(401).send({
          message:
            err.message || "Some error occurred while posting Option  ."
        });
      }
      else {
        console.log("Posted Successfully");
        res.status(200).send({
          message: "Posted Successfully",
          output: data
        })
      }
    });
  };


  exports.putOption = (req, res) => {

    const Options = new Option({
         option_name : req.body.option_name || null,
         added_by : req.body.added_by || null,
    });
  
    Option.putOption (req.params.id, Options, (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(401).send({
            message: `Not found Option with id ${req.params.id}.`
          });
        }
      }
      else {
        res.status(200).send({
            status:(200),
            message:"Success",
            Data:data
          })
      }
  });
  };

  exports.getOptionEdit = (req, res) => {
    Option.getOptionEdit (req.params.id, (err, data) => {
      if (err)
        res.status(401).send({
          message:
            err.message || "Some error occurred while retrieving data."
        });
      else 
      res.status(200).send({
        status:(200),
        message:"Success",
        Data:data
      })
    });
  };

  exports.deleteOption = (req, res) => {
    Option.deleteOption (req.params.id, (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(401).send({
            message: `Not found Option with id ${req.params.id}.`
          });
        }
      }
      else {
        res.status(200).send({
            status:(200),
            message:"Success",
          })
      }
  });
};