const SalesList = require("../models/sales.model.js");
const { Validator } = require('node-input-validator');

// Sales List
exports.getAllOrdersList = (req, res) => {
  SalesList.getAllOrdersList((err, data) => {
    if (err)
      res.status(401).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
    else
      res.status(200).send({
        status: (200),
        message: "Success",
        Data: data
      })
  });
};

// Order Details
exports.getAllOrderDetailsID = (req, res) => {
  SalesList.getAllOrderDetailsID(req.params.id, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(401).send({
          status: (401),
          message: `Not found order detail with id ${req.params.id}.`
        });
      }
    }
    else {
      res.status(200).send({
        status: (200),
        message: "Success",
        Data: data
      })
    }
  });
};

// InHouse Orders
exports.getInhouseOrders = (req, res) => {
  SalesList.getInhouseOrders((err, data) => {
    if (err)
      res.status(401).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
    else
      res.status(200).send({
        status: (200),
        message: "Success",
        Data: data
      })
  });
};

// Seller Orders
exports.getSellerOrders = (req, res) => {
  SalesList.getSellerOrders((err, data) => {
    if (err)
      res.status(401).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
    else
      res.status(200).send({
        status: (200),
        message: "Success",
        Data: data
      })
  });
};
// Pick-Point Orders
exports.getPickPointOrders = (req, res) => {
  SalesList.getPickPointOrders((err, data) => {
    if (err)
      res.status(401).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
    else
      res.status(200).send({
        status: (200),
        message: "Success",
        Data: data
      })
  });
};

// Sales ID
exports.getSalesListID = (req, res) => {
  SalesList.getSalesListID(req.params.id, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(401).send({
          status: (401),
          message: `Not found order with id ${req.params.id}.`
        });
      }
    }
    else {
      res.status(200).send({
        status: (200),
        message: "Success",
        Data: data
      })
    }
  });
};

// Delete Order List
exports.deleteSalesList = (req, res) => {
  SalesList.deleteSalesList(req.params.id, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(401).send({
          message: `Not found order with id ${req.params.id}.`
        });
      }
    }
    else {
      res.statusCode = 200;
      res.send("Order Deleted Succesfully");
    }
  });
};


exports.saveOrder = (async (req, res) => {
  const validate = new Validator(req.body, {
    payment_status: 'required|minLength:1|maxLength:50',
    delivery_status: 'required|minLength:1|maxLength:50',
    shipping_type: 'required|minLength:1|maxLength:50',
    grand_total: 'required|minLength:2|maxLength:10',
  });

  validate.check().then(async (matched) => {
    if (!matched) {
      // res.status(422).send(validate.errors);
      res.status(422).send({
        status: (422),
        message: "Errors",
        errors: (validate.errors)
      })
    }

    else {

      const orders = new SalesList({
        id: req.body.id,
        combined_order_id: req.body.combined_order_id || null,
        user_id: req.body.user_id || null,
        guest_id: req.body.guest_id || null,
        seller_id: req.body.seller_id || null,
        shipping_address: req.body.shipping_address || null,
        additional_info: req.body.additional_info || null,
        shipping_type: req.body.shipping_type || null,
        pickup_point_id: req.body.pickup_point_id || null,
        carrier_id: req.body.carrier_id || null,
        delivery_status: req.body.delivery_status || null,
        payment_type: req.body.payment_type || null,
        payment_status: req.body.payment_status || null,
        payment_details: req.body.payment_details || null,
        grand_total: req.body.grand_total || null,
        coupon_discount: req.body.coupon_discount || null,
        code: req.body.code || null,
        tracking_code: req.body.tracking_code || null,
        date: req.body.date || null,
        viewed: req.body.viewed || null,
        delivery_viewed: req.body.delivery_viewed || null,
        payment_status_viewed: req.body.payment_status_viewed || null,
        commission_calculated: req.body.commission_calculated || null,
      });

      SalesList.saveOrder(orders, (err, data) => {
        if (err) {
          console.log(err)
          res.status(401).send({
            message:
              err.message || "Some error occurred while posting Orders ."
          });
        }
        else {
          console.log("Posted Successfully");
          res.status(200).send({
            message: "Posted Successfully",
            output: orders
          })
        }
      });
    }
  })
});

exports.updateOrder = (async (req, res) => {
  const validate = new Validator(req.body, {
    payment_status: 'required|minLength:1|maxLength:50',
    delivery_status: 'required|minLength:1|maxLength:50',
    shipping_type: 'required|minLength:1|maxLength:50',
    grand_total: 'required|minLength:2|maxLength:10',
  });

  validate.check().then(async (matched) => {
    if (!matched) {
      // res.status(422).send(validate.errors);
      res.status(422).send({
        status: (422),
        message: "Errors",
        errors: (validate.errors)
      })
    }

    else {
      const orders = new SalesList({
        id: req.body.id,
        combined_order_id: req.body.combined_order_id,
        user_id: req.body.user_id,
        guest_id: req.body.guest_id,
        seller_id: req.body.seller_id,
        shipping_address: req.body.shipping_address,
        additional_info: req.body.additional_info,
        shipping_type: req.body.shipping_type,
        pickup_point_id: req.body.pickup_point_id,
        carrier_id: req.body.carrier_id,
        delivery_status: req.body.delivery_status,
        payment_type: req.body.payment_type,
        payment_status: req.body.payment_status,
        payment_details: req.body.payment_details,
        grand_total: req.body.grand_total,
        coupon_discount: req.body.coupon_discount,
        code: req.body.code,
        tracking_code: req.body.tracking_code,
        date: req.body.date,
        viewed: req.body.viewed,
        delivery_viewed: req.body.delivery_viewed,
        payment_status_viewed: req.body.payment_status_viewed,
        commission_calculated: req.body.commission_calculated,
      });

      SalesList.updateOrder(req.params.id, orders, (err, data) => {
        if (err) {
          if (err.kind === "not_found") {
            res.status(404).send({
              message: `Not found orders with id ${req.params.id}.`
            });
          }
        }
        else {
          res.status(200).send({
            status: (200),
            message: "Success",
            Data: orders
          })
        }
      });
    }
  })
});