var nodemailer = require('nodemailer');
const dbConfig = require("../config/db.config.js");
const mailer = require("../customerModels/mailer.models.js");
const Users = require("../models/user.model.js");
// const mailer = require("../models/");
const util = require('util');
const sql = require("../models/db");

exports.mail = (async(req, res) => {
 
  var transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: 'mobile.vriksha@gmail.com',
      pass: 'Win@vriksha2022'
    }
  });
  
  var mailOptions = {
    from: 'mobile.vrikshatech@gmail.com',
    to: 'dev.vriksha@gmail.com',
    subject: 'Sending Email using Node.js',
    text: 'That was easy!'
  };
  
  transporter.sendMail(mailOptions, function(error, info){
    if (error) {
      console.log(error);
    } else {
      console.log('Email sent: ' + info.response);
    }
  });

  //   let transporter = nodemailer.createTransport({
  //     host: dbConfig.smtpHost,
  //     port: dbConfig.smtpPort,
  //     auth: {
  //       user: dbConfig.smtpUserName,
  //       pass: dbConfig.smtpPassword,
  //     },
  //   });
  //   let message = {
  //     from: "kumar.venkat@vrikshatech.in",
  //     to: "nirmal@vrikshatech.com",
  //     subject: "Send Test Mail",
  //     html:
  //       "<h3>Project Id: </h3>" +
  //       "PJT342424" +
  //       "<h3>Project Name:</h3>" +
  //       "Test Project" +
  //       "<h3>Project City:</h3>",
  //   };
  // transporter.sendMail(message);
  // res.statusCode = 200;
  // res.send("Mail Sent Succesfully");
});

exports.NewsletterMail1 = (async (req, res) => {
    const query = util.promisify(sql.query).bind(sql);
    const userIdFetch = await query(`select id, email from users where email='${req.body.email}' limit 1`);
    const user_email = userIdFetch[0] ? userIdFetch[0]["email"] : 0
    x = userIdFetch.length
    if (!req.body) {
      res.status(400).send({
        message: "Email Cannot be Empty"
      });
    }
    // if (x == 0 ) {
    //   res.send({ message: "User does not exists" })
    // }
    else {
      console.log(user_email)
      console.log(userIdFetch)
      let url = {
        from: "dev.vrikshatech@gmail.com",
        to: user_email,
        subject: "sending mail ",
        html: '',
      };
      mailer.sendMail(url,(err, user_email) => {
        if (err) {
          console.log(0)
          res.statusCode = 200;
          res.send({message: "Mail sent to the email", email: user_email});
        }
      });
    }
  });

  exports.NewsletterMail = (req, res) => {
    // Validate request
    if(!req.body.email) {
        return res.status(400).send({
            message: "Fields can not be empty"
        });
    }

    const users = new Users({
        email: req.body.email, 
    });

    mailer.sendMail(users,(err, email) => {
      if (err) {
        console.log(0)
        res.statusCode = 200;
        res.send({message: "Mail sent to the email", email: users});
        console.log("Mail sent to the email", users)

      }
    });
};

//   exports.NewsletterMail = (req, res) => {
//     // Validate request
//     if(!req.body.content) {
//         return res.status(400).send({
//             message: "Fields can not be empty"
//         });
//     }

//     // Set options after the request was verified.

//     const smtpTransport = nodemailer.createTransport({
//         service: 'Gmail',
//         port: 465,
//         auth: {
//           user: 'YOUR_GMAIL_SERVER',
//           pass: 'YOUR_GMAIL_PASSWORD'
//         }
//     });

//     const listing = new Listing({
//         title: req.body.title, 
//         city: req.body.city,
//         street: req.body.street,
//         businessname: req.body.businessname,
//         description: req.body.description
//     });

//     listing.save()
//     .then(data => new Promise((resolve, reject) => {
//       var mailOptions = {
//         to: data.email,
//         subject: 'ENTER_YOUR_SUBJECT',
//         html: `<p>${data.title}</p>
//               <p>${data.city}</p>
//               <p>${data.street}</p>`,
//       };

//       smtpTransport.sendMail(mailOptions,
//         (error, response) => {
//           if (error) {
//             reject(error);
//           } else {
//             resolve(data);
//           }

//         });

//     }))
//     .then(data => {
//       smtpTransport.close(); // this awaited the actual send
//       res.send(data); 
//     })
//     .catch(err => {
//         res.status(500).send({
//             message: err.message || "Some error occurred while creating the listing."
//         });
//     });
// };