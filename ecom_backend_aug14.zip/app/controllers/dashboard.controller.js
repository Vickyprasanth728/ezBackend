const Dashboard = require("../models/dashboard.model.js");

exports.getAdminDashboard = (req, res) => {
  Dashboard.getAdminDashboard(req.params.keyword, (err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving lead count."
      });
    else res.send(data);
  });
};
