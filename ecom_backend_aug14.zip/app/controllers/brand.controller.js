const Brand = require("../models/brand.model.js");
const BrandTranslation = require("../models/brandTranslation.model.js");
const { Validator } = require('node-input-validator');
const path = require("path");
const fs = require("fs");

function keyGen(keyLength) {
  var i, key = "", characters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

  var charactersLength = characters.length;

  for (i = 0; i < keyLength; i++) {
    key += characters.substr(Math.floor((Math.random() * charactersLength) + 1), 1);
  }

  return key;
}

exports.getBrand = (req, res) => {
    Brand.getBrand((err, data) => {
      if (err)
      res.status(401).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
      else 
      res.status(200).send({
        status:(200),
        message:"Success",
        Data:data
      })
    });
  };

  // exports.saveBrand = (req, res) => {

  //   let logo = "";
    
  //   if (req.files.logo) {
  //     const extension = req.files.logo[0]["mimetype"].split('/')[1]
  //     logo = req.files.logo[0]["filename"] + '.' + extension
  //     logo = req.files.logo[0]["originalname"]
  //   }

  //   const brand = new Brand({
  //     id: req.body.id ,
  //     name: req.body.name || null,
  //     logo: logo || null,
  //     top : req.body.top || "0" ,
  //     slug : req.body.slug || "0" ,
  //     meta_title: req.body.meta_title || null,
  //     meta_description: req.body.meta_description || null,
  //   });
  
  //   Brand.saveBrand( brand, (err, data) => {
  //     if (err) {
  //       console.log(err)
  //       res.status(401).send({
  //         message:
  //           err.message || "Some error occurred while posting brands  ."
  //       });
  //     }
  //     else {

  //       let brandId = data.insertId

  //       if (req.files.logo) {
  //         //move profile image
  //         const currentPath = path.join(process.cwd(), "uploads", req.files.logo[0]["filename"]);
  //         const destinationPath = path.join(process.cwd(), "uploads/brand/logo/" + `${brandId}`, logo);
  
  //         const baseUrl = process.cwd() + '/uploads/brand/logo/' + `${brandId}`
  //         fs.mkdirSync(baseUrl, { recursive: true })
  //         fs.rename(currentPath, destinationPath, function (err) {
  //           if (err) {
  //             throw err
  //           } else {
  //             console.log("Successfully moved the Logo !")
  //           }
  //         });
  //       }

  //       const brandTranslation = new BrandTranslation({
  //         brand_id :  brandId,
  //         name :  req.body.name,
  //         lang :  req.body.lang || "EN",
  //       });
  
  //       BrandTranslation.saveBrandTranslation(brandTranslation, (err, data) => {
  //         if (err) {
  //           console.log(err)
  //           console.log("Brand Translation posted successfully");
  //           console.log("Posted Successfully");
  //           res.statusCode = 200;
  //         }
  //       });

  //       res.status(200).send({
  //         status:(200),
  //         message:"Success",
  //         Data:data
  //       })
  //     }
  //   });
  // };


  exports.saveBrand = (async (req, res) => {

    let logo = "";
    
    if (req.files.logo) {
      const extension = req.files.logo[0]["mimetype"].split('/')[1]
      logo = req.files.logo[0]["filename"] + '.' + extension
      logo = req.files.logo[0]["originalname"]
    }

    const validate = new Validator(req.body, {
      name: 'required|minLength:1|maxLength:50',
      // top: 'alphaNumeric|minLength:1|maxLength:10',
      // slug: 'minLength:1|maxLength:50',
      // meta_title: 'minLength:1|maxLength:50',
      // meta_description: 'minLength:1|maxLength:50',
    });

    validate.check().then(async (matched) => {
      if (!matched) {
        // res.status(422).send(VALID.errors);
        res.status(422).send({
          status:(422),
          message:"Errors",
          errors: (validate.errors)
        })
      }

      else {
        let x = req.body.name+"-"+keyGen(req.body.name.length = 3);
        const brand = new Brand({
          id: req.body.id ,
          name: req.body.name,
          logo: logo || null, 
          top : req.body.top || "0" ,
          slug : x ,
          meta_title: req.body.meta_title || null,
          meta_description: req.body.meta_description || null,
        });

        Brand.saveBrand( brand, (err, data) => {
          if (err) {
            console.log(err)
            res.status(401).send({
              message:
                err.message || "Some error occurred while posting brands  ."
            });
          }
          else {
    
            let brandId = data.insertId
    
            if (req.files.logo) {
              const currentPath = path.join(process.cwd(), "uploads", req.files.logo[0]["filename"]);
              const destinationPath = path.join(process.cwd(), "uploads/brand/logo/" + `${brandId}`, logo);
      
              const baseUrl = process.cwd() + '/uploads/brand/logo/' + `${brandId}`
              fs.mkdirSync(baseUrl, { recursive: true })
              fs.rename(currentPath, destinationPath, function (err) {
                if (err) {
                  throw err
                } else {
                  console.log("Successfully moved the Logo !")
                }
              });
            }
            res.status(200).send({
              status:(200),
              message:"Success",
              Output: brand
            })
          }
        });
      }
    })
  });

  exports.putBrand =(async (req, res) => {

    let logo = "";
    
    if (req.files.logo) {
      const extension = req.files.logo[0]["mimetype"].split('/')[1]
      logo = req.files.logo[0]["filename"] + '.' + extension
      logo = req.files.logo[0]["originalname"]
    }

    const validate = new Validator(req.body, {
      name: 'required|minLength:1|maxLength:50',
      // top: 'alphaNumeric|minLength:1|maxLength:10',
      // slug: 'minLength:1|maxLength:50',
      // meta_title: 'minLength:10|maxLength:50',
      // meta_description: 'minLength:10|maxLength:50',
    });

    validate.check().then(async (matched) => {
      if (!matched) {
        // res.status(422).send(VALID.errors);
        res.status(422).send({
          status:(422),
          message:"Errors",
          errors: (validate.errors)
        })
      }
      else {
        
        const brand = new Brand({
          name : req.body.name,
          logo : logo,
          top : req.body.top || "0",
          slug : req.body.slug ,
          meta_title : req.body.meta_title,
          meta_description : req.body.meta_description,
        });

    let brandId = req.params.id
    Brand.putBrand (req.params.id, brand, (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(401).send({
            message: `Not found brand with id ${req.params.id}.`
          });
        }
      }
      else {

        if (req.files.logo) {
          const currentPath = path.join(process.cwd(), "uploads", req.files.logo[0]["filename"]);
          const destinationPath = path.join(process.cwd(), "/uploads/brand/logo/" + `${brandId}`, logo);
          const baseUrl = process.cwd() + '/uploads/brand/logo/' + `${brandId}`
          fs.mkdirSync(baseUrl, { recursive: true })
          fs.rename(currentPath, destinationPath, function (err) {
            if (err) {
              throw err
            } else {
              console.log("Successfully moved the logo images !")
            }
          });
        }
        res.status(200).send({
          status:(200),
          message:"Success",
          Data:brand
        })
      }
    }
    ) }
  });
  });


  // exports.putBrand = (req, res) => {

  //   let logo = ""

  //   if (req.files.logo) {
  //     const extension = req.files.logo[0]["mimetype"].split('/')[1]
  //     logo = req.files.logo[0]["filename"] + '.' + extension
  //     logo = req.files.logo[0]["originalname"]
  //   }

  //   const brand = new Brand({
  //     name : req.body.name || null,
  //     logo : logo|| null,
  //     top : "0" ,
  //     slug : "0" ,
  //     meta_title : req.body.meta_title || null,
  //     meta_description : req.body.meta_description || null,
  //   });

  //   let brandId = req.params.id
  //   Brand.putBrand (req.params.id, brand, (err, data) => {
  //     if (err) {
  //       if (err.kind === "not_found") {
  //         res.status(401).send({
  //           message: `Not found brand with id ${req.params.id}.`
  //         });
  //       }
  //     }
  //     else {

  //       if (req.files.logo) {

  //         const currentPath = path.join(process.cwd(), "uploads", req.files.logo[0]["filename"]);
  //         const destinationPath = path.join(process.cwd(), "/uploads/brand/logo/" + `${brandId}`, logo);
  //         const baseUrl = process.cwd() + '/uploads/brand/logo/' + `${brandId}`
  //         fs.mkdirSync(baseUrl, { recursive: true })
  //         fs.rename(currentPath, destinationPath, function (err) {
  //           if (err) {
  //             throw err
  //           } else {
  //             console.log("Successfully moved the logo images !")
  //           }
  //         });
  //       }

  //       // const brandtranslation = new BrandTranslation({
  //       //   brand_id : brandId || null ,
  //       //   name : req.body.name || null ,
  //       //   lang : req.body.lang || null ,
  //       // });

  //       // BrandTranslation.putBrandTranslation (brandId , brandtranslation, (err, data) => {
  //       //   if (err) {
  //       //     if (err.kind === "not_found") {
  //       //       res.status(401).send({
  //       //         message: `Not found with brand id ${brandId}.`
  //       //       });
  //       //     }
  //       //   }
  //       // })

  //       res.status(200).send({
  //         status:(200),
  //         message:"Success",
  //         Data:data
  //       })
  //     }
  // });
  // };

  exports.getBrandID = (req, res) => {
    Brand.getBrandID(req.params.id, (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(401).send({
            status:(401),
            message: `Not found brand with id ${req.params.id}.`
          });
        }
      }
      else {
        res.status(200).send({
          status:(200),
          message:"Success",
          Data:data
        })
      }
  });
};

  exports.deleteBrand = (req, res) => {
    Brand.deleteBrand( req.params.id, (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(401).send({
            message: `Not found brand with id ${req.params.id}.`
          });
        }
      }
      else {
        res.status(200).send({
          status:(200),
          message:"Success",
        })
      }
  });
};