const CustomerPayment = require("../customerModels/custPayment.models.js");

// Customer Payment
exports.getCustomerPayment = (req, res) => {
  CustomerPayment.getCustomerPayment((err, data) => {
  if (err)
    res.status(500).send({
      message:
        err.message || "Some error occurred while retrieving data."
    });
  else res.send(data);
});
};

exports.saveCustomerPayment = (req, res) => {

    const customerPayment = new CustomerPayment({
        id : req.body.id,
        user_id : req.body.user_id,
        customer_package_id : req.body.customer_package_id,
        payment_method : req.body.payment_method	,
        payment_details : req.body.payment_details,
        approval : req.body.approval,
        offline_payment : req.body.offline_payment,
        reciept : req.body.reciept	
   });
  
   CustomerPayment.saveCustomerPayment ( customerPayment, (err, data) => {
      if (err) {
        console.log(err)
        res.status(500).send({
          message:
            err.message || "Some error occurred while posting Customer Payment  ."
        });
      }
      else {
        console.log("Posted Successfully");
        res.status(200).send({
          message: "Posted Successfully",
          output: data
        })
      }
    });
  };