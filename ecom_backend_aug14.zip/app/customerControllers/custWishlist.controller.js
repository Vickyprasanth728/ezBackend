const custWishlists = require("../customerModels/custWishlist.models.js");

// custWishlists
exports.getWishlists = (req, res) => {
    custWishlists.getWishlists(req.params.user_id, (err, data) => {
    if (err)
    res.status(401).send({
      message:
        err.message || "Some error occurred while retrieving data."
    });
    else
    res.status(200).send({
      status:(200),
      message:"Success",
      Data:data
    })
  });
};

exports.saveWishlist = (req, res) => {

    const custWishlist = new custWishlists({
        id : req.body.id,
        user_id : req.body.user_id,
        product_id : req.body.product_id,
   });
  
    custWishlists.saveWishlist ( custWishlist , (err, data) => {
      if (err) {
        console.log(err)
        res.status(401).send({
          message:
            err.message || "Some error occurred while posting cust wishlists  ."
        });
      }
      else {
        console.log("Posted Successfully");
        res.status(200).send({
          message: "Posted Successfully",
          output: custWishlist
        })
      }
    });
  };

exports.deleteWishlist = (req, res) => {
    custWishlists.deleteWishlist ( req.params.id, (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(401).send({
            message: `Not found wishlists with id ${req.params.id}.`
          });
        }
      }
      else {
        res.status(200).send({
          status:(200),
          message:"Success",
        })
      }
  });
};