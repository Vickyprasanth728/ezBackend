const Carts = require("../customerModels/carts.model");
const path = require("path");
const fs = require("fs");

exports.getCarts = (req, res) => {
    Carts.getCarts((err, data) => {
      if (err)
      res.status(401).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
      else 
      res.status(200).send({
        status:(200),
        message:"Success",
        Data:data
      })
    });
  };

  exports.saveCart = (req, res) => {

    const carts = new Carts({
        owner_id : req.body.owner_id,
        user_id : req.body.user_id,
        temp_user_id : req.body.temp_user_id ,
        address_id : req.body.address_id || null,
        product_id : req.body.product_id ,
        variation : req.body.variation ,
        price : req.body.price || null,
        tax : req.body.tax || null,
        shipping_cost : req.body.shipping_cost || null,
        shipping_type : req.body.shipping_type || null,
        pickup_point : req.body.pickup_point ,
        carrier_id : req.body.carrier_id ,
        discount : req.body.discount || null,
        product_referral_code : req.body.product_referral_code ,
        coupon_code : req.body.coupon_code ,
        coupon_applied : req.body.coupon_applied || null,
        quantity : req.body.quantity || null,
   });
  
    Carts.saveCart ( carts, (err, data) => {
      if (err) {
        console.log(err)
        res.status(401).send({
          message:
            err.message || "Some error occurred while posting carts."
        });
      }
      else {
        console.log("Posted Successfully");
        res.status(200).send({
          message: "Posted Successfully",
          output: carts
        })
      }
    });
  };

  exports.putCart = (req, res) => {

  const carts = new Carts({
      owner_id : req.body.owner_id,
      user_id :  req.body.user_id,
      temp_user_id : req.body.temp_user_id,
      address_id : req.body.address_id	,
      product_id : req.body.product_id,
      variation : req.body.variation,
      price : req.body.price,
      tax : req.body.tax,
      shipping_cost : req.body.shipping_cost,
      shipping_type : req.body.shipping_type,
      pickup_point : req.body.pickup_point,
      carrier_id : req.body.carrier_id,
      discount : req.body.discount,
      product_referral_code : req.body.product_referral_code,
      coupon_code : req.body.coupon_code,
      coupon_applied : req.body.coupon_applied,
      quantity : req.body.quantity,
  });

    Carts.putCart (req.params.id, carts, (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(401).send({
            message: `Not found carts with id ${req.params.id}.`
          });
        }
      }
      else {
        res.status(200).send({
          status:(200),
          message:"Success",
          Data: carts
        })
      }
  });
  };

  exports.getCartID = (req, res) => {
    Carts.getCartID(req.params.id, (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(401).send({
            status:(401),
            message: `Not found cart with id ${req.params.id}.`
          });
        }
      }
      else {
        res.status(200).send({
          status:(200),
          message:"Success",
          Data:data
        })
      }
  });
};

  exports.deleteCart = (req, res) => {
    Carts.deleteCart ( req.params.id, (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(401).send({
            message: `Not found cart with id ${req.params.id}.`
          });
        }
      }
      else {
        res.status(200).send({
          status:(200),
          message:"Success",
        })
      }
  });
};