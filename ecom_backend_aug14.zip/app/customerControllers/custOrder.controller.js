const Orders = require("../customerModels/custOrder.model.js");
const OrderDetails = require("../customerModels/custOrderDetails.models.js");
const CustomerPayment = require("../customerModels/custPayment.models.js");
const Carts = require("../customerModels/carts.model.js");

// orders List
exports.getCustOrders = (req, res) => {
  Orders.getCustOrders(req.params.user_id, (err, data) => {
    if (err)
      res.status(401).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
    else         
      res.status(200).send({
        status:(200),
        message:"Success",
        Data:data
      })
  });
};

exports.saveCustOrder = (req, res) => {

  const orders = new Orders({
    id: req.body.id,
    combined_order_id: req.body.combined_order_id,
    user_id: req.body.user_id,
    guest_id: req.body.guest_id,
    seller_id: req.body.seller_id,
    shipping_address: req.body.shipping_address,
    additional_info: req.body.additional_info,
    shipping_type: req.body.shipping_type,
    pickup_point_id: req.body.pickup_point_id,
    carrier_id: req.body.carrier_id,
    delivery_status: req.body.delivery_status,
    payment_type: req.body.payment_type,
    payment_status: req.body.payment_status,
    payment_details: req.body.payment_details,
    grand_total: req.body.grand_total,
    coupon_discount: req.body.coupon_discount,
    code: req.body.code,
    tracking_code: req.body.tracking_code,
    date: req.body.date,
    viewed: req.body.viewed,
    delivery_viewed: req.body.delivery_viewed,
    payment_status_viewed: req.body.payment_status_viewed,
    commission_calculated: req.body.commission_calculated,
  });

  Orders.saveCustOrder(orders, (err, data) => {
    if (err) {
      console.log(err)
      res.status(401).send({
        message:
          err.message || "Some error occurred while posting Orders  ."
      });
    }
    else {

      let userId = req.body.user_id
      let paymentDetails = req.body.payment_details
      let paymentMethod = req.body.payment_type

      const customerPayment = new CustomerPayment({
        user_id: userId,
        customer_package_id: req.body.customer_package_id,
        payment_method: paymentMethod,
        payment_details: paymentDetails,
        approval: req.body.approval,
        offline_payment: req.body.offline_payment,
        reciept: req.body.reciept
      });

      let orderId = data.insertId
      let sellerId = req.body.seller_id
      let deliveryStatus = req.body.delivery_status
      let shippingType = req.body.shipping_type
      let paymentStatus = req.body.payment_status
      let priceId = req.body.grand_total
      let pickpintId = req.body.pickup_point_id

      const orderDetails = new OrderDetails({
        order_id: orderId,
        seller_id: sellerId,
        product_id: req.body.product_id,
        variation: req.body.variation,
        price: priceId,
        tax: req.body.tax,
        shipping_cost: req.body.shipping_cost,
        quantity: req.body.quantity,
        payment_status: paymentStatus,
        delivery_status: deliveryStatus,
        shipping_type: shippingType,
        pickup_point_id: pickpintId,
        product_referral_code: req.body.product_referral_code,
      });
      CustomerPayment.saveCustomerPayment(customerPayment, (err, data) => {
        if (err) {
          console.log(err)
          console.log("Customer Payment posted successfully");
          console.log("Posted Successfully");
          res.status(200).send({
            message: "Posted Successfully",
            output: customerPayment
          })
        }
      });
      OrderDetails.saveCustOrderDetail(orderDetails, (err, data) => {
        if (err) {
          console.log(err)
          console.log("Order Details posted successfully");
          console.log("Posted Successfully");
          res.status(200).send({
            message: "Posted Successfully",
            output: orderDetails
          })
        }
      });
      Carts.deleteAllCarts((err, data) => {
        if (err) {
          console.log(err)
          console.log("Carts Deleted successfully");
          console.log("Deleted Successfully");
          res.status(200).send({
            status:(200),
            message:"Success",
          })
        }
      });
      console.log("Posted Successfully");
      res.status(200).send({
        message: "Posted Successfully",
        output: orders
      })
    }
  });
};

exports.getCustOrderID = (req, res) => {
  Orders.getCustOrderID(req.params.id, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(401).send({
          status:(401),
          message: `Not found order with id ${req.params.id}.`
        });
      }
    }
    else {
      res.status(200).send({
        status:(200),
        message:"Success",
        Data:data
      })
    }
});
};

exports.deleteCustOrder = (req, res) => {
  Orders.deleteCustOrder(req.params.id, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(401).send({
          message: `Not found orders with id ${req.params.id}.`
        });
      }
    }
    else {

      let orderId = req.params.id
      OrderDetails.deleteCustOrderDetails(orderId, (err, data) => {
        if (err) {
          if (err.kind === "not_found") {
            res.status(401).send({
              message: `Not found orders details with id ${orderId}.`
            });
          }
        }
      })
      res.status(200).send({
        status:(200),
        message:"Success",
      })
    }
  });
};

// Customer Orders View
exports.UpdateCustOrdersView = (req, res) => {
  Orders.UpdateCustOrdersView(req.params.keyword, req.params.id, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(401).send({
          message: `Not found orders View with id ${req.params.id}.`
        });
      }
    }
    else {
      res.statusCode = 200;
      res.send("Orders Viewed Succesfully");
    }
  });
};

exports.getCustOrdersTrack = (req, res) => {
  Orders.getCustOrdersTrack(req.query, (err, data) => {
    if (err)
      res.status(401).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
    else 
    res.status(200).send({
      status:(200),
      message:"Success",
      Data:data
    })
  });
};

// Orders Details 
exports.getOrderDetails = (req, res) => {
  OrderDetails.getOrderDetails((err, data) => {
    if (err)
      res.status(401).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
    else 
    res.status(200).send({
      status:(200),
      message:"Success",
      Data:data
    })
  });
};

exports.saveOrderDetail = (req, res) => {

  const orderDetails = new OrderDetails({
    id: req.body.id,
    order_id: req.body.order_id,
    seller_id: req.body.seller_id,
    product_id: req.body.product_id,
    variation: req.body.variation,
    price: req.body.price,
    tax: req.body.tax,
    shipping_cost: req.body.shipping_cost,
    quantity: req.body.quantity,
    payment_status: req.body.payment_status,
    delivery_status: req.body.delivery_status,
    shipping_type: req.body.shipping_type,
    pickup_point_id: req.body.pickup_point_id,
    product_referral_code: req.body.product_referral_code,
  });

  OrderDetails.saveOrderDetail(orderDetails, (err, data) => {
    if (err) {
      console.log(err)
      res.status(401).send({
        message:
          err.message || "Some error occurred while posting Order Details  ."
      });
    }
    else {
      console.log("Posted Successfully");
      res.status(200).send({
        message: "Posted Successfully",
        output: orderDetails
      })
    }
  });
};