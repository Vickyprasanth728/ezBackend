const CustNotifications = require("../customerModels/custNotification.models.js");

// Cust Notifications List
exports.getCustNotifications = (req, res) => {
    CustNotifications.getCustNotifications (req.params.notifiable_id, (err, data) => {
        if (err)
        res.status(500).send({
          message:
            err.message || "Some error occurred while retrieving data."
        });
        else res.send(data);
      });
    };
