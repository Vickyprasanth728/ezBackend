const CustShipping = require("../customerModels/custShipping.models.js");
const path = require("path");
const fs = require("fs");


// Shipping Address
exports.getCustShipping = (req, res) => {
  CustShipping.getCustShipping(req.params.user_id, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(401).send({
          status:(401),
          message: `Not found shipping customer ID with id ${req.params.user_id}.`
        });
      }
    }
    else {
      res.status(200).send({
        status:(200),
        message:"Success",
        Data:data
      })
    }
});
};

exports.saveCustShipping = (req, res) => {

  const address = new CustShipping({
      id : req.body.id,
      user_id : req.body.user_id,
      address : req.body.address,
      country_id : req.body.country_id,
      state_id : req.body.state_id,
      city_id : req.body.city_id,
      longitude : req.body.longitude,
      latitude : req.body.latitude,
      postal_code : req.body.postal_code,
      phone : req.body.phone,
      set_default : req.body.set_default
 });

 CustShipping.saveCustShipping ( address, (err, data) => {
    if (err) {
      console.log(err)
      res.status(401).send({
        message:
          err.message || "Some error occurred while posting Shipping Info  ."
      });
    }
    else {
      console.log("Posted Successfully");
      res.status(200).send({
        message: "Posted Successfully",
        output: address
      })
    }
  });
};

exports.putCustShipping = (req, res) => {

  const address = new CustShipping({
      id : req.body.id, 
      user_id : req.body.user_id, 
      address : req.body.address, 
      country_id : req.body.country_id, 
      state_id : req.body.state_id, 
      city_id : req.body.city_id, 
      longitude : req.body.longitude, 
      latitude : req.body.latitude, 
      postal_code : req.body.postal_code, 
      phone : req.body.phone, 
      set_default : req.body.set_default,
 });

  CustShipping.putCustShipping (req.params.id, address, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(401).send({
          message: `Not found shipping Info with id ${req.params.id}.`
        });
      }
    }
    else {
      res.status(200).send({
        status:(200),
        message:"Success",
        Data: address
      })
    }
});
};

exports.getCustShippingID = (req, res) => {
  CustShipping.getCustShippingID(req.params.id, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(401).send({
          status:(401),
          message: `Not found shipping ID with id ${req.params.id}.`
        });
      }
    }
    else {
      res.status(200).send({
        status:(200),
        message:"Success",
        Data:data
      })
    }
});
};

exports.deleteCustShipping = (req, res) => {
  CustShipping.deleteCustShipping ( req.params.id, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(401).send({
          message: `Not found Shipping Info with id ${req.params.id}.`
        });
      }
    }
    else {
      res.status(200).send({
        status:(200),
        message:"Success",
      })
    }
});
};

exports.UpdateShippingDefault = (req, res) => {
  CustShipping.UpdateShippingDefault(req.params.keyword, req.params.id, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(401).send({
          message: `Not found Cust Shipping with id ${req.params.id}.`
        });
      }
    }
    else {
      res.status(200).send({
        status:(200),
        message:"Success",
        Data: data
      })
    }
  });
};

// Shipping State
exports.getCustShippingStates = (req, res) => {
  CustShipping.getCustShippingStates ((err, data) => {
  if (err)
    res.status(401).send({
      message:
        err.message || "Some error occurred while retrieving data."
    });
  else 
    res.status(200).send({
      status:(200),
      message:"Success",
      Data:data
    })
});
};

exports.getCustShippingStateID = (req, res) => {
  CustShipping.getCustShippingStateID(req.params.id, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(401).send({
          status:(401),
          message: `Not found state with id ${req.params.id}.`
        });
      }
    }
    else {
      res.status(200).send({
        status:(200),
        message:"Success",
        Data:data
      })
    }
});
};
  // Shipping City
  exports.getCustShippingCities = (req, res) => {
    CustShipping.getCustShippingCities ((err, data) => {
    if (err)
      res.status(401).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
    else 
      res.status(200).send({
        status:(200),
        message:"Success",
        Data:data
      })
  });
  };

  exports.getCustShippingCityID = (req, res) => {
    CustShipping.getCustShippingCityID(req.params.id, (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(401).send({
            status:(401),
            message: `Not found city with id ${req.params.id}.`
          });
        }
      }
      else {
        res.status(200).send({
          status:(200),
          message:"Success",
          Data:data
        })
      }
  });
};

  // Shipping Countries
exports.getCustShippingCountries = (req, res) => {
  CustShipping.getCustShippingCountries ((err, data) => {
  if (err)
    res.status(401).send({
      message:
        err.message || "Some error occurred while retrieving data."
    });
  else 
    res.status(200).send({
      status:(200),
      message:"Success",
      Data:data
    })
});
};

exports.getCustShippingCountryID = (req, res) => {
  CustShipping.getCustShippingCountryID(req.params.id, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(401).send({
          status:(401),
          message: `Not found country with id ${req.params.id}.`
        });
      }
    }
    else {
      res.status(200).send({
        status:(200),
        message:"Success",
        Data:data
      })
    }
});
};
