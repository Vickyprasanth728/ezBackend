const custProduct = require("../customerModels/custProducts.model.js");

// Cust Products
exports.getCustProducts = (req, res) => {
    custProduct.getCustProducts(req.query,(err, data) => {
      if (err)
        res.status(401).send({
          message:
            err.message || "Some error occurred while retrieving data."
        });
      else 
        res.status(200).send({
        status:(200),
        message:"Success",
        Data:data
      })
    });
  };

  exports.getCustProductID = (req, res) => {
    custProduct.getCustProductID(req.params.id, (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(401).send({
            status:(401),
            message: `Not found product with id ${req.params.id}.`
          });
        }
      }
      else {
        res.status(200).send({
          status:(200),
          message:"Success",
          Data:data
        })
      }
  });
};

exports.getProductsPriceRange = (req, res) => {
  custProduct.getProductsPriceRange(req.query,(err, data) => {
    if (err)
      res.status(401).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
    else 
        res.status(200).send({
        status:(200),
        message:"Success",
        Data:data
      })
  });
};
