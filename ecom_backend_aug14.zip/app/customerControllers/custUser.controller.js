const CustUser = require("../customerModels/custUser.models.js");
const fs = require("fs")
const path = require("path");
const util = require('util');
const sql = require("../models/db");
const dayjs = require('dayjs');
const nodemailer = require('nodemailer');
var md5 = require('md5');
const mailer = require("../customerModels/mailer.models.js");
const dbConfig = require("../config/db.config.js");
const jwt = require('jsonwebtoken');

function keyGen(keyLength) {
  var i, key = "", characters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

  var charactersLength = characters.length;

  for (i = 0; i < keyLength; i++) {
    key += characters.substr(Math.floor((Math.random() * charactersLength) + 1), 1);
  }

  return key;
}

exports.getCustUsers = (req, res) => {
    CustUser.getCustUsers ((err, data) => {
      if (err)
        res.status(401).send({
          message:
            err.message || "Some error occurred while retrieving data."
        });
      else 
      res.status(200).send({
        status:(200),
        message:"Success",
        Data:data
      })
    });
  };

  exports.saveCustUser = (async(req, res) => {

    const email_verify_time = req.body.email_verified_at
    let emailVerifyTime = ""
    if (email_verify_time) {
      let start = dayjs(req.body.email_verified_at);
      emailVerifyTime = start.format("YYYY-MM-DD h:mm:ss")
    } else {
      emailVerifyTime = ""
    }

    if (!req.body) {
      res.status(400).send({
        message: "Cust User Cannot be Empty"
      });
    }
  
    const query1 = util.promisify(sql.query).bind(sql);
    const executivesFetch = await query1(`select email from users where email='${req.body.email}' limit 1`);
    const executives = executivesFetch[0] ? executivesFetch[0]["exec"] : 0
    
    if(executives != 0){
      res.send("Email already exists");
    }
    else {
    let avatar = "";

    if (req.files.avatar) {
        const extension = req.files.avatar[0]["mimetype"].split('/')[1]
        avatar = req.files.avatar[0]["filename"] + '.' + extension
        avatar_original = req.files.avatar[0]["originalname"]
      }
  
     const hashedPassword = md5(req.body.password);

      const users = new CustUser({
        id: req.body.id,
        referred_by : req.body.referred_by || null,
        provider_id : req.body.provider_id || null,
        user_type :'customer',
        name : req.body.name,
        email : req.body.email ,
        email_verified_at : emailVerifyTime,
        verification_code : req.body.verification_code || null,
        new_email_verificiation_code : req.body.new_email_verificiation_code || null,
        password : hashedPassword,
        remember_token : keyGen(30),
        device_token : req.body.device_token || null,
        avatar : avatar || null,
        avatar_original : avatar_original || null ,
        address : req.body.address || null,
        country : req.body.country || null,
        state	 : req.body.state || null,
        city : req.body.city || null,
        postal_code : req.body.postal_code || null,
        phone : req.body.phone || null,
        balance : req.body.balance || null, 
        banned : req.body.banned || null,
        referral_code : req.body.referral_code || null,
        customer_package_id : req.body.customer_package_id || null,
        remaining_uploads : req.body.remaining_uploads || null,
      });
  
    CustUser.saveCustUser( users, (err, data) => {
      if (err) {
        console.log(err)
        res.status(401).send({
          message:
            err.message || "Some error occurred while posting cust users  ."
        });
      }
      else {

        let userId = data.insertId

        if (req.files.avatar) {
          
          const currentPath = path.join(process.cwd(), "uploads", req.files.avatar[0]["filename"]);
          const destinationPath = path.join(process.cwd(), "/uploads/users/avatar/" + `${userId}`, avatar);
          const baseUrl = process.cwd() + '/uploads/users/avatar/' + `${userId}`
          fs.mkdirSync(baseUrl, { recursive: true })
          fs.rename(currentPath, destinationPath, function (err) {
            if (err) {
              throw err
            } else {
              console.log("Successfully moved the avatar cust user files !")
            }
          });
        }

        console.log("Posted Successfully");
        res.status(200).send({
          message: "Posted Successfully",
          output: users
        })
      }
    });
  }
  });

  exports.putCustUser = (async(req, res) => {

    const email_verify_time = req.body.email_verified_at
    let emailVerifyTime = ""
    if (email_verify_time) {
      let start = dayjs(req.body.email_verified_at);
      emailVerifyTime = start.format("YYYY-MM-DD")
    } else {
      emailVerifyTime = " "
    }

    if (!req.body) {
      res.status(400).send({
        message: "User Cannot be Empty"
      });
    }
  
    const query1 = util.promisify(sql.query).bind(sql);
    const executivesFetch = await query1(`select email from users where email='${req.body.email}' limit 1`);
    const executives = executivesFetch[0] ? executivesFetch[0]["exec"] : 0
    
    if(executives != 0){
      res.send("Email already exists");
    }
    else {
    let avatar = "";

    if (req.files.avatar) {
      const extension = req.files.avatar[0]["mimetype"].split('/')[1]
      avatar = req.files.avatar[0]["filename"] + '.' + extension
      avatar_original = req.files.avatar[0]["originalname"]
    }

    const hashedPassword = md5(req.body.password);

    const users = new CustUser({
      id: req.body.id,
      referred_by : req.body.referred_by,
      provider_id : req.body.provider_id,
      user_type : 'customer',
      name : req.body.name,
      email : req.body.email ,
      email_verified_at : emailVerifyTime,
      verification_code : req.body.verification_code,
      new_email_verificiation_code : req.body.new_email_verificiation_code,
      password : hashedPassword,
      remember_token : keyGen(30),
      device_token : req.body.device_token,
      avatar : avatar,
      avatar_original : req.body.avatar_original,
      address : req.body.address,
      country : req.body.country,
      state	 : req.body.state,
      city : req.body.city,
      postal_code : req.body.postal_code,
      phone : req.body.phone,
      balance : req.body.balance,
      banned : req.body.banned,
      referral_code : req.body.referral_code,
      customer_package_id : req.body.customer_package_id,
      remaining_uploads : req.body.remaining_uploads,
    });
  
    let userId = req.params.id

    CustUser.putCustUser (req.params.id, users, (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(401).send({
            message: `Not found Cust User with id ${req.params.id}.`
          });
        }
      }
      else {

        if (req.files.avatar) {
          
          const currentPath = path.join(process.cwd(), "uploads", req.files.avatar[0]["filename"]);
          const destinationPath = path.join(process.cwd(), "/uploads/users/avatar/" + `${userId}`, avatar);
          const baseUrl = process.cwd() + '/uploads/users/avatar/' + `${userId}`
          fs.mkdirSync(baseUrl, { recursive: true })
          fs.rename(currentPath, destinationPath, function (err) {
            if (err) {
              throw err
            } else {
              console.log("Successfully moved the avatar Cust User files !")
            }
          });
        }

        res.status(200).send({
          status:(200),
          message:"Success",
          Data: users
        })
      }
  });
 }
});


exports.putCustProfile = (async(req, res) => {

  const email_verify_time = req.body.email_verified_at
  let emailVerifyTime = ""
  if (email_verify_time) {
    let start = dayjs(req.body.email_verified_at);
    emailVerifyTime = start.format("YYYY-MM-DD")
  } else {
    emailVerifyTime = " "
  }

  if (!req.body) {
    res.status(400).send({
      message: "User Cannot be Empty"
    });
  }

  const query1 = util.promisify(sql.query).bind(sql);
  const executivesFetch = await query1(`select email from users where email='${req.body.email}' limit 1`);
  const executives = executivesFetch[0] ? executivesFetch[0]["exec"] : 0
  
  if(executives != 0){
    res.send("Email already exists");
  }
  else {
  let avatar = "";

  if (req.files.avatar) {
    const extension = req.files.avatar[0]["mimetype"].split('/')[1]
    avatar = req.files.avatar[0]["filename"] + '.' + extension
    avatar_original = req.files.avatar[0]["originalname"]
  }

  const users = new CustUser({
    id: req.body.id || null,
    name : req.body.name || null,
    email : req.body.email  || null,
    password : req.body.password || null,
    avatar : avatar || null,
    avatar_original : req.body.avatar_original || null,
    phone : req.body.phone || null
  });

  let userId = req.params.id

  CustUser.putCustProfile (req.params.id, users, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(401).send({
          message: `Not found Cust User with id ${req.params.id}.`
        });
      }
    }
    else {

      if (req.files.avatar) {
        
        const currentPath = path.join(process.cwd(), "uploads", req.files.avatar[0]["filename"]);
        const destinationPath = path.join(process.cwd(), "/uploads/users/avatar/" + `${userId}`, avatar);
        const baseUrl = process.cwd() + '/uploads/users/avatar/' + `${userId}`
        fs.mkdirSync(baseUrl, { recursive: true })
        fs.rename(currentPath, destinationPath, function (err) {
          if (err) {
            throw err
          } else {
            console.log("Successfully moved the avatar Cust User files !")
          }
        });
      }
      res.status(200).send({
        status:(200),
        message:"Success",
        Data: users
      })
    }
});
}
});

  exports.getCustUserID = (req, res) => {
    CustUser.getCustUserID(req.params.id, (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(401).send({
            status:(401),
            message: `Not found user with id ${req.params.id}.`
          });
        }
      }
      else {
        res.status(200).send({
          status:(200),
          message:"Success",
          Data:data
        })
      }
  });
};

exports.deleteCustUser = (req, res) => {
    CustUser.deleteCustUser( req.params.id, (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(401).send({
            message: `Not found user with id ${req.params.id}.`
          });
        }
      }
      else {
        res.status(200).send({
          status:(200),
          message:"Success",
        })
      }
  });
};

// exports.verifyEmail = (async (req, res) => {

//   const query = util.promisify(sql.query).bind(sql);
//   const userIdFetch = await query(`select id, email from users where email='${req.body.email}' limit 1`);
//   const user_email = userIdFetch[0] ? userIdFetch[0]["email"] : 0
//   x = userIdFetch.length

//   if (!req.body) {
//     res.status(400).send({
//       message: "Email Cannot be Empty"
//     });
//   }
//   if (x == 0) {
//     res.send({ message: "User does not exists" })
//   }
//   else {
//     console.log(user_email)
//     let url = {
//       from: "Dev.vriksha@gmail.com",
//       to: user_email,
//       subject: "Verify Email",
//       html: '<p> You requested for email verification </p>'
//     };
//     // mailer.sendMail();
//     mailer.sendMail(url,(err, user_email) => {
//       if (err) {
//         console.log(1)
//         throw err
//       } else {
//         console.log(0)
//         res.statusCode = 200;
//         res.send({message: "email", email: user_email});
//       }
//     });
//   }
// });


exports.verifyEmail = (async (req, res) => {
  
  const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: 'mobile.vriksha@gmail.com',
      pass: 'Win@vriksha2022'
    }
  });	
  
  const mailConfigurations = {
    from: 'Dev.vriksha@gmail.com',
    to: 'custie.vriksha@gmail.com',
    subject: 'Email Verification',
    text: ` Hi! There, You have recently visited `
  };
  
  transporter.sendMail(mailConfigurations, function(error, info){
    if (error) {
      console.log(error);
    } else {
      console.log(info.response);
    }
  });
});
