const custDashboard = require("../customerModels/custDashboard.model.js");

exports.getCustDashboard = (req, res) => {
    custDashboard.getCustDashboard(req.params.keyword, req.params.user_id, (err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving lead count."
      });
    else res.send(data);
  });
};