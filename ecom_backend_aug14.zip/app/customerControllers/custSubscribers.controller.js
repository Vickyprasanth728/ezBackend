const Subscribers = require("../customerModels/custSubscribers.models.js");

  exports.saveCustSubscribers = (req, res) => {
    const subscribers = new Subscribers({
        id : req.body.id ,
        email : req.body.email
   });
  
    Subscribers.saveCustSubscribers ( subscribers, (err, data) => {
      if (err) {
        console.log(err)
        res.status(500).send({
          message:
            err.message || "Some error occurred while posting subscribers."
        });
      }
      else {
          console.log("Posted Successfully");
          res.status(200).send({
          message: "Posted Successfully",
          output: data
        })
      }
    });
  };