const CustReviews = require("../customerModels/custReviews.models.js");

// Customer Reviews
exports.getCustReviews = (req, res) => {
    CustReviews.getCustReviews((err, data) => {
  if (err)
    res.status(401).send({
      message:
        err.message || "Some error occurred while retrieving data."
    });
  else
    res.status(200).send({
      status:(200),
      message:"Success",
      Data:data
    })
  });
};

exports.saveCustReview = (req, res) => {

    const reviews = new CustReviews({
      id : req.body.id,
      product_id : req.body.product_id,
      user_id : req.body.user_id,
      rating : req.body.rating || null,
      comment : req.body.comment,
      approval : req.body.approval,
      status : req.body.status || null,
      viewed : req.body.viewed || null	
   });
  
   CustReviews.saveCustReview ( reviews, (err, data) => {
      if (err) {
        console.log(err)
        res.status(401).send({
          message:
            err.message || "Some error occurred while posting reviews ."
        });
      }
      else {
        console.log("Posted Successfully");
        res.status(200).send({
          message: "Posted Successfully",
          output: reviews
        })
      }
    });
  };


  exports.putCustReview = (req, res) => {

    const reviews = new CustReviews ({
      owner_id : req.body.owner_id,
      product_id : req.body.product_id,
      user_id : req.body.user_id,
      rating : req.body.rating,
      comment : req.body.comment,
      status : req.body.status,
      viewed : req.body.viewed
    });
  
    CustReviews.putCustReview (req.params.id, reviews, (err, data) => {
        if (err) {
          if (err.kind === "not_found") {
            res.status(401).send({
              message: `Not found review with id ${req.params.id}.`
            });
          }
        }
        else {
          res.status(200).send({
            status:(200),
            message:"Success",
            Data: reviews
          })
        }
    });
    };
  
    exports.getCustReviewID = (req, res) => {
      CustReviews.getCustReviewID(req.params.id, (err, data) => {
        if (err) {
          if (err.kind === "not_found") {
            res.status(401).send({
              status:(401),
              message: `Not found review with id ${req.params.id}.`
            });
          }
        }
        else {
          res.status(200).send({
            status:(200),
            message:"Success",
            Data:data
          })
        }
    });
  };
  
    exports.deleteCustReview = (req, res) => {
      CustReviews.deleteCustReview ( req.params.id, (err, data) => {
        if (err) {
          if (err.kind === "not_found") {
            res.status(401).send({
              message: `Not found review with id ${req.params.id}.`
            });
          }
        }
        else {
          res.status(200).send({
            status:(200),
            message:"Success",
          })
        }
    });
  };