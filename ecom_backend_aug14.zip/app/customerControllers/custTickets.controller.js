const CustTicketSupports = require("../customerModels/custTickets.models.js");
const path = require("path");
const fs = require("fs");
const CustTicketReply = require("../customerModels/custTicketReply.models.js");

// Tickets List
exports.getCustTicketList = (req, res) => {
  CustTicketSupports.getCustTicketList(req.params.user_id, (err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
    else res.send(data);
  });
};

  exports.getCustTicketID = (req, res) => {
    CustTicketSupports.getCustTicketID(req.params.id, (err, data) => {
      if (err)
        res.status(500).send({
          message:
            err.message || "Some error occurred while retrieving data."
        });
      else res.send(data);
    });
  };

  exports.saveCustTicket = (req, res) => {

    let files = "";

    if (req.files.files) {
      const extension = req.files.files[0]["mimetype"].split('/')[1]
      files = req.files.files[0]["filename"] + '.' + extension
      files = req.files.files[0]["originalname"]
    }
    const tickets = new CustTicketSupports({
      id: req.body.id ,
      code: req.body.code || null,
      user_id: req.body.user_id || null,
      subject: req.body.subject || null,
      details: req.body.details || null,
      files: files || null,
      status: req.body.status || null,
      viewed: req.body.viewed || null,
      client_viewed: req.body.client_viewed || null,
    });
  
    let userId = req.body.user_id;
    let filesId = files;

    CustTicketSupports.saveCustTicket ( tickets, (err, data) => {
      if (err) {
        console.log(err)
        res.status(500).send({
          message:
            err.message || "Some error occurred while posting tickets  ."
        });
      }
      else {

        let ticketId = data.insertId

        if (req.files.files) {

          const currentPath = path.join(process.cwd(), "uploads", req.files.files[0]["filename"]);
          const destinationPath = path.join(process.cwd(), "/uploads/tickets/files/" + `${ticketId}`, files);
          const baseUrl = process.cwd() + '/uploads/tickets/files/' + `${ticketId}`
          fs.mkdirSync(baseUrl, { recursive: true })
          fs.rename(currentPath, destinationPath, function (err) {
            if (err) {
              throw err
            } else {
              console.log("Successfully moved the files images !")
            }
          });
        }

        const ticketReply = new CustTicketReply ({
          ticket_id : ticketId ,
          user_id : userId,
          reply : req.body.reply,
          files : filesId,
      });
      
      CustTicketReply.saveCustTicketReply (ticketReply, (err, data) => {
          if (err) {
            console.log(err)
            console.log("Ticket reply posted successfully");
            console.log("Posted Successfully");
            res.statusCode = 200;
          }
      });

        console.log("Posted Successfully");
        res.status(200).send({
          message: "Posted Successfully",
          output: data
        })
      }
    });
  };

  exports.getCustTicketReplyList = (req, res) => {
    CustTicketReply.getCustTicketReplyList(req.params.ticket_id, (err, data) => {
      if (err)
        res.status(500).send({
          message:
            err.message || "Some error occurred while retrieving data."
        });
      else res.send(data);
    });
  };

    // Seller Ticket Reply
    exports.saveCustTicketReply = (req, res) => {

      let files = "";
  
      if (req.files.files) {
        const extension = req.files.files[0]["mimetype"].split('/')[1]
        files = req.files.files[0]["filename"] + '.' + extension
        files = req.files.files[0]["originalname"]
      }
      const tickets = new CustTicketReply({
        id: req.body.id ,
        ticket_id: req.body.ticket_id || null,
        user_id: req.body.user_id || null,
        reply: req.body.reply || null,
        files: files || null,
      });
    
      CustTicketReply.saveCustTicketReply ( tickets, (err, data) => {
        if (err) {
          console.log(err)
          res.status(500).send({
            message:
              err.message || "Some error occurred while posting tickets  ."
          });
        }
        else {
  
          let ticketId = data.insertId
          if (req.files.files) {
  
            const currentPath = path.join(process.cwd(), "uploads", req.files.files[0]["filename"]);
            const destinationPath = path.join(process.cwd(), "/uploads/tickets/files/" + `${ticketId}`, files);
            const baseUrl = process.cwd() + '/uploads/tickets/files/' + `${ticketId}`
            fs.mkdirSync(baseUrl, { recursive: true })
            fs.rename(currentPath, destinationPath, function (err) {
              if (err) {
                throw err
              } else {
                console.log("Successfully moved the files images !")
              }
            });
          }
          console.log("Posted Successfully");
          res.status(200).send({
            message: "Posted Successfully",
            output: data
          })
        }
      });
    };
