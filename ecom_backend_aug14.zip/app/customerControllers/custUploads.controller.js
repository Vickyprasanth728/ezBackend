const CustUploadFiles = require("../customerModels/custUploads.models.js");
const path = require("path");
const fs = require("fs");

// Upload Files
exports.getCustUploadFiles = (req, res) => {
    CustUploadFiles.getCustUploadFiles(req.params.user_id, (err, data) => {
      if (err)
        res.status(500).send({
          message:
            err.message || "Some error occurred while retrieving data."
        });
      else res.send(data);
    });
  };