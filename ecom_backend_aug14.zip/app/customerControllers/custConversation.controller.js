const CustConversation = require("../customerModels/custConversation.models.js");
const CustMessages = require("../customerModels/custMessages.models.js");


exports.saveCustConversation = (req, res) => {
    
    const conversations = new CustConversation({
        id : req.body.id,
        sender_id : req.body.sender_id,
        receiver_id : req.body.receiver_id,
        title : req.body.title,
        sender_viewed : '0',
        receiver_viewed : '0'
    });
    
    CustConversation.saveCustConversation ( conversations, (err, data) => {
        if (err) {
        console.log(err)
        res.status(500).send({
            message:
            err.message || "Some error occurred while posting conversation  ."
        });
        }
        else {
    
        let convId = data.insertId;
        let senderId = req.body.sender_id;

        const messages = new CustMessages({
            conversation_id : convId,
            user_id : senderId,
            message : req.body.message,
    
        });
        CustMessages.saveCustMessage (messages, (err, data) => {
            if (err) {
                console.log(err)
                console.log("Cust Message posted successfully");
                console.log("Posted Sucessfully");
                res.statusCode = 200;
            }
        });

        console.log("Posted Successfully");
        res.status(200).send({
            message: "Posted Successfully",
            output: data
        })
        }
    });
};

// Cust Conversation List
exports.getCustConversation = (req, res) => {
    CustConversation.getCustConversation(req.params.sender_id, (err, data) => {
        if (err)
        res.status(500).send({
          message:
            err.message || "Some error occurred while retrieving data."
        });
        else res.send(data);
      });
    };

exports.getCustConversationID = (req, res) => {
    CustConversation.getCustConversationID(req.params.id, (err, data) => {
        if (err)
        res.status(500).send({
          message:
            err.message || "Some error occurred while retrieving data."
        });
        else res.send(data);
      });
    };

    
// Cust Messages List
exports.getCustMessages = (req, res) => {
    CustMessages.getCustMessages(req.params.conversation_id, (err, data) => {
        if (err)
        res.status(500).send({
          message:
            err.message || "Some error occurred while retrieving data."
        });
        else res.send(data);
      });
    };
  

exports.saveCustMessage = (req, res) => {
    
    const messages = new CustMessages({
        id : req.body.id,
        conversation_id : req.body.conversation_id,
        user_id : req.body.user_id,
        message : req.body.message,
    });
    
    CustMessages.saveCustMessage ( messages, (err, data) => {
        if (err) {
        console.log(err)
        res.status(500).send({
            message:
            err.message || "Some error occurred while posting conversation  ."
        });
        }
        else {
        console.log("Posted Successfully");
        res.status(200).send({
            message: "Posted Successfully",
            output: data
        })
        }
    });
};


