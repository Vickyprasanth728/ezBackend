const sql = require("../models/db.js");

// constructor
const SellerPayment = function (payment) {
    this.id = payment.id;
    this.seller_id = payment.seller_id,
    this.amount = payment.amount,
    this.payment_details = payment.payment_details,
    this.payment_method = payment.payment_method,
    this.txn_code = payment.txn_code
  };

  SellerPayment.getSellerPayment = (seller_id, result) => {

    let query  = ` SELECT pay.*, us.name as seller_name, us.user_type as user_type FROM payments as pay `  
        query += ` LEFT JOIN sellers as s on (pay.seller_id = s.id) `
        query += ` LEFT JOIN users as us on (s.user_id = us.id) `
        query += ` WHERE pay.seller_id = ${seller_id} `
        query += ` GROUP BY pay.id `
        query += ` ORDER BY pay.id `

    sql.query(query, seller_id , (err, res) => {
      if (err) {
        result(null, err);
        return;
      }
      else {
        result(null, res);
      }
    })
  };

  SellerPayment.saveSellerPayment = (data, result) => {
    console.log(data);
    let query = "INSERT INTO payments SET ?";
    sql.query(query, data, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      result(null, res);
    });
  };

module.exports = SellerPayment;
