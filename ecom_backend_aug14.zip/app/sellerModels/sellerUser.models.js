const sql = require("../models/db.js");
var md5 = require('md5');

// constructor
const SellerUsers = function (user) {
    this.id = user.id;
    this.referred_by = user.referred_by;
    this.provider_id = user.provider_id;
    this.user_type = user.user_type;
    this.name = user.name;
    this.email = user.email;
    this.email_verified_at = user.email_verified_at;
    this.verification_code = user.verification_code;
    this.new_email_verificiation_code = user.new_email_verificiation_code;
    this.password = user.password;
    this.remember_token = user.remember_token;
    this.device_token = user.device_token;
    this.avatar = user.avatar;
    this.avatar_original = user.avatar_original;
    this.address = user.address;
    this.country = user.country;
    this.state = user.state;
    this.city = user.city;
    this.postal_code = user.postal_code;
    this.phone = user.phone;
    this.balance = user.balance;
    this.banned = user.banned;
    this.referral_code = user.referral_code;
    this.customer_package_id = user.customer_package_id;
    this.remaining_uploads = user.remaining_uploads;
};

SellerUsers.getSellerUsers = (result) => {
    let query  = ` select us.*, sh.bank_payment_status as bank_payment, sh.cash_on_delivery_status as cash_payment, sh.bank_name as name_of_bank, sh.bank_acc_name as bank_account_name, sh.bank_acc_no as bank_account_name, sh.bank_routing_no as bank_routing_number from users as us `

        query += ` left join shops as sh on (us.id = sh.user_id) `
        query += ` left join addresses as ad on (us.id = ad.user_id) `
        query += ` left join sellers as s on (us.id = s.user_id) `
        query += ` where us.banned = 0 and us.user_type='seller' `
        query += ` group by us.id `
        query += ` order by us.id `

    sql.query(query, (err, res) => {
        if (err) {
            result(null, err);
            return;
        }
        result(null, res);
    });
};

SellerUsers.saveSellerUser = (data, result) => {
    console.log(data);
    let query = "INSERT INTO users SET ?";
    sql.query(query, data, (err, res) => {
        if (err) {
            console.log(err)
            result(err, null);
            return;
        }
        result(null, res);
    });
};

SellerUsers.putSellerUser = (id, data, result) => {

    let referred_by = data.referred_by || null;
    let provider_id = data.provider_id || null;
    let user_type = data.user_type || null;
    let name = data.name || null;
    let email = data.email || null;
    let email_verified_at = data.email_verified_at || null;
    let verification_code = data.verification_code || null;
    let new_email_verificiation_code = data.new_email_verificiation_code || null;
    let password = data.password || null;
    let remember_token = data.remember_token || null;
    let device_token = data.device_token || null;
    let avatar = data.avatar || null;
    let address = data.address || null;
    let country = data.country || null;
    let state = data.state || null;
    let city = data.city || null;
    let postal_code = data.postal_code || null;
    let phone = data.phone || null;
    let balance = data.balance || null;
    let banned = data.banned || null;
    let referral_code = data.referral_code || null;
    let customer_package_id = data.customer_package_id || null;
    let remaining_uploads = data.remaining_uploads || null;

    let query = "UPDATE users SET referred_by = " + referred_by + " , provider_id = ' " + provider_id + " ' , user_type = ' " + user_type + " ' , name = ' " + name + " ' , email = '" + email + "' , email_verified_at =  " + email_verified_at + " , verification_code = ' " + verification_code + " ', new_email_verificiation_code = ' " + new_email_verificiation_code + " ',  password = ' " + password + " ',  remember_token = ' " + remember_token + " ', device_token = ' " + device_token + " ' , avatar = ' " + avatar + " ', address = ' " + address + " ', country = ' " + country + " ', state = '" + state + "', city = '" + city + "', postal_code = '" + postal_code + "', phone = '" + phone + "',  balance = " + balance + " ,  banned = " + banned + " , referral_code = '" + referral_code + "', customer_package_id = " + customer_package_id + " ,remaining_uploads = " + remaining_uploads + " , updated_at = now()  WHERE id = ? "

    sql.query(query, id, (err, res) => {
        if (err) {
            console.log(err)
            result(err, null);
            return;
        }
        if (res.affectedRows == 0) {
            result({ kind: "not_found" }, null);
            return;
        }
        console.log("updated seller User : ", { id: id, ...data });
        result(null, data.id);
    });
};

SellerUsers.putSellerProfile = (id, data, result) => {

    let name = data.name || null;
    let email = data.email || null;
    let password = data.password || null;
    let phone = data.phone || null;
    let avatar = data.avatar || null;

    const encryptedpassword = md5(data.password);
    console.log('encrypted :',encryptedpassword);  
    console.log('pasword :',password);  

    let query = " UPDATE users SET name = ' " + name + " ' , email = '" + email + "', password = '"+encryptedpassword+"' , phone = '" + phone + "', avatar = '"+avatar+"' , updated_at = now()  WHERE id = ? "

    sql.query(query, id, (err, res) => {
        if (err) {
            console.log(err)
            return;
        }
        if (res.affectedRows == 0) {
            // not found Tutorial with the id
            result({ kind: "not_found" }, null);
            return;
        }
        console.log("updated user : ", { id: id, ...data });
        result(null, data.id);
    });
};
 
SellerUsers.getSellerUserID = (id, result) => {
    let query  = ` select us.*, sh.bank_payment_status as bank_payment, sh.cash_on_delivery_status as cash_payment, sh.bank_name as name_of_bank, sh.bank_acc_name as bank_account_name, sh.bank_acc_no as bank_account_name, sh.bank_routing_no as bank_routing_number from users as us `

        query += ` left join shops as sh on (us.id = sh.user_id) `
        query += ` left join addresses as ad on (us.id = ad.user_id) `
        query += ` left join sellers as s on (us.id = s.user_id) `
        query += ` where us.banned = 0 and us.user_type='seller' and us.id = ? `

    sql.query(query, id, (err, res) => {
        if (err) {
            result(null, err);
            return;
        }
        result(null, res[0]);
        console.log(null, res[0]);
    });
};

SellerUsers.deleteSellerUser = (id, result) => {
    console.log(id);
    let query  = ` DELETE FROM users ` 
        query += ` WHERE users.id = ? and users.user_type='seller' `;
        
    sql.query(query, id, (err, res) => {
        if (err) {
            console.log(err)
            result(err, null);
            return;
        }
        if (res.affectedRows == 0) {
            result({ kind: "not_found" }, null);
            return;
        }
        console.log("deleted seller user : ", { id: id });
        result(null, res);
    });
};

module.exports = SellerUsers;
