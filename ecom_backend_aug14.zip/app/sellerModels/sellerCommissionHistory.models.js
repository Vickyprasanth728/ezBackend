const sql = require("../models/db.js");

// constructor
const CommissionHistory = function (commission) {
    this.id = commission.id;
 };

  CommissionHistory.getSellerCommissionHistoryID = (seller_id, queryString, result) => {

    let query =  ` SELECT ch.id as id, o.code as code, ch.admin_commission as admin_commission, ch.seller_earning as seller_earning, us.name as user_name, ch.created_at as created_at from commission_histories as ch `
        
        query += ` LEFT JOIN orders as o on (o.id = ch.order_id) `
        query += ` LEFT JOIN sellers as s on (s.id = ch.seller_id) `
        query += ` LEFT JOIN order_details as od on (od.id = ch.order_detail_id) `
        query += ` LEFT JOIN users as us on (us.id = s.user_id) `
        query += ` WHERE ch.seller_id = ${seller_id} and us.user_type = 'seller' `

        // Date 
        if (queryString.startDate && queryString.endDate) {
          query += " and ch.created_at between " + `${queryString.startDate}` + ` and ${queryString.endDate} `
        }

        query += ` GROUP BY ch.id `
        query += ` ORDER BY ch.id `
  
    sql.query(query, seller_id, (err, res) => {
      if (err) {
        result(null, err);
        return;
      }
      result(null, res);
      console.log(null, res);
    });
  };


module.exports = CommissionHistory;
