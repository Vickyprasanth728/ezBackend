const sql = require("../models/db.js");


// constructor
const SellerUploadFiles = function (uploadfiles) {
    this.id = uploadfiles.id;
    this.file_original_name = uploadfiles.file_original_name;
    this.file_name = uploadfiles.file_name;
    this.user_id = uploadfiles.user_id;
    this.file_size = uploadfiles.file_size;
    this.extension = uploadfiles.extension;
    this.type = uploadfiles.type;
    this.external_link = uploadfiles.external_link;
 };
 
 
 SellerUploadFiles.getSellerUploadFiles = (user_id , result) => {

    let query  = ` SELECT up.* FROM uploads as up `
        query += ` LEFT JOIN users as us ON (up.user_id = us.id)  `
        query += ` WHERE up.user_id = ${user_id}  and us.user_type = 'seller' `
        query += ` GROUP BY up.id `
        query += ` ORDER BY up.id `
     
     sql.query(query, user_id , (err, res) => {
       if (err) {
         result(null, err);
         return;
       }
       result(null, res);
     });
 };

 SellerUploadFiles.saveSellerUploadFiles = (data, result) => {
  console.log(data);
  let query = "INSERT INTO uploads SET ?";
  sql.query(query, data, (err, res) => {
    if (err) {
      console.log(err)
      result(err, null);
      return;
    }
    result(null, res);
  });
};

SellerUploadFiles.deleteSellerUploadFiles = (id, result) => {
  console.log(id);
  let query = ` UPDATE uploads SET deleted_at = now() WHERE id = ? `;
  sql.query(query, id, (err, res) => {
    if (err) {
      console.log(err)
      result(err, null);
      return;
    }
    if (res.affectedRows == 0) {
      result({ kind: "not_found" }, null);
      return;
    }
    console.log("deleted seller uploads : ", { id: id });
    result(null, res);
  });
};

 module.exports = SellerUploadFiles;
