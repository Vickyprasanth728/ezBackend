const sql = require("../models/db.js");

// Constructor
const ShopDetails = function (shops) {
    this.id = shops.id;
    this.user_id = shops.user_id,
    this.name = shops.name,
    this.logo = shops.logo,
    this.sliders = shops.sliders,
    this.phone = shops.phone,
    this.address = shops.address,
    this.rating = shops.rating,
    this.num_of_reviews = shops.num_of_reviews,
    this.num_of_sale = shops.num_of_sale,
    this.seller_package_id = shops.seller_package_id,
    this.product_upload_limit = shops.product_upload_limit,
    this.package_invalid_at = shops.package_invalid_at,
    this.verification_status = shops.verification_status,
    this.verification_info = shops.verification_info,
    this.cash_on_delivery_status = shops.cash_on_delivery_status,
    this.admin_to_pay = shops.admin_to_pay,
    this.facebook = shops.facebook,
    this.instagram = shops.instagram,
    this.google = shops.google,
    this.twitter = shops.twitter,
    this.youtube = shops.youtube,
    this.slug = shops.slug,
    this.meta_title = shops.meta_title,
    this.meta_description = shops.meta_description,
    this.pick_up_point_id = shops.pick_up_point_id,
    this.shipping_cost = shops.shipping_cost,
    this.delivery_pickup_latitude = shops.delivery_pickup_latitude,
    this.delivery_pickup_longitude = shops.delivery_pickup_longitude,
    this.bank_name = shops.bank_name,
    this.bank_acc_name = shops.bank_acc_name,
    this.bank_acc_no = shops.bank_acc_no,
    this.bank_routing_no = shops.bank_routing_no,
    this.bank_payment_status = shops.bank_payment_status
 };

 ShopDetails.getShopDetails = (user_id, result) => {
  let query  = ` SELECT s.* FROM shops as s `

      query += ` LEFT JOIN users as us on (s.user_id = us.id) `
      query += ` WHERE s.user_id = ${user_id} and us.user_type = 'seller'`
      query += ` GROUP BY s.id `
      query += ` ORDER BY s.id DESC  `
  
   sql.query(query, user_id, (err, res) => {
     if (err) {
       result(null, err);
       return;
     }
     result(null, res);
   });
};

ShopDetails.saveShopDetail = (data, result) => {
    console.log(data);
    let query = "INSERT INTO shops SET ?";
    sql.query(query, data, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      result(null, res);
    });
  };

  ShopDetails.putShopDetail = (id, data, result) => {

    let name = data.name || null;
    let user_id = data.user_id || null;
    let logo = data.logo || null;
    let sliders = data.sliders || null;
    let phone = data.phone || null;
    let address = data.address || null;
    let rating = data.rating || null;
    let num_of_reviews = data.num_of_reviews || null;
    let num_of_sale = data.num_of_sale || null;
    let seller_package_id = data.seller_package_id || null;
    let product_upload_limit = data.product_upload_limit || null;
    let package_invalid_at = data.package_invalid_at || null;
    let verification_status = data.verification_status || null;
    let verification_info = data.verification_info || null;
    let cash_on_delivery_status = data.cash_on_delivery_status || null;
    let admin_to_pay = data.admin_to_pay || null;
    let facebook = data.facebook || null;
    let instagram = data.instagram || null;
    let google = data.google || null;
    let twitter = data.twitter || null;
    let youtube = data.youtube || null;
    let slug = data.slug || null;
    let meta_title = data.meta_title || null;
    let meta_description = data.meta_description || null;
    let pick_up_point_id = data.pick_up_point_id || null;
    let shipping_cost = data.shipping_cost || null;
    let delivery_pickup_latitude = data.delivery_pickup_latitude || null;
    let delivery_pickup_longitude = data.delivery_pickup_longitude || null;
    let bank_name = data.bank_name || null;
    let bank_acc_name = data.bank_acc_name || null;
    let bank_acc_no = data.bank_acc_no || null;
    let bank_routing_no = data.bank_routing_no || null;
    let bank_payment_status = data.bank_payment_status || null;
   
   
    let query = "UPDATE shops SET name = '"+name+"', user_id = '"+user_id+"', logo ='"+logo+"', sliders = '"+sliders+"' , phone = '"+phone+"', address = '"+address+"',  rating =  "+rating+" ,  num_of_reviews =  "+num_of_reviews+" , num_of_sale =  "+num_of_sale+" , seller_package_id =  "+seller_package_id+" , product_upload_limit =  "+product_upload_limit+" , package_invalid_at =  "+package_invalid_at+" , verification_status =  "+verification_status+" , verification_info =  "+verification_info+" , cash_on_delivery_status =  "+cash_on_delivery_status+" , admin_to_pay =  "+admin_to_pay+" , facebook = '"+facebook+"', instagram = '"+instagram+"',google = '"+google+"',twitter = '"+twitter+"'youtube = '" +youtube+"',slug = '"+slug+"',meta_title = '"+meta_title+"',meta_description = '"+meta_description+"',pick_up_point_id = '"+pick_up_point_id+"',  shipping_cost =  "+shipping_cost+" ,  delivery_pickup_latitude =  "+delivery_pickup_latitude+" ,  delivery_pickup_longitude =  "+delivery_pickup_longitude+" , bank_name = '"+bank_name+"', bank_acc_name = '"+bank_acc_name+"',  bank_acc_no = '"+bank_acc_no+"', bank_routing_no =  "+bank_routing_no+" ,  bank_payment_status =  "+bank_payment_status+"  , updated_at = now() WHERE id = ? "
  
    sql.query(query, id, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      if (res.affectedRows == 0) {
        result({ kind: "not_found" }, null);
        return;
      }
      console.log("updated shop : ", { id: id, ...data });``
      result(null, data.id);
    });
  };

  ShopDetails.putProfilePayment = (user_id, data, result) => {

    let name = data.name || null;
    // let user_id = data.user_id || null;
    let logo = data.logo || null;
    let sliders = data.sliders || null;
    let phone = data.phone || null;
    let address = data.address || null;
    let rating = data.rating || null;
    let num_of_reviews = data.num_of_reviews || null;
    let num_of_sale = data.num_of_sale || null;
    let seller_package_id = data.seller_package_id || null;
    let product_upload_limit = data.product_upload_limit || null;
    let package_invalid_at = data.package_invalid_at || null;
    let verification_status = data.verification_status || null;
    let verification_info = data.verification_info || null;
    let cash_on_delivery_status = data.cash_on_delivery_status || null;
    let admin_to_pay = data.admin_to_pay || null;
    let facebook = data.facebook || null;
    let instagram = data.instagram || null;
    let google = data.google || null;
    let twitter = data.twitter || null;
    let youtube = data.youtube || null;
    let slug = data.slug || null;
    let meta_title = data.meta_title || null;
    let meta_description = data.meta_description || null;
    let pick_up_point_id = data.pick_up_point_id || null;
    let shipping_cost = data.shipping_cost || null;
    let delivery_pickup_latitude = data.delivery_pickup_latitude || null;
    let delivery_pickup_longitude = data.delivery_pickup_longitude || null;
    let bank_name = data.bank_name || null;
    let bank_acc_name = data.bank_acc_name || null;
    let bank_acc_no = data.bank_acc_no || null;
    let bank_routing_no = data.bank_routing_no || null;
    let bank_payment_status = data.bank_payment_status || null;
   
   
    let query = "UPDATE shops SET name = '"+name+"', user_id = '"+user_id+"', logo ='"+logo+"', sliders = '"+sliders+"' , phone = '"+phone+"', address = '"+address+"',  rating =  "+rating+" ,  num_of_reviews =  "+num_of_reviews+" , num_of_sale =  "+num_of_sale+" , seller_package_id =  "+seller_package_id+" , product_upload_limit =  "+product_upload_limit+" , package_invalid_at =  "+package_invalid_at+" , verification_status =  "+verification_status+" , verification_info =  "+verification_info+" , cash_on_delivery_status =  "+cash_on_delivery_status+" , admin_to_pay =  "+admin_to_pay+" , facebook = '"+facebook+"', instagram = '"+instagram+"',google = '"+google+"',twitter = '"+twitter+"'youtube = '" +youtube+"',slug = '"+slug+"',meta_title = '"+meta_title+"',meta_description = '"+meta_description+"',pick_up_point_id = '"+pick_up_point_id+"',  shipping_cost =  "+shipping_cost+" ,  delivery_pickup_latitude =  "+delivery_pickup_latitude+" ,  delivery_pickup_longitude =  "+delivery_pickup_longitude+" , bank_name = '"+bank_name+"', bank_acc_name = '"+bank_acc_name+"',  bank_acc_no = '"+bank_acc_no+"', bank_routing_no =  "+bank_routing_no+" ,  bank_payment_status =  "+bank_payment_status+"  , updated_at = now() WHERE user_id = ? "
  
    sql.query(query, user_id, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      if (res.affectedRows == 0) {
        result({ kind: "not_found" }, null);
        return;
      }
      console.log("updated shop : ", { id: user_id, ...data });``
      result(null, data.id);
    });
  };

  ShopDetails.getShopDetailID = (id , result) => {
    let query  = ` select s.* from shops as s `

        query += ` WHERE s.id = ? `
  
    sql.query(query, id, (err, res) => {
      if (err) {
        result(null, err);
        return;
      }
      result(null, res[0]);
      console.log(null, res[0]);
    });
    };

module.exports = ShopDetails;
