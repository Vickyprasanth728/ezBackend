const sql = require("../models/db.js");

// constructor
const SellerMoneyWithdraw = function (payment) {
    this.id = payment.id;
    this.user_id = payment.user_id;
    this.amount = payment.amount;
    this.message = payment.message;
    this.status = payment.status;
    this.viewed = payment.viewed;
  };

  SellerMoneyWithdraw.getSellerMoneyWithdraw = (user_id, result) => {

    let query  = ` SELECT swr.*, swr.created_at as date, us.name as seller_name, us.user_type as user_type FROM seller_withdraw_requests as swr `  
        query += ` LEFT JOIN users as us on (swr.user_id = us.id) `
        query += ` WHERE swr.user_id = ${user_id} `
        query += ` GROUP BY swr.id `
        query += ` ORDER BY swr.id `

    sql.query(query, user_id , (err, res) => {
      if (err) {
        result(null, err);
        return;
      }
      else {
        result(null, res);
      }
    })
  };

  SellerMoneyWithdraw.saveSellerMoneyWithdraw = (data, result) => {
    console.log(data);
    let query = "INSERT INTO seller_withdraw_requests SET ?";
    sql.query(query, data, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      result(null, res);
    });
  };

module.exports = SellerMoneyWithdraw;
