const sql = require("../models/db.js");

// Constructor
const SellerMessages = function (messages) {
  this.id = messages.id;
  this.conversation_id = messages.conversation_id,
  this.user_id = messages.user_id,
  this.message = messages.message	
};

SellerMessages.getSellerMessages = (conversation_id, result) => {
    let query  = ` SELECT * FROM messages as mes `
      
        
         

 sql.query(query,conversation_id, (err, res) => {
   if (err) {
     result(null, err);
     return;
   }
   result(null, res);
 });
};

module.exports = SellerMessages;