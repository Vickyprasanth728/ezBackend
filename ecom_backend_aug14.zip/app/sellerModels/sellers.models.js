const sql = require("../models/db.js");

// constructor
const Sellers = function (payment) {
    this.id = payment.id;
    this.user_id  = payment.user_id ;
    this.rating = payment.rating;
    this.num_of_reviews = payment.num_of_reviews;
    this.num_of_sale = payment.num_of_sale;
    this.verification_status = payment.verification_status;
    this.verification_info = payment.verification_info;
    this.cash_on_delivery_status = payment.cash_on_delivery_status;
    this.admin_to_pay = payment.admin_to_pay;
    this.bank_name = payment.bank_name;
    this.bank_acc_name = payment.bank_acc_name;
    this.bank_acc_no = payment.bank_acc_no;
    this.bank_routing_no = payment.bank_routing_no;
    this.bank_payment_status = payment.bank_payment_status;
};

Sellers.getSellers = (result) => {
    let query  = ` select s.* from sellers as s `

    sql.query(query, (err, res) => {
        if (err) {
            result(null, err);
            return;
        }
        result(null, res);
    });
};

Sellers.saveSeller = (data, result) => {
    console.log(data);
    let query = "INSERT INTO sellers SET ?";
    sql.query(query, data, (err, res) => {
        if (err) {
            console.log(err)
            result(err, null);
            return;
        }
        result(null, res);
    });
};

Sellers.putSeller = (user_id, data, result) => {

    // let user_id = data.user_id || null;
    let rating = data.rating || null;
    let num_of_reviews = data.num_of_reviews || null;
    let num_of_sale = data.num_of_sale || null;
    let verification_status = data.verification_status || null;
    let verification_info = data.verification_info || null;
    let cash_on_delivery_status = data.cash_on_delivery_status || null;
    let admin_to_pay = data.admin_to_pay || null;
    let bank_name = data.bank_name || null;
    let bank_acc_name = data.bank_acc_name || null;
    let bank_acc_no = data.bank_acc_no || null;
    let bank_routing_no = data.bank_routing_no || null;
    let bank_payment_status = data.bank_payment_status || null;

    let query = " UPDATE sellers SET  rating =  "+rating+" , num_of_reviews =  "+num_of_reviews+" , num_of_sale =  "+num_of_sale+" , verification_status =  "+verification_status+" , verification_info =  '"+verification_info+"' , cash_on_delivery_status =  "+cash_on_delivery_status+" , admin_to_pay =  "+admin_to_pay+" , bank_name =  '"+bank_name+"' , bank_acc_name =  '"+bank_acc_name+"' , bank_acc_no =  '"+bank_acc_no+"' , bank_routing_no =  "+bank_routing_no+" , bank_payment_status =  "+bank_payment_status+" , updated_at = now()  WHERE user_id = ? "

    sql.query(query, user_id, (err, res) => {
        if (err) {
            console.log(err)
            return;
        }
        if (res.affectedRows == 0) {
            result({ kind: "not_found" }, null);
            return;
        }
        console.log("updated seller : ", { id: user_id, ...data });
        result(null, data.id);
    });
};

module.exports = Sellers ;
