const sql = require("../models/db.js");

// constructor
const SellerProducts = function (Products) {
    this.id = Products.id;
    this.seller_id = Products.seller_id,
    this.amount = Products.amount,
    this.payment_details = Products.payment_details,
    this.payment_method = Products.payment_method,
    this.txn_code = Products.txn_code
  };

  SellerProducts.getSellerProducts = (user_id, result) => {

    let query = "select p.*, cat.name as category_name, br.name as brand_name, us.name as user_name, col.name as color_name, att.name as attributes_name, av.value as attribute_values, up.file_name as image, ps.variant as variant, ps.sku as sku, ps.price as price, ps.qty as qty, fdp.discount as discount_flash, fdp.discount_type as discount_type_flash, sh.name as shop_name, br.logo as brand_logo from products as p "

    query += ` LEFT JOIN categories as cat on (cat.id = p.category_id) `
    query += ` LEFT JOIN brands as br on (br.id = p.brand_id) `
    query += ` LEFT JOIN users as us on (us.id = p.user_id) `
    query += ` LEFT JOIN colors as col on (col.id = p.colors) ` 
    query += ` LEFT JOIN attributes as att on (att.id = p.attributes) `
    query += ` LEFT JOIN attribute_values as av on (att.id = av.attribute_id) `
    query += ` LEFT JOIN uploads as up on (us.id = up.user_id) `
    query += ` LEFT JOIN sellers as sel on (us.id = sel.user_id) `
    query += ` LEFT JOIN shops as sh on (us.id = sh.user_id) `
    query += ` LEFT JOIN product_stocks as ps on (p.id = ps.product_id) `
    query += ` LEFT JOIN flash_deal_products as fdp on (p.id = fdp.product_id) `
    query += ` WHERE p.digital = 0 and p.user_id = ${user_id} and us.user_type = 'seller' `
    query += ` GROUP BY p.id `
    query += ` ORDER BY p.id `

    sql.query(query, user_id , (err, res) => {
      if (err) {
        result(null, err);
        return;
      }
      else {
        result(null, res);
      }
    })
  };

  SellerProducts.getSellerDigitalProducts = (user_id, result) => {

    let query = "select p.*, cat.name as category_name, br.name as brand_name, us.name as user_name, col.name as color_name, att.name as attributes_name, av.value as attribute_values, up.file_name as image, ps.variant as variant, ps.sku as sku, ps.price as price, ps.qty as qty, fdp.discount as discount_flash, fdp.discount_type as discount_type_flash, sh.name as shop_name, br.logo as brand_logo from products as p "

    query += ` LEFT JOIN categories as cat on (cat.id = p.category_id) `
    query += ` LEFT JOIN brands as br on (br.id = p.brand_id) `
    query += ` LEFT JOIN users as us on (us.id = p.user_id) `
    query += ` LEFT JOIN colors as col on (col.id = p.colors) ` 
    query += ` LEFT JOIN attributes as att on (att.id = p.attributes) `
    query += ` LEFT JOIN attribute_values as av on (att.id = av.attribute_id) `
    query += ` LEFT JOIN uploads as up on (us.id = up.user_id) `
    query += ` LEFT JOIN sellers as sel on (us.id = sel.user_id) `
    query += ` LEFT JOIN shops as sh on (us.id = sh.user_id) `
    query += ` LEFT JOIN product_stocks as ps on (p.id = ps.product_id) `
    query += ` LEFT JOIN flash_deal_products as fdp on (p.id = fdp.product_id) `
    query += ` WHERE p.digital !=0 and p.user_id = ${user_id} and us.user_type = 'seller' `
    query += ` GROUP BY p.id `
    query += ` ORDER BY p.id `

    sql.query(query, user_id , (err, res) => {
      if (err) {
        result(null, err);
        return;
      }
      else {
        result(null, res);
      }
    })
  };

module.exports = SellerProducts;