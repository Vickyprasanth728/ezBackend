const sql = require("../models/db.js");


// constructor
const SellerCouponUsage = function (coupon) {
  this.id = coupon.id;
  this.user_id = coupon.user_id;
  this.coupon_id = coupon.coupon_id;
};

SellerCouponUsage.getSellerCouponUsage = (result) => {
  let query = "select * from coupon_usages "

  sql.query(query, (err, res) => {
    if (err) {
      result(null, err);
      return;
    }
    result(null, res);
  });
};

SellerCouponUsage.saveSellerCouponUsage = (data, result) => {
    console.log(data);
    let query = "INSERT INTO coupon_usages SET ?";
    sql.query(query, data, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      result(null, res);
    });
  };

  SellerCouponUsage.putSellerCouponUsage = (coupon_id, data, result) => {

    // let coupon_id = data.coupon_id || null;
    let user_id = data.user_id|| null;
   
    let query = "UPDATE coupon_usages SET user_id = "+user_id+", updated_at = now()  WHERE coupon_id = ? "
  
    sql.query(query, coupon_id, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      if (res.affectedRows == 0) {
        result({ kind: "not_found" }, null);
        return;
      }
      console.log("updated coupon usages : ", { id: coupon_id, ...data });
      result(null, data.id);
    });
  };

module.exports = SellerCouponUsage;
