const sql = require("../models/db.js");

// constructor
const SellerReviews = function (reviews) {
    this.id = reviews.id;
    this.seller_id = reviews.seller_id,
    this.amount = reviews.amount,
    this.payment_details = reviews.payment_details,
    this.payment_method = reviews.payment_method,
    this.txn_code = reviews.txn_code
  };

  SellerReviews.getSellerProductReviews = (user_id, result) => {

    let query = "select r.*, p.name as product_name, us.name as customer_name, us.user_type as user_type, p.published as published from reviews as r "

    query += ` LEFT JOIN products as p on (p.id = r.product_id) `
    query += ` LEFT JOIN users as us on (us.id = r.user_id) `
    query += ` WHERE r.user_id = ${user_id} and us.user_type = 'customer' `
    query += ` GROUP BY r.id `
    query += ` ORDER BY r.id `

    sql.query(query, user_id , (err, res) => {
      if (err) {
        result(null, err);
        return;
      }
      else {
        result(null, res);
      }
    })
  };

module.exports = SellerReviews;