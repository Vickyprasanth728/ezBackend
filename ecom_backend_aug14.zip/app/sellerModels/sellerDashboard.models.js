const sql = require("../models/db.js");

// constructor
const SellerDashboard = function (reviews) {
    this.id = reviews.id;
  };

  SellerDashboard.getSellerDashboard = (keyword, user_id, result) => {
    let query = `SELECT`
    
    if (keyword == "total_products") {
      query += ` (SELECT ifnull(COUNT(*),0) from products as p `
      query += ` left join users as us on (us.id = p.user_id) `
      query += ` where us.user_type = 'seller' and p.user_id = ${user_id} ) as total_products`
    }
    else if (keyword == "rating") {
      query += ` (SELECT ifnull(AVG(rating),0) from products as p `
      query += ` left join users as us on (us.id = p.user_id) `
      query += ` where us.user_type = 'seller'  and p.user_id = ${user_id} ) as rating`
    }
    else if (keyword == "total_orders") {
      query += ` (SELECT ifnull(COUNT(*),0) from orders as o `
      query += ` left join users as us on (us.id = o.user_id) `
      query += ` where us.user_type = 'seller' and o.user_id = ${user_id} ) as total_orders`
    }
    else if (keyword == "total_sales") {
      query += ` (SELECT ifnull(SUM(grand_total),0) as total_sales from orders as o `
      query += ` left join users as us on (us.id = o.user_id) `
      query += ` where us.user_type = 'seller' and o.user_id = ${user_id} ) as total_sales `
    }
    else if (keyword == "category_product_count") {
      query += ` cat.name as category_name, count(p.category_id) as category_count from categories as cat `
      query += ` left join products as p on (cat.id = p.category_id) `
      query += ` left join users as us on (us.id = p.user_id) `
      query += ` where us.user_type = 'seller' and p.user_id = ${user_id} `
      query += ` group by cat.id `
      query += ` order by cat.id  `
    }
    else if (keyword == "new_orders") {
      query += ` (SELECT ifnull(COUNT(*),0) from orders as o `
      query += ` left join users as us on (us.id = o.user_id) `
      query += ` where us.user_type = 'seller' and o.user_id = ${user_id} and MONTH(o.created_at) = MONTH(NOW()) ) as new_orders`
    }
    else if (keyword == "cancelled") {
      query += ` (SELECT ifnull(COUNT(*),0) from orders as o `
      query += ` left join users as us on (us.id = o.user_id) `
      query += ` where us.user_type = 'seller' and o.delivery_status = 'cancelled' and o.user_id = ${user_id} and MONTH(o.created_at) = MONTH(NOW()) ) as cancelled `
    }
    else if (keyword == "pending") {
      query += ` (SELECT ifnull(COUNT(*),0) from orders as o `
      query += ` left join users as us on (us.id = o.user_id) `
      query += ` where us.user_type = 'seller' and o.delivery_status = 'pending' and o.user_id = ${user_id} and MONTH(o.created_at) = MONTH(NOW()) ) as delivery_on_process `
    }
    else if (keyword == "delivered") {
      query += ` (SELECT ifnull(COUNT(*),0) from orders as o `
      query += ` left join users as us on (us.id = o.user_id) `
      query += ` where us.user_type = 'seller' and o.delivery_status = 'delivered' and o.user_id = ${user_id} and MONTH(o.created_at) = MONTH(NOW()) ) as delivered `
     }
     else if (keyword == "monthly_total_sales") {
      query += ` (SELECT ifnull(SUM(grand_total),0) from orders as o `
      query += ` left join users as us on (us.id = o.user_id) `
      query += ` where us.user_type = 'seller' and o.user_id = ${user_id} and MONTH(o.created_at) = MONTH(NOW()) ) as monthly_total_sales`
    }
    else if (keyword == "last_month_total_sales") {
      query += ` (SELECT ifnull(SUM(grand_total),0) from orders as o `
      query += ` left join users as us on (us.id = o.user_id) `
      query += ` where us.user_type = 'seller' and o.user_id = ${user_id} and MONTH(o.created_at) = MONTH(NOW()) -1 ) as last_month_total_sales`
    }
  
    sql.query(query, (err, res) => {
      if (err) {
        console.log(res)
        console.log("error: ", err);
        result(err, null);
        return;
      }
      result(null, res);
      console.log(res);
    });
  };

module.exports = SellerDashboard;