const sql = require("../models/db.js");

// constructor
const SellerTicketReply = function (tickets) {
    this.id = tickets.id;
    this.ticket_id = tickets.ticket_id || null,
    this.user_id = tickets.user_id || null,
    this.reply = tickets.reply || null,
    this.files = tickets.files || null
  };

  // Seller Ticket Supports List
  SellerTicketReply.getSellerTicketReply = (ticket_id, result) => {

  let query  = ` SELECT tr.* FROM ticket_replies as tr`

      query += ` LEFT JOIN users as us on (us.id = tr.user_id) `
      query += ` LEFT JOIN tickets as t on (t.id = tr.ticket_id) `
      query += ` WHERE tr.ticket_id = ${ticket_id} `  
      query += ` GROUP BY tr.id `  
      query += ` ORDER BY tr.id `  

  sql.query(query, (err, res) => {
      if (err) {    
      result(null, err);
      return;
      } 
      else {
      result(null, res);
      }
  })  
};

SellerTicketReply.saveSellerTicketReply = (data, result) => {
    console.log(data);
    let query = "INSERT INTO ticket_replies SET ?";
    sql.query(query, data, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      result(null, res);
    });
  };
module.exports = SellerTicketReply;
