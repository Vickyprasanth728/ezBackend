const sql = require("../models/db.js");

// constructor
const SellerCoupons = function (coupons) {
    this.id = coupons.id;
    this.user_id = coupons.user_id;
    this.type = coupons.type;
    this.code = coupons.code;
    this.details = coupons.details;
    this.discount = coupons.discount;
    this.discount_type = coupons.discount_type;
    this.start_date = coupons.start_date;
    this.end_date = coupons.end_date;
  };

  SellerCoupons.getSellerCoupons = (user_id, result) => {

    let query  = ` SELECT cou.*, p.name as product_name, us.user_type as user_type FROM coupons as cou `  
        query += ` LEFT JOIN coupon_usages as cu on (cu.coupon_id = cou.id) `
        query += ` LEFT JOIN users as us on (cou.user_id = us.id) `
        query += ` LEFT JOIN products as p on (p.user_id = us.id) `
        query += ` WHERE cou.user_id = ${user_id} and us.user_type = 'seller' `
        query += ` GROUP BY cou.id `
        query += ` ORDER BY cou.id `

    sql.query(query, user_id, (err, res) => {
      if (err) {
        result(null, err);
        return;
      }
      else {
        result(null, res);
      }
    })
  };
  
  SellerCoupons.saveSellerCoupon = (data, result) => {
    console.log(data);
    let query = "INSERT INTO coupons SET ?";
    sql.query(query, data, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      result(null, res);
    });
  };

  SellerCoupons.putSellerCoupon = (id, data, result) => {
 
    let user_id = data.user_id || null;
    let type = data.type || null;
    let code = data.code || null;
    let details = data.details || null;
    let discount = data.discount || null;
    let discount_type = data.discount_type || null;
    let start_date = data.start_date || null;
    let end_date = data.end_date || null;

    let query = "UPDATE coupons SET user_id = "+user_id+" , type = '"+type+"', code = '"+code+"', details = '"+details+"', discount = "+discount+" , discount_type = '"+discount_type+"' ,  start_date = "+start_date+", end_date = "+end_date+" , updated_at = now()  WHERE id = ? "
  
    sql.query(query, id, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      if (res.affectedRows == 0) {
        result({ kind: "not_found" }, null);
        return;
      }
      console.log("Updated Seller Coupons : ", { id: id, ...data });
      result(null, data.id);
    });
  };
  

  SellerCoupons.getSellerCouponID = (id , result) => {
    let query  = ` SELECT cou.*, p.name as product_name FROM coupons as cou `

        query += ` LEFT JOIN coupon_usages as cu on (cu.coupon_id = cou.id) `
        query += ` LEFT JOIN users as us on (cou.user_id = us.id) `
        query += ` LEFT JOIN products as p on (p.user_id = us.id) `
        query += ` WHERE cou.id = ? and us.user_type = 'seller' `
        query += ` GROUP BY cou.id `
        query += ` ORDER BY cou.id `
  
    sql.query(query, id, (err, res) => {
      if (err) {
        result(null, err);
        return;
      }
      result(null, res[0]);
      console.log(null, res[0]);
    });
    };

    SellerCoupons.deleteSellerCoupon = (id, result) => {
      console.log(id);
      let query = "DELETE FROM coupons WHERE id = ?";
      sql.query(query, id, (err, res) => {
        if (err) {
          console.log(err)
          result(err, null);
          return;
        }
        if (res.affectedRows == 0) {
          result({ kind: "not_found" }, null);
          return;
        }
        console.log("Deleted Seller Coupons : ", { id: id });
        result(null, res);
      });
    };

module.exports = SellerCoupons;
