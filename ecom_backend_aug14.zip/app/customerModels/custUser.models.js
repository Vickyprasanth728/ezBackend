const sql = require("../models/db.js");
var md5 = require('md5');

// constructor
const CustUser = function (user) {
    this.referred_by = user.referred_by;
    this.provider_id = user.provider_id;
    this.user_type = user.user_type;
    this.name = user.name;
    this.email = user.email;
    this.email_verified_at = user.email_verified_at;
    this.verification_code = user.verification_code;
    this.new_email_verificiation_code = user.new_email_verificiation_code;
    this.password = user.password;
    this.remember_token = user.remember_token;
    this.device_token = user.device_token;
    this.avatar = user.avatar;
    this.avatar_original = user.avatar_original;
    this.address = user.address;
    this.country = user.country;
    this.state = user.state;
    this.city = user.city;
    this.postal_code = user.postal_code;
    this.phone = user.phone;
    this.balance = user.balance;
    this.banned = user.banned;
    this.referral_code = user.referral_code;
    this.customer_package_id = user.customer_package_id;
    this.remaining_uploads = user.remaining_uploads;
};

CustUser.getCustUsers = (result) => {
    let query  = ` select * from users as us `
        query += ` where us.banned = 0 and us.user_type='customer' `

    sql.query(query, (err, res) => {
        if (err) {
            result(null, err);
            return;
        }
        result(null, res);
    });
};

CustUser.saveCustUser = (data, result) => {
    console.log(data);
    let query = "INSERT INTO users SET ?";
    sql.query(query, data, (err, res) => {
        if (err) {
            console.log(err)
            result(err, null);
            return;
        }
        result(null, res);
    });
};

CustUser.putCustUser = (id, data, result) => {

    // let referred_by = data.referred_by || null;
    // let provider_id = data.provider_id || null;
    // let user_type = data.user_type || null;
    // let name = data.name || null;
    // let email = data.email || null;
    // let email_verified_at = data.email_verified_at || null;
    // let verification_code = data.verification_code || null;
    // let new_email_verificiation_code = data.new_email_verificiation_code || null;
    // let password = data.password || null;
    // let remember_token = data.remember_token || null;
    // let device_token = data.device_token || null;
    // let avatar = data.avatar || null;
    // let address = data.address || null;
    // let country = data.country || null;
    // let state = data.state || null;
    // let city = data.city || null;
    // let postal_code = data.postal_code || null;
    // let phone = data.phone || null;
    // let balance = data.balance || null;
    // let banned = data.banned || null;
    // let referral_code = data.referral_code || null;
    // let customer_package_id = data.customer_package_id || null;
    // let remaining_uploads = data.remaining_uploads || null;

    const updates = [];
    if (data.referred_by!='') updates.push(`referred_by = '${data.referred_by}'`);
    if (data.provider_id!='') updates.push(`provider_id = '${data.provider_id}'`);
    if (data.user_type!='') updates.push(`user_type = '${data.user_type}'`);
    if (data.name!='') updates.push(`name = '${data.name}'`);
    if (data.email!='') updates.push(`email = '${data.email}'`);
    if (data.email_verified_at!='') updates.push(`email_verified_at = '${data.email_verified_at}'`);
    if (data.verification_code!='') updates.push(`verification_code = '${data.verification_code}'`);
    if (data.new_email_verificiation_code!='') updates.push(`new_email_verificiation_code = '${data.new_email_verificiation_code}'`);
    if (data.remember_token!='') updates.push(`remember_token = '${data.remember_token}'`);
    if (data.device_token!='') updates.push(`device_token = '${data.device_token}'`);
    if (data.avatar!='') updates.push(`avatar = '${data.avatar}'`);
    if (data.address!='') updates.push(`address = '${data.address}'`);
    if (data.country!='') updates.push(`country = '${data.country}'`);
    if (data.state!='') updates.push(`state = '${data.state}'`);
    if (data.city!='') updates.push(`city = '${data.city}'`);
    if (data.postal_code!='') updates.push(`postal_code = '${data.postal_code}'`);
    if (data.phone!='') updates.push(`phone = '${data.phone}'`);
    if (data.balance!='') updates.push(`balance = '${data.balance}'`);
    if (data.banned!='') updates.push(`banned = '${data.banned}'`);
    if (data.referral_code!='') updates.push(`referral_code = '${data.referral_code}'`);
    if (data.customer_package_id!='') updates.push(`customer_package_id = '${data.customer_package_id}'`);
    if (data.remaining_uploads!='') updates.push(`remaining_uploads = '${data.remaining_uploads}'`);
  
    if (updates.length === 0) {
      res.status(400).json({status: (400), message: "No updates provided" });
      return;
    }
  
    let query = `UPDATE users SET ${updates.join(", ")} WHERE id = ? `

    // let query = "UPDATE users SET referred_by = "+ referred_by+" , provider_id = '"+provider_id+"' , user_type = '"+user_type+"' , name = '"+name+"' , email = '"+email+"' , email_verified_at = "+email_verified_at+" , verification_code = '"+verification_code+"', new_email_verificiation_code = '"+new_email_verificiation_code+"',  password = '"+password+"',  remember_token = '"+remember_token+"', device_token = '"+device_token+"' , avatar = '"+avatar+"', address = '"+address+"', country = '"+country+"', state = '"+ state+"', city = '"+city+"', postal_code = '"+postal_code+"', phone = '"+phone+"',  balance = "+balance+" ,  banned = "+banned+" , referral_code = '"+referral_code+"', customer_package_id = "+customer_package_id+" ,remaining_uploads = "+remaining_uploads+" , updated_at = now()  WHERE id = ? "

    sql.query(query, id, (err, res) => {
        if (err) {
            console.log(err)
            result(err, null);
            return;
        }
        if (res.affectedRows == 0) {
            result({ kind: "not_found" }, null);
            return;
        }
        console.log("updated cust User : ", { id: id, ...data });
        result(null, data.id);
    });
};

CustUser.putCustProfile = (id, data, result) => {

    let name = data.name || null;
    let email = data.email || null;
    let password = data.password || null;
    let phone = data.phone || null;
    let avatar = data.avatar || null;

    const encryptedpassword = md5(data.password);
    console.log('encrypted :',encryptedpassword);  
    console.log('pasword :',password);  

    let query = " UPDATE users SET name = ' " + name + " ' , email = '" + email + "', password = '"+encryptedpassword+"' , phone = '" + phone + "', avatar = '"+avatar+"' , updated_at = now()  WHERE id = ? "

    sql.query(query, id, (err, res) => {
        if (err) {
            console.log(err)
            return;
        }
        if (res.affectedRows == 0) {
            // not found Tutorial with the id
            result({ kind: "not_found" }, null);
            return;
        }
        console.log("updated user : ", { id: id, ...data });
        result(null, data.id);
    });
};
 
CustUser.getCustUserID = (id, result) => {
    let query  = ` select * from users as us `
        query += ` where us.banned = 0 and us.user_type='customer' and us.id = ?`

    sql.query(query, id, (err, res) => {
        if (err) {
            result(null, err);
            return;
        }
        if (res == !id) {
            result({ kind: "not_found" }, null);
            return;
        }
        result(null, res[0]);
        console.log(null, res[0]);
        });
    };

CustUser.deleteCustUser = (id, result) => {
    console.log(id);
    let query  = ` DELETE FROM users ` 
        query += ` WHERE users.id = ? and users.user_type='customer' `;
        
    sql.query(query, id, (err, res) => {
        if (err) {
            console.log(err)
            result(err, null);
            return;
        }
        if (res.affectedRows == 0) {
            result({ kind: "not_found" }, null);
            return;
        }
        console.log("deleted cust user : ", { id: id });
        result(null, res);
    });
};

module.exports = CustUser;
