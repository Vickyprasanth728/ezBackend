const sql = require("../models/db.js");

// Constructor
const Subscribers = function (subscribers) {
    this.id = subscribers.id;
    this.email = subscribers.email;
 };

Subscribers.saveCustSubscribers = (data, result) => {
    console.log(data);
    let query = "INSERT INTO subscribers SET ?";
    sql.query(query, data, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      result(null, res);
    });
  };

module.exports = Subscribers;
