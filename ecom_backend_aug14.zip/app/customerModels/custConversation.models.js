const sql = require("../models/db.js");

// Constructor
const CustConversation = function (conversation) {
    this.id = conversation.id;
    this.sender_id = conversation.sender_id	,
    this.receiver_id = conversation.receiver_id,
    this.title = conversation.title	,
    this.sender_viewed = conversation.sender_viewed,
    this.receiver_viewed = conversation.receiver_viewed
 };

 CustConversation.saveCustConversation = (data, result) => {
    console.log(data);
    let query = "INSERT INTO conversations SET ?";
    sql.query(query, data, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      result(null, res);
    });
};

 CustConversation.getCustConversation = (sender_id, result) => {
  let query  = ` select con.*, m.message as messages, us1.name as sender, us2.name as receiver, us1.user_type as sender_type, us2.user_type as receiver_type from conversations as con `

      query += ` LEFT JOIN messages as m ON (con.id = m.conversation_id) `
      query += ` LEFT JOIN users as us ON (us.id = m.user_id) `
      query += ` LEFT JOIN users as us1 ON (con.sender_id = us1.id) `
      query += ` LEFT JOIN users as us2 ON (con.receiver_id = us2.id) `
      query += ` WHERE con.sender_id = ${sender_id} `
      query += ` GROUP BY con.id `
      query += ` ORDER BY con.id `
  
   sql.query(query, sender_id, (err, res) => {
     if (err) {
       result(null, err);
       return;
     }
     result(null, res);
   });
};

 CustConversation.getCustConversationID = (id, result) => {
  let query  = ` select con.*, m.message as messages, us.name as users, us1.name as sender, us2.name as receiver from conversations as con `

      query += ` LEFT JOIN messages as m ON (con.id = m.conversation_id) `
      query += ` LEFT JOIN users as us ON (us.id = m.user_id) `
      query += ` LEFT JOIN users as us1 ON (con.sender_id = us1.id) `
      query += ` LEFT JOIN users as us2 ON (con.receiver_id = us2.id) `
      query += ` WHERE con.id = ? `
  
   sql.query(query, id, (err, res) => {
     if (err) {
       result(null, err);
       return;
     }
     result(null, res[0]);
   });
};

module.exports = CustConversation;
