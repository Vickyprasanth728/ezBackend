const sql = require("../models/db.js");

// constructor
const CustShipping = function (addresses) {
    this.user_id = addresses.user_id,
    this.address = addresses.address,
    this.country_id = addresses.country_id,
    this.state_id = addresses.state_id,
    this.city_id = addresses.city_id,
    this.longitude = addresses.longitude,
    this.latitude = addresses.latitude,
    this.postal_code = addresses.postal_code,
    this.phone = addresses.phone,
    this.set_default = addresses.set_default
};

CustShipping.getCustShipping = (user_id, result) => {

  let query = ` SELECT ad.*, cou.name as country, st.name as state, c.name as city, us.name as users from addresses as ad `

  query += ` LEFT JOIN states as st ON (ad.state_id = st.id) `
  query += ` LEFT JOIN countries as cou ON (ad.country_id = cou.id) `
  query += ` LEFT JOIN cities as c ON (ad.city_id = c.id) `
  query += ` LEFT JOIN users as us ON (ad.user_id = us.id) `
  query += ` WHERE ad.user_id = ${user_id} and us.user_type = 'customer' `
  query += ` GROUP BY ad.id `
  query += ` ORDER BY ad.id `

  sql.query(query, user_id, (err, res) => {
    if (err) {
      result(null, err);
      return;
    }
    if (res == !user_id) {
      result({ kind: "not_found" }, null);
      return;
    }
    result(null, res[0]);
    console.log(null, res[0]);
  });
};

CustShipping.saveCustShipping = (data, result) => {
  console.log(data);
  let query = "INSERT INTO addresses SET ?";
  sql.query(query, data, (err, res) => {
    if (err) {
      console.log(err)
      result(err, null);
      return;
    }
    result(null, res);
  });
};

CustShipping.putCustShipping = (id, data, result) => {

  // let user_id = data.user_id || null
  // let address = data.address || null
  // let country_id = data.country_id || null
  // let state_id = data.state_id || null
  // let city_id = data.city_id || null
  // let longitude = data.longitude || null
  // let latitude = data.latitude || null
  // let postal_code = data.postal_code || null
  // let phone = data.phone || null
  // let set_default = data.set_default || null

  const updates = [];

  if (data.user_id != '') updates.push(`user_id = '${data.user_id}'`);
  if (data.address != '') updates.push(`address = '${data.address}'`);
  if (data.country_id != '') updates.push(`country_id = '${data.country_id}'`);
  if (data.state_id != '') updates.push(`state_id = '${data.state_id}'`);
  if (data.city_id != '') updates.push(`city_id = '${data.city_id}'`);
  if (data.longitude != '') updates.push(`longitude = '${data.longitude}' `);
  if (data.latitude != '') updates.push(`latitude = '${data.latitude}' `);
  if (data.postal_code != '') updates.push(`postal_code = '${data.postal_code}' `);
  if (data.phone != '') updates.push(`phone = '${data.phone}' `);
  if (data.set_default != '') updates.push(`set_default = '${data.set_default}' `);

  if (updates.length === 0) {
    res.status(400).json({ status: (400), message: "No updates provided" });
    return;
  }

  let query = `UPDATE addresses SET ${updates.join(", ")} WHERE id = ? `

  // let query = "UPDATE addresses SET user_id = "+user_id+" , address = '"+address+"' , country_id =  "+country_id+" , country_id = "+country_id+" , state_id = "+state_id+",  city_id = "+city_id+" , longitude = "+longitude+" , latitude = "+latitude+" , postal_code = '"+postal_code+"' , phone = '"+phone+"' , set_default = "+set_default+" ,   updated_at = now()  WHERE id = ? "

  sql.query(query, id, (err, res) => {
    if (err) {
      console.log(err)
      result(err, null);
      return;
    }
    if (res.affectedRows == 0) {
      result({ kind: "not_found" }, null);
      return;
    }
    console.log("Updated Shipping Info : ", { id: id, ...data });
    result(null, data.id);
  });
};

CustShipping.getCustShippingID = (id, result) => {

  let query = ` SELECT ad.*, st.name as state, cou.name as country, c.name as city, us.name as users from addresses as ad `

  query += ` LEFT JOIN states as st ON (ad.state_id = st.id) `
  query += ` LEFT JOIN countries as cou ON (ad.country_id = cou.id) `
  query += ` LEFT JOIN cities as c ON (ad.city_id = c.id) `
  query += ` LEFT JOIN users as us ON (ad.user_id = us.id) `
  query += ` WHERE ad.id = ? and us.user_type = 'customer' `
  query += ` GROUP BY ad.id `
  query += ` ORDER BY ad.id `

  sql.query(query, id, (err, res) => {
    if (err) {
      result(null, err);
      return;
    }
    if (res == !id) {
      result({ kind: "not_found" }, null);
      return;
    }
    result(null, res[0]);
    console.log(null, res[0]);
  });
};

CustShipping.deleteCustShipping = (id, result) => {
  console.log(id);
  let query = "DELETE FROM addresses WHERE id = ?";
  sql.query(query, id, (err, res) => {
    if (err) {
      console.log(err)
      result(err, null);
      return;
    }
    if (res.affectedRows == 0) {
      result({ kind: "not_found" }, null);
      return;
    }
    console.log("Deleted Shipping Info : ", { id: id });
    result(null, res);
  });
};

CustShipping.UpdateShippingDefault = (keyword, id, result) => {
  // let query  = ` UPDATE addresses SET set_default = '2' `
  //     query += ` WHERE id = ?  `

  let query = ``

  if (keyword == "set_default") {
    query += ` UPDATE addresses SET set_default = '2' `
    query += ` WHERE id = ?  `
  }

  sql.query(query, id, (err, res) => {
    if (err) {
      console.log(err)
      result(err, null);
      return;
    }
    if (res.affectedRows == 0) {
      result({ kind: "not_found" }, null);
      return;
    }
    console.log("Address Default Updated Succesfully :", { id });
    result(null, res);
  });
};


CustShipping.getCustShippingStates = (result) => {
  let query = ` SELECT st.* , c.name as country_name from states as st `

  query += ` LEFT JOIN countries as c on (c.id = st.country_id) `

  sql.query(query, (err, res) => {
    if (err) {
      result(null, err);
      return;
    }
    result(null, res);
  });
};

CustShipping.getCustShippingStateID = (id, result) => {
  let query = ` SELECT st.* , c.name as country_name from states as st `

  query += ` LEFT JOIN countries as c on (c.id = st.country_id) `
  query += ` WHERE st.id = ? `

  sql.query(query, id, (err, res) => {
    if (err) {
      result(null, err);
      return;
    }
    if (res == !id) {
      result({ kind: "not_found" }, null);
      return;
    }
    result(null, res[0]);
    console.log(null, res[0]);
  });
};

CustShipping.getCustShippingCities = (result) => {
  let query = ` SELECT c.* , s.name as state_name from cities as c `

  query += ` LEFT JOIN states as s on (c.state_id = s.id) `

  sql.query(query, (err, res) => {
    if (err) {
      result(null, err);
      return;
    }
    result(null, res);
  });
};

CustShipping.getCustShippingCityID = (id, result) => {
  let query = ` SELECT c.* , s.name as state_name from cities as c `

  query += ` LEFT JOIN states as s on (c.state_id = s.id) `
  query += ` WHERE c.id = ? `

  sql.query(query, id, (err, res) => {
    if (err) {
      result(null, err);
      return;
    }
    if (res == !id) {
      result({ kind: "not_found" }, null);
      return;
    }
    result(null, res[0]);
    console.log(null, res[0]);
  });
};

CustShipping.getCustShippingCountries = (result) => {
  let query = ` SELECT cou.* from countries as cou `

  sql.query(query, (err, res) => {
    if (err) {
      result(null, err);
      return;
    }
    result(null, res);
  });
};

CustShipping.getCustShippingCountryID = (id, result) => {
  let query = ` SELECT cou.* from countries as cou `

  query += ` WHERE cou.id = ? `

  sql.query(query, id, (err, res) => {
    if (err) {
      result(null, err);
      return;
    }
    if (res == !id) {
      result({ kind: "not_found" }, null);
      return;
    }
    result(null, res[0]);
    console.log(null, res[0]);
  });
};


module.exports = CustShipping;
