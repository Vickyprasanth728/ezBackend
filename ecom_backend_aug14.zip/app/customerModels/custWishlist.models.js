const sql = require("../models/db.js");

// constructor
const custWishlists = function (wishlists) {
    this.user_id = wishlists.user_id;
    this.product_id = wishlists.product_id;
  };

custWishlists.getWishlists = (user_id, result) => {
  let query  = ` SELECT wi.*, us.name as users, p.name as product_name FROM wishlists as wi `
      query += ` LEFT JOIN users as us on (us.id = wi.user_id) ` 
      query += ` LEFT JOIN products as p on (p.id = wi.product_id) `
      query += ` WHERE wi.user_id = ${user_id} and us.user_type = 'customer' `
      query += ` GROUP BY wi.id ` 
      query += ` ORDER BY wi.id ` 

    sql.query(query, user_id, (err, res) => {
      if (err) {
        result(null, err);
        return;
      }
      else {
        result(null, res);
      }
    })
  };

custWishlists.saveWishlist = (data, result) => {
  console.log(data);
  let query = "INSERT INTO wishlists SET ?";
  sql.query(query, data, (err, res) => {
    if (err) {
      console.log(err)
      result(err, null);
      return;
    }
    result(null, res);
  });
};

custWishlists.deleteWishlist = (id, result) => {
    console.log(id);
    let query = "DELETE FROM wishlists WHERE id = ?";
    sql.query(query, id, (err, res) => {
        if (err) {
        console.log(err)
        result(err, null);
        return;
        }
        if (res.affectedRows == 0) {
        result({ kind: "not_found" }, null);
        return;
        }
        console.log("Deleted wishlists : ", { id: id });
        result(null, res);
    });
    };

module.exports = custWishlists;