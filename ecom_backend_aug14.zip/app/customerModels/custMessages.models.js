const sql = require("../models/db.js");


// Constructor
const CustMessages = function (messages) {
  this.id = messages.id;
  this.conversation_id = messages.conversation_id,
  this.user_id = messages.user_id,
  this.message = messages.message	
};

CustMessages.getCustMessages = (conversation_id, result) => {
let query  = ` select mes.*, us.name as users, us.user_type as user_type from messages as mes `

    query += ` LEFT JOIN conversations as con ON (con.id = mes.conversation_id) `
    query += ` LEFT JOIN users as us ON (us.id = mes.user_id) `
    query += ` WHERE mes.conversation_id = ${conversation_id} `
    query += ` GROUP BY mes.id `
    query += ` ORDER BY mes.id `

 sql.query(query,conversation_id, (err, res) => {
   if (err) {
     result(null, err);
     return;
   }
   result(null, res);
 });
};

CustMessages.saveCustMessage = (data, result) => {
  console.log(data);
  let query = "INSERT INTO messages SET ?";
  sql.query(query, data, (err, res) => {
    if (err) {
      console.log(err)
      result(err, null);
      return;
    }
    result(null, res);
  });
};

module.exports = CustMessages;