const sql = require("../models/db.js");

// constructor
const CustTicketReply = function (tickets) {
    this.id = tickets.id;
    this.ticket_id = tickets.ticket_id || null,
    this.user_id = tickets.user_id || null,
    this.reply = tickets.reply || null,
    this.files = tickets.files || null
  };

  CustTicketReply.getCustTicketReplyList = (ticket_id , result) => {
    let query  = ` SELECT tr.*  FROM ticket_replies as tr `
  
    query += ` LEFT JOIN tickets as tic on (tr.ticket_id = tic.id) `
    query += ` LEFT JOIN users as us on (us.id = tr.user_id) `
    query += ` WHERE tr.ticket_id = ${ticket_id} `
    query += ` GROUP BY tr.id `  
    query += ` ORDER BY tr.id `
  
    sql.query(query, (err, res) => {
      if (err) {
        result(null, err);
        return;
      }
      result(null, res);
      console.log(null, res);
    });
  };

CustTicketReply.saveCustTicketReply = (data, result) => {
    console.log(data);
    let query = "INSERT INTO ticket_replies SET ?";
    sql.query(query, data, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      result(null, res);
    });
  };
module.exports = CustTicketReply;
