const sql = require("../models/db.js");

// constructor
const CustUploadFiles = function (uploadfiles) {
    this.id = uploadfiles.id;
    this.file_original_name = uploadfiles.file_original_name;
    this.file_name = uploadfiles.file_name;
    this.user_id = uploadfiles.user_id;
    this.file_size = uploadfiles.file_size;
    this.extension = uploadfiles.extension;
    this.type = uploadfiles.type;
    this.external_link = uploadfiles.external_link;
 };

CustUploadFiles.getCustUploadFiles = (user_id, result) => {

    let query  = ` SELECT up.* FROM uploads as up `
        query += ` LEFT JOIN users as us ON (up.user_id = us.id)  `
        query += ` WHERE up.user_id = ${user_id}  and us.user_type = 'customer' `
        query += ` GROUP BY up.id `
        query += ` ORDER BY up.id `
     
     sql.query(query, user_id , (err, res) => {
       if (err) {
         result(null, err);
         return;
       }
       result(null, res);
     });
 };

module.exports = CustUploadFiles;
