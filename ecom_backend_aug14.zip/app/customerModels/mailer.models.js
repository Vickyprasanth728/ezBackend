const dbConfig = require("../config/db.config.js");
var nodemailer = require('nodemailer');

let mailer = nodemailer.createTransport({
  host: dbConfig.smtpHost,
  port: dbConfig.smtpPort,
  auth: {
    user: dbConfig.smtpUserName,
    pass: dbConfig.smtpPassword,
  },
});

module.exports = mailer;