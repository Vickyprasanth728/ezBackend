const sql = require("../models/db.js");

// Constructor
const OrderDetails = function (orderDetails) {
    this.id = orderDetails.id;
    this.order_id = orderDetails.order_id;
    this.seller_id = orderDetails.seller_id;
    this.product_id = orderDetails.product_id;
    this.variation = orderDetails.variation;
    this.price = orderDetails.price;
    this.tax = orderDetails.tax;
    this.shipping_cost = orderDetails.shipping_cost;
    this.quantity = orderDetails.quantity;
    this.payment_status = orderDetails.payment_status;
    this.delivery_status = orderDetails.delivery_status;
    this.shipping_type = orderDetails.shipping_type;
    this.pickup_point_id = orderDetails.pickup_point_id;
    this.product_referral_code = orderDetails.product_referral_code
 };

 OrderDetails.getCustOrderDetails = (result) => {
    let query  = ` select od.* from  order_details as od `
  
        query += ` LEFT JOIN users as us on (us.id = o.user_id) `
        query += ` LEFT JOIN products as p on (us.id = p.user_id) `
        query += ` LEFT JOIN shops as s on (s.user_id = us.id) `
        query += ` LEFT JOIN payments as pay on (us.id = o.user_id) `
        query += ` LEFT JOIN carriers as car on (car.id = o.carrier_id) `
        query += ` GROUP BY o.id `
        query += ` ORDER BY o.id DESC  `
    
     sql.query(query, (err, res) => {
       if (err) {
         result(null, err);
         return;
       }
       result(null, res);
     });
  };
  
  OrderDetails.saveCustOrderDetail = (data, result) => {
      console.log(data);
      let query = "INSERT INTO order_details SET ?";
      sql.query(query, data, (err, res) => {
        if (err) {
          console.log(err)
          result(err, null);
          return;
        }
        result(null, res);
      });
    };
  
    OrderDetails.deleteCustOrderDetails = (order_id, result) => {
      console.log(order_id);
      let query = "DELETE FROM order_details WHERE order_id = ?";
      sql.query(query, order_id, (err, res) => {
        if (err) {
          console.log(err)
          result(err, null);
          return;
        }
        if (res.affectedRows == 0) {
          result({ kind: "not_found" }, null);
          return;
        }
        console.log("Order details Deleted Succesfully : ", { id: order_id });
        result(null, res);
      });
    };
  module.exports = OrderDetails;