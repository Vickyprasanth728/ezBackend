const sql = require("../models/db.js");

// constructor
const Carts = function (carts) {
    this.owner_id = carts.owner_id,
    this.user_id = carts.user_id,
    this.temp_user_id = carts.temp_user_id,
    this.address_id = carts.address_id	,
    this.product_id = carts.product_id,
    this.variation = carts.variation,
    this.price = carts.price,
    this.tax = carts.tax,
    this.shipping_cost = carts.shipping_cost,
    this.shipping_type = carts.shipping_type,
    this.pickup_point = carts.pickup_point,
    this.carrier_id = carts.carrier_id,
    this.discount = carts.discount,
    this.product_referral_code = carts.product_referral_code,
    this.coupon_code = carts.coupon_code,
    this.coupon_applied = carts.coupon_applied,
    this.quantity = carts.quantity
  };


  Carts.getCarts = (result) => {

  let query  = ` SELECT ca.*, ad.address as address, us.name as users, p.name as product_name, car.name as carrier_name, pp.name as pickup_place, cou.code as coupon_name FROM carts as ca `

      query += ` LEFT JOIN addresses as ad ON (ca.address_id = ad.id) `
      query += ` LEFT JOIN users as us ON (ca.user_id = us.id) `
      query += ` LEFT JOIN products as p ON (ca.product_id = p.id) `
      query += ` LEFT JOIN carriers as car ON (ca.carrier_id = car.id) `
      query += ` LEFT JOIN pickup_points as pp ON (ca.pickup_point = pp.id) `
      query += ` LEFT JOIN coupons as cou ON (ca.coupon_code = cou.id) `
      query += ` GROUP BY ca.id `
      query += ` ORDER BY ca.id `


    sql.query(query, (err, res) => {
      if (err) {
        result(null, err);
        return;
      }
      else {
        result(null, res);
      }
    })
  };

  Carts.saveCart = (data, result) => {
    console.log(data);
    let query = "INSERT INTO carts SET ?";
    sql.query(query, data, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      result(null, res);
    });
  };


  Carts.putCart = (id, data, result) => {

    // let owner_id = data.owner_id || null
    // let user_id = data.user_id || null
    // let temp_user_id = data.temp_user_id || null
    // let address_id = data.address_id	 || null
    // let product_id = data.product_id || null
    // let variation = data.variation || null
    // let price = data.price || null
    // let tax = data.tax || null
    // let shipping_cost = data.shipping_cost || null
    // let shipping_type = data.shipping_type || null
    // let pickup_point = data.pickup_point || null
    // let carrier_id = data.carrier_id || null
    // let discount = data.discount || null
    // let product_referral_code = data.product_referral_code || null
    // let coupon_code = data.coupon_code || null
    // let coupon_applied = data.coupon_applied || null
    // let quantity = data.quantity || null

    const updates = [];

    if (data.owner_id!='') updates.push(`owner_id = '${data.owner_id}'`);
    if (data.user_id!='') updates.push(`user_id = '${data.user_id}'`);
    if (data.temp_user_id!='') updates.push(`temp_user_id = '${data.temp_user_id}'`);
    if (data.address_id!='') updates.push(`address_id = '${data.address_id}'`);
    if (data.product_id!='') updates.push(`product_id = '${data.product_id}'`);
    if (data.variation!='') updates.push(`variation = '${data.variation}' `);
    if (data.price!='') updates.push(`price = '${data.price}' `);
    if (data.tax!='') updates.push(`tax = '${data.tax}' `);
    if (data.shipping_cost!='') updates.push(`shipping_cost = '${data.shipping_cost}' `);
    if (data.shipping_type!='') updates.push(`shipping_type = '${data.shipping_type}' `);
    if (data.pickup_point!='') updates.push(`pickup_point = '${data.pickup_point}' `);
    if (data.carrier_id!='') updates.push(`carrier_id = '${data.carrier_id}' `);
    if (data.discount!='') updates.push(`discount = '${data.discount}' `);
    if (data.product_referral_code!='') updates.push(`product_referral_code = '${data.product_referral_code}' `);
    if (data.coupon_code!='') updates.push(`coupon_code = '${data.coupon_code}' `);
    if (data.coupon_applied!='') updates.push(`coupon_applied = '${data.coupon_applied}' `);
    if (data.quantity!='') updates.push(`quantity = '${data.quantity}' `);
  
    if (updates.length === 0) {
      res.status(400).json({status: (400), message: "No updates provided" });
      return;
    }
  
    let query = `UPDATE carts SET ${updates.join(", ")} WHERE id = ? `
   
    // let query = "UPDATE carts SET owner_id = "+owner_id+" , user_id = "+user_id+" , temp_user_id =  "+temp_user_id+" , address_id = "+address_id+" , product_id = "+product_id+" , variation = '"+variation+"' , price = "+price+" , tax = "+tax+" , shipping_cost = "+shipping_cost+" , shipping_type = '"+shipping_type+"' ,  pickup_point = "+pickup_point+" ,  carrier_id = "+carrier_id+" ,  discount = "+discount+" , product_referral_code = '"+product_referral_code+"' , coupon_code = '"+coupon_code+"' , coupon_applied = "+coupon_applied+" ,  quantity = "+quantity+" ,   updated_at = now()  WHERE id = ? "
  
    sql.query(query, id, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      if (res.affectedRows == 0) {
        result({ kind: "not_found" }, null);
        return;
      }
      console.log("Updated Cart : ", { id: id, ...data });
      result(null, data.id);
    });
  };

  Carts.getCartID = (id , result) => {
    let query = " SELECT * FROM carts WHERE id = ? "
  
    sql.query(query, id, (err, res) => {
      if (err) {
        result(null, err);
        return;
      }
      if (res == !id) {
        result({ kind: "not_found" }, null);
        return;
      }
      result(null, res[0]);
      console.log(null, res[0]);
    });
    };

    Carts.deleteCart = (id, result) => {
        console.log(id);
        let query = "DELETE FROM carts WHERE id = ?";
        sql.query(query, id, (err, res) => {
          if (err) {
            console.log(err)
            result(err, null);
            return;
          }
          if (res.affectedRows == 0) {
            result({ kind: "not_found" }, null);
            return;
          }
          console.log("Deleted Carts : ", { id: id });
          result(null, res);
        });
      };

    Carts.deleteAllCarts = (result) => {
      let query = "DELETE FROM carts ";
      sql.query(query,(err, res) => {
        if (err) {
          console.log(err)
          result(err, null);
          return;
        }
        if (res.affectedRows == 0) {
          result({ kind: "not_found" }, null);
          return;
        }
        console.log("Your Cart is deleted successfully");
        console.log("Your Cart is Empty now !!!");
        result(null, res);
      });
    };

module.exports = Carts;
