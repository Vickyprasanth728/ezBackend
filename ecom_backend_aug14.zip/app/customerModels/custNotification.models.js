const sql = require("../models/db.js");

// Constructor
const CustNotifications = function (notifications) {
  this.id = notifications.id
  this.type = notifications.type
  this.notifiable_type = notifications.notifiable_type
  this.notifiable_id = notifications.notifiable_id
  this.data = notifications.data
  this.read_at = notifications.read_at
};

CustNotifications.getCustNotifications = (notifiable_id, result) => {
let query  = ` select no.* from notifications as no`

    query += ` WHERE no.notifiable_id = ${notifiable_id} and no.read_at = null `

 sql.query(query, notifiable_id, (err, res) => {
   if (err) {
     result(null, err);
     return;
   }
   result(null, res);
 });
};

CustNotifications.saveCustNotifications = (data, result) => {
  console.log(data);
  let query = "INSERT INTO notifications SET ?";
  sql.query(query, data, (err, res) => {
    if (err) {
      console.log(err)
      result(err, null);
      return;
    }
    result(null, res);
  });
};

module.exports = CustNotifications;