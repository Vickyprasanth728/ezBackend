const sql = require("../models/db.js");

// constructor
const custDashboard = function (dashboard) {
    this.id = dashboard.id;
 };

 
 custDashboard.getCustDashboard = (keyword, user_id, result) => {
  let query = `SELECT`
  
  if (keyword == "carts") {
    query += ` (SELECT ifnull(COUNT(*),0) from carts as c `
    query += ` left join users as us on (us.id = c.user_id) `
    query += ` where us.user_type = 'customer' and c.user_id = ${user_id} ) as total_carts`
  }
  else if (keyword == "wishlist") {
    query += ` (SELECT ifnull(COUNT(*),0) from wishlists as wi `
    query += ` left join users as us on (us.id = wi.user_id) `
    query += ` where us.user_type = 'customer' and wi.user_id = ${user_id} ) as wishlist`
  }
  else if (keyword == "orders") {
    query += ` (SELECT ifnull(COUNT(*),0) from orders as o `
    query += ` left join users as us on (us.id = o.user_id) `
    query += ` where us.user_type = 'customer' and o.user_id = ${user_id} ) as total_orders`
  }

  sql.query(query, (err, res) => {
    if (err) {
      console.log(res)
      console.log("error: ", err);
      result(err, null);
      return;
    }
    result(null, res);
  });
};

module.exports = custDashboard;