const sql = require("../models/db.js");
const util = require('util');

// constructor
const custProduct = function (product) {
   this.name = product.name;
   this.added_by = product.added_by;
   this.user_id = product.user_id;
   this.category_id	 = product.category_id;
   this.brand_id = product.brand_id;
   this.photos	 = product.photos;
   this.thumbnail_img = product.thumbnail_img;
   this.video_provider = product.video_provider;
   this.video_link = product.video_link;
   this.tags = product.tags;
   this.description = product.description;
   this.unit_price = product.unit_price;
   this.purchase_price = product.purchase_price;
   this.variant_product = product.variant_product;
   this.attributes = product.attributes;
   this.choice_options = product.choice_options;
   this.colors = product.colors;
   this.variations = product.variations;
   this.todays_deal = product.todays_deal;
   this.published = product.published;
   this.approved = product.approved;
   this.stock_visibility_state = product.stock_visibility_state;
   this.cash_on_delivery = product.cash_on_delivery;
   this.featured = product.featured;
   this.seller_featured = product.seller_featured;
   this.current_stock = product.current_stock;
   this.unit = product.unit;
   this.weight = product.weight;
   this.min_qty = product.min_qty;
   this.low_stock_quantity = product.low_stock_quantity;
   this.discount = product.discount	;
   this.discount_type = product.discount_type;
   this.discount_start_date = product.discount_start_date;
   this.discount_end_date = product.discount_end_date;
   this.tax = product.tax;
   this.tax_type = product.tax_type;
   this.shipping_type = product.shipping_type;
   this.shipping_cost = product.shipping_cost;
   this.is_quantity_multiplied = product.is_quantity_multiplied;
   this.est_shipping_days = product.est_shipping_days;
   this.num_of_sale = product.num_of_sale;
   this.meta_title = product.meta_title;
   this.meta_description = product.meta_description;
   this.meta_img = product.meta_img;
   this.pdf = product.pdf;
   this.slug = product.slug;
   this.rating = product.rating;
   this.barcode = product.barcode;
   this.digital = product.digital;
   this.auction_product = product.auction_product;
   this.file_name = product.file_name;
   this.file_path = product.file_path;
   this.external_link = product.external_link;
   this.external_link_btn = product.external_link_btn;
   this.wholesale_product = product.wholesale_product;
};

custProduct.getCustProducts = (queryString, result) => {
    let query = "select p.*, cat.name as category_name, br.name as brand_name, us.name as user_name, col.name as color_name, att.name as attributes_name, av.value as attribute_values, up.file_name as image, ps.variant as variant, ps.sku as sku, ps.price as price, ps.qty as qty, fdp.discount as discount_flash, fdp.discount_type as discount_type_flash, sh.name as shop_name, br.logo as brand_logo from products as p "

    query += ` LEFT JOIN categories as cat on (cat.id = p.category_id) `
    query += ` LEFT JOIN brands as br on (br.id = p.brand_id) `
    query += ` LEFT JOIN users as us on (us.id = p.user_id) `
    query += ` LEFT JOIN colors as col on (col.id = p.colors) ` 
    query += ` LEFT JOIN attributes as att on (att.id = p.attributes) `
    query += ` LEFT JOIN attribute_values as av on (att.id = av.attribute_id) `
    query += ` LEFT JOIN uploads as up on (us.id = up.user_id) `
    query += ` LEFT JOIN sellers as sel on (us.id = sel.user_id) `
    query += ` LEFT JOIN shops as sh on (us.id = sh.user_id) `
    query += ` LEFT JOIN product_stocks as ps on (p.id = ps.product_id) `
    query += ` LEFT JOIN flash_deal_products as fdp on (p.id = fdp.product_id) `
    query += ` WHERE p.digital = 0 and p.approved = 1 and p.published = 1 `
    query += ` GROUP BY p.id `

    // Purchase Price
    if (queryString.minPrice && queryString.maxPrice) {
      query += " and p.purchase_price between " + ` ${queryString.minPrice} and ${queryString.maxPrice} `
    }
    // Sort By
    if (queryString.order_by) {
      let orderByString = queryString.order_by.split('|')
      query += " order by " + `${orderByString[0]} ${orderByString[1]} `
    }
    else 
    {
      query += " order by p.id desc"
    }
    
    sql.query(query, (err, res) => {
      if (err) {
        result(null, err);
        return;
      }
      result(null, res);
    });
};

custProduct.getCustProductID = (id , result) => {
    let query = "select p.*, cat.name as category_name, br.name as brand_name, us.name as user_name, col.name as color_name, att.name as attributes_name, av.value as attribute_values, up.file_name as image, ps.variant as variant, ps.sku as sku, ps.price as price, ps.qty as qty, fdp.discount as discount_flash, fdp.discount_type as discount_type_flash, sh.name as shop_name, br.logo as brand_logo from products as p "

    query += ` LEFT JOIN categories as cat on (cat.id = p.category_id) `
    query += ` LEFT JOIN brands as br on (br.id = p.brand_id) `
    query += ` LEFT JOIN users as us on (us.id = p.user_id) `
    query += ` LEFT JOIN colors as col on (col.id = p.colors) ` 
    query += ` LEFT JOIN attributes as att on (att.id = p.attributes) `
    query += ` LEFT JOIN attribute_values as av on (att.id = av.attribute_id) `
    query += ` LEFT JOIN uploads as up on (us.id = up.user_id) `
    query += ` LEFT JOIN sellers as sel on (us.id = sel.user_id) `
    query += ` LEFT JOIN shops as sh on (us.id = sh.user_id) `
    query += ` LEFT JOIN product_stocks as ps on (p.id = ps.product_id) `
    query += ` LEFT JOIN flash_deal_products as fdp on (p.id = fdp.product_id) `
    query += ` WHERE p.digital = 0 and p.approved = 1 and p.published = 1 and p.id = ? `
    query += ` GROUP BY p.id `
    query += ` ORDER BY p.id `
  
    sql.query(query, id, (err, res) => {
      if (err) {
        result(null, err);
        return;
      }
      if (res == !id) {
        result({ kind: "not_found" }, null);
        return;
      }
      result(null, res[0]);
      console.log(null, res[0]);
    });
    };
        
    custProduct.getProductsPriceRange = (queryString,result) => {

    let query  = ` select p.id, p.purchase_price from products as p `

      query += ` LEFT JOIN categories as cat on (cat.id = p.category_id) `
      query += ` LEFT JOIN brands as br on (br.id = p.brand_id) `
      query += ` LEFT JOIN users as us on (us.id = p.user_id) `
      query += ` LEFT JOIN colors as col on (col.id = p.colors) ` 
      query += ` LEFT JOIN attributes as att on (att.id = p.attributes) `
      query += ` LEFT JOIN attribute_values as av on (att.id = av.attribute_id) `
      query += ` LEFT JOIN uploads as up on (us.id = up.user_id) `
      query += ` LEFT JOIN sellers as sel on (us.id = sel.user_id) `
      query += ` LEFT JOIN shops as sh on (us.id = sh.user_id) `
      query += ` LEFT JOIN product_stocks as ps on (p.id = ps.product_id) `
      query += ` LEFT JOIN flash_deal_products as fdp on (p.id = fdp.product_id) `
      query += ` WHERE p.digital = 0 `
      query += ` GROUP BY p.id `

      // purchase price
      if (queryString.minPrice && queryString.maxPrice) {
       query += " and p.purchase_price between " + ` ${queryString.minPrice} and ${queryString.maxPrice} `
      }
        query += ` ORDER BY p.id `
      
      sql.query(query, (err, res) => {
        if (err) {
          result(null, err);
          return;
        }
        result(null, res);
      });
    };

module.exports = custProduct;
