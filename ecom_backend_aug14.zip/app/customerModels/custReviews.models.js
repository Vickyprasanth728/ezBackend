const sql = require("../models/db.js");

// Constructor
const CustReviews = function (reviews) {
    this.product_id = reviews.product_id,
    this.user_id = reviews.user_id,
    this.rating	 = reviews.rating	,
    this.comment = reviews.comment,
    this.status = reviews.status,
    this.viewed = reviews.viewed
 };

 CustReviews.getCustReviews = (result) => {
  let query  = ` select re.*, p.name as product_name, us.name as users from reviews as re `

      query += ` LEFT JOIN products as p ON (p.id = re.product_id) `
      query += ` LEFT JOIN users as us ON (us.id = re.user_id) `
      query += ` GROUP BY re.id `
      query += ` ORDER BY re.id `
  
   sql.query(query, (err, res) => {
     if (err) {
       result(null, err);
       return;
     }
     result(null, res);
   });
};

CustReviews.saveCustReview = (data, result) => {
    console.log(data);
    let query = "INSERT INTO reviews SET ?";
    sql.query(query, data, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      result(null, res);
    });
  };

  CustReviews.putCustReview = (id, data, result) => {

    // let product_id = data.product_id || null
    // let user_id = data.user_id || null
    // let rating = data.rating || null
    // let comment = data.comment	 || null
    // let status = data.status || null
    // let viewed = data.viewed || null

    const updates = [];

    if (data.product_id != '') updates.push(`product_id = '${data.product_id}'`);
    if (data.user_id != '') updates.push(`user_id = '${data.user_id}'`);
    if (data.rating != '') updates.push(`rating = '${data.rating}'`);
    if (data.comment != '') updates.push(`comment = '${data.comment}'`);
    if (data.status != '') updates.push(`status = '${data.status}'`);
    if (data.viewed != '') updates.push(`viewed = '${data.viewed}' `);
  
    if (updates.length === 0) {
      res.status(400).json({ status: (400), message: "No updates provided" });
      return;
    }
  
    let query = `UPDATE reviews SET ${updates.join(", ")} WHERE id = ? `
   
    // let query = " UPDATE reviews SET product_id = "+product_id+" , user_id = "+user_id+" , rating =  "+rating+" , comment = '"+comment+"', status = "+status+" , viewed = "+viewed+",   updated_at = now()  WHERE id = ? "
  
    sql.query(query, id, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      if (res.affectedRows == 0) {
        result({ kind: "not_found" }, null);
        return;
      }
      console.log("updated review : ", { id: id, ...data });
      result(null, data.id);
    });
  };

  CustReviews.getCustReviewID = (id , result) => {
    let query  = ` select re.*, p.name as product_name, us.name as users from reviews as re `

        query += ` LEFT JOIN products as p ON (p.id = re.product_id) `
        query += ` LEFT JOIN users as us ON (us.id = re.user_id) `
        query += ` WHERE re.id = ? `
  
      sql.query(query, id, (err, res) => {
        if (err) {
          result(null, err);
          return;
        }
        if (res == !id) {
          result({ kind: "not_found" }, null);
          return;
        }
        result(null, res[0]);
        console.log(null, res[0]);
      });
    };

    CustReviews.deleteCustReview = (id, result) => {
        console.log(id);
        let query = "DELETE FROM reviews WHERE id = ?";
        sql.query(query, id, (err, res) => {
          if (err) {
            console.log(err)
            result(err, null);
            return;
          }
          if (res.affectedRows == 0) {
            result({ kind: "not_found" }, null);
            return;
          }
          console.log("Deleted Reviews : ", { id: id });
          result(null, res);
        });
      };

module.exports = CustReviews;
