const sql = require("../models/db.js");

// Constructor
const Orders = function (orders) {
    this.combined_order_id = orders.combined_order_id,
    this.user_id = orders.user_id,
    this.guest_id = orders.guest_id,
    this.seller_id = orders.seller_id,
    this.shipping_address = orders.shipping_address,
    this.additional_info = orders.additional_info,
    this.shipping_type = orders.shipping_type,
    this.pickup_point_id = orders.pickup_point_id,
    this.carrier_id = orders.carrier_id,
    this.delivery_status = orders.delivery_status,
    this.payment_type = orders.payment_type,
    this.payment_status = orders.payment_status,
    this.payment_details = orders.payment_details,
    this.grand_total = orders.grand_total,
    this.coupon_discount = orders.coupon_discount,
    this.code = orders.code,
    this.tracking_code = orders.tracking_code,
    this.date = orders.date,
    this.viewed = orders.viewed,
    this.delivery_viewed = orders.delivery_viewed,
    this.payment_status_viewed = orders.payment_status_viewed,
    this.commission_calculated = orders.commission_calculated
 };

 Orders.getCustOrders = (user_id , result) => {
  let query  = ` select o.*, us.email as email, ad.address as address, o.code as order_code, us.name as customer_name, s.name as seller, o.grand_total as amount, o.delivery_status as delivery_status, o.payment_type as payment_method, o.payment_status as payment_status, p.tax as taxes, us.user_type as user_type, p.shipping_cost as shipping_cost, car.name as carrier_name, COUNT(p.id) as num_of_products, cou.discount as coupon_discount_amount, od.variation as Variation, pp.name as pick_point_name from orders as o `

      query += ` LEFT JOIN users as us on (us.id = o.user_id) `
      query += ` LEFT JOIN products as p on (us.id = p.user_id) `
      query += ` LEFT JOIN order_details as od on (o.id = od.order_id) `
      query += ` LEFT JOIN shops as s on (s.user_id = us.id) `
      query += ` LEFT JOIN payments as pay on (us.id = o.user_id) `
      query += ` LEFT JOIN carriers as car on (car.id = o.carrier_id) `
      query += ` LEFT JOIN coupons as cou on (us.id = cou.user_id) `
      query += ` LEFT JOIN addresses as ad on (us.id = ad.user_id) `
      query += ` LEFT JOIN pickup_points as pp on (pp.id = o.pickup_point_id) `
      query += ` WHERE o.user_id = ${user_id} and us.user_type = 'customer' `
      query += ` GROUP BY o.id `
      query += ` ORDER BY o.id DESC  `
  
   sql.query(query, user_id, (err, res) => {
     if (err) {
       result(null, err);
       return;
     }
     result(null, res);
   });
};

Orders.saveCustOrder = (data, result) => {
    console.log(data);
    let query = "INSERT INTO orders SET ?";
    sql.query(query, data, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      result(null, res);
    });
  };

  Orders.getCustOrderID = (id , result) => {

    let query  = ` select o.*, us.email as email, ad.address as address, o.code as order_code, us.name as customer_name, s.name as seller, o.grand_total as amount, o.delivery_status as delivery_status, o.payment_type as payment_method, o.payment_status as payment_status, p.tax as taxes, us.user_type as user_type, p.shipping_cost as shipping_cost, car.name as carrier_name, COUNT(p.id) as num_of_products, cou.discount as coupon_discount_amount, od.variation as Variation, pp.name as pick_point_name from orders as o `

    query += ` LEFT JOIN users as us on (us.id = o.user_id) `
    query += ` LEFT JOIN products as p on (us.id = p.user_id) `
    query += ` LEFT JOIN order_details as od on (o.id = od.order_id) `
    query += ` LEFT JOIN shops as s on (s.user_id = us.id) `
    query += ` LEFT JOIN payments as pay on (us.id = o.user_id) `
    query += ` LEFT JOIN carriers as car on (car.id = o.carrier_id) `
    query += ` LEFT JOIN coupons as cou on (us.id = cou.user_id) `
    query += ` LEFT JOIN addresses as ad on (us.id = ad.user_id) `
    query += ` LEFT JOIN pickup_points as pp on (pp.id = o.pickup_point_id) `
    query += ` WHERE o.id = ? `
    query += ` GROUP BY o.id `
    query += ` ORDER BY o.id DESC  `
  
    sql.query(query, id, (err, res) => {
      if (err) {
        result(null, err);
        return;
      }
      if (res == !id) {
        result({ kind: "not_found" }, null);
        return;
      }
      result(null, res[0]);
      console.log(null, res[0]);
    });
    };

    Orders.deleteCustOrder = (id, result) => {
      console.log(id);
      let query = "DELETE FROM orders WHERE id = ?";
      sql.query(query, id, (err, res) => {
        if (err) {
          console.log(err)
          result(err, null);
          return;
        }
        if (res.affectedRows == 0) {
          result({ kind: "not_found" }, null);
          return;
        }
        console.log("Deleted Order : ", { id: id });
        result(null, res);
      });
    };

Orders.UpdateCustOrdersView = (keyword, id, result) => {
  // let query  = ` UPDATE orders SET viewed = '1' `
  //     query += ` WHERE id = ?  `

  let query = ``

  if (keyword == "viewed") {
    query += ` UPDATE orders SET viewed = '1' `
    query += ` WHERE id = ?  `
  }
  else if (keyword == "delivery_viewed") {
    query += ` UPDATE orders SET delivery_viewed = '1' `
    query += ` WHERE id = ?  `
  }
  else if (keyword == "payment_status_viewed") {
    query += ` UPDATE orders SET payment_status_viewed = '1' `
    query += ` WHERE id = ?  `
  }

  sql.query(query, id, (err, res) => {
    if (err) {
      console.log(err)
      result(err, null);
      return;
    }
    if (res.affectedRows == 0) {
      result({ kind: "not_found" }, null);
      return;
    }
    console.log("Orders Viewed Succesfully :", { id });
    result(null, res);
  });
};

  Orders.getCustOrdersTrack = (queryString, result) => {
    let query  = ` select o.*, us.email as email, ad.address as address, o.code as order_code, us.name as customer_name, s.name as seller, o.grand_total as amount, o.delivery_status as delivery_status, o.payment_type as payment_method, o.payment_status as payment_status, p.tax as taxes, us.user_type as user_type, p.shipping_cost as shipping_cost, car.name as carrier_name, COUNT(p.id) as num_of_products, cou.discount as coupon_discount_amount, od.variation as Variation, pp.name as pick_point_name from orders as o `
  
      query += ` LEFT JOIN users as us on (us.id = o.user_id) `
      query += ` LEFT JOIN products as p on (us.id = p.user_id) `
      query += ` LEFT JOIN order_details as od on (o.id = od.order_id) `
      query += ` LEFT JOIN shops as s on (s.user_id = us.id) `
      query += ` LEFT JOIN payments as pay on (us.id = o.user_id) `
      query += ` LEFT JOIN carriers as car on (car.id = o.carrier_id) `
      query += ` LEFT JOIN coupons as cou on (us.id = cou.user_id) `
      query += ` LEFT JOIN addresses as ad on (us.id = ad.user_id) `
      query += ` LEFT JOIN pickup_points as pp on (pp.id = o.pickup_point_id) `
      query += ` WHERE us.user_type = 'customer' `

      if (queryString.code) {
        query += " and o.code = " + `${queryString.code} `
      }
      query += ` GROUP BY o.id `
      query += ` ORDER BY o.id DESC  `
    
     sql.query(query,(err, res) => {
       if (err) {
         result(null, err);
         return;
       }
       result(null, res);
     });
  };

module.exports = Orders;
