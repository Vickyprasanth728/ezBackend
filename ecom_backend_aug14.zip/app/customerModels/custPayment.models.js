const sql = require("../models/db.js");

// Constructor
const CustomerPayment = function (payment) {
    this.id = payment.id;
    this.user_id = payment.user_id,
    this.customer_package_id = payment.customer_package_id,
    this.payment_method	 = payment.payment_method	,
    this.payment_details = payment.payment_details,
    this.approval = payment.approval,
    this.offline_payment = payment.offline_payment,
    this.reciept = payment.reciept	
 };

 CustomerPayment.getCustomerPayment = (result) => {
  let query  = ` select cp.* from customer_package_payments as cp `

      query += ` LEFT JOIN users as us on (us.id = o.user_id) `
      query += ` LEFT JOIN products as p on (us.id = p.user_id) `
      query += ` LEFT JOIN shops as s on (s.user_id = us.id) `
      query += ` LEFT JOIN payments as pay on (us.id = o.user_id) `
      query += ` LEFT JOIN carriers as car on (car.id = o.carrier_id) `
      query += ` GROUP BY cp.id `
      query += ` ORDER BY cp.id DESC  `
  
   sql.query(query, (err, res) => {
     if (err) {
       result(null, err);
       return;
     }
     result(null, res);
   });
};

CustomerPayment.saveCustomerPayment = (data, result) => {
    console.log(data);
    let query = "INSERT INTO customer_package_payments SET ?";
    sql.query(query, data, (err, res) => {
      if (err) {
        console.log(err)
        result(err, null);
        return;
      }
      result(null, res);
    });
  };


module.exports = CustomerPayment;
