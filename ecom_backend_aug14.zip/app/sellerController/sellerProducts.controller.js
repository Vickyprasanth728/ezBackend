const SellerProducts = require("../sellerModels/sellerProducts.models.js");
const Product = require("../models/product.model.js");
const ProductStock = require("../models/productStock.model.js");
const ProductTaxes = require("../models/productTaxes.model.js");
const ProductTranslation = require("../models/productTranslation.model.js");
const SellerReviews = require("../sellerModels/sellerReviews.models.js");
const fs = require("fs")
const util = require('util');
const sql = require("../models/db.js");
const readXlsxFile = require('read-excel-file/node');

exports.getSellerProducts = (req, res) => {
    SellerProducts.getSellerProducts (req.params.user_id, (err, data) => {
      if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
      else res.send(data);
    });
  };
exports.getSellerDigitalProducts = (req, res) => {
    SellerProducts.getSellerDigitalProducts (req.params.user_id, (err, data) => {
      if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
      else res.send(data);
    });
  };

  // Product Bulk Import
  exports.bulkImport = (async (req, res) => {
    const query = util.promisify(sql.query).bind(sql);
  
    readXlsxFile('./uploads/' + req.file.filename).then((rows) => {
  
      rows.shift();
      rows.forEach(async (row) => {

      // company_name
      const users_nameIdFetch = await query(`select id from users where name ='${row[2]}' limit 1`);
      const users_nameId = users_nameIdFetch[0] ? users_nameIdFetch[0]["id"] : 0

      const category_nameIdFetch = await query(`select id from categories where name ='${row[3]}' limit 1`);
      const categoryId = category_nameIdFetch[0] ? category_nameIdFetch[0]["id"] : 0

      const brand_nameIdFetch = await query(`select id from brands where name ='${row[4]}' limit 1`);
      const brandId = brand_nameIdFetch[0] ? brand_nameIdFetch[0]["id"] : 0

      const attributes_nameIdFetch = await query(`select id from attributes where name ='${row[14]}' limit 1`);
      const attributesId = attributes_nameIdFetch[0] ? attributes_nameIdFetch[0]["id"] : 0

      const color_nameIdFetch = await query(`select id from colors where name ='${row[16]}' limit 1`);
      const colorId = color_nameIdFetch[0] ? color_nameIdFetch[0]["id"] : 0

      const taxes_nameIdFetch = await query(`select id from taxes where name ='${row[60]}' limit 1`);
      const taxesId = taxes_nameIdFetch[0] ? taxes_nameIdFetch[0]["id"] : 0

      let productData = new (Product)({
        name: row[0] || null,
        added_by: row[1] || null,
        user_id: users_nameId,
        category_id: categoryId,
        brand_id: brandId,
        photos: row[5] || null,
        thumbnail_img: row[6] || null,
        video_provider: row[7] || null,
        video_link: row[8] || null,
        tags: row[9] || null,
        description: row[10] || null,
        unit_price: row[11] || null,
        purchase_price: row[12] || null,
        variant_product: row[13] || null,
        attributes: attributesId,
        choice_options: row[15] || null,
        colors: colorId,
        variations: row[17] || null,
        todays_deal: row[18] || null,
        published: row[19] || null,
        approved: row[20] || null,
        stock_visibility_state: row[21] || null,
        cash_on_delivery: row[22] || null,
        featured: row[23] || null,
        seller_featured: row[24] || null,
        current_stock: row[25] || null,
        unit: row[26] || null,
        weight: row[27] || null,
        min_qty: row[28] || null,
        low_stock_quantity: row[29] || null,
        discount: row[30] || null,
        discount_type: row[31] || null,
        discount_start_date: row[32] || null,
        discount_end_date: row[33] || null,
        tax: row[34] || null,
        tax_type: row[35] || null,
        shipping_type: row[36] || null,
        shipping_cost: row[37] || null,
        is_quantity_multiplied: row[38] || null,
        est_shipping_days: row[39] || null,
        num_of_sale: row[40] || null,
        meta_title: row[41] || null,
        meta_description: row[42] || null,
        meta_img: row[43] || null,
        pdf: row[44] || null,
        slug: row[45] || null,
        rating: row[46] || null,
        barcode: row[47] || null,
        digital: row[48] || null,
        auction_product: row[49] || null,
        file_name: row[50] || null,
        file_path: row[51] || null,
        external_link: row[52] || null,
        external_link_btn: row[53] || null,
        wholesale_product: row[54] || null,
      });
      console.log(productData)
      Product.saveProduct(productData, (err, data) => {
        if (err) {
          res.status(500).send({
            message:
              err.message || "Some error occurred while retrieving Contacts."
          });
        }
        else {
          let productId = data.insertId
          let taxId = row[34] || null;
          let taxType = row[35] || null;

          const productstock = new ProductStock({
            product_id: productId,
            variant: row[55] || null,
            sku: row[56] || null,
            price: row[57] || null,
            qty: row[58] || null, 
            image: row[59] || null,
          }); 
      
          const productTaxes = new ProductTaxes({
            product_id : productId,
            tax_id : taxesId,
            tax : taxId,
            tax_type : taxType,
          });
      
          const productTranslation = new ProductTranslation({
            product_id : productId,
            name : row[63] || null,
            unit : row[64] || null,
            description : row[65] || null,
            lang : row[66] || null,
          });

          ProductStock.saveProductStock(productstock, (err, data) => { if (err) { console.log(err); result(err, null); return; } })
          ProductTaxes.saveProductTaxes(productTaxes, (err, data) => { if (err) { console.log(err); result(err, null); return; } })
          ProductTranslation.saveProductTranslation(productTranslation, (err, data) => { if (err) { console.log(err); result(err, null); return; } })
          res.statusCode = 200;
        }
      })
    });
    res.send("Products Saved Succesfully");
  });
});


exports.getSellerProductReviews = (req, res) => {
    SellerReviews.getSellerProductReviews (req.params.user_id, (err, data) => {
      if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
      else res.send(data);
    });
  };