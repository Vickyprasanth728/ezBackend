const SellerConversation = require("../sellerModels/sellerConversations.models.js");
const SellerMessages = require("../sellerModels/sellerMessages.models.js");

// Seller Conversation List
exports.getSellerConversation = (req, res) => {
    SellerConversation.getSellerConversation(req.params.sender_id, (err, data) => {
        if (err)
        res.status(500).send({
          message:
            err.message || "Some error occurred while retrieving data."
        });
        else res.send(data);
      });
    };

exports.getSellerConversationID = (req, res) => {
    SellerConversation.getSellerConversationID(req.params.id, (err, data) => {
        if (err)
        res.status(500).send({
          message:
            err.message || "Some error occurred while retrieving data."
        });
        else res.send(data);
      });
    };

    
// Seller Messages List
exports.getSellerMessages = (req, res) => {
    SellerMessages.getSellerMessages(req.params.conversation_id, (err, data) => {
        if (err)
        res.status(500).send({
          message:
            err.message || "Some error occurred while retrieving data."
        });
        else res.send(data);
      });
    };



