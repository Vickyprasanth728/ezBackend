const SellerUsers = require("../sellerModels/sellerUser.models.js");
const ShopDetails = require("../sellerModels/shopDetails.models.js")
const Sellers = require("../sellerModels/sellers.models.js")
const fs = require("fs")
const path = require("path");
const util = require('util');
const sql = require("../models/db");
const dayjs = require('dayjs');
var md5 = require('md5');

exports.getSellerUsers = (req, res) => {
    SellerUsers.getSellerUsers ((err, data) => {
      if (err)
        res.status(500).send({
          message:
            err.message || "Some error occurred while retrieving data."
        });
      else res.send(data);
    });
  };

  exports.saveSellerUser = (async(req, res) => {

    const email_verify_time = req.body.email_verified_at
    let emailVerifyTime = ""
    if (email_verify_time) {
      let start = dayjs(req.body.email_verified_at);
      emailVerifyTime = start.format("YYYY-MM-DD h:mm:ss")
    } else {
      emailVerifyTime = ""
    }

    if (!req.body) {
      res.status(400).send({
        message: "Cust User Cannot be Empty"
      });
    }
  
    const query1 = util.promisify(sql.query).bind(sql);
    const executivesFetch = await query1(`select email from users where email='${req.body.email}' limit 1`);
    const executives = executivesFetch[0] ? executivesFetch[0]["exec"] : 0
    
    if(executives != 0){
      res.send("Email already exists");
    }
    else {
    let avatar = "";

    if (req.files.avatar) {
        const extension = req.files.avatar[0]["mimetype"].split('/')[1]
        avatar = req.files.avatar[0]["filename"] + '.' + extension
        avatar_original = req.files.avatar[0]["originalname"]
      }

      const hashedPassword = md5(req.body.password);
  
      const users = new SellerUsers({
        id: req.body.id,
        referred_by : req.body.referred_by,
        provider_id : req.body.provider_id,
        user_type : 'seller',
        name : req.body.name,
        email : req.body.email ,
        email_verified_at : emailVerifyTime,
        verification_code : req.body.verification_code,
        new_email_verificiation_code : req.body.new_email_verificiation_code,
        password : hashedPassword,
        remember_token : req.body.remember_token,
        device_token : req.body.device_token,
        avatar : avatar || null,
        avatar_original : avatar_original || null,
        address : req.body.address,
        country : req.body.country,
        state	 : req.body.state,
        city : req.body.city,
        postal_code : req.body.postal_code,
        phone : req.body.phone,
        balance : req.body.balance,
        banned : req.body.banned,
        referral_code : req.body.referral_code,
        customer_package_id : req.body.customer_package_id,
        remaining_uploads : req.body.remaining_uploads,
      });
  
    SellerUsers.saveSellerUser( users, (err, data) => {
      if (err) {
        console.log(err)
        res.status(500).send({
          message:
            err.message || "Some error occurred while posting seller user  ."
        });
      }
      else {

        let userId = data.insertId;
        let nameId = req.body.name;
        let addressId =  req.body.address;
        let phoneId =  req.body.phone;

        if (req.files.avatar) {
          
          const currentPath = path.join(process.cwd(), "uploads", req.files.avatar[0]["filename"]);
          const destinationPath = path.join(process.cwd(), "/uploads/users/avatar/" + `${userId}`, avatar);
          const baseUrl = process.cwd() + '/uploads/users/avatar/' + `${userId}`
          fs.mkdirSync(baseUrl, { recursive: true })
          fs.rename(currentPath, destinationPath, function (err) {
            if (err) {
              throw err
            } else {
              console.log("Successfully moved the avatar seller user files !")
            }
          });
        }
          const shops = new ShopDetails({
            user_id : userId || null,
            name : nameId || null,
            logo : req.body.logo || null,
            sliders : req.body.sliders || null,
            phone : phoneId || null,
            address : addressId || null,
            rating : req.body.rating || null,
            num_of_reviews : req.body.num_of_reviews || null,
            num_of_sale : req.body.num_of_sale || null,
            seller_package_id : req.body.seller_package_id || null,
            product_upload_limit : req.body.product_upload_limit || null,
            package_invalid_at : req.body.package_invalid_at || null,
            verification_status : req.body.verification_status || null,
            verification_info : req.body.verification_info || null,
            cash_on_delivery_status : req.body.cash_on_delivery_status || null,
            admin_to_pay : req.body.admin_to_pay || null,
            facebook : req.body.facebook || null,
            instagram : req.body.instagram || null,
            google : req.body.google || null,
            twitter : req.body.twitter || null,
            youtube : req.body.youtube || null,
            slug : req.body.slug || null,
            meta_title : req.body.meta_title || null,
            meta_description : req.body.meta_description || null,
            pick_up_point_id : req.body.pick_up_point_id || null,
            shipping_cost : req.body.shipping_cost || null,
            delivery_pickup_latitude : req.body.delivery_pickup_latitude || null,
            delivery_pickup_longitude : req.body.delivery_pickup_longitude || null,
            bank_name : req.body.bank_name || null,
            bank_acc_name : req.body.bank_acc_name || null,
            bank_acc_no : req.body.bank_acc_no || null,
            bank_routing_no : req.body.bank_routing_no || null,
            bank_payment_status : req.body.bank_payment_status  || null,	
        });

          let ratingId = req.body.rating || null
          let NoOfReviews = req.body.num_of_reviews || null
          let NoOfSale = req.body.num_of_sale || null
          let verifyStatus = req.body.verification_status || null
          let verifyInfo = req.body.verification_info || null
          let Cod = req.body.cash_on_delivery_status || null;
          let bankName = req.body.bank_name || null;
          let bankAccName =  req.body.bank_acc_name || null;
          let bankAccNo =  req.body.bank_acc_no || null;
          let bankRouteNo =  req.body.bank_routing_no || null;
          let adminToPay = req.body.admin_to_pay || null;
          let paymentStatus = req.body.admin_to_pay || null;

          const sellers = new Sellers({
            user_id: userId ,
            rating: ratingId ,
            num_of_reviews: NoOfReviews,
            num_of_sale: NoOfSale,
            verification_status: verifyStatus ,
            verification_info: verifyInfo,
            cash_on_delivery_status: Cod ,
            admin_to_pay: adminToPay ,
            bank_name: bankName,
            bank_acc_name: bankAccName,
            bank_acc_no: bankAccNo,
            bank_routing_no: bankRouteNo,
            bank_payment_status:paymentStatus,
        });

        ShopDetails.saveShopDetail (shops, (err, data) => {
          if (err) {
            console.log(err)
            console.log("Shop Details posted successfully");
            console.log("Posted Successfully");
            res.statusCode = 200;
          }
        });

        Sellers.saveSeller (sellers , (err, data) => {
          if (err) {
            console.log(err)
            console.log("Seller Details posted successfully");
            console.log("Posted Successfully");
            res.statusCode = 200;
          }
        });
        console.log("Posted Successfully");
        res.status(200).send({
          message: "Posted Successfully",
          output: data
        })
      }
    });
  }
  });

  exports.putSellerUser = (async(req, res) => {

    const email_verify_time = req.body.email_verified_at
    let emailVerifyTime = ""
    if (email_verify_time) {
      let start = dayjs(req.body.email_verified_at);
      emailVerifyTime = start.format("YYYY-MM-DD")
    } else {
      emailVerifyTime = " "
    }

    if (!req.body) {
      res.status(400).send({
        message: "User Cannot be Empty"
      });
    }
  
    const query1 = util.promisify(sql.query).bind(sql);
    const executivesFetch = await query1(`select email from users where email='${req.body.email}' limit 1`);
    const executives = executivesFetch[0] ? executivesFetch[0]["exec"] : 0
    
    if(executives != 0){
      res.send("Email already exists");
    }
    else {
    let avatar = "";

    if (req.files.avatar) {
      const extension = req.files.avatar[0]["mimetype"].split('/')[1]
      avatar = req.files.avatar[0]["filename"] + '.' + extension
      avatar_original = req.files.avatar[0]["originalname"]
    }

    const hashedPassword = md5(req.body.password);

    const users = new SellerUsers({
      id: req.body.id || null,
      referred_by : req.body.referred_by || null,
      provider_id : req.body.provider_id || null,
      user_type : 'seller' || null,
      name : req.body.name || null,
      email : req.body.email  || null,
      email_verified_at : emailVerifyTime || null,
      verification_code : req.body.verification_code || null,
      new_email_verificiation_code : req.body.new_email_verificiation_code || null,
      password : hashedPassword || null,
      remember_token : req.body.remember_token || null,
      device_token : req.body.device_token || null,
      avatar : avatar || null,
      avatar_original : req.body.avatar_original || null,
      address : req.body.address || null,
      country : req.body.country || null,
      state	 : req.body.state || null,
      city : req.body.city || null,
      postal_code : req.body.postal_code || null,
      phone : req.body.phone || null,
      balance : req.body.balance || null,
      banned : req.body.banned || null,
      referral_code : req.body.referral_code || null,
      customer_package_id : req.body.customer_package_id || null,
      remaining_uploads : req.body.remaining_uploads || null,
    });
  
    let userId = req.params.id
    let nameId = req.body.name;
    let addressId =  req.body.address;
    let phoneId =  req.body.phone;

    SellerUsers.putSellerUser (req.params.id, users, (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(404).send({
            message: `Not found seller User with id ${req.params.id}.`
          });
        }
      }
      else {

        if (req.files.avatar) {
          
          const currentPath = path.join(process.cwd(), "uploads", req.files.avatar[0]["filename"]);
          const destinationPath = path.join(process.cwd(), "/uploads/users/avatar/" + `${userId}`, avatar);
          const baseUrl = process.cwd() + '/uploads/users/avatar/' + `${userId}`
          fs.mkdirSync(baseUrl, { recursive: true })
          fs.rename(currentPath, destinationPath, function (err) {
            if (err) {
              throw err
            } else {
              console.log("Successfully moved the avatar seller User files !")
            }
          });
        }

        const shops = new ShopDetails({
          user_id : userId || null,
          name : nameId || null,
          logo : req.body.logo || null,
          sliders : req.body.sliders || null,
          phone : phoneId || null,
          address : addressId || null,
          rating : req.body.rating || null,
          num_of_reviews : req.body.num_of_reviews || null,
          num_of_sale : req.body.num_of_sale || null,
          seller_package_id : req.body.seller_package_id || null,
          product_upload_limit : req.body.product_upload_limit || null,
          package_invalid_at : req.body.package_invalid_at || null,
          verification_status : req.body.verification_status || null,
          verification_info : req.body.verification_info || null,
          cash_on_delivery_status : req.body.cash_on_delivery_status || null,
          admin_to_pay : req.body.admin_to_pay || null,
          facebook : req.body.facebook || null,
          instagram : req.body.instagram || null,
          google : req.body.google || null,
          twitter : req.body.twitter || null,
          youtube : req.body.youtube || null,
          slug : req.body.slug || null,
          meta_title : req.body.meta_title || null,
          meta_description : req.body.meta_description || null,
          pick_up_point_id : req.body.pick_up_point_id || null,
          shipping_cost : req.body.shipping_cost || null,
          delivery_pickup_latitude : req.body.delivery_pickup_latitude || null,
          delivery_pickup_longitude : req.body.delivery_pickup_longitude || null,
          bank_name : req.body.bank_name || null,
          bank_acc_name : req.body.bank_acc_name || null,
          bank_acc_no : req.body.bank_acc_no || null,
          bank_routing_no : req.body.bank_routing_no || null,
          bank_payment_status : req.body.bank_payment_status  || null,	
      });

          let ratingId = req.body.rating || null
          let NoOfReviews = req.body.num_of_reviews || null
          let NoOfSale = req.body.num_of_sale || null
          let verifyStatus = req.body.verification_status || null
          let verifyInfo = req.body.verification_info || null
          let Cod = req.body.cash_on_delivery_status || null;
          let bankName = req.body.bank_name || null;
          let bankAccName =  req.body.bank_acc_name || null;
          let bankAccNo =  req.body.bank_acc_no || null;
          let bankRouteNo =  req.body.bank_routing_no || null;
          let adminToPay = req.body.admin_to_pay || null;
          let paymentStatus = req.body.admin_to_pay || null;

        const sellers = new Sellers({
          user_id: userId  || null ,
          rating: ratingId  || null ,
          num_of_reviews: NoOfReviews || null ,
          num_of_sale: NoOfSale || null ,
          verification_status: verifyStatus  || null ,
          verification_info: verifyInfo || null ,
          cash_on_delivery_status: Cod  || null ,
          admin_to_pay: adminToPay  || null ,
          bank_name: bankName || null ,
          bank_acc_name: bankAccName || null ,
          bank_acc_no: bankAccNo || null ,
          bank_routing_no: bankRouteNo || null ,
          bank_payment_status:paymentStatus || null ,
      });

      ShopDetails.putProfilePayment (req.params.id, shops, (err, data) => {
        if (err) {
          if (err.kind === "not_found") {
            res.status(404).send({
              message: `Not found profile payment with id ${req.params.id}.`
            });
          }
        }
      });

      Sellers.putSeller (req.params.id, sellers, (err, data) => {
        if (err) {
          if (err.kind === "not_found") {
            res.status(404).send({
              message: `Not found sellers with id ${req.params.id}.`
            });
          }
        }
      });
    
        res.statusCode = 200;
        res.send("Seller User updated Succesfully");
      }
  });
 }
});


exports.putSellerProfile = (async(req, res) => {

  const email_verify_time = req.body.email_verified_at
  let emailVerifyTime = ""
  if (email_verify_time) {
    let start = dayjs(req.body.email_verified_at);
    emailVerifyTime = start.format("YYYY-MM-DD")
  } else {
    emailVerifyTime = " "
  }

  if (!req.body) {
    res.status(400).send({
      message: "User Cannot be Empty"
    });
  }

  const query1 = util.promisify(sql.query).bind(sql);
  const executivesFetch = await query1(`select email from users where email='${req.body.email}' limit 1`);
  const executives = executivesFetch[0] ? executivesFetch[0]["exec"] : 0
  
  if(executives != 0){
    res.send("Email already exists");
  }
  else {
  let avatar = "";

  if (req.files.avatar) {
    const extension = req.files.avatar[0]["mimetype"].split('/')[1]
    avatar = req.files.avatar[0]["filename"] + '.' + extension
    avatar_original = req.files.avatar[0]["originalname"]
  }

  const users = new SellerUsers({
    id: req.body.id || null,
    name : req.body.name || null,
    email : req.body.email  || null,
    password : req.body.password || null,
    avatar : avatar || null,
    avatar_original : req.body.avatar_original || null,
    phone : req.body.phone || null
  });

  let userId = req.params.id

  SellerUsers.putSellerProfile (req.params.id, users, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found seller User with id ${req.params.id}.`
        });
      }
    }
    else {

      if (req.files.avatar) {
        
        const currentPath = path.join(process.cwd(), "uploads", req.files.avatar[0]["filename"]);
        const destinationPath = path.join(process.cwd(), "/uploads/users/avatar/" + `${userId}`, avatar);
        const baseUrl = process.cwd() + '/uploads/users/avatar/' + `${userId}`
        fs.mkdirSync(baseUrl, { recursive: true })
        fs.rename(currentPath, destinationPath, function (err) {
          if (err) {
            throw err
          } else {
            console.log("Successfully moved the avatar seller User files !")
          }
        });
      }
      res.statusCode = 200;
      res.send("Sellers User updated Succesfully");
    }
});
}
});

  exports.getSellerUserID = (req, res) => {
    SellerUsers.getSellerUserID(req.params.id, (err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
    else res.send(data);
  });
};

exports.deleteSellerUser = (req, res) => {
  SellerUsers.deleteSellerUser ( req.params.id, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found seller User with id ${req.params.id}.`
        });
      }
    }
    else {
      res.statusCode = 200;
      res.send("Seller User deleted Succesfully");
    }
});
};
