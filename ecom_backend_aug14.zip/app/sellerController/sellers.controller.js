const Sellers = require("../sellerModels/sellers.models.js");

exports.getSellers  = (req, res) => {
    Sellers.getSellers ((err, data) => {
      if (err)
        res.status(500).send({
          message:
            err.message || "Some error occurred while retrieving data."
        });
      else res.send(data);
    });
  };

  exports.putSeller = (async(req, res) => {
  
    const seller = new Sellers({
      id: req.body.id || null,
      user_id: req.body.user_id || null,
      rating: req.body.rating || null,
      num_of_reviews: req.body.num_of_reviews || null,
      num_of_sale: req.body.num_of_sale || null,
      verification_status: req.body.verification_status || null,
      verification_info: req.body.verification_info || null,
      cash_on_delivery_status: req.body.cash_on_delivery_status || null,
      admin_to_pay: req.body.admin_to_pay || null,
      bank_name: req.body.bank_name || null,
      bank_acc_name: req.body.bank_acc_name || null,
      bank_acc_no: req.body.bank_acc_no || null,
      bank_routing_no: req.body.bank_routing_no || null,
      bank_payment_status: req.body.bank_payment_status || null,
    });
  
    Sellers.putSeller (req.params.id, seller, (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(404).send({
            message: `Not found sellers with id ${req.params.id}.`
          });
        }
      }
      else {
  
        res.statusCode = 200;
        res.send("Sellers updated Succesfully");
      }
  });
  }
  );
  