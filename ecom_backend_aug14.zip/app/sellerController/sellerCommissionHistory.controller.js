const CommissionHistory = require("../sellerModels/sellerCommissionHistory.models.js");

exports.getSellerCommissionHistoryID = (req, res) => {
  CommissionHistory.getSellerCommissionHistoryID(req.params.seller_id, req.query, (err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
    else res.send(data);
  });
};