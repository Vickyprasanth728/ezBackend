const SellerCoupons = require("../sellerModels/sellerCoupons.models.js");
const SellerCouponUsage = require("../sellerModels/sellerCouponsUsage.models.js");
const path = require("path");
const fs = require("fs");

exports.getSellerCoupons = (req, res) => {
    SellerCoupons.getSellerCoupons (req.params.user_id, (err, data) => {
      if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
      else res.send(data);
    });
  };

  exports.saveSellerCoupon = (req, res) => {
    const coupons = new SellerCoupons({
      id : req.body.id,
      user_id : req.body.user_id,
      type : req.body.type,
      code : req.body.code,
      details : req.body.details,
      discount : req.body.discount,
      discount_type : req.body.discount_type,
      start_date : req.body.start_date,
      end_date : req.body.end_date,
    });
  
    SellerCoupons.saveSellerCoupon( coupons, (err, data) => {
      if (err) {
        console.log(err)
        res.status(500).send({
          message:
            err.message || "Some error occurred while posting Coupons ."
        });
      }
      else {

        let couponId = data.insertId
        let userId = req.body.user_id

        const couponUsage = new SellerCouponUsage({
          user_id : userId,
          coupon_id : couponId,
        });
  
        SellerCouponUsage.saveSellerCouponUsage(couponUsage, (err, data) => {
          if (err) {
            console.log(err)
            console.log("Coupon Usage posted successfully");
            console.log("Posted Successfully");
            res.statusCode = 200;
          }
        });

        console.log("Posted Successfully");
        res.status(200).send({
          message: "Posted Successfully",
          output: data
        })
      }
    });
  };

  exports.putSellerCoupon = (req, res) => {

    const sellerCoupons = new SellerCoupons({
      id: req.body.id || null ,
      user_id : req.body.user_id,
      type : req.body.type,
      code : req.body.code,
      details : req.body.details,
      discount : req.body.discount,
      discount_type : req.body.discount_type,
      start_date : req.body.start_date,
      end_date : req.body.end_date,
    });
  
    let couponId = req.params.id
    let userId = req.body.user_id

    SellerCoupons.putSellerCoupon (req.params.id, sellerCoupons, (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(404).send({
            message: `Not found seller coupons with id ${req.params.id}.`
          });
        }
      }
      else {

        const sellerCouponUsage = new SellerCouponUsage({
          user_id : userId || null,
          coupon_id : couponId || null,
        });

        SellerCouponUsage.putSellerCouponUsage (couponId , sellerCouponUsage, (err, data) => {
          if (err) {
            if (err.kind === "not_found") {
              res.status(404).send({
                message: `Not found with coupon id ${couponId}.`
              });
            }
          }
        })

        res.statusCode = 200;
        res.send("Seller Coupons updated Succesfully");
      }
  });
  };
  
  exports.getSellerCouponID = (req, res) => {
    SellerCoupons.getSellerCouponID(req.params.id, (err, data) => {
      if (err)
        res.status(500).send({
          message:
            err.message || "Some error occurred while retrieving data."
        });
      else res.send(data);
    });
  };

  exports.deleteSellerCoupon = (req, res) => {
    SellerCoupons.deleteSellerCoupon ( req.params.id, (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(404).send({
            message: `Not found couponId with id ${req.params.id}.`
          });
        }
      }
      else {
        res.statusCode = 200;
        res.send("Seller Coupon deleted Succesfully");
      }
  });
};