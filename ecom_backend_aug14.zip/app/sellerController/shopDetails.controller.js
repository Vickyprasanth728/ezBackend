const ShopDetails = require("../sellerModels/shopDetails.models.js");
const fs = require("fs")
const dayjs = require('dayjs');
const path = require("path");


// Products
exports.getShopDetails = (req, res) => {
    ShopDetails.getShopDetails(req.params.user_id,(err, data) => {
      if (err)
        res.status(500).send({
          message:
            err.message || "Some error occurred while retrieving data."
        });
      else res.send(data);
    });
  };

  exports.saveShopDetail = (req, res) => {

    let logo = "" ;
    let sliders = "" ;

    if (req.files.logo) {
      const extension = req.files.logo[0]["mimetype"].split('/')[1]
      logo = req.files.logo[0]["filename"] + '.' + extension
      logo = req.files.logo[0]["originalname"]
    }
    if (req.files.sliders) {
      const extension = req.files.sliders[0]["mimetype"].split('/')[1]
      sliders = req.files.sliders[0]["filename"] + '.' + extension
      sliders = req.files.sliders[0]["originalname"]
    }

    const shops = new ShopDetails({
        id : req.body.id,
        user_id : req.body.user_id,
        name : req.body.name,
        logo : logo,
        sliders : sliders,
        phone : req.body.phone,
        address : req.body.address,
        rating : req.body.rating,
        num_of_reviews : req.body.num_of_reviews,
        num_of_sale : req.body.num_of_sale,
        seller_package_id : req.body.seller_package_id,
        product_upload_limit : req.body.product_upload_limit,
        package_invalid_at : req.body.package_invalid_at,
        verification_status : req.body.verification_status,
        verification_info : req.body.verification_info,
        cash_on_delivery_status : req.body.cash_on_delivery_status,
        admin_to_pay : req.body.admin_to_pay,
        facebook : req.body.facebook,
        instagram : req.body.instagram,
        google : req.body.google,
        twitter : req.body.twitter,
        youtube : req.body.youtube,
        slug : req.body.slug,
        meta_title : req.body.meta_title,
        meta_description : req.body.meta_description,
        pick_up_point_id : req.body.pick_up_point_id,
        shipping_cost : req.body.shipping_cost,
        delivery_pickup_latitude : req.body.delivery_pickup_latitude,
        delivery_pickup_longitude : req.body.delivery_pickup_longitude,
        bank_name : req.body.bank_name,
        bank_acc_name : req.body.bank_acc_name,
        bank_acc_no : req.body.bank_acc_no,
        bank_routing_no : req.body.bank_routing_no,
        bank_payment_status : req.body.bank_payment_status	
   });
  
   ShopDetails.saveShopDetail ( shops, (err, data) => {
      if (err) {
        console.log(err)
        res.status(500).send({
          message:
            err.message || "Some error occurred while posting shop details ."
        });
      }
      else {

        let shopId = data.insertId

        if (req.files.logo) {
          
          const currentPath = path.join(process.cwd(), "uploads", req.files.logo[0]["filename"]);
          const destinationPath = path.join(process.cwd(), "/uploads/shops/logo/" + `${shopId}`, logo);
          const baseUrl = process.cwd() + '/uploads/shops/logo/' + `${shopId}`
          fs.mkdirSync(baseUrl, { recursive: true })
          fs.rename(currentPath, destinationPath, function (err) {
            if (err) {
              throw err
            } else {
              console.log("Successfully moved the logo files !")
            }
          });
        }
        if (req.files.sliders) {
          
          const currentPath = path.join(process.cwd(), "uploads", req.files.sliders[0]["filename"]);
          const destinationPath = path.join(process.cwd(), "/uploads/shops/sliders/" + `${shopId}`, sliders);
          const baseUrl = process.cwd() + '/uploads/shops/sliders/' + `${shopId}`
          fs.mkdirSync(baseUrl, { recursive: true })
          fs.rename(currentPath, destinationPath, function (err) {
            if (err) {
              throw err
            } else {
              console.log("Successfully moved the sliders files !")
            }
          });
        }
        console.log("Posted Successfully");
        res.status(200).send({
        message: "Posted Successfully",
        output: data
        })
      }
    });
  };

  exports.putShopDetail = (req, res) => {

    let logo = "" ;
    let sliders = "" ;

    if (req.files.logo) {
      const extension = req.files.logo[0]["mimetype"].split('/')[1]
      logo = req.files.logo[0]["filename"] + '.' + extension
      logo = req.files.logo[0]["originalname"]
    }
    if (req.files.sliders) {
      const extension = req.files.sliders[0]["mimetype"].split('/')[1]
      sliders = req.files.sliders[0]["filename"] + '.' + extension
      sliders = req.files.sliders[0]["originalname"]
    }

    const shops = new ShopDetails({
        id :req.body.id || null,
        user_id : req.body.user_id || null,
        name : req.body.name || null,
        logo : logo || null,
        sliders : sliders || null,
        phone : req.body.phone || null,
        address : req.body.address || null,
        rating : req.body.rating || null,
        num_of_reviews : req.body.num_of_reviews || null,
        num_of_sale : req.body.num_of_sale || null,
        seller_package_id : req.body.seller_package_id || null,
        product_upload_limit : req.body.product_upload_limit || null,
        package_invalid_at : req.body.package_invalid_at || null,
        verification_status : req.body.verification_status || null,
        verification_info : req.body.verification_info || null,
        cash_on_delivery_status : req.body.cash_on_delivery_status || null,
        admin_to_pay : req.body.admin_to_pay || null,
        facebook : req.body.facebook || null,
        instagram : req.body.instagram || null,
        google : req.body.google || null,
        twitter : req.body.twitter || null,
        youtube : req.body.youtube || null,
        slug : req.body.slug || null,
        meta_title : req.body.meta_title || null,
        meta_description : req.body.meta_description || null,
        pick_up_point_id : req.body.pick_up_point_id || null,
        shipping_cost : req.body.shipping_cost || null,
        delivery_pickup_latitude : req.body.delivery_pickup_latitude || null,
        delivery_pickup_longitude : req.body.delivery_pickup_longitude || null,
        bank_name : req.body.bank_name || null,
        bank_acc_name : req.body.bank_acc_name || null,
        bank_acc_no : req.body.bank_acc_no || null,
        bank_routing_no : req.body.bank_routing_no || null,
        bank_payment_status : req.body.bank_payment_status	
    });
  
    let shopId = req.params.id
    
    ShopDetails.putShopDetail (req.params.id, shops , (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(404).send({
            message: `Not found shops with id ${req.params.id}.`
          });
        }
      }
      else {

        if (req.files.logo) {
          
            const currentPath = path.join(process.cwd(), "uploads", req.files.logo[0]["filename"]);
            const destinationPath = path.join(process.cwd(), "/uploads/shops/logo/" + `${shopId}`, logo);
            const baseUrl = process.cwd() + '/uploads/shops/logo/' + `${shopId}`
            fs.mkdirSync(baseUrl, { recursive: true })
            fs.rename(currentPath, destinationPath, function (err) {
              if (err) {
                throw err
              } else {
                console.log("Successfully moved the logo files !")
              }
            });
          }

        if (req.files.sliders) {
          
            const currentPath = path.join(process.cwd(), "uploads", req.files.sliders[0]["filename"]);
            const destinationPath = path.join(process.cwd(), "/uploads/shops/sliders/" + `${shopId}`, sliders);
            const baseUrl = process.cwd() + '/uploads/shops/sliders/' + `${shopId}`
            fs.mkdirSync(baseUrl, { recursive: true })
            fs.rename(currentPath, destinationPath, function (err) {
              if (err) {
                throw err
              } else {
                console.log("Successfully moved the sliders files !")
              }
            });
          }
        res.statusCode = 200;
        res.send("Shop updated Succesfully");
      }
  });
  };

  exports.getShopDetailID = (req, res) => {
    ShopDetails.getShopDetailID(req.params.id, (err, data) => {
      if (err)
        res.status(500).send({
          message:
            err.message || "Some error occurred while retrieving data."
        });
      else res.send(data);
    });
  };