const SellerPayment = require("../sellerModels/sellerPayment.models.js");
const SellerMoneyWithdraw = require("../sellerModels/sellerMoneyWithdraw.models.js");

exports.getSellerPayment = (req, res) => {
    SellerPayment.getSellerPayment (req.params.seller_id, (err, data) => {
      if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
      else res.send(data);
    });
  };

  exports.getSellerMoneyWithdraw = (req, res) => {
    SellerMoneyWithdraw.getSellerMoneyWithdraw (req.params.user_id, (err, data) => {
      if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
      else res.send(data);
    });
  };

  exports.saveSellerMoneyWithdraw = (req, res) => {
    const withdraw = new SellerMoneyWithdraw({
      id : req.body.id,
      user_id : req.body.user_id,
      amount : req.body.amount,
      message : req.body.message,
      status : req.body.status,
      viewed : req.body.viewed,
    });
  
    SellerMoneyWithdraw.saveSellerMoneyWithdraw( withdraw, (err, data) => {
      if (err) {
        console.log(err)
        res.status(500).send({
          message:
            err.message || "Some error occurred while posting money withdraw ."
        });
      }
      else {

        // let sellerId = data.insertId;
        // let amount = req.body.amount;

        // const payment = new SellerPayment ({
        //     seller_id : sellerId,
        //     amount : amount,
        //     payment_details : req.body.payment_details,
        //     payment_method : req.body.payment_method,
        //     txn_code : req.body.txn_code,
        // });
        
        // SellerPayment.saveSellerPayment (payment, (err, data) => {
        //     if (err) {
        //       console.log(err)
        //       console.log("Seller Ticket reply posted successfully");
        //       console.log("Posted Successfully");
        //       res.statusCode = 200;
        //     }
        // });

          console.log("Posted Successfully");
          res.status(200).send({
          message: "Posted Successfully",
          output: data
        })
      }
    });
  };
