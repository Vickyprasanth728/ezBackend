const SellerDashboard = require("../sellerModels/sellerDashboard.models.js");

exports.getSellerDashboard = (req, res) => {
  SellerDashboard.getSellerDashboard (req.params.keyword, req.params.user_id, (err, data) => {
      if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
      else res.send(data);
    });
  };